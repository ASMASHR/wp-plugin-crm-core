<?php

function searchbox_shortcode() {
    ob_start();
    ?>
    <div class="searchbox-container">
        <input type="text" id="user-searchbox" class="searchbox" placeholder="Rechercher..." tabindex="1" />
        <div id="search-results" class="searchbox-result" style="display: none; border: 1px solid #ccc; position: absolute; background: #fff;"></div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const searchBox = document.getElementById('user-searchbox');
            const resultsDiv = document.getElementById('search-results');
            let currentIndex = -1; // Current focused index

            searchBox.addEventListener('input', function() {
                const query = searchBox.value.trim();

                if (query.length < 3) {
                    resultsDiv.style.display = 'none';
                    return;
                }

                fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=user_search&query=' + encodeURIComponent(query))
                    .then(response => response.json())
                    .then(data => {
                        let resultsHtml = '';
                        data.forEach(result => {
                            resultsHtml += '<div class="result-item" tabindex="-1">' + result + '</div>';
                        });
                        resultsDiv.innerHTML = resultsHtml;
                        resultsDiv.style.display = resultsHtml ? 'block' : 'none';
                        currentIndex = -1; // Reset index
                    });
            });

            document.addEventListener('click', function(event) {
                if (!searchBox.contains(event.target) && !resultsDiv.contains(event.target)) {
                    resultsDiv.style.display = 'none';
                    resultsDiv.innerHTML = '';
                    searchBox.value = ''; 
                }
            });

            document.addEventListener('keydown', function(event) {
                const items = resultsDiv.querySelectorAll('.result-item');
                if (resultsDiv.style.display === 'block' && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
                    event.preventDefault();
                    if (event.key === 'ArrowDown') {
                        currentIndex = (currentIndex + 1) % items.length;
                    } else if (event.key === 'ArrowUp') {
                        currentIndex = (currentIndex - 1 + items.length) % items.length;
                    }
                    items.forEach((item, index) => {
                        item.style.backgroundColor = index === currentIndex ? '#e0e0e0' : '#fff';
                    });
                }
                if (event.key === 'Enter' && currentIndex > -1) {
                    items[currentIndex].querySelector('a').click();
                }
            });
        });
    </script>
    <?php
    return ob_get_clean();
}

// [searchbox] shortcode
add_shortcode('searchbox', 'searchbox_shortcode');

// AJAX
add_action('wp_ajax_user_search', 'user_search_callback');
add_action('wp_ajax_nopriv_user_search', 'user_search_callback');
function user_search_callback() {
    $query = isset($_GET['query']) ? sanitize_text_field($_GET['query']) : '';

    if (strlen($query) < 3) {
        wp_send_json([]);
    }
    

    $args = [
        'number' => -1,
        'meta_query' => [
            [
                'key' => 'user_status',
                'value' => ['ACTIF', 'actif', 'active'],
                'compare' => 'IN',
            ],
        ],
        'role__in' => ['tiers', 'customer', 'prospect', 'non_qualifie', 'hors_cible']
    ];
    $user_query = new WP_User_Query($args);
    $users = $user_query->get_results();
	
    $filtered_users = array_filter($users, function($user) use ($query) {
		if (stripos($user->display_name, $query) !== false ||stripos($user->user_nicename, $query) !== false || stripos($user->user_email, $query) !== false) {
			return true;
		}
		$user_meta = get_user_meta($user->ID);
		foreach ($user_meta as $key => $values) {
			foreach ($values as $value) {
				if (stripos($value, $query) !== false) {
					return true;
				}
			}
		}

		return false;
	});
$filtered_users = array_slice($filtered_users, 0, 10);
 //wp_send_json_error(['count'=>count($users),'aaa'=>count($filtered_users),'filtered_users'=>$filtered_users]);
    $results = [];
    foreach ($filtered_users as $user) {
        $first_name = get_user_meta($user->ID, 'billing_first_name', true);
        $last_name = get_user_meta($user->ID, 'billing_last_name', true);
        $company_name = get_user_meta($user->ID, 'billing_company', true);
        $user_id_hash = generate_user_hash($user->ID);
        $profil_url = site_url('/crm-customer/'.$user_id_hash);

        $display = $first_name || $last_name ? "$first_name $last_name" : '';
        if ($company_name) {
            $display .= $display ? " : $company_name" : $company_name;
        }
        if ($display) {
            $results[] = '<a href="' . esc_url($profil_url) . '" class="result-link">' . esc_html($display) . '</a>';
        }
    }

    wp_send_json($results);
}

