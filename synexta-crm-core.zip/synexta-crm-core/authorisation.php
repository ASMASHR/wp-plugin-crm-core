<?php
// Vérifie ou crée la page de connexion
function check_or_create_login_page() {
    $page = get_page_by_path('login');
    if (!$page) {
        $admins = get_users(array('role' => 'administrator'));
        $admin_id = !empty($admins) ? $admins[0]->ID : 0;
        // Crée une nouvelle page 'Connexion' avec un shortcode [login].
        wp_insert_post(array(
            'post_title'   => 'Connexion',
            'post_name'    => 'login',
            'post_content' => '[login]', 
            'post_status'  => 'publish',
            'post_author'  => $admin_id,
            'post_type'    => 'page'
        ));
    }
}
// Vérifie ou crée la page pour définir un nouveau mot de passe.
function check_or_create_new_password_page() {
    $page = get_page_by_path('crm-password-send');
    if (!$page) {
        $admins = get_users(array('role' => 'administrator'));
        $admin_id = !empty($admins) ? $admins[0]->ID : 0;

        // Crée une page 'Connexion - nouveau mot de passe' avec un shortcode [custom_reset_password].
        wp_insert_post(array(
            'post_title'   => 'Connexion - génération mot de passe',
            'post_name'    => 'crm-password-send',
            'post_content' => '[custom_reset_password]', 
            'post_status'  => 'publish',
            'post_author'  => $admin_id,
            'post_type'    => 'page'
        ));
    }
}
// Vérifie ou crée la page pour réinitialiser le mot de passe.
function check_or_create_reset_password_page() {
    $page = get_page_by_path('crm-reset-request');
    if (!$page) {
        $admins = get_users(array('role' => 'administrator'));
        $admin_id = !empty($admins) ? $admins[0]->ID : 0;

        // Crée une page 'Réinitialisation de mot de passe' avec un shortcode [reset_password].
        wp_insert_post(array(
            'post_title'   => 'Re-initialisation mot de passe : demande',
            'post_name'    => 'crm-reset-request',
            'post_content' => '[reset_password]', 
            'post_status'  => 'publish',
            'post_author'  => $admin_id,
            'post_type'    => 'page'
        ));
    }
}
// Restreint l'accès au site pour les utilisateurs non connectés
function restrict_site_accessxxx() {
    if (is_page(array('crm-login', 'crm-reset-request','crm-password-send'))) {
        return; // Ne restreint pas ces pages
    }

    // Si l'utilisateur n'est pas connecté, redirige vers la page de connexion.
    if (!is_user_logged_in()) {
        check_or_create_login_page();
		//check_or_create_reset_password_page();
		//check_or_create_new_password_page();
		$url=$_SERVER['REQUEST_URI'];
        if (strpos($url, 'wp-login.php') === false) {
            // Vérifier si l'utilisateur est connecté
              if (!is_user_logged_in()) {
                wp_safe_redirect(home_url('/crm-login'));
                exit;
            }
        }
   
       // wp_safe_redirect(site_url('/login'));
        exit;
    } else {
        
        $user = wp_get_current_user();
        $allowed_roles = array('administrator', 'utilisateur_crm', 'responsable_crm','customer');

        if (!array_intersect($allowed_roles, $user->roles)) {
            wp_safe_redirect(site_url('/crm-login'));
            exit;
        }
    }
}
function restrict_site_access() {
    
    // Vérifiez si l'utilisateur est connecté et ajoutez un log
    $is_logged_in = is_user_logged_in();
    error_log('Utilisateur connecté: ' . ($is_logged_in ? 'Oui' : 'Non'));
    
    // Si l'utilisateur est sur la page de connexion, ne rien faire
    if (is_page(array('crm-login', 'crm-reset-request', 'crm-password-send'))) {
        return;
    }

    // Si l'utilisateur n'est pas connecté
    if (!is_user_logged_in()) { 
        wp_safe_redirect(home_url('/crm-login'));
            exit;
       
    }

    // Si l'utilisateur est connecté, vérifie les rôles
    $user = wp_get_current_user();
    $allowed_roles = array('administrator', 'utilisateur_crm', 'responsable_crm', 'customer');

    // Ajouter un log pour afficher les rôles de l'utilisateur connecté
    error_log('Rôles de l\'utilisateur connecté: ' . implode(', ', $user->roles));

    // Si l'utilisateur n'a pas les rôles autorisés, redirige vers la page de connexion
    if (!array_intersect($allowed_roles, $user->roles)) {
        error_log('Utilisateur non autorisé, redirection vers la page de login');
        wp_safe_redirect(site_url('/crm-login'));
        exit;
    }
}
add_action('template_redirect', 'restrict_site_access');



// Génère le formulaire de connexion via le shortcode [login].
function crm_login_shortcode($atts) {
    $atts = shortcode_atts(array(
        'url' => '',
    ), $atts, 'login');

    $output = '<div class="crm_login">';
    
    if (is_user_logged_in()) {
        $logout_url = wp_logout_url();
        $output .= '<a href="#" id="logout-link">Déconnexion</a>';
        
        // Ajouter un script pour gérer le logout en un clic
        $output .= '<script type="text/javascript">
            document.addEventListener("DOMContentLoaded", function() {
                document.getElementById("logout-link").addEventListener("click", function(e) {
                    e.preventDefault();
                    window.location.href = "' . esc_url($logout_url) . '";
                });
            });
        </script>';
    } else {
      
        // Si une erreur de connexion est définie, affiche un message d'erreur.
        
		if (isset($_SESSION['login_error'])) {
            $output .= '<p style="color: red; font-weight: bold;">' . $_SESSION['login_error'] . '</p>';
            unset($_SESSION['login_error']); 
        }
		unset($_SESSION['reset_key']);
	 	unset($_SESSION['reset_login']);
    

        $redirect_to = isset($_REQUEST['redirect_to']) ? $_REQUEST['redirect_to'] : home_url();
        // Affiche le formulaire de connexion.
        $output .= '<form method="post" action="' . esc_url(wp_login_url($redirect_to)) . '">';
        $output .= '<p><label for="user_login">Email :</label><input type="text" name="log" id="user_login" required></p>';
        $output .= '<p><label for="user_pass">Mot de passe :</label><input type="password" name="pwd" id="user_pass" required></p>';
        $output .= '<p><input type="submit" value="Connexion"></p>';
        $output .= '</form>';

        $output .= '<p><a href="' . esc_url(site_url('/crm-reset-request')) . '">Mot de passe oublié ?</a></p>';
    }

    $output .= '</div>';

    // Gère les redirections en fonction du rôle de l'utilisateur connecté.
    if (!empty($atts['url'])) {
        $urls = explode(' ', $atts['url']);
        $redirects = [];
        foreach ($urls as $url) {
            if (strpos($url, ':') !== false) {
                list($url_path, $role) = explode(':', $url);
                $redirects[trim($role)] = trim($url_path);
            } else {
                $redirects['default'] = trim($url);
            }
        }

        if (!empty($redirects)) {
            add_filter('login_redirect', function($redirect_to, $requested_redirect_to, $user) use ($redirects) {
                if (is_wp_error($user) || !$user) {
                    return $redirect_to;
                }

                $user_roles = $user->roles;
                foreach ($user_roles as $role) {
                    if (isset($redirects[$role])) {
                        return $redirects[$role];
                    }
                }

                return isset($redirects['default']) ? $redirects['default'] : $redirect_to;
            }, 10, 3);
        }
    }

    return $output;
}
add_shortcode('login', 'crm_login_shortcode');


// Ajoute un message d'erreur personnalisé lors de la connexion.
function custom_login_errors($errors, $redirect_to) {
    if (isset($_POST['log']) && isset($_POST['pwd'])) {
        $user = get_user_by('login', $_POST['log']);
        if (!$user) {
            $errors->add('invalid_username', 'Identifiant ou mot de passe incorrect.');
        }
    }
    return $errors;
}
add_filter('wp_login_errors', 'custom_login_errors', 10, 2);

// Démarre une session pour afficher les erreurs de connexion.
function start_session_for_login_error() {
    if (!session_id()) {
        session_start();
    }
}
add_action('init', 'start_session_for_login_error');

// Rediriger après la connexion en cas d'erreur
function redirect_on_login_error() {
   if (isset($_GET['login_error']) && $_GET['login_error'] == '1') {
        $_SESSION['login_error'] = 'Identifiant ou mot de passe incorrect.';
        wp_redirect(site_url('/crm-login'));
        exit;
    } 

}
add_action('login_form', 'redirect_on_login_error');



function redirect_wp_login() {
    error_log('Utilisateur connecté:heeer '.$_SERVER['REQUEST_METHOD'] );
  
    /*if (strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false && $_SERVER['REQUEST_URI'] !== '/login') {
        wp_redirect(site_url('/crm-login'));
        exit;
    }*/
	if ((strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false&&$_SERVER['REQUEST_METHOD']=="GET"&&!is_user_logged_in())||(strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false && strpos($_SERVER['REQUEST_URI'], 'wp-admin') !== false)) {
        wp_redirect(site_url('/crm-login'));
        exit;
    }
	

}
add_action('init', 'redirect_wp_login', 1);

// Redirection vers la page de connexion avec une erreur
function redirect_failed_login($username) {
    $login_url = wp_login_url(); 
    $login_url = add_query_arg('login_error', '1', $login_url); 
    wp_redirect($login_url); 
    exit;
}
add_action('wp_login_failed', 'redirect_failed_login');


///////////////// fin functions login 


// Shortcode [reset_password]
function crm_reset_password_shortcode() {
	
    if (is_user_logged_in()) {
        return '<p>Vous êtes djà connecté. <a href="' . esc_url(home_url()) . '">Retour à l’accueil</a>.</p>';
    }
    $message = '';
    $message_class = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_login'])) {
        $user_login = sanitize_text_field($_POST['user_login']);
        
        $user = get_user_by('email', $user_login) ?: get_user_by('login', $user_login);

        if ($user) {
            $email_sent = retrieve_password($user_login);

            if ($email_sent && !is_wp_error($email_sent)) {
                $login_url = site_url('/crm-login'); 
				$message = 'Mail envoyé. Vérifiez vos e-mails pour le lien de confirmation. Puis rendez-vous sur <a href="' . esc_url($login_url) . '">la page de connexion</a>.';
				$message_class = 'success';
            } else {
                $message = 'Une erreur s’est produite lors de lenvoi du lien de réinitialisation. Veuillez réessayer.';
                $message_class = 'error';
            }
        } else {
            $message = 'Aucun utilisateur trouvé avec cet identifiant ou e-mail.';
            $message_class = 'error';
        }
    }
    ob_start();
    if (!empty($message)) {
        echo '<p class="' . esc_attr($message_class) . '">' . wp_kses_post($message) . '</p>';
    }
	else{
		
    echo '<form method="post" action="">';
    echo wp_nonce_field('lostpassword', '_wpnonce', true, false);
    echo '<p>Merci de renseigner votre identifiant ou votre adresse e-mail. Vous recevrez un e-mail contenant les instructions vous permettant de réinitialiser votre mot de passe.</p>';
    echo '<p><label for="user_login">Email ou Nom d’utilisateur :</label>';
    echo '<input type="text" name="user_login" id="user_login" required></p>';
    echo '<p><input type="submit" value="Envoyer un lien de réinitialisation"></p>';
    echo '</form>';


	}
    return ob_get_clean();
}
add_shortcode('reset_password', 'crm_reset_password_shortcode');


function custom_password_reset_success_redirect($redirect_to) {
    return add_query_arg('status', 'password_reset', site_url('/crm-reset-request'));
}
add_filter('password_reset_redirect', 'custom_password_reset_success_redirect');


function custom_password_reset_redirect($redirect_to, $redirect_to_raw, $user) {
    return add_query_arg('status', 'email_sent', site_url('/crm-reset-request'));
}
add_filter('lostpassword_redirect', 'custom_password_reset_redirect', 10, 3);

//fin




//reset password mail &&  shortcode 

//Démarre une session pour les params de rénitialisations du mot de passe
add_action('init', function() {
    if (isset($_GET['key'], $_GET['login'])) {
        session_start();
        $_SESSION['reset_key'] = sanitize_text_field($_GET['key']);
        $_SESSION['reset_login'] = sanitize_text_field($_GET['login']);
        wp_redirect(site_url('/crm-password-send'));
        exit;
    }
});

// Ajoute un shortcode pour gérer la réinitialisation du mot de passe.
function custom_reset_password_form() {
    session_start();

    // Si un message de succès est défini, affichez-le.
    if (isset($_SESSION['success_message'])) {
        ob_start();
        echo '<div class="success-message" style="color: green; margin-bottom: 20px;">' . esc_html($_SESSION['success_message']) . '</div>';
        echo '<p><a href="' . esc_url(site_url('/crm-login')) . '">Retourner à la page de connexion</a></p>';
        unset($_SESSION['success_message']); // Supprimez le message après affichage.
        return ob_get_clean();
    }

    // Sinon, affichez le formulaire de réinitialisation.
    if (!isset($_SESSION['reset_key'], $_SESSION['reset_login'])) {
        return '<p>Le lien de réinitialisation est invalide.</p>';
    }
    $key = $_SESSION['reset_key'];
    $login = $_SESSION['reset_login'];

 	unset($_SESSION['reset_key']);
	 unset($_SESSION['reset_login']);
    ob_start();
    ?>
    <form name="resetpassform" id="resetpassform" action="<?php echo esc_url(site_url('/crm-password-send')); ?>" method="post" autocomplete="off">
        <input type="hidden" name="rp_key" value="<?php echo esc_attr($key); ?>">
        <input type="hidden" name="login" value="<?php echo esc_attr($login); ?>">

        <p>
            <label for="pass1">Nouveau mot de passe :</label>
            <div style="position: relative; display: inline-block;">
                <input type="password" name="pass1" id="pass1" class="input" size="20" autocomplete="new-password" style="padding-right: 30px;">
                <span id="toggle-password" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer;" aria-label="Afficher ou masquer le mot de passe">
                    👁️
                </span>
            </div>
        </p>

        <p class="description indicator-hint">
            Conseil&nbsp;: Le mot de passe devrait contenir au moins douze caractères. Pour le rendre plus sûr, utilisez des lettres en majuscules et minuscules, des nombres, et des symboles tels que ! " ? $ % ^ &amp; ).
        </p>

        <p class="submit reset-pass-submit">
            <button type="button" id="generate-password" class="button wp-generate-pw hide-if-no-js skip-aria-expanded">Générer un mot de passe</button>
            <input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Enregistrer le mot de passe">
        </p>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const generateButton = document.getElementById('generate-password');
            const pass1 = document.getElementById('pass1');
            const togglePassword = document.getElementById('toggle-password');

            // Génération de mot de passe
            generateButton.addEventListener('click', function() {
                function generatePassword(length) {
                    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
                    let password = "";
                    for (let i = 0; i < length; i++) {
                        password += charset.charAt(Math.floor(Math.random() * charset.length));
                    }
                    return password;
                }

                const newPassword = generatePassword(12);
                pass1.value = newPassword;
            });

            // Afficher/Masquer le mot de passe
            togglePassword.addEventListener('click', function() {
                const type = pass1.getAttribute('type') === 'password' ? 'text' : 'password';
                pass1.setAttribute('type', type);
                togglePassword.textContent = type === 'password' ? '👁️' : '🙈';
            });

            // Validation avant soumission
            document.getElementById('resetpassform').addEventListener('submit', function(e) {
                const password = pass1.value.trim();

                if (password.length < 12) {
                    e.preventDefault();
                    alert("Le mot de passe doit contenir au moins 12 caractères.");
                }
            });
        });
    </script>
    <?php
    return ob_get_clean();
}

add_shortcode('custom_reset_password', 'custom_reset_password_form');

// Gestion de la réinitialisation du mot de passe
add_action('init', function() {
    if (isset($_POST['rp_key'], $_POST['login'], $_POST['pass1'])) {
        $key = sanitize_text_field($_POST['rp_key']);
        $login = sanitize_text_field($_POST['login']);
        $new_password = $_POST['pass1'];

        $user = check_password_reset_key($key, $login);
        if (is_wp_error($user)) {
            wp_die('Lien de réinitialisation invalide.');
        }

        if (strlen($new_password) < 12) {
            wp_die('Le mot de passe doit contenir au moins 12 caractères.');
        }

        reset_password($user, $new_password);

        session_start();
        $_SESSION['success_message'] = 'Votre mot de passe a été réinitialisé avec succès. Vous pouvez maintenant vous connecter.';
        wp_redirect(site_url('/crm-password-send'));
        exit;
    }
});

//fin



// Fonction pour gérer la déconnexion personnalisée.
function custom_logout_redirect_after($redirect_to) {
 
    return site_url('/crm-login.php');
}
add_filter('logout_redirect', 'custom_logout_redirect_after');
//redirection si session expiré vers la page du connexion
function redirect_on_session_expired() {
    ?>
    <script>
        jQuery(document).ready(function($) {
            $(document).on('heartbeat-tick.wp-auth-check', function(event, data) {
                if (data['wp-auth-check'] === false) {
                    // Redirection vers la page de connexion
                    window.location.href = "<?php echo esc_url(wp_login_url()); ?>";
                }
            });
        });
    </script>
    <?php
}
add_action('admin_footer', 'redirect_on_session_expired');
add_action('wp_footer', 'redirect_on_session_expired'); // Pour le frontend
//redirection si session expiré à /login 
function custom_session_expired_redirect_with_message() {
    if (!is_user_logged_in()) {
        $redirect_url = '/crm-login';
        wp_redirect($redirect_url);
        exit;
    }
}
add_action('auth_redirect', 'custom_session_expired_redirect_with_message');
//deconnexion sans confirmation
add_action('init', function () {
    if (isset($_GET['action']) && $_GET['action'] === 'logout') {
        
        wp_logout();
        wp_redirect('/crm-login');
        exit;
    }
});


?>