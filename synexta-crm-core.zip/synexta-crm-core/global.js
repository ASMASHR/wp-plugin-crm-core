document.addEventListener("DOMContentLoaded", function() {
    const tables = document.querySelectorAll("table.crm-table");

    tables.forEach(table => {
        const headerRow = table.querySelector("thead tr");
        const headerCells = Array.from(headerRow.children);
        const tableBody = table.querySelector("tbody");
        if (!table.parentElement.classList.contains("crm-table-container")) {

            var tableContainer = document.createElement("div");
            tableContainer.classList.add("crm-table-container");
            table.parentNode.insertBefore(tableContainer, table);

            const filtersContainer = document.createElement("div");
            filtersContainer.classList.add("filters-container");
            const quickFilter = document.createElement("input");
            const errorContainer = document.createElement("div");
            quickFilter.setAttribute("type", "text");
            errorContainer.setAttribute("id", "msg-div-container");
            errorContainer.classList.add("msg-div-container");
            quickFilter.setAttribute("placeholder", "Recherche rapide");
            quickFilter.classList.add("quick-filter");
            //tableContainer.insertBefore(quickFilter, table);
            //tableContainer.insertBefore(errorContainer, table);
            ///

            // Ajout des filtres dans le conteneur
            filtersContainer.appendChild(quickFilter);



            // Insertion des éléments dans le DOM
            //table.parentNode.insertBefore(tableContainer, table);
            tableContainer.appendChild(filtersContainer);
            tableContainer.appendChild(table);

        } else {
            tableContainer = table.parentElement;
        }



        const applyFilter = function() {
            const rows = tableBody.querySelectorAll("tr");
            const filterValue = quickFilter.value.toLowerCase();
            rows.forEach(row => {
                const cells = Array.from(row.children);
                let rowVisible = false;
                cells.forEach(cell => {
                    const cellText = cell.textContent.toLowerCase();
                    if (cellText.includes(filterValue)) {
                        rowVisible = true;
                    }
                });
                row.style.display = rowVisible ? "" : "none";
            });

        };

        //quickFilter.addEventListener("input", applyFilter);


        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === "childList") {
                    applyFilter();
                }
            });
        });

        observer.observe(tableBody, { childList: true });

        const visibleColumns = [];
        let totalWidth = 0;
        const containerWidth = tableContainer.clientWidth - 20;
        headerCells.forEach((cell, cellIndex) => {
            const cellWidth = cell.offsetWidth;
            totalWidth += cellWidth;

            if (totalWidth <= containerWidth) {
                visibleColumns.push(cellIndex);
            }

            const cellText = cell.textContent.trim();
            if (cellText.indexOf(" ") === -1 && cellText.indexOf("-") === -1) {
                cell.classList.add("single-word");
            }
        });

        headerCells.forEach((cell, cellIndex) => {
            if (!visibleColumns.includes(cellIndex)) {
                cell.style.display = "none";
            }
        });

        const rows = tableBody.querySelectorAll("tr");
        rows.forEach((row, rowIndex) => {
            const cells = Array.from(row.children);
            const columnsToHide = [];

            cells.forEach((cell, cellIndex) => {
                if (!visibleColumns.includes(cellIndex)) {
                    columnsToHide.push(cellIndex);
                    cell.style.display = "none";
                }
            });

            if (columnsToHide.length > 0) {
                const toggleCell = document.createElement("td");
                toggleCell.innerHTML = "&#9660;";
                toggleCell.classList.add("toggle-cell");
                toggleCell.addEventListener("click", function() {
                    toggleHiddenColumns(row, columnsToHide, headerCells);
                });
                row.appendChild(toggleCell);
            }
        });
    });

    function toggleHiddenColumns(row, columnsToHide, headerCells) {
        let hiddenRow = row.nextElementSibling;
        if (hiddenRow && hiddenRow.classList.contains("hidden-row")) {
            hiddenRow.remove();
        } else {
            hiddenRow = document.createElement("tr");
            hiddenRow.classList.add("hidden-row");
            const cell = document.createElement("td");
            cell.colSpan = row.children.length;

            const hiddenColumnsContainer = document.createElement("div");
            hiddenColumnsContainer.classList.add("hidden-columns-container");
            columnsToHide.forEach(index => {
                const columnTitle = headerCells[index].textContent;
                const hiddenTd = row.children[index];
                const columnValue = hiddenTd.innerHTML;
                if (columnValue !== "") {
                    const columnElement = document.createElement("div");
                    columnElement.classList.add("hidden-column");
                    columnElement.innerHTML = `<strong>${columnTitle}:</strong> ${columnValue}`;
                    hiddenColumnsContainer.appendChild(columnElement);
                }
            });

            cell.appendChild(hiddenColumnsContainer);
            hiddenRow.appendChild(cell);
            row.parentNode.insertBefore(hiddenRow, row.nextSibling);
        }
    }
});


jQuery(document).ready(function($) {
    $(document).on('input', '#quick-filter', function() {

        var searchTerm = $(this).val();
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'filter_users',
                search: searchTerm
            },
            success: function(response) {
                $('#users-table-wrapper').html(response);
            }
        });
    });
});
document.addEventListener("DOMContentLoaded", function() {
    const table = document.querySelector(".connected-user table");
    const submenu = document.querySelector(".sousmenu");

    if (table && submenu) {
        table.addEventListener("mouseover", function() {
            submenu.style.display = "block";
        });

        table.addEventListener("mouseleave", function() {
            submenu.style.display = "none";
        });

        submenu.addEventListener("mouseover", function() {
            submenu.style.display = "block";
        });

        submenu.addEventListener("mouseleave", function() {
            submenu.style.display = "none";
        });
    }
});

jQuery(document).ready(function($) {
    $(".syn-core-start").on("click", function(e) {
        e.preventDefault();
        $(".syn-core-message").text("Début de la synchronisation...").show();

        $.ajax({
            url: ajax_object.ajax_url,
            type: "POST",
            data: {
                action: "sync_crm_vos_factures"
            },
            success: function(response) {
                if (response.success) {
                    $("body").append(`<div class="syn-core-synchro-modal" style="display:block;"><div class="syn-core-synchro-modal-content"><p>Synchronisation terminée !</p></div></div>`);

                    setTimeout(function() {
                        $(".syn-core-synchro-modal").fadeOut();
                        location.reload();
                    }, 3000);
                } else {
                    alert("Erreur : " + response.data.message);
                }
            },
            error: function() {
                alert("Une erreur est survenue lors de la synchronisation.");
            }
        });
    });
});