<?php
// Ce fichier contient les shortcodes et actions utilisés dans le CRM Synexta.
// Shortcodes disponibles :
// [info] - Affiche les informations de version et auteur du plugin.
// [current-user] - Affiche l'avatar et le nom de l'utilisateur connecté, avec options de sync si admin/responsable CRM.
// [connected_user] - Affiche le prénom, nom ou display name de l'utilisateur connecté.
// [current] - Affiche le nom de la société ou le nom/prénom du client actuel.
// [compte-id] - Affiche l'ID associé au compte VosFactures de l'utilisateur.
// Actions notables :
// Synchronisation manuelle des factures via l'API VosFactures avec [Démarrer synchro].
// Planification WP-Cron pour synchronisation quotidienne des factures.
// Option de forcer la synchronisation manuellement via URL (?force_sync).


function info_shortcode() {
    $plugin_file = plugin_dir_path(__FILE__) . 'synexta-crm.php';
    $plugin_data = get_plugin_data($plugin_file);
    $version = isset($plugin_data['Version']) ? $plugin_data['Version'] : '1.0.0';
    $year = date('Y');
    $output = '<div class="versioninfo">CRM v.' . esc_html($version) . ', (c)' . esc_html($year) . ' par <a href="https://synexta.fr" target="_blank">Synexta</a></div>';
    return $output;
}

function current_user_shortcode() {
    if (!is_user_logged_in()) {
        return '';
    }

    $current_user = wp_get_current_user();
    $user_rolesArr = $current_user->roles;
   $user_avatar = get_avatar($current_user->ID);
    $user_display_name = !empty($current_user->first_name) ? $current_user->first_name : $current_user->display_name;
    $user_roles = array_map(function($role) {
        return ucwords(str_replace('_', ' ', $role));
    }, $current_user->roles);
    $user_roles_display = implode(', ', $user_roles);


    $latest_invoice_date =  get_option('_vosfacture_last_sync')??null;
    

    $latest_invoice_date_formatted = $latest_invoice_date ? date('d/m H:i', strtotime($latest_invoice_date)) : '--';


    $output = '
    <div class="connected-user" style="position: relative;">
        <table>
            <tr>
                <td>' . $user_avatar . '</td>
                <td>
                    <span class="user">' . esc_html($user_display_name) . '</span>
                    <span class="droits">' . esc_html($user_roles_display) . '</span>
                </td>
            </tr>
        </table>
        <div class="sousmenu" style="display:none;">';
        if((in_array('administrator', $user_rolesArr)|| in_array('responsable_crm', $user_rolesArr))&& get_option('vosfactures_sync_enabled') === 'yes'){
            $output .= '
                <div class="syn-core-synchro-info">
                 <a href="#" class="syn-core-start">Démarrer synchro</a>
                <p class="syn-core-last-sync">Dernière synchro : ' . esc_html($latest_invoice_date_formatted) . '</p>
                
                <div class="syn-core-message" style="display:none;"></div>
                </div>';


        }
        
        if((in_array('administrator', $user_rolesArr)|| in_array('responsable_crm', $user_rolesArr)|| in_array('utilisateur_crm', $user_rolesArr))){
                $output .=crm_afficher_emails_restants();
        }

            $output .= '<a href="' . wp_logout_url() . '" class="logout">Déconnexion</a>';

            $output .= '
            </div>
        </div>
       ';
    
    return $output;
    
}

// display name of current connecter account

function connected_user_shortcode() {
    if (!is_user_logged_in()) {
        return '';
    }

    $current_user = wp_get_current_user();
    $first_name = $current_user->first_name;
    $last_name = $current_user->last_name;
    $display_name = $current_user->display_name;

    if (!empty($first_name)) {
        return esc_html($first_name);
    } elseif (!empty($last_name)) {
        return esc_html($last_name);
    } else {
        return esc_html($display_name);
    }
}

add_shortcode('connected_user', 'connected_user_shortcode');



// current displayed customer

function current_customer_shortcode() {
    if (!is_user_logged_in()) {
        return '<div class="current-customer-name">du client</div>';
    }

    $hashedId = get_hashed_id_from_url();
    $user_id = null;
    if ($hashedId) {
        $user_id = get_user_id_from_hash($hashedId);
    }

    if (!$user_id) {
        return '<div class="current-customer-name">du client</div>';
    }

    $nom_societe = get_user_meta($user_id, 'billing_company', true);
    $prenom = get_user_meta($user_id, 'billing_first_name', true);
    $nom = get_user_meta($user_id, 'billing_last_name', true);

    $output_content = $nom_societe ?: ($prenom || $nom ? "$prenom / $nom" : "du client");

    return '<span class="current-customer-name">' . esc_html($output_content) . '</span>';
}

// current user id a refaire
// [compte-id]

function compte_id_shortcode() {
    if (!is_user_logged_in()) {
        return '<div class="vosfactures-id">ID non disponible</div>';
    }

    $hashedId = get_hashed_id_from_url();
    $vosfactures_id = null;
    if ($hashedId) {
        $user_id = get_user_id_from_hash($hashedId); // Décoder le hash user_id 
    }

    if (!$user_id) {
        return '<div class="vosfactures-id">ID non disponible</div>';
    }
    
    $vosfactures_id = get_user_meta($user_id, 'vosfactures_id', true);

    return esc_html($user_id);
    // en fonction des cas user_id est l'ID du compte WORDPRESS et "vosfactures_id" la clé "identifiant vosfacture" associé à ce compte.
    // En fonction de ce qu'on veut faire on peut faire return de l'un ou de l'autre
}

add_shortcode('info', 'info_shortcode');
add_shortcode('current-user', 'current_user_shortcode');
add_shortcode('current', 'current_customer_shortcode');
add_shortcode('compte-id', 'compte_id_shortcode'); // Enregistre le nouveau shortcode
/*
 *Synchronise les factures en récupérant les données depuis l'API VosFactures manuellement en cliquant sur "Démarrer synchro".
 * 
 * - Récupère la date de la dernire facture enregistrée dans les métadonnées.
 * - Si aucune facture n'est trouvée, prend la date du jour.
 * - Définit la période de synchronisation : de 60 jours avant la dernière facture jusqu'à 14 jours après.
 * - Lance l'importation des factures sur cette période.
 */

function sync_crm_vos_factures() {

    $current_user = wp_get_current_user();
    $user_rolesArr = $current_user->roles;
    if((in_array('administrator', $user_rolesArr)|| in_array('responsable_crm', $user_rolesArr))&& get_option('vosfactures_sync_enabled') === 'yes'){
       
            global $wpdb;
            $latest_invoice_date = $wpdb->get_var("
            SELECT meta_value FROM {$wpdb->postmeta} 
            WHERE meta_key = '_vosfacture_issue_date' 
            ORDER BY meta_value DESC 
            LIMIT 1
        ");
        
       /* if (!$latest_invoice_date) {
            $latest_invoice_date = date('Y-m-d'); 
        }*/
        $latest_invoice_date = date('Y-m-d'); 
        
        $start_date = date('Y-m-d', strtotime("-60 days", strtotime($latest_invoice_date)));
        $end_date = date('Y-m-d', strtotime("+14 days", strtotime($latest_invoice_date))); 
        
        $imported_invoices = vosfactures_import_invoices($start_date, $end_date);
    
    


    wp_send_json_success(['message' => 'Synchronisation terminée','imported_invoices'=>$imported_invoices]);
 }
}

add_action('wp_ajax_sync_crm_vos_factures', 'sync_crm_vos_factures');

/**
 * Planifie une tâche WP-Cron pour synchroniser les factures une fois par jour.
 * 
 * - Vérifie si l'événement 'vosfactures_daily_sync' est déj programmé.
 * - Si ce n'est pas le cas, il est ajouté au cron pour s'exécuter tous les jours à minuit.
 */
function schedule_vosfactures_sync() {
    if (get_option('vosfactures_sync_enabled') === 'yes') {
        if (!wp_next_scheduled('vosfactures_daily_sync')) {
            wp_schedule_event(strtotime('midnight'), 'daily', 'vosfactures_daily_sync');
        }
    } else {
        wp_clear_scheduled_hook('vosfactures_daily_sync'); 
    }
}
add_action('wp', 'schedule_vosfactures_sync');

// Lier la tâche au cron
add_action('vosfactures_daily_sync', 'vosfactures_sync_invoices');
/**
 * Synchronise les factures en récupérant les données depuis l'API VosFactures.
 * 
 * - Récupère la date de la dernière facture enregistrée dans les métadonnées.
 * - Si aucune facture n'est trouvée, prend la date du jour.
 * - Définit la période de synchronisation : de 60 jours avant la dernière facture jusqu'à 14 jours après.
 * - Lance l'importation des factures sur cette période.
 */
function vosfactures_sync_invoices() {
    global $wpdb;

   /* $latest_invoice_date = $wpdb->get_var("
        SELECT meta_value FROM {$wpdb->postmeta} 
        WHERE meta_key = '_vosfacture_issue_date' 
        ORDER BY meta_value DESC 
        LIMIT 1
    ");

    if (!$latest_invoice_date) {
        $latest_invoice_date = date('Y-m-d');
    }*/
    $latest_invoice_date = date('Y-m-d'); 
       
    $start_date = date('Y-m-d', strtotime("-60 days", strtotime($latest_invoice_date)));
    $end_date = date('Y-m-d', strtotime("+14 days", strtotime($latest_invoice_date))); 
   
    vosfactures_import_invoices($start_date, $end_date);

}
/**
 * Permet d'exécuter manuellement la synchronisation en ajoutant ?force_sync dans l'URL.
 * 
 * Exemple : https://crm-dev.synexta.fr/?force_sync
 * 
 * - Exécute immédiatement la fonction vosfactures_sync_invoices().
 * - Affiche un message indiquant que la synchronisation a été effectuée.
 */
add_action('init', function() {
    if (isset($_GET['force_sync'])) {
        vosfactures_sync_invoices();
        echo "Synchronisation exécutée.";
        exit;
    }
});

/**
 * Ce shortcode affiche un bilan en temps réel des envois d’emails CRM effectués aujourd’hui et sur l’heure en cours, comparés aux quotas configurés dans l’administration.
 * Il indique :
 * ✅ Le nombre d’emails envoyés aujourd’hui et le quota quotidien restant
 * ✅ Le nombre d’emails envoyés sur l’heure actuelle et le quota horaire restant
 * 📊 Un indicateur de couleur dynamique (🟢 Vert, 🟠 Orange, 🔴 Rouge) selon le pourcentage utilisé :
 * Vert : Moins de 60% du quota utilisé
 * Orange : Entre 60% et 89%
 * Rouge : 90% ou plus utilisé
 * 🔧 Paramètres requis :
 * Les options suivantes doivent être configurées via update_option() ou une interface BO :
 * crm_email_daily_limit → limite d’emails par jour
 * crm_email_hourly_limit → limite d’emails par heure
 * crm_emails_sent_stats → tableau de logs contenant datetime pour chaque email envoyé


 */

function crm_afficher_emails_restants() {
    if (post_type_exists('crm_documents')) {
             $now_ts = current_time('timestamp');
    $today = date('Y-m-d', $now_ts);
    $current_hour = date('Y-m-d H', $now_ts);

    $email_stats = get_option('crm_emails_sent_stats', []);
    //echo var_dump($email_stats);
    $daily_limit = (int) get_option('crm_email_daily_limit', 0);
    $hourly_limit = (int) get_option('crm_email_hourly_limit', 0);

    if (!is_array($email_stats)) $email_stats = [];

    // Filtrage des 7 derniers jours
    $email_stats = array_filter($email_stats, function ($entry) use ($now_ts) {
        return isset($entry['datetime']) && strtotime($entry['datetime']) > ($now_ts - 7 * DAY_IN_SECONDS);
    });

    $emails_sent_today = 0;
    $emails_sent_this_hour = 0;

    foreach ($email_stats as $entry) {
        if (!isset($entry['datetime'])) continue;

        $entry_date = date('Y-m-d', strtotime($entry['datetime']));
        $entry_hour = date('Y-m-d H', strtotime($entry['datetime']));

        if ($entry_date === $today) $emails_sent_today++;
        if ($entry_hour === $current_hour) $emails_sent_this_hour++;
    }

    // Calculs
    $restant_jour = max(0, $daily_limit - $emails_sent_today);
    $restant_heure = max(0, $hourly_limit - $emails_sent_this_hour);

    // % utilisés
    $percent_day = $daily_limit > 0 ? round(($emails_sent_today / $daily_limit) * 100) : 0;
    $percent_hour = $hourly_limit > 0 ? round(($emails_sent_this_hour / $hourly_limit) * 100) : 0;

    // Couleurs : vert < 60%, orange < 90%, rouge sinon
    $get_color_class = function($percent) {
        if ($percent < 60) return 'vert';
        if ($percent < 90) return 'orange';
        return 'rouge';
    };

    $class_day = $get_color_class($percent_day);
    $class_hour = $get_color_class($percent_hour);

    // Affichage HTML
    ob_start(); ?>
    <style>
        .crm-email-limits p, .crm-email-limits li { margin: 5px 0;
        font-size:12px !important; }
        .crm-email-limits .vert { color: green; font-weight: bold; }
        .crm-email-limits .orange { color: darkorange; font-weight: bold; }
        .crm-email-limits .rouge { color: red; font-weight: bold; }
    </style>
    <div class="crm-email-limits"style="display:none">
        <p><strong>📨 Suivi des envois d’emails</strong></p>
        <ul>
            <li>📆 Limite journalière : <strong><?php echo $daily_limit; ?></strong></li>
            <li>⏰ Limite horaire : <strong><?php echo $hourly_limit; ?></strong></li>
        </ul>
        <p>📅 Aujourd’hui : <span class="<?php echo $class_day; ?>">
            <?php echo "$emails_sent_today envoyés / $daily_limit max (" . $percent_day . "%) → $restant_jour restants"; ?>
        </span></p>
        <p>🕒 Cette heure : <span class="<?php echo $class_hour; ?>">
            <?php echo "$emails_sent_this_hour envoyés / $hourly_limit max (" . $percent_hour . "%) → $restant_heure restants"; ?>
        </span></p>
    </div>
    <div class="crm-email-limits">
        <p><strong>📨 Suivi emails</strong></p>
        <p>📅 Aujourd’hui : <span class="<?php echo $class_day; ?>">
            <?php echo "→ $restant_jour restants"; ?>
        </span></p>
        <p>🕒 Cette heure : <span class="<?php echo $class_hour; ?>">
            <?php echo " → $restant_heure restants"; ?>
        </span></p>
    </div>
    <?php
    return ob_get_clean();
        }
    else{
        return '';
    }
}

function searchbox_shortcode() {
    ob_start();
    ?>
    <div class="searchbox-container">
        <input type="text" id="user-searchbox" class="searchbox" placeholder="Rechercher..." tabindex="1" />
        <div id="search-results" class="searchbox-result" style="display: none; border: 1px solid #ccc; position: absolute; background: #fff;"></div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const searchBox = document.getElementById('user-searchbox');
            const resultsDiv = document.getElementById('search-results');
            let currentIndex = -1; // Current focused index

            searchBox.addEventListener('input', function() {
                const query = searchBox.value.trim();

                if (query.length < 3) {
                    resultsDiv.style.display = 'none';
                    return;
                }

                fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=user_search&query=' + encodeURIComponent(query))
                    .then(response => response.json())
                    .then(data => {
                        let resultsHtml = '';
                        data.forEach(result => {
                            resultsHtml += '<div class="result-item" tabindex="-1">' + result + '</div>';
                        });
                        resultsDiv.innerHTML = resultsHtml;
                        resultsDiv.style.display = resultsHtml ? 'block' : 'none';
                        currentIndex = -1; // Reset index
                    });
            });

            document.addEventListener('click', function(event) {
                if (!searchBox.contains(event.target) && !resultsDiv.contains(event.target)) {
                    resultsDiv.style.display = 'none';
                    resultsDiv.innerHTML = '';
                    searchBox.value = ''; 
                }
            });

            document.addEventListener('keydown', function(event) {
                const items = resultsDiv.querySelectorAll('.result-item');
                if (resultsDiv.style.display === 'block' && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
                    event.preventDefault();
                    if (event.key === 'ArrowDown') {
                        currentIndex = (currentIndex + 1) % items.length;
                    } else if (event.key === 'ArrowUp') {
                        currentIndex = (currentIndex - 1 + items.length) % items.length;
                    }
                    items.forEach((item, index) => {
                        item.style.backgroundColor = index === currentIndex ? '#e0e0e0' : '#fff';
                    });
                }
                if (event.key === 'Enter' && currentIndex > -1) {
                    items[currentIndex].querySelector('a').click();
                }
            });
        });
    </script>
    <?php
    return ob_get_clean();
}

// [searchbox] shortcode
add_shortcode('searchbox', 'searchbox_shortcode');

// AJAX
add_action('wp_ajax_user_search', 'user_search_callback');
add_action('wp_ajax_nopriv_user_search', 'user_search_callback');
function user_search_callback() {
    $query = isset($_GET['query']) ? sanitize_text_field($_GET['query']) : '';

    if (strlen($query) < 3) {
        wp_send_json([]);
    }
    

    $args = [
        'number' => -1,
        'meta_query' => [
            [
                'key' => 'user_status',
                'value' => ['ACTIF', 'actif', 'active'],
                'compare' => 'IN',
            ],
        ],
        'role__in' => ['tiers', 'customer', 'prospect', 'non_qualifie', 'hors_cible']
    ];
    $user_query = new WP_User_Query($args);
    $users = $user_query->get_results();
	
    $filtered_users = array_filter($users, function($user) use ($query) {
		if (stripos($user->display_name, $query) !== false ||stripos($user->user_nicename, $query) !== false || stripos($user->user_email, $query) !== false) {
			return true;
		}
		$user_meta = get_user_meta($user->ID);
		foreach ($user_meta as $key => $values) {
			foreach ($values as $value) {
				if (stripos($value, $query) !== false) {
					return true;
				}
			}
		}

		return false;
	});
    $filtered_users = array_slice($filtered_users, 0, 10);
    //wp_send_json_error(['count'=>count($users),'aaa'=>count($filtered_users),'filtered_users'=>$filtered_users]);
    $results = [];
    foreach ($filtered_users as $user) {
        $first_name = get_user_meta($user->ID, 'billing_first_name', true);
        $last_name = get_user_meta($user->ID, 'billing_last_name', true);
        $company_name = get_user_meta($user->ID, 'billing_company', true);
        $user_id_hash = generate_user_hash($user->ID);
        $profil_url = site_url('/crm-customer/'.$user_id_hash);

        $display = $first_name || $last_name ? "$first_name $last_name" : '';
        if ($company_name) {
            $display .= $display ? " : $company_name" : $company_name;
        }
        if ($display) {
            $results[] = '<a href="' . esc_url($profil_url) . '" class="result-link">' . esc_html($display) . '</a>';
        }
    }

    wp_send_json($results);
}
