<?php


function event_documents_shortcode($atts) {
    global $wpdb;
    $current_user = wp_get_current_user(); 

    $atts = shortcode_atts([
        'tags' => '',
        'count' => 10,  
    ], $atts, 'crm_list_evenements');

    $author_id = get_current_user_id();
    $user_roles = $current_user->roles;
    wp_enqueue_script('shortcode-list-events-js', plugin_dir_url(__FILE__) . 'shortcode_crm_list_evenements.js', array(), '1.0', true);
    //wp_enqueue_style('shortcode-list-events-css', plugin_dir_url(__FILE__) . 'shortcodes.css', array(), '1.0', true);
    wp_enqueue_style('shortcode-list-logs-css', plugin_dir_url(__FILE__) . '../../global.css', array(), '1.0', true);
   
    wp_enqueue_script('shortcode-list-events-data-table-js', plugin_dir_url(__FILE__) . '../../assets/js/jquery.dataTables.js', array(), '1.0', true);
    wp_enqueue_script('shortcod-list-events-data-table-responsive-js', plugin_dir_url(__FILE__) . '../../assets/js/dataTables.responsive.min.js', array(), '1.0', true);
    wp_enqueue_style('shortcode-list-events-data-table-css', plugin_dir_url(__FILE__) . '../../assets/styles/jquery.dataTables.css', array(), '1.0', 'all');
    wp_enqueue_style('shortcode-list-events-data-table-responsive-css', plugin_dir_url(__FILE__) . '../../assets/styles/responsive.dataTables.min.css', array(), '1.0', 'all');
    
  
    $searchIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/recherche.svg';
    $args = [
        'post_type' =>  'crm_docs_gen',
        'posts_per_page' => -1,
        'meta_query' => []
    ];
    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_event_tags';
    $tags = $wpdb->get_results("SELECT * FROM $table_name WHERE status = 1");


 
    $class_names = [];

        
    $tags_filter = [];
    

    $query = new WP_Query($args);
    $all_posts=$query->posts;
    $self_events=[];
    $other_events=[];
    foreach ($all_posts as $post) {
        if ($post->post_author == $author_id) {
            $self_events[] = $post;
        } 
        else {
            if (in_array('administrator', $user_roles) || in_array('responsable_crm', $user_roles)) {
       
            $other_events[] = $post;
        }

        }
    }
    //tags="a faire"
    $filtered_self_posts=[];
    $filtered_others_posts=[];
    if (!empty($atts['tags'])) {
        $tags_filter = event_get_tag_ids($atts['tags']);
       
        $filtered_self_posts = filter_events_by_tags($self_events, $tags_filter);
        $filtered_others_posts = filter_events_by_tags($other_events, $tags_filter);
    }
    else{
        $filtered_self_posts=filter_events_by_date($self_events);
        $filtered_others_posts=filter_events_by_date($other_events); 

    }
   
    
   
    

    $count = isset($atts['count']) ? $atts['count'] : 10;
    ob_start();
    echo '<div class="sy-crm-event-table-container">
    
        <div class="sy-crm-event-table-header">
         <div class="crm-table-header-quick-filter">
                <input type="text" id="sy-crm-event-table-header-filter"class="sy-crm-event-table-header-filter" value="" placeholder="Rechercher...">
                <button id="filter-events-btn">  
                    <img src="' . esc_url($searchIconUrl) . '" alt="Rechercher">
                </button>
            </div>

        ';
        echo '<select id="filter-events-tag" class="sy-crm-event-table-select-filter">
        <option value="">Tous les tags</option>';
        foreach ($tags as $tag) {
           
            
            echo '<option value="' . esc_attr($tag->tag_name) . '" >' . esc_html($tag->tag_name) . '</option>';
        }
        echo '</select></div>';
        
   
  if(!empty($filtered_self_posts))
{
    echo '<h4 class=”sy-crm-event-table-title”>Mes événements</h4>
        <table class="sy-crm-event-table "data-count="' . esc_html($count) . '" id="sy-crm-user-event-table"style="width:100%;">
        <thead><tr><th>Tiers</th><th>Date</th><th>Titre</th>
        <th>Tags</th></tr></thead><tbody>';
        //<th>Auteur</th>
      
            foreach ($filtered_self_posts as $p) {
                $name = get_the_title($p->ID);
                //$date_creation = get_the_date('F j, Y', get_post_meta($p->ID, '_generated_event_date'));
                //$date_creation = get_post_meta($p->ID, '_generated_event_date', true);
                $date_format = get_option('date_format');
                $date_meta =get_post_meta($p->ID, '_generated_event_date', true);
                
        
                $is_overdue=false;
                if (!empty($date_meta)) {
                    // Convertir la date en timestamp (si elle est bien formatée)
                    $timestamp = strtotime($date_meta);
                    $is_overdue = $timestamp && $timestamp < strtotime(date('Y-m-d')); 
                    if ($timestamp) {
                        $date_creation =  date_i18n($date_format, strtotime($date_meta));;
                    } else {
                        $date_creation = 'Date invalide';
                    }
                } else {
                    $date_creation =  date_i18n($date_format, strtotime($date_meta));;
                }/**/
                $doc_tagsId = get_post_meta($p->ID, '_generated_event_tags', true)!=""?get_post_meta($p->ID, '_generated_event_tags', true):(get_post_meta($p->ID, '_generated_doc_tags', true)??[]);
                if (!is_array($doc_tagsId)) {
                    $doc_tagsId = explode(',', $doc_tagsId); 
                }
                
                $doc_tags = event_get_tags($doc_tagsId);
                
                //$userDocId = get_post_meta($p->ID, '_generated_event_user_id', true)??get_post_meta($p->ID, '_generated_document_user_id', true);
                $eventUserId = get_post_meta($p->ID, '_generated_event_user_id', true);
                $userDocId = !empty($eventUserId) ? $eventUserId : get_post_meta($p->ID, '_generated_doc_user_id', true);
                $user_info = get_userdata($userDocId);
                $first_name = $user_info->first_name;
                $last_name = $user_info->last_name;
                $company_name = get_user_meta($userDocId, 'billing_company', true);
                $nomAffiche=$company_name?$company_name:$last_name.' '.$first_name;
                $hashedId=  crm_events_generate_user_hash($userDocId);  
                $link=home_url('crm-customer/' . $hashedId.'?event='.$p->ID);
                $linkProp=home_url('crm-customer/' . $hashedId);
                
                $author_id = $p->post_author;
    
                // Récupérer le display name de l'auteur
                $author_name = get_the_author_meta('display_name', $author_id);
                $post_author_id = $p->post_author; // Récupérer l'ID de l'auteur du post
                    $post_author_info = get_userdata($post_author_id);
                    $post_author_name = $post_author_info->first_name && $post_author_info->last_name?$post_author_info->first_name . ' ' . $post_author_info->last_name:$post_author_info->display_name;
                    
                echo '<tr  class="sy-crm-event-table-detail-row ' . ($is_overdue ? 'sy-crm-event-table-detail-row-overdue' : '') . '">';
                echo '<td class="sy-crm-event-table-detail-cell sy-crm-event-table-detail-proprietaire"data-url="' . esc_url($linkProp) . '"><span>'. esc_html($nomAffiche) . '</span></td>';
                echo '<td class="sy-crm-event-table-detail-cell sy-crm-event-table-detail-date" data-url="' . esc_url($link) . '"data-order="' . date('Y-m-d', strtotime($date_meta)) . '"><span>' . esc_html($date_creation) . '</span></td>';
               // echo ' <td class="sy-crm-event-table-detail-cell sy-crm-event-table-detail-auteur" data-url="' . esc_url($link) . '"> ' . esc_html($author_name) . '</span></td>'; 
             
                echo '<td class="sy-crm-event-table-detail-cell sy-crm-event-table-detail-titre"data-url="' . esc_url($link) . '"><span>' . esc_html($name) . '</span>';
                        
                echo '</td>';
            
                echo '<td class="sy-crm-event-table-detail-cell sy-crm-event-table-detail-tags">';
                if(!empty($doc_tags)){
                foreach ($doc_tags as $t) {
                    echo '<span class="sy-crm-event-table-detail-tag ' . esc_html(sanitize_title($t->tag_name)) . '"style="'.esc_attr($t->tag_style).'">' . esc_html($t->tag_name) . '</span> ';
                }

                }
                echo '</td>';
                
                echo '</tr>';
            

        
     }
    echo '</tbody></table>';
    }

    if(!empty($filtered_others_posts))
    {
        echo '<h4 class=”sy-crm-event-table-title”>Evénements équipe</h4>
        <table class="sy-crm-event-table "data-count="' . esc_html($count) . '"id="sy-crm-others-event-table"style="width:100%;"><thead><tr><th>Tiers</th><th>Date</th><th>Auteur</th><th>Titre</th> <th>Tags</th></tr></thead><tbody>
        ';
   
        foreach ($filtered_others_posts as $p) {
            $name = get_the_title($p->ID);
            $date_format = get_option('date_format');
                $date_meta =get_post_meta($p->ID, '_generated_event_date', true);
                
        
                $is_overdue=false;
               if (!empty($date_meta)) {
                    // Convertir la date en timestamp (si elle est bien formatée)
                    $timestamp = strtotime($date_meta);
                    $is_overdue = $timestamp && $timestamp < strtotime(date('Y-m-d')); 
                    if ($timestamp) {
                        $date_creation =  date_i18n($date_format, strtotime($date_meta));;
                    } else {
                        $date_creation = 'Date invalide';
                    }
                } else {
                    $date_creation =  date_i18n($date_format, strtotime($date_meta));;
                }
                $doc_tagsId = get_post_meta($p->ID, '_generated_event_tags', true)!=""?get_post_meta($p->ID, '_generated_event_tags', true):(get_post_meta($p->ID, '_generated_doc_tags', true)??[]);
                if (!is_array($doc_tagsId)) {
                    $doc_tagsId = explode(',', $doc_tagsId); 
                }
                
                $doc_tags = event_get_tags($doc_tagsId);
                $author_id = $p->post_author;
    
                // Récupérer le display name de l'auteur
                $author_name = get_the_author_meta('display_name', $author_id);
                
                //$userDocId = get_post_meta($p->ID, '_generated_event_user_id', true)??get_post_meta($p->ID, '_generated_document_user_id', true);
                $eventUserId = get_post_meta($p->ID, '_generated_event_user_id', true);
                $userDocId = !empty($eventUserId) ? $eventUserId : get_post_meta($p->ID, '_generated_doc_user_id', true);
                $user_info = get_userdata($userDocId);
                $first_name = $user_info->first_name;
                $last_name = $user_info->last_name;
                $company_name = get_user_meta($userDocId, 'billing_company', true);
                $nomAffiche=$company_name?$company_name:$last_name.' '.$first_name;
                
                $hashedId=  crm_events_generate_user_hash($userDocId);  
                $link=home_url('crm-customer/' . $hashedId.'?event='.$p->ID);
                $linkProp=home_url('crm-customer/' . $hashedId);
            
                $post_author_id = $p->post_author; // Récupérer l'ID de l'auteur du post
                $post_author_info = get_userdata($post_author_id);
                //$post_author_name = $post_author_info->first_name || $post_author_info->last_name?$post_author_info->first_name . ' ' . $post_author_info->last_name:$post_author_info->display_name;
              
                echo '<tr  class="sy-crm-event-table-detail-row ' . ($is_overdue ? 'event-detail-row-overdue' : '') . '">';
                echo '<td class="sy-crm-event-table-detail-cell sy-crm-event-table-detail-proprietaire"data-url="' . esc_url($linkProp) . '"><span>'. esc_html($company_name). '</span></td>';
                echo '<td class="sy-crm-event-table-detail-cell sy-crm-event-table-detail-date" data-url="' . esc_url($link) . '"data-order="' . date('Y-m-d', strtotime($date_meta)) . '"><span>' . esc_html($date_creation) . '</span></td>';
                 echo ' <td class="sy-crm-event-table-detail-cell sy-crm-event-table-detail-auteur" data-url="' . esc_url($link) . '"> <span class="sy-crm-event-table-detail-createur">' . esc_html($author_name) . '</span></td>'; 
               echo '<td class="sy-crm-event-table-detail-cell sy-crm-event-table-detail-titre"data-url="' . esc_url($link) . '"><span>' . esc_html($name) . '</span>';
                echo '</td>';
            
                echo '<td class="sy-crm-event-table-detail-cell sy-crm-event-table-detail-tags">';
                if(!empty($doc_tags)){
                    foreach ($doc_tags as $t) {
                    echo '<span class="sy-crm-event-table-detail-tag ' . esc_html(sanitize_title($t->tag_name)) . '"style="'.esc_attr($t->tag_style).'">' . esc_html($t->tag_name) . '</span> ';
                }
            }
                echo '</td>';
                
                echo '</tr>';
        }

    
    echo '</tbody></table>';
     
    }
    
    echo '</div>';
   
    
    wp_reset_postdata();
    return ob_get_clean();
}
add_shortcode('crm_list_evenements', 'event_documents_shortcode');
function event_get_tag_ids($tag_names) {
    global $wpdb;
    $table_tags = $wpdb->prefix . 'crm_event_tags';
    
    $tag_names_array =  explode(',', $tag_names);
    $tag_ids = [];
    foreach ($tag_names_array as $tag_name) {
        $tag_id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_tags WHERE tag_name = %s AND status = 1",
            $tag_name
        ));
        if ($tag_id) {
            $tag_ids[] = $tag_id;
        }
    }

    return $tag_ids;

}
function event_get_tags($tag_ids) {
    global $wpdb;
    $table_tags = $wpdb->prefix . 'crm_event_tags';
    
    $tag_ids = array_map('intval', $tag_ids);

    if (empty($tag_ids)) return [];

    $tags = $wpdb->get_results(
        "SELECT tag_name, tag_style FROM $table_tags WHERE id IN (" . implode(',', $tag_ids) . ")"
    );

    return $tags;

}
function filter_events_by_tags($events, $tags_filter) {
    $filtered_events = [];
    $today = date('Y-m-d');

    foreach ($events as $post) {
        $generated_event_tags = get_post_meta($post->ID, '_generated_event_tags', true)!=""?get_post_meta($post->ID, '_generated_event_tags', true):(get_post_meta($post->ID, '_generated_doc_tags', true)??[]);
           
        $date_meta = get_post_meta($post->ID, '_generated_event_date', true);

        // Vérification des tags
        if (!empty($generated_event_tags) && array_intersect($tags_filter, (array) $generated_event_tags)) {
             $filtered_events[]=$post;
        /*   if (!empty($date_meta) && strtotime($date_meta) >= strtotime($today)) {
                $filtered_events[] = $post;
            }*/
        }
    }
    return $filtered_events;
}
function filter_events_by_date($events) {
    $filtered_events = [];
    $today = date('Y-m-d');

    foreach ($events as $post) {
        $generated_event_tags = get_post_meta($post->ID, '_generated_event_tags', true)!=""?get_post_meta($post->ID, '_generated_event_tags', true):(get_post_meta($post->ID, '_generated_doc_tags', true)??[]);
           
        $date_meta = get_post_meta($post->ID, '_generated_event_date', true);

        // Vérification des tags
        
           if (!empty($date_meta) && strtotime($date_meta) >= strtotime($today)) {
                $filtered_events[] = $post;
            }
        }
    
    return $filtered_events;
}