jQuery(document).ready(function($) {
    $('#sy-crm-events-logs-table-header-filter').on('keyup', function() {
        let value = $(this).val().toLowerCase();
        tableEventsLogs.search(value).draw();
    });


    $('#sy-crm-events-logs-table-author-filter').on('change', function() {
        tableEventsLogs.draw();

    });
    $('.sy-crm-events-logs-table-detail-cell').on('click', function() {
        var url = $(this).data('url');
        window.location.href = url;
    });
    //sy-crm-events-logs-table

    var tableEventsLogs = $('#sy-crm-events-logs-table').DataTable({
        "paging": true,
        "searching": true,
        "ordering": true,
        "pageLength": $('#sy-crm-events-logs-table').data('count'),
        "search": {
            "smart": false,
            "caseInsensitive": true
        },
        "searchDelay": 100,
        "columnDefs": [{
                "orderable": true,
                "targets": 2,
                "type": 'html'
            }, {
                "orderable": true,
                "targets": 3,
                "type": 'html'
            },
            { "responsivePriority": 1, "targets": [0, 1, 3, 2] },
            { "responsivePriority": 1, "targets": '_all' }
        ],
        "order": [
            [0, 'desc']
        ],
        "lengthChange": false,
        "info": true,
        "responsive": true,
        "pagingType": "full_numbers",
        "language": {
            "paginate": {
                "previous": "<",
                "next": ">",
                "first": "<<",
                "last": ">>"
            },
            "info": " _START_ - _END_ / _TOTAL_",
            "infoEmpty": "Aucun évènement disponible",
            "zeroRecords": "Aucun évènement correspondant trouvé",
            "emptyTable": "Aucun évènement trouvé",
            "infoFiltered": "(filtré à partir de _MAX_ entrées )"
        },
        /*"drawCallback": function() {
            $('.dataTables_paginate').appendTo('.sy-crm-event-table-info');
            $('#custom-info').html($('.dataTables_info').html());
        }*/
    });

    if ($('#sy-crm-events-logs-table_filter').length > 0) {
        $('#sy-crm-events-logs-table_filter').hide()
    }

    $.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
        var selectedAuteur = $('#sy-crm-events-logs-table-author-filter').val().toLowerCase();
        var AuthorRow = $(tableEventsLogs.row(dataIndex).node()).data('auteur') ? $(tableEventsLogs.row(dataIndex).node()).data('auteur').toLowerCase() : '';

        var authorMatches = !selectedAuteur || AuthorRow.includes(selectedAuteur);

        return authorMatches;
    });


})