jQuery(document).ready(function($) {
            //gestion events list 
            

            
            $.fn.dataTable.ext.pager.numbers_length = 4;
           
            //
            $('.sy-crm-event-table-user-events').each(function() {
                var table = $(this).DataTable({
                    "paging": true,
                    "pageLength": $(this).data('count'),
                    "searching": true,
                    "ordering": true,
                    "search": {
                        "smart": false,
                        "caseInsensitive": true
                    },
                    "searchDelay": 100,
                    "columnDefs": [
                        { "orderable": true, "targets": 0, "type": 'html' },
                        { "orderable": false, "targets": 4 },
                        { "responsivePriority": 1, "targets": [0, 1, 4, 2, 3] },
                        { "responsivePriority": 2, "targets": '_all' }
                    ],
                    "order": [[0, 'desc']],
                    "lengthChange": false,
                    "info": true,
                    "responsive": true,
                    "pagingType": "full_numbers",
                    "language": {
                        "paginate": { "previous": "<", "next": ">", "first": "<<", "last": ">>" },
                        "info": " _START_ - _END_ / _TOTAL_",
                        "infoEmpty": "Aucun évènement disponible",
                        "zeroRecords": "Aucun évènement correspondant trouvé",
                        "emptyTable": "Aucun évènement trouvé",
                        "infoFiltered": "(filtré à partir de _MAX_ entrées )"
                    }
                });
            
                // Si tu veux cacher le filtre par défaut
                var filterDiv = $(this).closest('.event-tab-content').find('.dataTables_filter');
                if (filterDiv.length > 0) {
                    filterDiv.hide();
                }
            });
            $('#quick-filter-events-input').on('keyup', function() {
                let value = $(this).val();
                $('.event-tab-content').each(function() {
                    //if ($(this).is(':visible')) {
                        $(this).find('.sy-crm-event-table-user-events').DataTable().search(value).draw();
                   // }
                });
            });
            
            $("#filter-events-tag").on("change", function() {
                let value = $(this).val();
                $('.event-tab-content').each(function() {
                //    if ($(this).is(':visible')) {
                        $(this).find('.sy-crm-event-table-user-events').DataTable().search(value).draw();
                   // }
                });
            });
            $(document).on('click', '.event-tab-btn', function () {
                $('.event-tab-btn').removeClass('active-tab');
                $(this).addClass('active-tab');

                $('.event-tab-content').hide();
                $('#' + $(this).data('tab')).show();
            });


                        
            //


            $(document).on('click', '.sy-crm-event-table-action-generate', function(e) {
                e.preventDefault();
                var postId = $(this).data('id');
                $('#generate_event_notification').removeClass('text-success text-error').addClass('text-info').text('Traitement en cours...');

                $.post(ajax_object.ajax_url, {
                    action: 'crm_event_regenerate_pdf',
                    event_id: postId
                }, function(response) {
                    if (response.success) {

                        $(`#generate_event_notification`)
                            .text("Pdf regéneré avec succès")
                            .addClass("text-success").removeClass("text-error")
                            .fadeIn()
                            .delay(500)
                            .fadeOut(function() {
                                location.reload();
                            });

                    } else {

                        $(`#generate_event_notification`)
                            .text("Erreur dans la regénération du pdf. ")
                            .addClass("text-error").removeClass("text-success")
                            .fadeIn()
                            .delay(500)
                            .fadeOut(function() {
                                // location.reload();
                            });

                    }
                });
            });
            //edition

            let editVarsEditors = {};


            $(document).on("click", ".sy-crm-event-table-menu-detail-btn,.event-info-cell", function(e) {
                        e.preventDefault();
                        $('#add-new-attachement-tr,#sy-crm-edit-event-send-email-section-container').hide(); //
                        const eventId = $(this).data("id");
                        //const precedentId = $(this).data("precedent");
                        //const suivantId = $(this).data("suivant");
                        $('#sy-crm-event-edit-sidebar-confirm-edit-btn').show();
                        $('#generate_event_confirm_edit_btn').hide();
                        $('#sy-crm-event-edit-sidebar-submit-btn').hide();
                        $("#sy-crm-event-edit-sidebar-event-title").attr('readOnly', true);
                        $('#sy-crm-event-edit-sidebar-content').show().empty();
                        $("#sy-crm-event-edit-sidebar-submit-btn").prop("disabled", true);

                        $("#sy-crm-event-edit-sidebar-vars-container").hide();
                        $("#sy-crm-event-edit-sidebar-version").hide();
                        
                        const currentTr = $(`.sy-crm-event-table-user-events tr[data-id="${eventId}"]`);

                        const precedentId = currentTr.data("precedent");
                        const suivantId = currentTr.data("suivant");
                        console.log(eventId,currentTr,precedentId,suivantId)
                       
                        $('#sy-crm-event-edit-sidebar-confirm-edit-btn').data("id", eventId)

                        if (suivantId) {

                            $('#sy-crm-event-edit-sidebar-next-button').data("id", suivantId).attr('disabled', false);
                        } else {
                            $('#sy-crm-event-edit-sidebar-next-button').data("id", "").attr('disabled', true);


                        }
                        if (precedentId) {


                            $('#sy-crm-event-edit-sidebar-pev-button').data("id", precedentId).attr('disabled', false);
                        } else {
                            $('#sy-crm-event-edit-sidebar-pev-button').data("id", "").attr('disabled', true);


                        }
                        const url = new URL(window.location);
                        if (url.searchParams.has('event')) {
                            url.searchParams.delete('event');
                            history.replaceState(null, '', url.toString());
                        }
                        $.ajax({
                                    url: ajax_object.ajax_url,
                                    type: "POST",
                                    data: {
                                        action: "get_event_details",
                                        document_id: eventId,
                                    },
                                    success: function(response) {
                                            $('#sy-crm-event-edit-sidebar .crm_events_tags_list').hide();
                                            $('#sy-crm-event-edit-sidebar .crm_events_tags_selected_list').hide().empty();
                                            $('.crm_events_tags_tag').show();
                                            $('.crm_events_tags_container label').hide();
                                            $('#sy-crm-edit-event-send-mail-options').hide();
                                            $('#sy-crm-edit-event-send-mail-form-send-attachments-via-link').removeAttr('checked')
                                            $('#sy-crm-edit-event-send-email-checkbox').removeAttr('checked');
                                            $('#sy-crm-edit-event-mail-recipients-wrapper .recipient-group:not(:first)').remove();
                                            $('#sy-crm-edit-event-send-email-section').hide();
                                            //.hide().attr('disabled', true)
                                            $('#generate_event_envoi_btn').data('id', eventId);


                                            if (response.success) {

                                                let initialTags = [];
                                                const data = response.data;
                                                const attachments = data.attachments || [];
                                                const variables = data.variables_event || {};
                                                const templateVersion = data.template_version;
                                                const eventVersion = data.event_version;
                                                const variablesTemplate = data.variables_template || [];
                                                let preFilled = response.data.pre_filled;
                                                const templateRacine = response.data.racine;
                                                const compteur = response.data.compteur || 1;
                                                editVarsEditors = {};
                                                if (data.canDelete == true) {
                                                    $('#sy-crm-event-edit-sidebar-delete-btn').attr('disabled', false).show();
                                                } else {
                                                    $('#sy-crm-event-edit-sidebar-delete-btn').attr('disabled', true).hide();
                                                }
                                                if (data.associated_users.length > 0) {
                                                    //

                                                    $('#sy-event-edit-sidebar-users-list-trigger').attr('data-edit', '0').attr('data-old-value', JSON.stringify(data.associated_users.flat()));;
                                                    $('#sy-crm-event-edit-sidebar-association-users-options').show();
                                                    $('#sy-event-edit-sidebar-users-list-trigger .sy-event-edit-sidebar-users-list-selected-item').hide();
                                                    $('#sy-event-edit-sidebar-users-list .sy-event-edit-sidebar-users-list-item').show();
                                                    data.associated_users.forEach(id => {
                                                        $(`#sy-event-edit-sidebar-users-list .sy-event-edit-sidebar-users-list-item[data-id="${id}"]`).hide()
                                                        $(`#sy-event-edit-sidebar-users-list-trigger .sy-event-edit-sidebar-users-list-selected-item[data-id="${id}"]`).show()

                                                    })
                                                    $('#sy-event-edit-sidebar-users-list-trigger .sy-event-edit-sidebar-users-list-selected-item').each(function() {
                                                        let $item = $(this);

                                                        $item.text($item.text().replace('✖', '').trim());

                                                    });


                                                } else {
                                                    $('#sy-crm-event-edit-sidebar-association-users-options').hide();
                                                }


                                                $('#sy-crm-event-edit-sidebar-delete-btn').data("id", eventId);


                                                const today = new Date();
                                                const formattedDate = data.date_now

                                                $('#sy-crm-event-edit-sidebar-date').val(data.event_date).data('original-value', data.event_date).attr('readonly', true);
                                                $('#sy-crm-event-edit-sidebar-duration').val(data.event_dure).data('original-value', data.event_dure).attr('readonly', false);
                                                let infoDiv = $('#sy-crm-event-edit-sidebar-duration').parent().parent().next('.duration-warning');

                                                let duration = data.event_dure;
                                                if (duration) {
                                                    let match = duration.match(/^(\d+)h(\d+)$/);

                                                    if (match) {
                                                        let hours = parseInt(match[1], 10);
                                                        let minutes = parseInt(match[2], 10);

                                                        if (hours > 24 || (hours === 24 && minutes > 0)) {
                                                            if ($('#duration-warning').length === 0) {
                                                                infoDiv.html('<span style="color: red; font-size: 12px; display: block; margin-top: 5px;">Durée supérieure à 24 heures !</span>');
                                                            }
                                                        } else {
                                                            infoDiv.empty();
                                                        }
                                                    }


                                                } else {
                                                    infoDiv.empty();
                                                }
                                                let titlehtml = data.title;

                                                $("#sy-crm-event-edit-sidebar-tier").html(data.tiers).attr('href', data.FicheTiers);
                                                $("#sy-crm-event-edit-sidebar-creator").html('<span>Par : </span>' + data.creator);
                                                $("#sy-crm-event-edit-sidebar-creation-date").html('<span>Crée le : </span>' + data.dateCreation);

                                                if (data.canEdit == true) {
                                                    $('#sy-crm-event-edit-sidebar-confirm-edit-btn').show();
                                                    // $('#generate_event_envoi_btn').show();

                                                } else {
                                                    $('#sy-crm-event-edit-sidebar-confirm-edit-btn').hide();

                                                    // $('#generate_event_envoi_btn').hide();
                                                }
                                                if (data.tags_data && Array.isArray(data.tags_data) && data.tags_data.length > 0) {
                                                    let tagsList = data.tags_data;
                                                    initialTags = tagsList.map(tag => tag.id);
                                                    tagsList.forEach(tag => {
                                                        var tagName = tag.tagName;
                                                        var tagClass = tagName.toLowerCase().replace(/[^a-z0-9\-_]/g, '-');
                                                        titlehtml += '  <span class=" event_tag ' + tagClass + '" data-id="' + tag.id + '"style="' + tag.style + '">' + tag.tagName + '</span>';
                                                        let tagElement = $('<span class="event_tag crm_events_tags_selected ' + tagClass + ' disabled" data-id="' + tag.id + '"style="' + tag.style + '">' +
                                                            tag.tagName + ' <span class="crm_events_tags_remove" data-id="' + tag.id + '" >x</span></span>');
                                                        $('#sy-crm-event-edit-sidebar .crm_events_tags_list')
                                                            .find('.crm_events_tags_tag[data-id="' + tag.id + '"]')
                                                            .hide();
                                                        $('#sy-crm-event-edit-sidebar .crm_events_tags_selected_list').append(tagElement).hide().data('initial-tags', initialTags);
                                                    });
                                                } else {
                                                    $('#sy-crm-event-edit-sidebar .crm_events_tags_selected_list').empty().hide().data('initial-tags', '');


                                                }
                                                $('#crm-event-sidebar-header-title').html(titlehtml);
                                                let formattedContent = data.eventContent.replace(/<p><br><\/p>/g, '<br>');
                                                $('#sy-crm-event-edit-sidebar-content').html(formattedContent);

                                                //$('#sy-crm-event-edit-sidebar-content').html(data.eventContent)
                                                //$("#sy-crm-event-edit-sidebar-submit-btn").prop("disabled", true);
                                                $("#sy-crm-event-edit-sidebar-event-title").val(data.title).data("original-value", (data.title)).attr('readOnly', true);
                                                $("#sy-crm-event-edit-sidebar-event-id").val(eventId);
                                                //////////////////
                                                const versionContainer = $("#sy-crm-event-edit-sidebar-version");
                                                const editContentContainer = $("#sy-crm-event-edit-sidebar-vars-container");





                                                let container = $('#sy-crm-event-edit-sidebar-vars');
                                                let hiddenChamps = [
                                                    'devis', 'factures-echues', 'facture',
                                                    'template_name', 'document_name', 'user_status', 'display_name', 'display_author_name', 'display_author_bio', 'first_name', 'last_name', 'display_user_bio',
                                                    'wc_last_active', 'tax_no', 'user_mailing', 'shipping_first_name', 'shipping_last_name', 'shipping_company',
                                                    'shipping_address_1', 'shipping_address_2', 'shipping_city', 'shipping_postcode',
                                                    'shipping_country', 'shipping_state', 'shipping_phone', 'shipping_email',
                                                    'reference_template', 'creation_date', 'billing_first_name', 'billing_last_name',
                                                    'billing_company', 'billing_address_1', 'billing_address_2', 'billing_city',
                                                    'billing_postcode', 'billing_country', 'billing_state', 'billing_phone',
                                                    'billing_email', 'civilite', 'don_ref', 'don_date', 'don_moyen', 'don_montant_nb', 'don_montant_txt', 'don_etat', 'don_etat', 'don_commentaire', 'est_annule'
                                                ];
                                                // let hiddenChamps = ['template_name*', 'template_name', 'reference_template*', 'reference_template', 'event_name', 'document_name', 'display_author_bio', 'display_author_bio*', 'display_author_bio *', 'display_user_bio', 'display_user_bio *', 'display_user_bio @', 'display_user_bio @ *', 'display_user_bio * @'];
                                                //let readOnlyChamps = ['creation_date#*', 'creation_date*', 'creation_date', 'display_author_name', 'display_author_name*', 'display_author_name *', 'display_author_bio', 'display_author_bio*', 'display_author_bio *', 'display_user_bio', 'display_user_bio *', 'display_user_bio @', 'display_user_bio @ *', 'display_user_bio * @'];
                                                let existingVariables = Object.keys(variables);
                                                container.empty();

                                                // Identifier les nouvelles variables qui ne sont pas dans `existingVariables`
                                                let newVariables = variablesTemplate.filter(varName => !existingVariables.includes(varName));

                                                let readOnlyVariables = [];
                                                let editableVariables = [];




                                                Object.entries(variables).forEach(([variable, value]) => {

                                                            let cleanedVariable = variable.replace(/[*#@]/g, '').replace(/[*#@]/g, '').trim();

                                                            if ((cleanedVariable == 'display_author_bio' || cleanedVariable == 'display_user_bio') && !variable.includes('@')) {
                                                                variable = `${variable}@`;
                                                            }
                                                            if (cleanedVariable == 'creation_date') {
                                                                value = data.dateCreation
                                                            }
                                                            // Déterminer le style caché et en lecture seule
                                                            let hiddenStyle = hiddenChamps.includes(cleanedVariable) ? 'style="display:none;"' : '';
                                                            // const readOnlyAttr = readOnlyChamps.includes(variable) ? 'readonly' : '';
                                                            const readOnlyAttr = '';
                                                            let fieldHtml = '';
                                                            if (variable.includes('@')) {
                                                                value = value.replace(/\r\n|\r|\n/g, '<br>');
                                                                let requiredChamp = variable.includes('*');
                                                                const labelText = (labelsArray[variable.replace('@', '').replace('*', '').trim()] || variable.replace('@', '').replace('*', '').trim());
                                                                const sanitizedVariable = variable.replace(/'/g, '&#39;');
                                                                const sanitizedVariableId = variable.replace(/'/g, '&#39;').replace(/[@*]/g, 'a').replace(/\s+/g, '_');
                                                                const newvalue = generate_event_escapeString(value);

                                                                hiddenStyle = hiddenChamps.includes(cleanedVariable) ? 'style="display:none;"' : 'style="height:260px;"';


                                                                container.append(`
                                            <div class="variable__item editor__container" ${hiddenStyle}>
                                                <label class="crm-doc-label" for="${sanitizedVariableId}">${labelText}${requiredChamp ? ' *' : ''} :</label>
                                                <div style="width:100%"data-original-value="${newvalue}"style="height:250px;">
                                                    <div id="${sanitizedVariableId}" name="${sanitizedVariable}" style="width: -webkit-fill-available; height:200px;" ${requiredChamp ? 'required' : ''} ${readOnlyAttr}>${value}</div>
                                                </div>
                                            </div>
                                            <div class="text-error" style="display:none;">Ce champ est requis.</div>
                                        `);
                                                                const quillInstance = new Quill(`#${sanitizedVariableId}`, { theme: "snow", readOnly: readOnlyAttr });
                                                                // quillInstance.setContents(quillEditContent.clipboard.convert(value));
                                                                editVarsEditors[sanitizedVariableId] = quillInstance;



                                                                quillInstance.on("text-change", function() {
                                                                    $(document).trigger("quill-text-change", [sanitizedVariableId, quillInstance]);
                                                                });

                                                            } else if (variable.includes('|')) {
                                                                const options = variable.split('|').slice(1);
                                                                const parts = variable.split('|');
                                                                let labelText = parts[0].trim();
                                                                let requiredChamp = labelText.includes('*');
                                                                labelText = labelText.replace(/[^a-zA-Z0-9\s]/g, ''); // Nettoyage
                                                                const sanitizedVariable = variable.replace(/'/g, '&#39;');

                                                                container.append(`
                                            <div class="variable__item" ${hiddenStyle}>
                                                <label class="crm-doc-label" for="${sanitizedVariable}">${labelText}${requiredChamp ? ' *' : ''} :</label>
                                                <select class="crm-doc-select" id="${sanitizedVariable}"data-original-value="${value}" name="${sanitizedVariable}" ${requiredChamp ? 'required' : ''}>
                                                    ${options.map(option => `<option value="${option}"${value == option ? ' selected' : ''}>${option}</option>`).join('')}
                                                </select>
                                            </div>
                                            <div class="text-error" style="display:none;">Ce champ est requis.</div>
                                        `);
    
                                    } else if (variable.includes('#')) {
                                        const labelText = labelsArray[cleanedVariable] || cleanedVariable;
                                        let requiredChamp = labelText.includes('*');
                            
                                        container.append(`
                                            <div class="variable__item" ${hiddenStyle}>
                                                <label class="crm-doc-label" for="${variable}">${labelText}${requiredChamp ? ' *' : ''} :</label>
                                                <input class="crm-doc-input"type="date" id="${variable}"data-original-value="${value}" name="${variable}" value="${value}" ${requiredChamp ? 'required' : ''} ${readOnlyAttr}/>
                                            </div>
                                            <div class="text-error" style="display:none;">Ce champ est requis.</div>
                                        `);
                            
                                    } else {
                                        const requiredChamp = variable.includes('*');
                                        const labelText = labelsArray[cleanedVariable] || cleanedVariable;
                                        const sanitizedVariable = cleanedVariable.replace(/'/g, '&#39;');
                           
                                        container.append(`
                                            <div class="variable__item" ${hiddenStyle}>
                                                <label class="crm-doc-label"for="${variable}">${labelText}${requiredChamp ? ' *' : ''} :</label>
                                                <input class="crm-doc-input"type="text" id="${variable}"data-original-value="${value}" name="${variable}" value="${value}" ${requiredChamp ? 'required' : ''} ${readOnlyAttr}/>
                                            </div>
                                            <div class="text-error" style="display:none;">Ce champ est requis.</div>
                                        `);
                                    }
                                    
                                    
                                })

    
                                const attachmentsArray = Array.isArray(attachments) ? attachments : Object.values(attachments);
                                
                            const generatedPdf= data.generatedPdf
                                // Construire la table des pièces jointes
                                if (attachmentsArray.length > 0 || (data.acceptAttachement == "on"&&data.canEdit==true)) {
                                
                                    $('.sy-crm-event-sidebar-content-top-right').show();
                                    let attachmentsHtml = "<p>Documents joints :</p><table><thead><tr></tr></thead><tbody>";
                                    if (attachmentsArray.length > 0) {
                                    
                                        attachmentsArray.forEach((docUrl) => {
                                            
                                        
                                            const fileName = docUrl.split("/").pop();
                                            const fileExtension = fileName.split('.').pop().toLowerCase();
                                            const iconUrl = data.plugin_base_url+ '/'+ getFileIcon(fileExtension);
                                            const deleteIcon = data.plugin_base_url+ '/trash-icon.svg';
                                            attachmentsHtml += `
                                                <tr>
                                                    <td class="crm_event_attachement_type"><img class="icon-attachment" src="${iconUrl}" alt="File Icon"></td>
                                
                                                    <td class="crm_event_attachement_name"><a href="${docUrl}" target="_blank">${fileName}</a></td>
                                                <td class="crm_event_attachement_action"> `;

                                                if(data.canDelete==true){
                                                    attachmentsHtml += `<img  class="crm-event-delete-attachment" data-event-id="${eventId}" data-url="${docUrl}" src="${deleteIcon}" alt="delete Icon">
                                                `;
                                                }
                                                else{
                                                    attachmentsHtml += `--`;
                                                }
                                                    attachmentsHtml += `
                                                    </td>
                                                    </tr>
                                            `;
                                        });
                                    }
                                    else{
                                        attachmentsHtml += `
                                                <tr>
                                                    <td colspan="3">--</td></tr>
                                            `;
                                       

                                    }

                                    if (data.acceptAttachement == "on"&&data.canEdit==true) {
                                        const iconAdd = data.plugin_base_url + "add-icon.svg";
                                        attachmentsHtml += ` <tr id="add-new-attachement-tr"style="display:none;">
                                            <td colspan="3"style="text-align: end;">
                                            <img  class="add-attachment"   id="add-new-event-attachment-btn"src="${iconAdd}" alt="Add Icon" >
                                        
                                            
                                            </td>
                                        </tr>`;
                                    }
                                    attachmentsHtml += "</tbody></table>";
                                    
                                    $("#sy-crm-event-edit-sidebar-options").html(attachmentsHtml).show();
                                    
                            
                                }   
                             else{
                                $("#sy-crm-event-edit-sidebar-options").hide();
                                } 
                                if(attachmentsArray.length > 0||generatedPdf!=""){

                                    $('#sy-crm-edit-event-send-mail-options').data('visibility','on');
                                }
                                else{

                                    $('#sy-crm-edit-event-send-mail-options').data('visibility','off');
                                }
                                const historyMails = response.data.history_mails || [];
                                const historiqueDiv = $('#sy-crm-event-edit-sidebar-options-historique-emails');
                                let tableHTML = '';
                                if (historyMails.length > 0) {
                                    $('.sy-crm-event-sidebar-content-top-right').show();
                                
                                    tableHTML += `<p>Historique d'envoi des emails :</p>

                                        <div class="sy-crm-event-header-filters">
                                            <input id="quick-filter-history-mails-input" placeholder="Chercher..." class="crm-table-header-quick-filter" />

                                            <select id="filter-type-history-mails" class="sy-crm-event-table-select-filter">
                                                <option value="">Types</option>
                                                <option value="Envoyé">Envoyé</option>
                                                <option value="Ouverture">Ouverture</option>
                                                <option value="Réouverture">Réouverture</option>
                                                <option value="Téléchargement">Téléchargement</option>
                                            </select>
                                        </div>
                                        <table id="table-history-mails" class="table table-bordered table-sm" style="font-size: 13px; width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Type</th>
                                                    <th>Details</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                    `;
                                
                                    historyMails.forEach(entry => {
                                        const email = entry.email || '';
                                        const dateEnvoi = `${entry.date_envoi_formatted || ''} `;
                                        const dateEnvoiRaw = `${entry.date_envoi_raw || ''} `;
                                        const etat = entry.etat || '—';
                                        const dateOuverture = entry.etat === "lu" ? (entry.date_ouverture || '—') : 'Non ouvert';
                                        const piecesJointes = Array.isArray(entry.liens_documents) && entry.liens_documents.length > 0 ? 'Oui' : 'Non';
                                
                                        tableHTML += `
                                                <tr>
                                                    <td data-order="${dateEnvoiRaw}">${dateEnvoi}</td>
                                                    <td>Envoyé</td>
                                                    <td>${email}</td>
                                                </tr>
                                            `;

                                            // Ligne 2 : OUVERTURE
                                            if (entry.etat === 'lu') {
                                                const dateOuverture = entry.date_ouverture_formatted || '';
                                                let dateOuvertureRaw=entry.date_ouverture
                                                const ip = entry.ip_ouverture || 'IP inconnue';

                                                tableHTML += `
                                                    <tr>
                                                        <td data-order="${dateOuvertureRaw}">${dateOuverture}</td>
                                                        <td>Ouverture</td>
                                                        <td>${ip}</td>
                                                    </tr>
                                                `;

                                                // Réouvertures
                                                if (Array.isArray(entry.reouvertures) && entry.reouvertures.length > 0) {
                                                    entry.reouvertures.forEach((re, index) => {
                                                        const dateRe = re.date || '';
                                                        let dateRaw=re.date_raw;
                                                        const ipRe = re.ip || 'IP inconnue';
                                                        //${index + 1}

                                                        tableHTML += `
                                                            <tr>
                                                                <td data-order="${dateRaw}">${dateRe}</td>
                                                                <td>Réouverture </td>
                                                                <td>${ipRe}</td>
                                                            </tr>
                                                        `;
                                                    });
                                                }
                                            }
                                            if (Array.isArray(entry.documents_ouverts) && entry.documents_ouverts.length > 0) {
                                                entry.documents_ouverts.forEach((doc, index) => {
                                                    const dateDoc = doc.date || '';
                                                    const dateDocRaw = doc.date_raw || '';
                                                    const ipDoc = doc.ip || 'IP inconnue';
                                                    const fichier = doc.fichiers || 'Nom inconnu';
                                            
                                                    tableHTML += `
                                                        <tr>
                                                            <td data-order="${dateDocRaw}">${dateDoc}</td>
                                                            <td>Téléchargement </td>
                                                            <td>
                                                                <div><strong>Fichier :</strong> ${fichier}</div>
                                                                <div><strong>IP :</strong> ${ipDoc}</div>
                                                            </td>
                                                        </tr>
                                                    `;
                                                });
                                            }

                                    });
                                
                                    tableHTML += '</tbody></table>';
                                    setTimeout(() => {
                                        if ($.fn.DataTable.isDataTable('#table-history-mails')) {
                                            $('#table-history-mails').DataTable().destroy();
                                        }
                                    
                                        var historyTable =$('#table-history-mails').DataTable({
                                            "paging": true,
                                            "pageLength": 15,
                                            "searching": true,
                                            "ordering": true,
                                            "search": {
                                            "smart": false,
                                            "caseInsensitive": true
                                            },
                                            "searchDelay": 100,
                                            "columnDefs": [{
                                            "orderable": true,
                                            "targets": 0,
                                            "type": 'html'
                                            },
                                           { "responsivePriority": 0, "targets": '_all' }
                                            ],
                                            "order": [
                                            [0, 'desc']
                                            ],
                                            "lengthChange": false,
                                            "info": true,
                                            "responsive": true,
                                            "pagingType": "full_numbers",
                                            "language": {
                                            "paginate": {
                                            "previous": "<",
                                            "next": ">",
                                            "first": "<<",
                                            "last": ">>"
                                            },
                                            "info": " _START_ - _END_ / _TOTAL_",
                                            "infoEmpty": "Aucun historique disponible",
                                            "zeroRecords": "Aucun historique correspondant trouvé",
                                            "emptyTable": "Aucun historique trouvé",
                                            "infoFiltered": "(filtré à partir de _MAX_ entrées )"
                                            },
                                        });
                                        if ($('#table-history-mails_filter').length > 0) {
                                        $('#table-history-mails_filter').hide()
                                    }
                                        $(document).on('keyup','#quick-filter-history-mails-input', function() {
                                            let value = $(this).val();
                                            historyTable.search(value).draw();
                                        });
                                        $(document).on('change', '#filter-type-history-mails', function () {
                                            const selectedType = $(this).val();
                                            if (selectedType != '') {
                                                historyTable.search(selectedType).draw();
                                            }
                                        });
                                   
                                    }, 100);
                                    
                                   
                                } 
                               

                                historiqueDiv.html(tableHTML).show(); 


                                $("#sy-crm-event-edit-sidebar").addClass("open").show();
                                $('#sy-crm-event-edit-sidebar-confirm-edit-btn').on("click", function() {
                                    $('#sy-crm-event-edit-sidebar-content').hide();
                                    $('#sy-crm-edit-event-send-email-checkbox').parent().show();
                                    //versionContainer.hide();
                                    //editContentContainer.show();
                                    if (templateVersion === eventVersion) {
                                        versionContainer.hide();
                                        editContentContainer.show();
                                        $('#generate_event_confirm_edit_btn').hide();
                                        $('#sy-crm-event-edit-sidebar-confirm-edit-btn').hide();
                                        $('#sy-crm-event-edit-sidebar-submit-btn,#sy-crm-edit-event-send-email-section-container').show();//
                                        $('.crm_events_tags_container label').show();

                                        $("#sy-crm-event-edit-sidebar-event-title,#sy-crm-event-edit-sidebar-date,#sy-crm-event-edit-sidebar-duration").attr('readOnly', false);

                                        $('#sy-event-edit-sidebar-users-list-trigger').attr('data-edit', '1');
                                        $('#add-new-attachement-tr').show();
                                        $('#sy-crm-event-edit-sidebar .crm_events_tags_selected_list').show();
                                        $('#sy-crm-event-edit-sidebar .crm_events_tags_selected_list .crm_events_tags_selected').removeClass('disabled');
                                        $('#sy-crm-event-edit-sidebar .crm_events_tags_list').show();
                                        if(attachmentsArray.length > 0 || (data.acceptAttachement == "on"&&data.canEdit==true)) {
                                            $("#sy-crm-event-edit-sidebar-options").show();
                                        }
                                        $('#sy-event-edit-sidebar-users-list-trigger .sy-event-edit-sidebar-users-list-selected-item').each(function() {
                                            let $item = $(this);

                                            if (!$item.text().includes('✖')) {
                                                $item.append(' ✖');
                                            }
                                        });

                                    } else {
                                        versionContainer.show();
                                        editContentContainer.hide();
                                        $('#generate_event_confirm_edit_btn').show();
                                        $('#sy-crm-event-edit-sidebar-confirm-edit-btn').hide();
                                        //$('#sy-crm-event-edit-sidebar-submit-btn').show();

                                        //$("#sy-crm-event-edit-sidebar-event-title").attr('readOnly',false);

                                    }
                                });



                                $("#generate_event_confirm_edit_btn").on("click", function() {
                                    versionContainer.hide();
                                    editContentContainer.show();
                                    $('#generate_event_confirm_edit_btn').hide();
                                    $('#sy-crm-event-edit-sidebar-submit-btn,#sy-crm-edit-event-send-email-section-container').show();//
                                    $("#sy-crm-event-edit-sidebar-event-title,#sy-crm-event-edit-sidebar-date,#sy-crm-event-edit-sidebar-duration").attr('readOnly', false);

                                    $('#sy-event-edit-sidebar-users-list-trigger').attr('data-edit', '1');;
                                    $('#sy-event-edit-sidebar-users-list-trigger .sy-event-edit-sidebar-users-list-selected-item').each(function() {
                                        let $item = $(this);

                                        if (!$item.text().includes('✖')) {
                                            $item.append(' ✖');
                                        }
                                    });


                                    $('#add-new-attachement-tr').show();
                                    $('#sy-crm-event-edit-sidebar .crm_events_tags_selected_list .crm_events_tags_selected').removeClass('disabled');
                                    $('#sy-crm-event-edit-sidebar .crm_events_tags_list').show();

                                    $('#sy-crm-event-edit-sidebar .crm_events_tags_selected_list').show();
                                    $('.crm_events_tags_container label').show();
                                    if(attachmentsArray.length > 0 || (data.acceptAttachement == "on"&&data.canEdit==true)) {
                                        $("#sy-crm-event-edit-sidebar-options").show();
                                    }
                                       

                                });

                            } 
                            else {
                                alert("Erreur: " + response.data);
                            }
                        },
                        error: function() {
                            alert("Une erreur s\'est produite.");
                        }
                });
            });

    $(document).on("quill-text-change", function (event, editorId, quillInstance) {
        checkForUpdateChanges();
    });
  

    function generate_event_escapeString(str) {
        if (typeof str !== "string") return str;
        if (str.includes('"')) {
            return str.replace(/"/g, " ");
        }
        else
        return str;

       // return str.replace(/\"/g, "'").replace(/\'/g, "\\'");
    }
    $("#sy-crm-event-edit-sidebar-event-title").on("input", checkForUpdateChanges);
    $("#sy-crm-event-edit-sidebar-options-new-attachment").on("change",function(){
        const filesInput = $('#sy-crm-event-edit-sidebar-options-new-attachment');
        if($('#sy-crm-edit-event-send-mail-options').length>0)
        {
            if ($('#sy-crm-edit-event-send-email-checkbox').is(':checked')&&(filesInput.length > 0 && filesInput[0].files.length > 0||$('#sy-crm-edit-event-send-mail-options').data('visibility')=='on')) {
            $('#sy-crm-edit-event-send-mail-options').slideDown();

        }
        else{
           

            $('#sy-crm-edit-event-send-mail-options').slideUp();
            

        }
    }
        ////////
        checkForUpdateChanges
    } );
    $("#sy-crm-event-edit-sidebar-date").on("change", checkForUpdateChanges);
    $("#sy-crm-event-edit-sidebar-duration").on("change", checkForUpdateChanges);

    $(document).on("input", "#sy-crm-event-edit-sidebar-vars input",checkForUpdateChanges );
    $(document).on("input", "#sy-crm-event-edit-sidebar-event-title",checkForUpdateChanges );
    $(document).on("change", "#sy-crm-event-edit-sidebar-vars select",checkForUpdateChanges );
   
    function checkForUpdateChanges() {
        let hasChanges = false;
        $('#sy-crm-event-edit-sidebar-vars').find('input:visible, select:visible').each(function() {
            
            const originalValue = $(this).data('original-value');
            const currentValue = $(this).val();

            if (originalValue != currentValue) {
                hasChanges = true;
                return false; 
            }
        });
        let editorHasChanges=false;
        let updatedTitle=$("#sy-crm-event-edit-sidebar-event-title").data("original-value")!=$("#sy-crm-event-edit-sidebar-event-title").val();
        let updatedDuration=$("#sy-crm-event-edit-sidebar-duration").data("original-value")!=$("#sy-crm-event-edit-sidebar-duration").val();
        let updatedDate=$("#sy-crm-event-edit-sidebar-date").data("original-value")!=$("#sy-crm-event-edit-sidebar-date").val();
        let hasNewFiles = $("#sy-crm-event-edit-sidebar-options-new-attachment").get(0).files && $("#sy-crm-event-edit-sidebar-options-new-attachment").get(0).files.length > 0;
        for (const [editorId, quillInstance] of Object.entries(editVarsEditors)) {
            const currentContent = generate_event_escapeString(quillInstance.root.innerHTML); 
            const originalContent = $(`#${editorId}`).parent().data("original-value"); 
            if (originalContent != ""&&currentContent != originalContent) {
                editorHasChanges= true;  
   
                

            }
        }
        let initialTags = $('#sy-crm-event-edit-sidebar .crm_events_tags_selected_list').data('initial-tags')|| [];
       
        let currentTags=[];
        setTimeout(function() {
            let currentTags = [];
            let elements = $('#sy-crm-event-edit-sidebar .crm_events_tags_selected');
            
           
            elements.each(function() {
                let tagId = $(this).attr('data-id');
                currentTags.push(tagId);
            });
        let updatedTags= initialTags.sort().join(',') !== currentTags.sort().join(',');

        let listAssociatedUsers = [];

        $('#sy-event-edit-sidebar-users-list-trigger .sy-event-edit-sidebar-users-list-selected-item:visible').each(function() {
            listAssociatedUsers.push($(this).data('id'));
        });
        
        let oldValue = $('#sy-event-edit-sidebar-users-list-trigger').attr('data-old-value');
        let oldList = oldValue ? JSON.parse(oldValue).map(Number) : [];
        listAssociatedUsers.sort();
        oldList.sort();
        let recipients=[];
        let changedAssociatedUsers = listAssociatedUsers.length !== oldList.length || 
            listAssociatedUsers.some((value, index) => value !== oldList[index]);
            if($('#sy-crm-edit-event-send-email-checkbox').is(':checked')){

              
                recipients = $('input[name="sy-crm-edit-event-recipients[]"]').map(function () {
                    const value = $(this).val().trim();
                    return value;
                }).get().filter(v => v !== '');
            }
        if (changedAssociatedUsers||hasChanges||updatedTitle||hasNewFiles||editorHasChanges||updatedTags||updatedDuration||updatedDate||($('#sy-crm-edit-event-send-email-checkbox').is(':checked')&&recipients.length>0))
                    
         {
            $("#sy-crm-event-edit-sidebar-submit-btn").prop("disabled", false);
        } else {
            $("#sy-crm-event-edit-sidebar-submit-btn").prop("disabled", true);
        }
        }, 100); 
        

       
        
      
    }
 

    $(document).on("submit", "#sy-crm-event-edit-sidebar-form", function(e) {
        e.preventDefault();

        const formData = new FormData(this);
        isValid = true;
        //const quillContent = quillEditContent.root.innerHTML;
        //formData.append("content", quillContent);
        let variables= {};
        formData.append("action", "edit_generated_post_content");
        formData.append('event_date', $('#sy-crm-event-edit-sidebar-date').val());
        formData.append('event_dure', $('#sy-crm-event-edit-sidebar-duration').val());
        $('#sy-event-edit-sidebar-users-list-trigger .sy-event-edit-sidebar-users-list-selected-item:visible').each(function() {
            
            formData.append('associated_users[]', $(this).data('id'));
        });
        //formData.append("generatePdf", "on");
        const filesInput = $("#sy-crm-event-edit-sidebar-options-new-attachment");
        if (filesInput.length > 0 && filesInput[0].files.length > 0) {
            const files = filesInput[0].files;
            for (let i = 0; i < files.length; i++) {
                const file = files[i];

                const forbiddenExtensions = ["php", "js", "exe", "bat", "sh"];
                const fileExtension = file.name.split('.').pop().toLowerCase();

                if (forbiddenExtensions.includes(fileExtension)) {
                    isValid = false;
                    filesInput.parent().next(".text-error")
                        .text("Le fichier " + file.name + " a une extension non autorisée.")
                        .show();
                } else {
                    formData.append("additional_files[]", file);
                    filesInput.parent().next(".text-error").hide();
                }
            }
        }

        const docTitleInput = $('#sy-crm-event-edit-sidebar-event-title');
        if (!docTitleInput.val().trim()) {
            isValid = false;
            docTitleInput.parent().next('.text-error').show(); 
        } else {
            docTitleInput.parent().next('.text-error').hide(); 
        }
        const editorContents = getAllEditorContents(editVarsEditors);
        $('#sy-crm-event-edit-sidebar-vars').find('input, select').each(function () {
            const input = $(this);
            const isRequired = input.prop('required'); 
            
            if (isRequired && !input.val().trim()) { 
                isValid = false;
                input.parent().next('.text-error').show();
            } 
            else {
                input.parent().next('.text-error').hide();
                const value = $(this).val() || ""; 
                variables[input.attr('name')] = value;
                
                            
            }
        });
        
            for (const editorId in editorContents) {
                if (editorContents.hasOwnProperty(editorId)) {
                    const $editorElement = $(`#${editorId}`);
                    const varName = $editorElement.attr('name');
                    const content = editorContents[editorId];
            
                    const $errorMessageElement = $editorElement.parent().parent().next('.text-error');
            
                    if ($editorElement.attr('required') && (!content || content.trim() === '<p><br></p>')) {
                        isValid = false;
                        $editorElement.addClass('error'); 
                        
                        // Affiche le message d'erreur
                        $errorMessageElement.text('Ce champ est requis.').show();
                    } else {
                        $editorElement.removeClass('error');
                        
                        $errorMessageElement.text('').hide();
                    }
            
                    variables[varName] = content;
                }
            }

            //  $('# .crm_events_tags_selected_list')
            var selectedTags = [];
            
            $('#sy-crm-event-edit-sidebar .crm_events_tags_selected').each(function() {
                
                formData.append('selected_tags[]', $(this).data('id'));
            });

            let recipients=[];
            let send_attachments_via_link = $('#sy-crm-edit-event-send-mail-form-send-attachments-via-link').is(':checked') ? 1 : 0;

            if($('#sy-crm-edit-event-send-email-checkbox').is(':checked')){

                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                
                // Supprimer les anciens messages d'erreur
                $('#sy-crm-edit-event-send-email-section .text-error').remove();

                recipients = $('input[name="sy-crm-edit-event-recipients[]"]').map(function () {
                    const value = $(this).val().trim();

                    if (!value) {
                        $(this).parent().after('<p class="text-error text-error">Ce champ est requis</p>');
                        isValid = false;
                    } else if (!emailRegex.test(value)) {
                        $(this).parent().after('<p class="text-error text-error">Adresse email invalide</p>');
                        isValid = false;
                    }

                    return value;
                }).get();
                
            }/**/

        if(isValid)
        {
            $("#sy-crm-event-edit-sidebar").animate({ scrollTop: 0 }, 100, function() {

            
                $("#sy-crm-event-edit-sidebar-notif").removeClass('text-success text-error').addClass('text-info').text('Traitement en cours...');  
            })   
            formData.append('variables', JSON.stringify(variables));

            /**/recipients.forEach(email => {
                formData.append('recipients[]', email);
            });
            formData.append('send_attachments_via_link', send_attachments_via_link);
            formData.append('send_event_by_mail', $('#sy-crm-edit-event-send-email-checkbox').is(':checked')?1:0);
            $.ajax({
                url: ajax_object.ajax_url,
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                       // alert("event mis à jour avec succès.");
                        // location.reload(); 
                        $("#sy-crm-event-edit-sidebar").animate({ scrollTop: 0 }, 1000, function() {

            
                         $("#sy-crm-event-edit-sidebar-notif")
                         .text("Évènement mis à jour avec succès")
                         .addClass("text-success").removeClass("text-error")
                         .fadeIn()
                         .delay(500)
                         .fadeOut(function() {
                            location.reload();
                         });
                        })
                 } else {
                    $("#sy-crm-event-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {

            
                     $("#sy-crm-event-edit-sidebar-notif")
                         .text(response.data.message)
                         .removeClass("text-success").addClass("text-error")
                         .fadeIn()
                         .delay(500)
                         .fadeOut(
                             
                         );
                        })
                 }
                   
                },
                error: function() {
                    alert("Une erreur s\'est produite lors de la mise à jour.");
                }
            });
            
        }
    });

    // Suppression des pieces jointes
    $(document).on("click", ".crm-event-delete-attachment", function() {
        const button = $(this);
        const eventId = button.data("event-id");
        const docUrl = button.data("url");
       
        const confirmation = confirm("Êtes-vous sûr de vouloir supprimer cette pièce jointe?");
        
    if (confirmation) { 
        $("#sy-crm-event-edit-sidebar").animate({ scrollTop: 0 }, 100, function() {

            
            $("#sy-crm-event-edit-sidebar-notif").removeClass('text-success text-error').addClass('text-info').text('Traitement en cours...');  
        })
        $.ajax({
            url: ajax_object.ajax_url,
            method: "POST",
            data: {
                action: "delete_attachement",
                // security: deleteeventNonce, // Nonce généré pour la sécurité
                event_id: eventId,
                attachement_url: docUrl,
            },
            success: function(response) {
                if (response.success) {
                    //alert(response.data.message);
                   // location.reload();
                   $("#sy-crm-event-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {

                   let msgContainer=$('#sy-crm-event-edit-sidebar').hasClass('open')?"sy-crm-event-edit-sidebar-notif":'sy-crm-event-edit-sidebar-notif';
                   $(`#${msgContainer}`)
                   .text("Attachement supprimé avec succès")
                   .addClass("text-success").removeClass("text-error")
                   .fadeIn()
                   .delay(500)
                   .fadeOut(function() {
                       location.reload();
                   });
                })
           } else {
            $("#sy-crm-event-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {

                let msgContainer=$('#sy-crm-event-edit-sidebar').hasClass('open')?"sy-crm-event-edit-sidebar-notif":'sy-crm-event-edit-sidebar-notif';
               
                $(`#${msgContainer}`)
                   .text(response.data.message)
                   .removeClass("text-success").addClass("text-error")
                   .fadeIn()
                   .delay(500)
                   .fadeOut(
                       
                   );
                })
           }
                
            },
            error: function() {
                alert("Une erreur s\'est produite lors de la suppression du event.");
            },
        });
    }


    });
    // Suppression des evenements
    $(document).on("click", ".crm-event-delete-event", function(e) {
        e.preventDefault();
        const eventId = $(this).data("id");
        const containerNotif = $(this).data("notif-container");

        if (confirm("Êtes-vous sûr de vouloir supprimer cet évènement ?")) {
            $("#sy-crm-event-edit-sidebar").animate({ scrollTop: 0 }, 100, function() {
                $("#sy-crm-event-edit-sidebar-notif").removeClass('text-success text-error').addClass('text-info').text('Traitement en cours...');  
            })
            $.ajax({
                url: ajax_object.ajax_url,
                type: "POST",
                data: {
                    action: "delete_event",
                    event_id: eventId,
                    security: ajax_object.security
                },
                success: function(response) {
                    if (response.success) {
                        if(containerNotif=="sy-crm-event-edit-sidebar-notif"){
                            $("#sy-crm-event-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {
                                $(`#${containerNotif}`)
                                    .text(response.data.message)
                                    .addClass("text-success").removeClass("text-error text-info")
                                    .fadeIn()
                                    .delay(500)
                                    .fadeOut(function() {
                                        const url = new URL(window.location);
                                    
                                        location.reload();
                                    });
                                })

            
                        }
                        else{
                            $(`#${containerNotif}`)
                            .text(response.data.message)
                            .addClass("text-success").removeClass("text-error text-info")
                            .fadeIn()
                            .delay(500)
                            .fadeOut(function() {
                                const url = new URL(window.location);
                               /* if (url.searchParams.has('event')) {
                                    url.searchParams.delete('event');
                                    history.replaceState(null, '', url.toString());
                                }*/
                                location.reload();
                            });
                        }
                        
                    } else {
                        $(`#${containerNotif}`)
                            .text(response.data.message)
                            .removeClass("text-success").addClass("text-error")
                            .fadeIn()
                            .delay(500)
                            .fadeOut();
                    }
                },
                error: function() {
                    $(`#${containerNotif}`)
                        .text("Erreur lors de la suppression du event.")
                        .removeClass("text-success").addClass("text-error")
                        .fadeIn()
                        .delay(500)
                        .fadeOut();
                }
            });
        }
    });



    $(document).on('click', '#add-new-attachment-btn', function () {
        $("#sy-crm-event-edit-sidebar-options-new").show();
    });
    $(document).on('click', '#add-new-event-attachment-btn', function () {
        $("#sy-crm-event-edit-sidebar-options-new").show();
    });
    function getFileIcon(fileExtension) {
        switch (fileExtension) {
            case 'pdf':
                return 'pdf-icon.svg';
            case 'doc':
            case 'docx':
                return 'word-icon.svg';
            case 'xls':
            case 'xlsx':
                return 'excel-icon.svg';
            case 'jpg':
            case 'jpeg':
            case 'png':
                return 'image-icon.svg';
            case 'zip':
            case 'rar':
                return 'zip-icon.svg';
            default:
                return 'default-icon.svg';
        }
    }
    


    $('#sy-event-edit-sidebar-users-list-trigger').on('click', function() {
        if($(this).data('edit')==1){
   
           $('#sy-event-edit-sidebar-users-list').toggle();
       }
   });
   
   // Ajouter l'utilisateur sélectionné en tant que tag
   $('#sy-event-edit-sidebar-users-list').on('click', '.sy-event-edit-sidebar-users-list-item', function() {
       let userId = $(this).data('id');
       let userName = $(this).text();
       $(this).hide();
   
       // Vérifier si l'utilisateur est déjà ajouté
       if ($(`#sy-event-edit-sidebar-users-list-trigger span[data-id="${userId}"]`).length === 0) {
           $('#sy-event-edit-sidebar-users-list-trigger').append(`<span class="sy-event-edit-sidebar-users-list-selected-item" data-id="${userId}">${userName} ✖</span>`);
       }
       else{
   
       $(`#sy-event-edit-sidebar-users-list-trigger span[data-id="${userId}"]`).show()
       }
   
       $('#sy-event-edit-sidebar-users-list').hide(); 
       checkForUpdateChanges()
   });
   
   $('#sy-event-edit-sidebar-users-list-trigger').on('click', '.sy-event-edit-sidebar-users-list-selected-item', function(e) {
       if($('#sy-event-edit-sidebar-users-list-trigger').data('edit')==1){
           //
           let userId=$(this).data('id');
           $(this).remove();
           $(`#sy-event-edit-sidebar-users-list .sy-event-edit-sidebar-users-list-item[data-id="${userId}"]`).show();
           checkForUpdateChanges();
           e.stopPropagation()
       }
   });
   //add recipients
        

$(document).on('change', '#sy-crm-edit-event-send-email-checkbox', function () {
    if ($(this).is(':checked')) {
        $('#sy-crm-edit-event-send-email-section').slideDown();
        if($('#sy-crm-edit-event-send-mail-options').data('visibility')=='on'){
            $('#sy-crm-edit-event-send-mail-options').slideDown()
        }
        else{
            $('#sy-crm-edit-event-send-mail-options').slideUp()
        }
    } else {
        $('#sy-crm-edit-event-send-email-section').slideUp();
        $('#sy-crm-edit-event-send-mail-options').slideUp()
    }
  //  if($('#sy-crm-event-edit-sidebar-submit-btn').is(':visible')){
        checkForUpdateChanges();
  /*  }
else{
    checkForEnvoiChanges();
} */
});
$(document).on('click', '.sy-crm-edit-event-add-recipient-btn', function () {
    $('#sy-crm-edit-event-mail-recipients-wrapper').append(`
        <div class="recipient-group">
            <div  class="recipient-group-top">
            <input type="email" name="sy-crm-edit-event-recipients[]" class="sy-crm-edit-event-recipients" required>
            <button type="button" class="sy-crm-edit-event-remove-recipient-btn">-</button>
            </div>
            
        </div>
    `);
});
function checkForEnvoiChanges(){

    setTimeout(function() {
       
    
   
    let recipients=[];
        if($('#sy-crm-edit-event-send-email-checkbox').is(':checked')){

          
            recipients = $('input[name="sy-crm-edit-event-recipients[]"]').map(function () {
                const value = $(this).val().trim();
                return value;
            }).get().filter(v => v !== '');
        }
    if (($('#sy-crm-edit-event-send-email-checkbox').is(':checked')&&recipients.length>0))
                
     {
        $("#generate_event_envoi_btn").prop("disabled", false);
        
    } else {
        $("#generate_event_envoi_btn").prop("disabled", true);
    }
    }, 100); 
    

   
    
}
$(document).on('click', '#generate_event_envoi_btnold', function (e) {
    e.preventDefault();
    
    let isValid = true;
    $('.text-error').remove();
    let recipients=[];
    let send_attachments_via_link = $('#sy-crm-edit-event-send-mail-form-send-attachments-via-link').is(':checked') ? 1 : 0;

    if($('#sy-crm-edit-event-send-email-checkbox').is(':checked')){

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        // Supprimer les anciens messages d'erreur
        $('#sy-crm-edit-event-send-email-section .text-error').remove();

        recipients = $('input[name="sy-crm-edit-event-recipients[]"]').map(function () {
            const value = $(this).val().trim();

            if (!value) {
                $(this).parent().after('<p class="text-error text-error">Ce champ est requis</p>');
                isValid = false;
            } else if (!emailRegex.test(value)) {
                $(this).parent().after('<p class="text-error text-error">Adresse email invalide</p>');
                isValid = false;
            }

            return value;
        }).get();
    }
        

     if (!isValid) return;

    const $notif = $('#sy-crm-event-edit-sidebar-notif');
    $("#sy-crm-event-edit-sidebar").animate({ scrollTop: 0 }, 100, function() {

            
        $("#sy-crm-event-edit-sidebar-notif").removeClass('text-success text-error').addClass('text-info').text('Traitement en cours...');  
    }) 
    
//$('.sy-crm-send-mail-submit-btn').attr('disabled',true)
    $.ajax({
        url: ajax_object.ajax_url,
        type: 'POST',
        data: {
            action: 'send_event_to_emails',
            event_id: $(this).data('id'),
            recipients: recipients,
            send_attachments_via_link:send_attachments_via_link
        },
        success: function (response) {
            if (response.success) { 
                $('.sy-crm-send-mail-submit-btn').attr('disabled',false)
                $("#sy-crm-event-send-mail-sidebar").animate({ scrollTop: 0 }, 100, function() {

                $notif.text('Email(s) envoyé(s) avec succès.')
                .addClass("text-success").removeClass("text-error text-info")
                .fadeIn()
                .delay(500)
                .fadeOut(function() {
                    
                    location.reload();
                });
            });
            } else {
                $notif.text('Erreur lors de l’envoi des emails.').addClass('text-error').removeClass("text-success text-info");
                console.error(response);
            }
        },
        error: function () {
            $notif.text('Erreur AJAX lors de la requête.').addClass('text-error').removeClass("text-success text-info");
        }
    });
})
$(document).on('click', '#generate_event_envoi_btn', function (e) {
    e.preventDefault();

    // Étape 1 : Vérifier visibilité
    if (!$('#sy-crm-edit-event-send-email-section-container').is(':visible')) {
        $('#sy-crm-edit-event-send-email-section-container').show();
        $('#sy-crm-edit-event-send-email-checkbox').prop('checked', true).trigger('change');
        $('#sy-crm-edit-event-send-email-checkbox').parent().hide();
        console.log($('#sy-crm-edit-event-send-email-checkbox').parent());
        return;
    }

    let isValid = true;
    $('.text-error').remove();
    let recipients = [];
    let send_attachments_via_link = $('#sy-crm-edit-event-send-mail-form-send-attachments-via-link').is(':checked') ? 1 : 0;

    if ($('#sy-crm-edit-event-send-email-checkbox').is(':checked')) {

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        // Supprimer les anciens messages d'erreur
        $('#sy-crm-edit-event-send-email-section .text-error').remove();

        recipients = $('input[name="sy-crm-edit-event-recipients[]"]').map(function () {
            const value = $(this).val().trim();

            if (!value) {
                $(this).parent().after('<p class="text-error text-error">Ce champ est requis</p>');
                isValid = false;
            } else if (!emailRegex.test(value)) {
                $(this).parent().after('<p class="text-error text-error">Adresse email invalide</p>');
                isValid = false;
            }

            return value;
        }).get();
    }

    if (!isValid) return;

    const $notif = $('#sy-crm-event-edit-sidebar-notif');
    $("#sy-crm-event-edit-sidebar").animate({ scrollTop: 0 }, 100, function () {
        $notif.removeClass('text-success text-error').addClass('text-info').text('Traitement en cours...');
    });

    $.ajax({
        url: ajax_object.ajax_url,
        type: 'POST',
        data: {
            action: 'send_event_to_emails',
            event_id: $(this).data('id'),
            recipients: recipients,
            send_attachments_via_link: send_attachments_via_link
        },
        success: function (response) {
            if (response.success) {
                $('.sy-crm-send-mail-submit-btn').attr('disabled', false);
                $("#sy-crm-event-send-mail-sidebar").animate({ scrollTop: 0 }, 100, function () {
                    $notif.text('Email(s) envoyé(s) avec succès.')
                        .addClass("text-success").removeClass("text-error text-info")
                        .fadeIn()
                        .delay(500)
                        .fadeOut(function () {
                            location.reload();
                        });
                });
            } else {
                $notif.text('Erreur lors de l’envoi des emails.').addClass('text-error').removeClass("text-success text-info");
                console.error(response);
            }
        },
        error: function () {
            $notif.text('Erreur AJAX lors de la requête.').addClass('text-error').removeClass("text-success text-info");
        }
    });
});

// Retirer un champ
$(document).on('click', '.sy-crm-edit-event-remove-recipient-btn', function () {
    $(this).closest('.recipient-group').remove();
});
$(document).on('input', 'input[name="sy-crm-edit-event-recipients[]"]', function (e) {
    $(this).parent().next('.text-error').remove();
   // if($('#sy-crm-event-edit-sidebar-submit-btn').is(':visible')){
        checkForUpdateChanges()
    /*}
else{
    checkForEnvoiChanges();
}  */  
   
});

   //
    //fin edition

$('#sy-event-add-sidebar-users-list-trigger').on('click', function() {
    $('#sy-event-add-sidebar-users-list').toggle();
});

// Ajouter l'utilisateur sélectionné en tant que tag
$('#sy-event-add-sidebar-users-list').on('click', '.sy-event-add-sidebar-users-list-item', function() {
    let userId = $(this).data('id');
    let userName = $(this).text();
    $(this).hide();

    // Vérifier si l'utilisateur est déjà ajouté
    if ($(`#sy-event-add-sidebar-users-list-trigger span[data-id="${userId}"]`).length === 0) {
        $('#sy-event-add-sidebar-users-list-trigger').append(`<span class="sy-event-add-sidebar-users-list-selected-item" data-id="${userId}">${userName} ✖</span>`);
    }

    $('#sy-event-add-sidebar-users-list').hide(); 
});

$('#sy-event-add-sidebar-users-list-trigger').on('click', '.sy-event-add-sidebar-users-list-selected-item', function(e) {
    e.stopPropagation()
    let userId=$(this).data('id');
    $(this).remove();
    $(`#sy-event-add-sidebar-users-list .sy-event-add-sidebar-users-list-item[data-id="${userId}"]`).show()

});

// Cacher la liste si on clique en dehors
$(document).on('click', function(e) {
    if (!$(e.target).closest('#sy-event-add-sidebar-users-list-trigger, #sy-event-add-sidebar-users-list').length) {
        $('#sy-event-add-sidebar-users-list').hide();
    }
    if (!$(e.target).closest('#sy-event-edit-sidebar-users-list-trigger, #sy-event-edit-sidebar-users-list').length) {
        $('#sy-event-edit-sidebar-users-list').hide();
    }
    
});/**/

$(document).on('change', '#sy-crm-new-event-send-email-checkbox', function () {
    if ($(this).is(':checked')) {
        $('#sy-crm-new-event-send-email-section').slideDown();
        $('#sy-crm-new-event-sidebar-submit-btn').text('Envoyer')
        if($('#sy-crm-event-add-send-email-section-attachment-option').data('autorise-pdf')=='on'){

        $('#sy-crm-event-add-send-email-section-attachment-option').slideDown();
        }
    } else {
        $('#sy-crm-new-event-send-email-section').slideUp();
        $('#sy-crm-new-event-sidebar-submit-btn').text('Générer')

        $('#sy-crm-event-add-send-email-section-attachment-option').slideUp();
    }
});
$(document).on('click', '.sy-crm-new-event-add-recipient-btn', function () {
    $('#sy-crm-new-event-mail-recipients-wrapper').append(`
        <div class="recipient-group">
            <div  class="recipient-group-top">
            <input type="email" name="sy-crm-new-event-recipients[]" class="sy-crm-new-event-recipients" required>
            <button type="button" class="sy-crm-new-event-remove-recipient-btn">-</button>
            </div>
            
        </div>
    `);
});

// Retirer un champ
$(document).on('click', '.sy-crm-new-event-remove-recipient-btn', function () {
    $(this).closest('.recipient-group').remove();
});
$(document).on('input', 'input[name="sy-crm-new-event-recipients[]"]', function (e) {
    $(this).parent().next('.text-error').remove();
    });
//////////////////


const labelsArray = {
    'user_status': 'Statut utilisateur',
    'display_name': 'Nom affiché',
    'nickname': 'Surnom',
    'first_name': 'Prénom',
    'last_name': 'Nom',
    'description': 'Description',
    'wc_last_active': 'Dernière activité WooCommerce',
    'tax_no': 'Numéro fiscal',
    'user_mailing': 'Adresse de messagerie utilisateur',
    'shipping_first_name': 'Prénom (livraison)',
    'shipping_last_name': 'Nom (livraison)',
    'shipping_company': 'Entreprise (livraison)',
    'shipping_address_1': 'Adresse 1 (livraison)',
    'shipping_address_2': 'Adresse 2 (livraison)',
    'shipping_city': 'Ville (livraison)',
    'shipping_postcode': 'Code postal (livraison)',
    'shipping_country': 'Pays (livraison)',
    'shipping_state': 'Région/État (livraison)',
    'shipping_phone': 'Téléphone (livraison)',
    'shipping_email': 'E-mail (livraison)',
    'billing_first_name': 'Prénom (facturation)',
    'billing_last_name': 'Nom (facturation)',
    'billing_company': 'Entreprise (facturation)',
    'billing_address_1': 'Adresse 1 (facturation)',
    'billing_address_2': 'Adresse 2 (facturation)',
    'billing_city': 'Ville (facturation)',
    'billing_postcode': 'Code postal (facturation)',
    'billing_country': 'Pays (facturation)',
    'billing_state': 'Région/État (facturation)',
    'billing_phone': 'Téléphone (facturation)',
    'billing_email': 'E-mail (facturation)',
    'reference_template': 'Référence modèle',
    'creation_date': 'Date de création',
    'template_name': 'Nom template',
    'document_name': 'Nom du document',
    'display_author_name': 'Auteur',
    'display_author_bio': 'Description de l\'auteur',
    'display_user_bio': 'Description du client',
    'civilite': 'Civilité'
};
$('#sy-crm-event-add-note-btn').click(function(){
    const userId = $(this).data('user-id');
    const templateId = $(this).data('defaulte-template');
    if(templateId){
    $('#sy-crm-event-add-sidebar-templates-select').val(templateId).trigger('change');
    $('.sy-crm-event-add-sidebar-templates-container').hide();
    $('#sy-crm-event-add-sidebar').addClass('open').show();
    $('.sy-crm-event-sidebar-header h5').html('Ajouter une note')
  

    }
    else{
        alert('le model pour les notes n\'est pas configuré')
    }
   
})
$('#sy-crm-event-show-add-sidebar-btn').click(function() {
    $('.sy-crm-event-add-sidebar-templates-container').show();
    $('#sy-crm-event-add-sidebar').addClass('open').show();
    $("#sy-crm-event-edit-sidebar").removeClass("open");
    $('.sy-crm-event-sidebar-header h5').html('Ajouter un évènement')
  
    const url = new URL(window.location);
    if (url.searchParams.has('event')) {
        url.searchParams.delete('event');
        history.replaceState(null, '', url.toString());
    }
    $(".sy-crm-event-note-sidebar").removeClass("open").hide();


});
function upadteDuration(){
    let updatedDuration=$("#sy-crm-event-edit-sidebar-duration").data("original-value")!=$("#sy-crm-event-edit-sidebar-duration").val();
    if(updatedDuration){
        $.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'update_event_duration',
                event_id: $('#generate_event_envoi_btn').data('id'),
                duration: $("#sy-crm-event-edit-sidebar-duration").val(),
               
            },
            success: function (response) {
                if (response.success) { 
                   console.log(response)
                } else {
                    console.error(response);
                }
            },
            error: function () {
                console.error('Erreur AJAX lors de la requête.')
            }
        });
    }
    ;

}

const quillEditors = {};

function decodeHtmlEntities(str) {
    var txt = document.createElement('textarea');
    txt.innerHTML = str;
    return txt.value;
}
$('#sy-crm-event-add-sidebar-templates-select').change(function() {
            const templateId = $('#sy-crm-event-add-sidebar-templates-select').val();
            const userId = $('#sy-crm-event-show-add-sidebar-btn').data('user-id');
            if (!templateId || !userId) {
                $('#sy-crm-event-add-sidebar-template-content, #gen-event-sidebar-associated-templates').hide();
                return;
            }

            //const userId = $('#user_select').val();
//

            $('#sy-crm-new-event-mail-recipients-wrapper .recipient-group:not(:first)').remove();
$('#sy-crm-event-add-send-email-section-attachment-option').slideUp();

$('#sy-crm-new-event-send-email-checkbox').removeAttr('checked')
$('#sy-crm-new-event-send-mail-form-send-attachments-via-link').removeAttr('checked')
$('#sy-crm-new-event-send-email-section').slideUp();



//
            $.get(ajax_object.ajax_url, { action: 'get_template_variables', template_id: templateId, user_id: userId }, function(response) {
                        if (response.success) {
                            const container = $('#sy-crm-event-add-sidebar-vars');
                            container.empty();
                            const today = new Date();
                            const formattedDate =response.data.date_creation
                            //const formattedDate = `${today.getDate().toString().padStart(2, '0')}-${(today.getMonth() + 1).toString().padStart(2, '0')}`; // JJ-MM
                            const variables = response.data.variables;
                            let associatedTemplates = response.data.associated_templates;
                            let associatedTemplatesData = response.data.associated_templates_data;
                            let preFilled = response.data.pre_filled;
                            const templateRacine = response.data.racine;
                            //const compteur = (response.data.compteur || 1).toString().padStart(4, '0');
                            const compteur = response.data.compteur || 1;
                            const templateNom = decodeHtmlEntities(response.data.templateNom);
                            const societeNom = response.data.societeNom;
                            //- ${societeNom} -
                            const docTitle = `${templateNom} - ${formattedDate}`;
                            $('#sy-crm-event-sidebar-title-input').val(docTitle);
                            $('#sy-crm-event-add-sidebar-date').val(today.toISOString().split('T')[0])

                            let hiddenChamps = [

                                'devis','factures-echues','facture',
                                'template_name', 'document_name', 'user_status', 'display_name', 'display_author_name', 'display_author_bio', 'first_name', 'last_name', 'display_user_bio',
                                'wc_last_active', 'tax_no', 'user_mailing', 'shipping_first_name', 'shipping_last_name', 'shipping_company',
                                'shipping_address_1', 'shipping_address_2', 'shipping_city', 'shipping_postcode',
                                'shipping_country', 'shipping_state', 'shipping_phone', 'shipping_email',
                                'reference_template', 'creation_date', 'billing_first_name', 'billing_last_name',
                                'billing_company', 'billing_address_1', 'billing_address_2', 'billing_city',
                                'billing_postcode', 'billing_country', 'billing_state', 'billing_phone',
                                'billing_email', 'civilite','don_ref', 'don_date', 'don_moyen', 'don_montant_nb', 'don_montant_txt', 'don_etat', 'don_etat','don_commentaire','est_annule'
                            ];
                            

                            variables.forEach(variable => {

                                        let cleanedVariable = variable.replace(/[*#@]/g, '').replace(/[*#@]/g, '').trim();
                                        let value = preFilled[variable] || '';
                                        if ((cleanedVariable == 'display_author_bio' || cleanedVariable == 'display_user_bio')&& !variable.includes('@')) {
                                            variable = `${variable}@`;
                                        }
                                        // Tests sur la version nettoyée de la variable
                                        if (cleanedVariable === 'reference_template') {
                                            value = `${templateRacine}-${formattedDate}-${compteur}`;
                                        } else if (cleanedVariable === 'template_name') {
                                            value = `${templateNom}`;
                                        } 
                                        /*else if (cleanedVariable === 'creation_date') {
                                            const day = today.getDate().toString().padStart(2, '0');
                                            const month = (today.getMonth() + 1).toString().padStart(2, '0');
                                            const year = today.getFullYear();
                                            value = `${year}-${month}-${day}`;
                                        }*/
                                        else if (cleanedVariable === 'event_name' || cleanedVariable === 'document_name') {
                                            value = docTitle;
                                        }

                                        // Application des styles pour les champs cachés
                                        //let hiddenChamps = ['template_name*', 'template_name', 'reference_template*', 'reference_template','event_name','document_name'];
                                        //let readOnlyChamps = ['creation_date#*','creation_date*', 'creation_date', 'display_author_name', 'display_author_name*', 'display_author_name *', 'display_author_bio', 'display_author_bio*', 'display_author_bio *', 'display_user_bio', 'display_user_bio *', 'display_user_bio @', 'display_user_bio @ *', 'display_user_bio * @'];

                                        let hiddenStyle = hiddenChamps.includes(cleanedVariable) ? 'style="display:none;"' : '';
                                        //const readOnlyAttr = readOnlyChamps.includes(variable) ? 'readonly' : '';
                                        const readOnlyAttr ='';
                                        if (variable.includes('@')) {
                                            let requiredChamp = variable.includes('*');
                                            value = value.replace(/\r\n|\r|\n/g, '<br>');
                                            hiddenStyle = hiddenChamps.includes(cleanedVariable) ? 'style="display:none;"' : 'style="height:260px;"';
                                                                  
                                            const labelText = (labelsArray[variable.replace('@', '').replace('*', '').trim()] || variable.replace('@', '').replace('*', '').trim());
                                            const sanitizedVariable = variable.replace(/'/g, '&#39;');
                                            const sanitizedVariableId = variable.replace(/'/g, '&#39;').replace(/[@*]/g, 'a').replace(/\s+/g, '_');
                                            const newvalue = generate_event_escapeString(value);
                                            container.append(`
                                                <div class="variable__item editor__container"  ${hiddenStyle}>
                                                    <div style="height:260px; "data-original-value="${newvalue}">
                                                        <div id="${sanitizedVariableId}" name="${sanitizedVariable}" style="width: -webkit-fill-available; height:200px;" ${requiredChamp ? 'required' : ''} ${readOnlyAttr}>${value}</div>
                                                    </div>
                                                </div>
                                                <div class="text-error" style="display:none;">Ce champ est requis.</div>
                                            `);



                                            const quillInstance = new Quill(`#${sanitizedVariableId}`, {
                                                theme: "snow",
                                                placeholder: `${labelText}${requiredChamp ? ' *' : ''}`,
                                                readOnly: readOnlyAttr,

                                            });
                                            quillEditors[sanitizedVariableId] = quillInstance;


                                            quillInstance.on("text-change", function() {
                                                $(document).trigger("quill-new-text-change", [sanitizedVariableId, quillInstance]);
                                            });



                                        } else if (variable.includes('|')) {
                                            const options = variable.split('|').slice(1);
                                            const parts = variable.split('|');
                                            let labelText = parts[0].trim();
                                            let requiredChamp = labelText.includes('*');
                                            labelText = labelText.replace(/[^a-zA-Z0-9\s]/g, ''); // Nettoyage
                                            const sanitizedVariable = variable.replace(/'/g, '&#39;'); // Gestion des apostrophes

                                            container.append(`
                                                <div class="variable__item"${hiddenStyle}>
                                                    <select class="crm-doc-select"data-original-value="${value}" id="${sanitizedVariable}" name="${sanitizedVariable}" ${requiredChamp ? 'required' : ''}${readOnlyAttr}>
                                                    <option value="">${labelText}${requiredChamp ? ' *' : ''}</option>    
                                                    ${options.map(option => `<option value="${option}">${option}</option>`).join('')}
                                                    </select>
                                                </div>
                                                <div class="text-error" style="display:none;">Ce champ est requis.</div>
                                            `);
                                        } 
                                        else if (variable.includes('#')) {
                                            const cleanedVariable = variable.replace(/[*#@]/g, '').replace(/[*#@]/g, '').trim(); 
                                            const labelText = labelsArray[cleanedVariable] || cleanedVariable;
                                            let requiredChamp = labelText.includes('*');
                                            //labelText = labelText.replace(/[^a-zA-Z0-9\s]/g, '');
                                            container.append(`
                                                <div class="variable__item"${hiddenStyle}>
                                                    <label class="crm-doc-label"for="${variable}">${labelText} ${requiredChamp ? ' *' : ''} :</label>
                                                    <input class="crm-doc-input"type="date" data-original-value="${value}" id="${variable}" name="${variable}" value="${value}"  ${requiredChamp ? 'required' : ''}${readOnlyAttr}/>
                                                </div>
                                                <div class="text-error" style="display:none;">Ce champ est requis.</div>
                                            `);
                                        } 
                                        else {
                                            const requiredChamp = variable.includes('*');
                                            const cleanedVariable = variable.replace(/\*\s*/g,'');
                                                const labelText = labelsArray[cleanedVariable] || cleanedVariable;
                                                const sanitizedVariable = cleanedVariable.replace(/'/g, '&#39;'); // Gestion des apostrophes

                                                if (requiredChamp) {
                                                    //value = preFilled[cleanedVariable] || ''; 
                                                    container.append(`
                                                        <div class="variable__item"${hiddenStyle}>
                                                            <input class="crm-doc-input" placeholder="${labelText} * "type="text"data-original-value="${value}" id="${variable}" name="${variable}" value="${value}" required ${readOnlyAttr}/>
                                                        </div>
                                                        <div class="text-error" style="display:none;">Ce champ est requis.</div>
                                                    `);
                                                } else {
                                                    //value = preFilled[variable] || '';
                                                    container.append(`
                                                        <div class="variable__item"${hiddenStyle}>
                                                             <input class="crm-doc-input"type="text"placeholder="${labelText} " id="${variable}" name="${variable}" value="${value}" ${readOnlyAttr}/>
                                                        </div>
                                                    `);
                                                }
                                            }
                            });

                            container.show();           
                            if (associatedTemplatesData && associatedTemplatesData.length > 0) {
                                    const associatedContainer = $('#gen-event-sidebar-associated-templates');
                                    associatedContainer.empty();
                                    associatedContainer.append('<p>Le template sélectionné a des templates associés :</p>');
                                    // Construction du tableau HTML
                                    associatedContainer.append(`
                                        <table class="associated-templates-table">
                                            <thead>
                                                <tr>
                                                    <th></th>
                                                    <th>Nom de la template</th>
                                                    <th>Nom de l'évènement à générer</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                ${associatedTemplatesData.map(template => `
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" id="template_${template.id}" class="associated-template" value="${template.id}" checked />
                                                        </td>
                                                        <td>
                                                            <label class="crm-doc-label" for="template_${template.id}">${template.name}</label>
                                                        </td>
                                                        <td>
                                                            <input type="text" id="nom_doc_${template.id}" class="nom-doc-input" value="${template.nom_doc}" />
                                                            <div class="text-error" style="display:none;">Le nom du l'évènement est requis.</div>

                                                        </td>
                                                    </tr>
                                                `).join('')}
                                            </tbody>
                                        </table>
                                    `);

                                associatedContainer.append(`
                                    <div class="generate_other_events_container">
                                        <input type="checkbox" id="generate-associated-events" />
                                        <label class="crm-doc-label"for='generate-associated-events'>
                                            Voulez-vous générer les events associés ?
                                        </label>
                                    </div>
                                `);
                            $('#gen-event-sidebar-associated-templates').show();
                            }

           // $('#gen-event-sidebar-event-title-container').show();

            $('#sy-crm-event-add-sidebar-template-content').slideDown();
            const autoriseeventsJoints = response.data.autorise_documents_joints;
            const autorisepdf = response.data.template_autorise_generation_pdf;

            // Afficher le champ d'upload si l'option est activée autorise_documents_joints
            if (autoriseeventsJoints === 'on') {

                $('#sy-crm-event-add-sidebar-options').slideDown(); 
            }
            else{
                $('#sy-crm-event-add-sidebar-options').slideUp(); 
            }
            if($('#sy-crm-event-add-send-email-section-attachment-option').length>0)
            {
                if(autoriseeventsJoints === 'on'||autorisepdf === 'on'){
                $('#sy-crm-event-add-send-email-section-attachment-option').data('autorise-pdf',autorisepdf); 
            }
            else{
                $('#sy-crm-event-add-send-email-section-attachment-option').data('autorise-pdf',autorisepdf); 
            }
        }
            if(response.data.autorise_association_users=='on'){
                $('#sy-crm-event-add-sidebar-association-users-options').show();
            }
            else{
                $('#sy-crm-event-add-sidebar-association-users-options').hide();   
            }

        }
    });
});
$(document).on('change','#sy-crm-event-add-sidebar-options-files', function () {
    const filesInput = $('#sy-crm-event-add-sidebar-options-files');
    if($('#sy-crm-event-add-send-email-section-attachment-option').length>0&&$('#sy-crm-new-event-send-email-checkbox').is(':checked'))
        {
    if (filesInput.length > 0 && filesInput[0].files.length > 0||$('#sy-crm-event-add-send-email-section-attachment-option').data('autorise-pdf')=='on') {
        $('#sy-crm-event-add-send-email-section-attachment-option').slideDown();

    }
    else{
       

        $('#sy-crm-event-add-send-email-section-attachment-option').slideUp();
        

    }
}

})
//gen_event_tag 
$(document).on('click', '.crm_events_tags_tag', function() {
    var tagName = $(this).text();
    var tagClass =  tagName.toLowerCase().replace(/[^a-z0-9\-_]/g, '-');
    var tagId = $(this).data('id');
    var style=$(this).attr('style')
    $(this).hide();
    var selectedContainer = $(this).parent().next('.crm_events_tags_selected_list');
    if (selectedContainer.find('.crm_events_tags_selected[data-id="' + tagId + '"]').length === 0) {
        var tagElement = $('<span class="crm_events_tags_selected event_tag ' + tagClass + '" data-id="' + tagId + '"style="' + style + '">' + tagName + ' <span class="crm_events_tags_remove" data-id="' + tagId + '">x</span></span>');
        if(selectedContainer.hasClass('crm_events_tags_selected_list_edit_sideBar')){
            checkForUpdateChanges();
        }
        selectedContainer.append(tagElement);
    }
});
$(document).on('click', '.crm_events_tags_selected', function(e) {
    e.preventDefault()
    if(!$(this).hasClass('disabled'))
        {
            selectedContainer=$(this).parent();
            if(selectedContainer.hasClass('crm_events_tags_selected_list_edit_sideBar')){
                checkForUpdateChanges();
            }
            var tagId = $(this).data('id');
            $(this).closest('.crm_events_tags_selected_list').prev('.crm_events_tags_list')
            .find('.crm_events_tags_tag[data-id="' + tagId + '"]').show();

            $(this).remove();
        }
});
$(".event-duration-input").on("blur", function () {
    let input = $(this).val().trim(); 
    let infoDiv = $(this).parent().parent().next('.duration-warning');

    // Formater l'input
    if (/^\d+$/.test(input)) {
        input = input + "h00";
    } else if (/^(\d+)[:h](\d{1,2})$/.test(input)) {
        input = input.replace(":", "h");
        let parts = input.split("h");
        let hours = parts[0];
        let minutes = parts[1].padStart(2, "0");
        input = `${hours}h${minutes}`;
    } else {
        input = "0h00";
    }

    $(this).val(input);

    let match = input.match(/^(\d+)h(\d+)$/);
    if (match) {
        let hours = parseInt(match[1], 10);
        let minutes = parseInt(match[2], 10);

        if (hours > 24 || (hours === 24 && minutes > 0)) {
            infoDiv.html('<span style="color: red; font-size: 12px; display: block; margin-top: 5px;">Durée supérieure à 24 heures !</span>');
        } else {
            infoDiv.empty(); 
        }
    } else {
        infoDiv.empty(); 
    }
});



$(".sy-event-sidebar-custom-info-container").hover(
    function() {
        $(this).find(".sy-event-sidebar-custom-info-tooltip").fadeIn(200);
    },
    function() {
        $(this).find(".sy-event-sidebar-custom-info-tooltip").fadeOut(200);
    }
);

//
function getAllEditorContents(editorsList) {
const editorContents = {};
for (const id in editorsList) {
if (editorsList.hasOwnProperty(id)) {
    editorContents[id] = editorsList[id].root.innerHTML; 
}
}
return editorContents;
}
$(document).on('change', '#generate-associated-events', function () {
});
//gestion btn submit
$(document).on("input", "#sy-crm-event-add-sidebar-template-content input",checkForAddChanges );
$(document).on("change", "#sy-crm-event-add-sidebar-template-content select",checkForAddChanges );
$(document).on("quill-new-text-change", function (event, editorId, quillInstance) {
checkForAddChanges();
});

function checkForAddChanges() {
let hasChanges = false;
$('#sy-crm-event-add-sidebar-template-content').find('input:visible, select:visible').each(function() {

const originalValue = $(this).data('original-value');
const currentValue = $(this).val();

if (originalValue != currentValue) {
    hasChanges = true;
    return false; 
}
});
let editorHasChanges=false;
for (const [editorId, quillInstance] of Object.entries(quillEditors)) {
const currentContent = generate_event_escapeString(quillInstance.root.innerHTML); 
const originalContent = $(`#${editorId}`).parent().data("original-value"); 
if (originalContent != ""&&currentContent != originalContent) {
    editorHasChanges= true;  

    

}
}

/*if (hasChanges||editorHasChanges)
        
{
$("#sy-crm-new-event-sidebar-submit-btn").prop("disabled", false);
} else {
$("#sy-crm-new-event-sidebar-submit-btn").prop("disabled", true);
}*/
}
//submit add event
$('#sy-crm-new-event-sidebar-submit-btn').click(function () {
let isValid = true;
const variables = {};
const docTitleInput = $('#sy-crm-event-sidebar-title-input');
if (!docTitleInput.val()) {
isValid = false;
docTitleInput.next('.text-error').show(); 
} else {
docTitleInput.parent().next('.text-error').hide(); 
}
const editorContents = getAllEditorContents(quillEditors);
$('#sy-crm-event-add-sidebar-vars').find('input, select').each(function () {
const input = $(this);
const isRequired = input.prop('required'); 

if (isRequired && !input.val().trim()) { 
    isValid = false;
    input.parent().next('.text-error').show();
} 
else {
    input.parent().next('.text-error').hide();
    const value = $(this).val() || ""; 
    variables[input.attr('name')] = value;
    
                
}
});


for (const editorId in editorContents) {
    if (editorContents.hasOwnProperty(editorId)) {
        const $editorElement = $(`#${editorId}`);
        const varName = $editorElement.attr('name');
        const content = editorContents[editorId];

        const $errorMessageElement = $editorElement.parent().parent().next('.text-error');

        if ($editorElement.attr('required') && (!content || content.trim() === '<p><br></p>')) {
            isValid = false;
            $editorElement.addClass('error'); 
            
            // Affiche le message d'erreur
            $errorMessageElement.text('Ce champ est requis.').show();
        } else {
            $editorElement.removeClass('error');
            
            $errorMessageElement.text('').hide();
        }

        variables[varName] = content;
    }
}

        

const generateAssociated = $('#generate-associated-events').is(':checked'); // Vérifie si le checkbox est coché
if (generateAssociated){
$('.nom-doc-input').each(function () {
    let input = $(this);
    if (!input.val().trim()) { 
        isValid = false;
        input.next('.text-error').show();
    } 
    else {
        input.next('.text-error').hide();
    }
    
    
})
}
const filesInput = $('#sy-crm-event-add-sidebar-options-files');
const filesData = new FormData();
var selectedTags = [];

$('.sy-crm-event-add-sidebar .crm_events_tags_selected').each(function() {
    
    filesData.append('selected_tags[]', $(this).data('id'));
});
if (filesInput.length > 0 && filesInput[0].files.length > 0) {
const files = filesInput[0].files;
for (let i = 0; i < files.length; i++) {
    const file = files[i];

    // Vérification des extensions interdites
    const forbiddenExtensions = ['php', 'js', 'exe', 'bat', 'sh'];
    const fileExtension = file.name.split('.').pop().toLowerCase();

    if (forbiddenExtensions.includes(fileExtension)) {
        isValid = false;
        filesInput.parent().next('.text-error')
            .text('Le fichier "' + file.name + '" a une extension non autorisée.')
            .show();
    } else {
        filesData.append('additional_files[]', file); 
        filesInput.parent().next('.text-error').hide(); 
    }
}
}
let recipients=[];
let send_attachments_via_link = $('#sy-crm-new-event-send-mail-form-send-attachments-via-link').is(':checked') ? 1 : 0;

if($('#sy-crm-new-event-send-email-checkbox').is(':checked')){

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    // Supprimer les anciens messages d'erreur
    $('#sy-crm-new-event-send-email-section .text-error').remove();

     recipients = $('input[name="sy-crm-new-event-recipients[]"]').map(function () {
        const value = $(this).val().trim();

        if (!value) {
            $(this).parent().after('<p class="text-error text-error">Ce champ est requis</p>');
            isValid = false;
        } else if (!emailRegex.test(value)) {
            $(this).parent().after('<p class="text-error text-error">Adresse email invalide</p>');
            isValid = false;
        }

        return value;
    }).get();
}

if (!isValid) return;

const selectedTemplates = [];
if (generateAssociated) {
$('.associated-template:checked').each(function () {
    const templateId = $(this).val(); 
    const nomDoc = $(`#nom_doc_${templateId}`).val();

    selectedTemplates.push({
        id: templateId,
        nom_doc: nomDoc
    });
});
}

$('.sy-event-add-sidebar-users-list-trigger .sy-event-add-sidebar-users-list-selected-item').each(function() {

filesData.append('associated_users[]', $(this).data('id'));
});
recipients.forEach(email => {
    filesData.append('recipients[]', email);
});
filesData.append('send_attachments_via_link', send_attachments_via_link);
filesData.append('send_event_by_mail', $('#sy-crm-new-event-send-email-checkbox').is(':checked')?1:0);
// Appel AJAX pour générer le event
const doctitle = $('#sy-crm-event-sidebar-title-input').val(); 
const templateId = $('#sy-crm-event-add-sidebar-templates-select').val();
const userId = $('#sy-crm-event-show-add-sidebar-btn').data('user-id');
filesData.append('action', 'save_generated_event');
filesData.append('template_id', templateId);
filesData.append('user_id', userId);
filesData.append('variables', JSON.stringify(variables));
filesData.append('doctitle', doctitle);
filesData.append('selectedTemplates', JSON.stringify(selectedTemplates));
filesData.append('generateAssociated', generateAssociated);
filesData.append('event_dure', $('#sy-crm-event-add-sidebar-duration').val());
filesData.append('event_date', $('#sy-crm-event-add-sidebar-date').val());
$("#sy-crm-event-add-sidebar").animate({ scrollTop: 0 }, 100, function() {

    $('#sy-crm-event-add-sidebar-notif').removeClass('text-success text-error').addClass('text-info').text('Envoi en cours...');  
}) 
// Envoi de la requête AJAX avec $.ajax()
/**/$.ajax({
url: ajax_object.ajax_url,
type: 'POST',
data: filesData,
processData: false,
contentType: false, 
success: function (response) {

    if (response.success) {
        $("#sy-crm-event-add-sidebar").animate({ scrollTop: 0 }, 1000, function() {

        $('#sy-crm-event-add-sidebar-notif')
            .text('Évènement ajouté avec succes.')
            .addClass("text-success").removeClass("text-error text-info")
            .fadeIn()
            .delay(500)
            .fadeOut(function() {
                
                const baseUrl = window.location.origin;
                const redirectionUrl = baseUrl + '/' + response.data.url_redirection;
                window.location.href = redirectionUrl;
            });
        });
    } else {
        $("#sy-crm-event-add-sidebar").animate({ scrollTop: 0 }, 500, function() {

       
        $('#sy-crm-event-add-sidebar-notif')
            .text(response.data.message)
            .removeClass("text-success text-info").addClass("text-error")
            .fadeIn()
            .delay(500)
            .fadeOut();
        })
    }
},
error: function() {
    $("#sy-crm-event-add-sidebar").animate({ scrollTop: 0 }, 500, function() {

       
    $('#sy-crm-event-add-sidebar-notif')
        .text("Erreur lors de l\'ajout du event.")
        .removeClass("text-success").addClass("text-error")
        .fadeIn()
        .delay(500)
        .fadeOut();
    })
}


});
});
//sent email functions
$(document).on('click', '.sy-crm-event-table-menu-send-mail-btn', function () {
    const eventId = $(this).data('id');
    const userEmail = $(this).data('mail');

    $.ajax({
        url: ajax_object.ajax_url,
        type: 'POST',
        data: {
            action: 'get_event_mail_data',
            event_id: eventId
        },
        success: function (response) {
            if (response.success) {
                $('#sy-crm-event-mail-recipients-wrapper .recipient-input').val(userEmail);
                $('#sy-crm-event-mail-sidebar-event-id').val(eventId);
                $('#sy-crm-event-send-mail-form-send-attachments-via-link').removeAttr('checked') 
                // Afficher le contenu HTML + bio + fichiers
                $('#sy-crm-event-mail-content-preview').html(response.data.htmlContent);
                if(response.data.attachements)
                {
                    $('#sy-crm-event-send-mail-form-send-attachments-via-link-container').show();
                    
                    
                }
                else{
                    $('#sy-crm-event-send-mail-form-send-attachments-via-link-container').hide();
                }
                $('#sy-crm-event-send-mail-sidebar').show().addClass('open');
            } else {
                console.log('Erreur côté serveur lors de la récupération des données.');
            }
        },
        error: function () {
            console.log('Erreur AJAX lors de la requête.');
        }
    });
})

// Ajouter un champ destinataire supplémentaire
$(document).on('click', '.add-recipient-btn', function () {
    $('#sy-crm-event-mail-recipients-wrapper').append(`
        <div class="recipient-group">
            <div  class="recipient-group-top">
            <input type="email" name="recipients[]" class="recipient-input" required>
            <button type="button" class="remove-recipient-btn">-</button>
            </div>
            
        </div>
    `);
});

// Retirer un champ
$(document).on('click', '.remove-recipient-btn', function (e) {
    e.preventDefault()
    $(this).closest('.recipient-group').remove();
});
$(document).on('input', 'input[name="recipients[]"]', function (e) {
    $(this).parent().next('.text-error').remove();
    });
    $(document).on('submit', '#sy-crm-event-send-mail-form', function (e) {
        e.preventDefault();
    
        let isValid = true;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
        // Supprimer les anciens messages d'erreur
        $('.text-error').remove();
    
        const recipients = $('input[name="recipients[]"]').map(function () {
            const value = $(this).val().trim();
    
            if (!value) {
                $(this).parent().after('<p class="text-error text-error">Ce champ est requis</p>');
                isValid = false;
            } else if (!emailRegex.test(value)) {
                $(this).parent().after('<p class="text-error text-error">Adresse email invalide</p>');
                isValid = false;
            }
    
            return value;
        }).get();
        let send_attachments_via_link = $('#sy-crm-event-send-mail-form-send-attachments-via-link').is(':checked') ? 1 : 0;
        if (!isValid) return;
    
        // Afficher un message de chargement
        const $notif = $('#sy-crm-event-send-mail-sidebar-notif');
        $("#sy-crm-event-send-mail-sidebar").animate({ scrollTop: 0 }, 100, function() {

            $notif.removeClass('text-success text-error').addClass('text-info').text('Envoi en cours...');
        }) 
        
    $('.sy-crm-send-mail-submit-btn').attr('disabled',true)
        $.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'send_event_to_emails',
                event_id: $('#sy-crm-event-mail-sidebar-event-id').val(),
                recipients: recipients,
                send_attachments_via_link:send_attachments_via_link
            },
            success: function (response) {
                if (response.success) { 
                    $('.sy-crm-send-mail-submit-btn').attr('disabled',false)
                    $("#sy-crm-event-send-mail-sidebar").animate({ scrollTop: 0 }, 100, function() {

                    $notif.text('Email(s) envoyé(s) avec succès.')
                    .addClass("text-success").removeClass("text-error text-info")
                    .fadeIn()
                    .delay(500)
                    .fadeOut(function() {
                        
                        location.reload();
                    });
                });
                } else {
                    $notif.text('Erreur lors de l’envoi des emails.').addClass('text-error').removeClass("text-success text-info");
                    console.error(response);
                }
            },
            error: function () {
                $notif.text('Erreur AJAX lors de la requête.').addClass('text-error').removeClass("text-success text-info");
            }
        });
    });
    
    
$(document).on('click','.sy-crm-event-send-mail-header-btn,.discard-send-event-by-mail-sidebar', function (e) {
    e.preventDefault()
    const $sidebar = $('#sy-crm-event-send-mail-sidebar'); 
  
    if ($sidebar.is(':visible')   ) {
        $sidebar.removeClass('open').hide(); 
        $('#sy-crm-event-mail-recipients-wrapper .recipient-group:not(:first)').remove();
        $('#sy-crm-event-send-mail-form-send-attachments-via-link').removeAttr('checked') 
    }
});

//fermeture des sidebar
 /*$(document).on('click', function (e) {
        const $sidebar = $('#sy-crm-event-send-mail-sidebar'); 
        const $target = $(e.target);
    
        // Vérifie si le clic est en dehors du sidebar ET de tout bouton lié (toggle ou remove)
        if (
            $sidebar.is(':visible') &&
            $target.closest('#sy-crm-event-send-mail-sidebar').length === 0 &&
            $target.closest('.sy-crm-event-table-menu-send-mail-btn').length === 0 &&
            $target.closest('.remove-recipient-btn').length === 0
        ) {
            $sidebar.removeClass('open').hide(); 
            $('#sy-crm-event-mail-recipients-wrapper .recipient-group:not(:first)').remove();
        }
    });*/

    $(document).on("click", function(e) {
        let isInsideNewEventSideBar=$(e.target).closest("#sy-crm-event-add-sidebar").length;
        let isRemoveMailBtn=$(e.target).closest(".sy-crm-new-event-remove-recipient-btn").length > 0;
        let isRemoveMailBtnNoteSideBar=$(e.target).closest(".sy-crm-event-note-remove-recipient-btn").length > 0;
        const isOutsideNewEventSidebar = !isInsideNewEventSideBar;
        const isBtnAddNewEventSidebar = $(e.target).closest("#sy-crm-event-show-add-sidebar-btn").length;
        const isDiscardNewEventButton = $(e.target).is(".discard-add-event-sidebar");
        const removeTagBtn= $(e.target).is(".crm_events_tags_selected")||$(e.target).is(".crm_events_tags_remove")
        const isPaginationClick = $(e.target).closest(".paginate_button").length > 0;
        let isRemoveMailBtnEditSideBar=$(e.target).closest(".sy-crm-edit-event-remove-recipient-btn").length > 0;
        
        if (removeTagBtn||isBtnAddNewEventSidebar||isPaginationClick||isRemoveMailBtnEditSideBar||isRemoveMailBtn||isRemoveMailBtnNoteSideBar) {
            
            return; 
            
        }
        //isOutsideNewEventSidebar)||
        if ((isDiscardNewEventButton) && $("#sy-crm-event-add-sidebar").hasClass("open")) {
            $("#sy-crm-event-add-sidebar").removeClass("open").hide();

            $('#variables-container').empty().hide();
            $('#sy-crm-event-add-sidebar-templates-select,#sy-crm-event-sidebar-title-input').val('');
            $('#sy-crm-event-add-sidebar-options').empty().slideUp();
            $('#gen-event-sidebar-associated-templates').empty().slideUp();
            $('#sy-crm-event-add-sidebar-template-content').slideUp();
           // $('#sy-crm-new-event-sidebar-submit-btn').attr('disabled',true);
            $('#sy-crm-event-add-sidebar .crm_events_tags_selected_list').empty();
            $('#sy-crm-event-add-sidebar .crm_events_tags_list .crm_events_tags_tag').show();
            $('#sy-crm-new-event-mail-recipients-wrapper .recipient-group:not(:first)').remove();
            $('#sy-crm-new-event-send-email-section').hide();
            $('#sy-crm-new-event-send-email-checkbox').removeAttr('checked')
 

        }
        const isInsideEditSidebar = $(e.target).closest("#sy-crm-event-edit-sidebar").length > 0;
         

        const isOutsideEditSidebar = !isInsideEditSidebar ;
        const isDiscardEditSidebarButton1 = $(e.target).is("#generate_event_edit_discard");
        const isDiscardEditEditSidebarButton2= $(e.target).is(".discard-sidebar");

        const isOutsideNoteSidebar = !$(e.target).closest(".sy-crm-event-note-sidebar").length;
        const isDiscardNoteButton = $(e.target).is(".discard-note-sidebar");
//isOutsideEditSidebar ||
         if (( isDiscardEditSidebarButton1 ||isDiscardEditEditSidebarButton2)&& $("#sy-crm-event-edit-sidebar").hasClass("open")) {
            upadteDuration();
            $("#sy-crm-event-edit-sidebar").removeClass("open");
            $("#sy-crm-event-add-sidebar").removeClass("open")
            $("#sy-crm-event-edit-sidebar-options,#sy-crm-event-edit-sidebar-vars").empty();
            $("#sy-crm-event-edit-sidebar-event-title").val("");
            $("#sy-crm-event-edit-sidebar input:not(.sy-crm-edit-event-recipient-input)").val("");
            $("#sy-crm-event-edit-sidebar-options-new").hide();
            $("#sy-crm-event-edit-sidebar-submit-btn").prop("disabled", true);
            $('#sy-crm-event-edit-sidebar-confirm-edit-btn').show();
            $('#generate_event_confirm_edit_btn').hide();
            $('#sy-crm-event-edit-sidebar-submit-btn').hide();
            $("#sy-crm-event-edit-sidebar-event-title").attr('readOnly',true);
            $('#sy-crm-event-edit-sidebar-content').show().empty();
            $("#sy-crm-event-edit-sidebar-vars-container").hide();
            $("#sy-crm-event-edit-sidebar-version").hide();
            const url = new URL(window.location);
            if (url.searchParams.has('event')) {
                url.searchParams.delete('event');
                history.replaceState(null, '', url.toString());
            }
            
         
        }

        // Fermer la sidebar des notes si elle est ouverte et clic à l'extérieur ||isOutsideNoteSidebar
        if ((isDiscardNoteButton) && $(".sy-crm-event-note-sidebar").hasClass("open")) {
            $(".sy-crm-event-note-sidebar").removeClass("open").hide();
            $('#sy-crm-event-note-sidebar-vars').empty();

            $('.sy-crm-event-note-sidebar .crm_events_tags_selected_list').empty();
            $('.sy-crm-event-note-sidebar .crm_events_tags_list .crm_events_tags_tag').show();
            $('#sy-crm-event-note-sidebar-options').empty().slideUp(); 
        }
        
    });
   
//

})