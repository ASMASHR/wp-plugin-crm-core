<?php 
use Dompdf\Dompdf;
use Dompdf\Options;
/**
 * ======================================================
 * 📄 Fichier de fonctions personnalisées pour VosFactures
 * ======================================================
 * 
 * Ce fichier contient un ensemble de fonctions utilisées
 * pour gérer les interactions avec VosFactures et d'autres
 * fonctionnalités liées aux utilisateurs et aux documents.
 * 
 * 🧩 Liste des fonctions disponibles :
 * 
 * 1. ajax_get_templates_by_user_role()
 *    → Récupère les modèles CRM accessibles à un utilisateur donné selon ses rôles.
 * 
 * 2. ajax_get_template_variables()
 *    → Récupère les variables d’un template (et ses modèles associés), avec valeurs pré-remplies selon l’utilisateur.
 * 
 * 3. sanitize_filename()
 *    → Nettoie un nom de fichier pour le rendre compatible avec les systèmes de fichiers.
 * 
 * 4. generate_pdf()
 *    → Génère un PDF depuis le contenu d’un post WordPress avec pied de page personnalisé..
 * 
 * 5. ajax_save_generated_event()
 *    → Génére un document à partir d’un modèle (template) en insérant dynamiquement des variables fournies par l'utilisateur .
 * 
 *
 * 5. calculer_date_expiration()
 *    → Calcule la date d'expiration d'un document basé sur un modèle (template).
 * 
 * 6. get_file_icon()
 *    →  Récupére l’icône appropriée en fonction de l’extension d’un fichier.
 * 
 * 7. crm_events_generate_user_hash()
 *    →  Génère un hash unique pour un utilisateur donné à partir de son ID en utilisant une clé secrète.
 * 
 * 8. get_post_id_from_title() 
 *    →  Récupére l'ID d'un post à partir de son titre dans un type de post spécifique
 * 
 * 9. delete_event_handler() 
 *    →  Gère la suppression d'un document via une requête AJAX sécurisée.
 * 
 * 10. format_date_wp() 
 *    →  Formate une date selon les paramètres de configuration de WordPress
 * 
 * 11. event_get_devis_var_value() 
 *    →  Récupére les données du dernier devis (généré via l’outil VosFactures) associé à un client spécifique.
 * 
 * 
 * 12. event_get_facture_var_value() 
 *    →  Récupére les données du derniere facture (généré via l’outil VosFactures) associé à un client spécifique.
 * 
 * 13. event_get_factures_echues_var_value() 
 *    →  Récupére les données des factures echoué généré via l’outil VosFactures (liens de reglement et pdf associé) associé à un client spécifique.
 * 
 * 14.event_get_unpaid_factures()
 *     →  helper function pour recuperer les factures non payés.
 * 
 * 15.event_get_vosfactures_documents()
 *     →  helper function pour recuperer le dernier devis ou facture selon le type d'action.
 * 
 * 16.event_vosfactures__download_and_attach_pdf()
 *     →  helper function pour télécharger un pdf de devis ou facture dans la liste des pieces jointe d'un evenement.
 * 
 * 17.redirection_vofacture_shortcode_function()
 *     →  Création d’un shortcode permettant de rediriger vers le lien de règlement d’une facture, tout en permettant de tracker les clics sur ce lien.
 
 * 18.crm_events_vf_custom_rewrite_rule()
 *     →  Ajoute une règle de réécriture personnalisée pour gérer les URLs de type "vos-facture-paiment/{trackinginvoice}"
 * 
 * 19.create_vosfacture_redirect_page()
 *     →   crée automatiquement une page  WordPress associée si elle n'existe pas. Cette page sert de point d'entrée our rediriger vers le lien de paiement d'une facture via un shortcode
 * ------------------------------------------------------
 * Chaque fonction est documentée individuellement plus bas.
 **/



/**
 * Récupère les templates accessibles à un utilisateur en fonction de son rôle.
 * 
 * Cette fonction est utilisée pour récupérer la liste des templates CRM disponibles pour un utilisateur spécifique.
 * Elle prend en compte l'ID de l'utilisateur passé via la requête GET et vérifie si l'utilisateur a le droit d'accéder aux templates,
 * en fonction des rôles qui lui sont assignés. Si l'utilisateur est un administrateur ou un responsable CRM, tous les templates sont renvoyés.
 * Sinon, seuls les templates dont les rôles d'accès sont compatibles avec ceux de l'utilisateur seront retournés.
 * 
 * Fonctionnement :
 * - Vérifie si l'ID de l'utilisateur est fourni et valide.
 * - Vérifie que l'utilisateur existe et récupère ses rôles.
 * - Récupère tous les templates CRM enregistrés.
 * - Filtre les templates en fonction des rôles associés à chaque template et des rôles de l'utilisateur.
 * - Renvoie une liste de templates accessibles sous forme de tableau avec leurs ID et titres.
 * - En cas d'erreur (ID manquant ou utilisateur introuvable), retourne un message d'erreur.
 * 
 * @return void
 */
function ajax_get_templates_by_user_role() {
    // Vérifiez si l'ID utilisateur est fourni
    if (!isset($_GET['user_id']) || empty($_GET['user_id'])) {
        wp_send_json_error(['message' => 'ID utilisateur manquant.']);
    }
    $current_user = wp_get_current_user();
    $user_roles = $current_user->roles;
    

    $user_id = intval($_GET['user_id']);
    $user = get_userdata($user_id);

    if (!$user) {
        wp_send_json_error(['message' => 'Utilisateur non trouvé.']);
    }
    $templatesDispo = get_posts([
        'post_type' => 'crm_documents',
        'numberposts' => -1,
    ]);
    $templates = [];
    foreach ($templatesDispo as $template) {

        $roles_selectionnes = get_post_meta($template->ID, '_template_roles_acces', true);
        $roles_selectionnes = $roles_selectionnes ? json_decode($roles_selectionnes, true):[];
        if (array_intersect($roles_selectionnes, $user->roles) || in_array("administrator", $user_roles) || in_array("responsable_crm", $user_roles)) {
            $templates[] =['id'=>$template->ID,'title'=>$template->post_title];
        }
    }

    wp_send_json_success(['templates' => $templates]);
    ob_end_clean();
}
add_action('wp_ajax_get_templates_by_user_role', 'ajax_get_templates_by_user_role');

/**
 * Récupère les variables d'un template et les informations associées à un utilisateur.
 * 
 * Cette fonction est utilisée pour extraire les variables d'une template (contenu dynamique entre accolades)
 * et les informations pertinentes liées à l'utilisateur qui demande ces variables.
 * Elle permet également de récupérer les templates associés au template principal, ainsi que les variables de ces templates associés.
 * Les informations utilisateur comme le nom, le prénom, et le nom de société sont utilisées pour remplir les variables prédéfinies.
 * 
 * Fonctionnement :
 * - Récupère l'ID du template et de l'utilisateur via les paramètres GET.
 * - Extrait toutes les variables (entre accolades) du contenu du template.
 * - Récupère les templates associés au template principal, et pour chaque template associé :
 *   - Vérifie si l'utilisateur a le droit d'y accéder en fonction de ses rôles.
 *   - Extrait également les variables du contenu des templates associés.
 * - Récupère des informations utilisateurs comme le nom de société, le prénom et le nom pour remplir certaines variables.
 * - Regroupe toutes les variables uniques du template et de ses templates associés.
 * - Récupère des données supplémentaires comme la version du template et les documents générés associés.
 * - Renvoie un objet JSON contenant :
 *   - Les variables uniques.
 *   - Les métadonnées du template.
 *   - Les valeurs pré-remplies des variables à partir des informations de l'utilisateur.
 *   - Les templates associés et leurs données.
 *   - Le nombre de documents générés à partir du template.
 * 
 * @return void
 */


function ajax_get_template_variables() {
    $template_id = intval($_GET['template_id']);
    $user_id = intval($_GET['user_id']);
    $user = get_userdata($user_id);

    $template_content = get_post_field('post_content', $template_id);
    preg_match_all('/\{([^\}]+)\}/', $template_content, $matches);
    $variables = array_unique($matches[1]);

    $template_meta = get_post_meta($template_id);
    $associated_templates = get_post_meta($template_id, '_associes_list', true); 

    $template_autorise_generation_pdf = get_post_meta($template_id, '_template_autorise_generation_pdf', true);
    $associated_templates = json_decode($associated_templates, true);
    $associated_variables = [];
    $associated_templates_data= [];
    $nom_societe =get_user_meta($user_id, 'billing_company', true);
    $first_name =get_user_meta($user_id, 'billing_first_name', true);
    $last_name = get_user_meta($user_id, 'billing_last_name', true);
   
    $prenom_nom=$last_name .' '.$first_name;
    $societeNom = !empty($nom_societe) ? $nom_societe :( $prenom_nom?$prenom_nom:$user->display_name);
    $current_user = wp_get_current_user();

// Récupérer le nom et le prénom ou, à défaut, le display_name
$creatorNom = !empty($current_user->user_lastname) && !empty($current_user->user_firstname) 
    ? $current_user->user_firstname . ' ' . $current_user->user_lastname 
    : $current_user->display_name;

    
    $autorise_documents_joints = get_post_meta($template_id, '_template_autorise_documents_joints', true);
    //$formattedDate = date('y') . date('m');
    
    $formattedDate = date('d-m');
    if ($associated_templates) {
        foreach ($associated_templates as $associated_template_id) {
            $roles_selectionnes = get_post_meta($associated_template_id, '_template_roles_acces', true);
            $roles_selectionnes = $roles_selectionnes ? json_decode($roles_selectionnes, true):[];
            if (array_intersect($roles_selectionnes, $user->roles) || in_array("administrator", $user->roles) || in_array("responsable_crm", $user->roles)) {
                $associated_content = get_post_field('post_content', $associated_template_id);
                preg_match_all('/\{([^\}]+)\}/', $associated_content, $assoc_matches);
                $associated_variables = array_merge($associated_variables, $assoc_matches[1]);
                $associated_template_name = get_the_title($associated_template_id);
                $template_version = get_post_meta($associated_template_id, '_template_version', true);
                $templateRacine = get_post_meta($associated_template_id, '_racine', true);
                $generatedPostTitle =$formattedDate.' - '.$societeNom.' - '. $associated_template_name  ;
                $associated_templates_data[]=[
                    'id' => $associated_template_id,
                    'name' => $associated_template_name,
                    'nom_doc'=>$generatedPostTitle
                ];
            }
        }
        $associated_variables = array_unique($associated_variables);
    }
    $variables = array_merge($associated_variables, $variables);
    $variables = array_unique($variables);
    
    $pre_filled = [];
    foreach ($variables as $variable) {
        $variable_cleaned = str_replace(['@', '*','#'], '', $variable);
        $meta_value = get_user_meta($user_id, $variable, true)??get_user_meta($user_id, $variable_cleaned, true);
        if ($meta_value) {
            $pre_filled[$variable] = $meta_value;
        }

        if($variable_cleaned=="display_author_name"){
         
            $pre_filled[$variable] = $creatorNom;   
        }
        
        if ($variable_cleaned == "display_author_bio") { 
            $meta_value = get_user_meta($current_user->ID, 'description', true);
           
            $pre_filled[$variable] = $meta_value;  
        }
        if ($variable_cleaned == "display_user_bio") { 
            $meta_value = get_user_meta($user_id, 'description', true);
            $pre_filled[$variable] = $meta_value;  
        }  
        if ($variable_cleaned == "civilite") { 
            $meta_value = get_user_meta($user_id, 'user_civilite', true);
            $pre_filled[$variable] = $meta_value;  
        } 
        if ($variable_cleaned == "creation_date") { 
            
            $date_format = get_option('date_format');

            $date_creation = date_i18n($date_format, current_time('timestamp')); 
   
            $pre_filled[$variable] = $date_creation;  
        }
    }
$autorise_association_users=get_post_meta($template_id, '_template_users_acces', true);
$date_format = get_option('date_format');

$date_creation = date_i18n($date_format, current_time('timestamp')); 
                       
    wp_send_json_success([
        'variables' => $variables,
        //'template_meta' => $template_meta,
        'pre_filled' => $pre_filled,
        'user_id' => $user_id,
        'racine' => get_post_meta($template_id, '_racine', true),
        'compteur' => count(get_posts([
            'post_type'   => 'crm_docs_gen',
            'meta_key'    => '_used_template_id',
            'meta_value'  => $template_id,
            'numberposts' => -1,
        ])),
        'associated_templates' => $associated_templates,
        'associated_templates_data' => $associated_templates_data,
        'templateNom' => get_the_title($template_id),
        'societeNom'=>$societeNom,
        'autorise_documents_joints'=>$autorise_documents_joints,
        'creatorNom'=>$creatorNom,
        'autorise_association_users'=>$autorise_association_users,
        'date_creation'=>$date_creation,
        'template_autorise_generation_pdf'=>$template_autorise_generation_pdf
    ]);
}

add_action('wp_ajax_get_template_variables', 'ajax_get_template_variables');



function sanitize_filename($filename) {
     $filename = preg_replace('/[\/:*?"<>|\'\\\\]/', '-', $filename);
    $filename = str_replace(' ', '-', $filename);
     while (strpos($filename, '--') !== false) {
        $filename = str_replace('--', '-', $filename);
    }
    $filename = trim($filename, '-');

    $filename = substr($filename, 0, 255);

    return $filename;
}
/**
 * Génère un PDF depuis le contenu d’un post WordPress avec pied de page personnalisé.
 *
 * Cette fonction utilise Dompdf pour créer un fichier PDF à partir d’un contenu HTML,
 * applique un style CSS (depuis un fichier), ajoute un pied de page contenant des
 * informations spécifiques selon le département lié au template utilisé, puis enregistre
 * le fichier dans un dossier structuré par année et utilisateur dans `/uploads/documents-crm`.
 *
 * Fonctionnalités :
 * - Récupération du post et de son contenu.
 * - Déduction de l’utilisateur lié à l’événement ou au document.
 * - Définition d’un nom de fichier sécurisé via `sanitize_filename()`.
 * - Application d’un style CSS personnalisé pour le PDF.
 * - Génération du PDF avec Dompdf, format A4 vertical.
 * - Ajout d’un pied de page :
 *     - Texte personnalisé selon le département.
 *     - Lignes multiples de texte.
 *     - Pagination (page X sur Y).
 * - Enregistrement dans un répertoire `/uploads/documents-crm/année/utilisateur/`.
 *
 * @param int $postId ID du post source.
 * @param string $content (non utilisé dans cette version, le contenu est directement extrait du post).
 * @param string $filename Nom suggéré pour le fichier PDF.
 * @return string URL du fichier PDF généré.
 */

function generate_pdf($postId, $content, $filename) {
    $post = get_post($postId);
    //$user_id=get_post_meta($postId, '_generated_event_user_id',true);
    $eventUserId = get_post_meta($postId, '_generated_event_user_id', true);
    $user_id = !empty($eventUserId) ? $eventUserId : get_post_meta($postId, '_generated_doc_user_id', true);
    $filename1=sanitize_filename($filename);

    $user_info = get_userdata($user_id);
    $vosfactures_id=get_user_meta($user_id, 'vosfactures_id',true);
    $user_login = $user_info->user_login??$vosfactures_id;
    if (empty($user_login)) {
        $user_login= $user_id;
        
    }
    
    $year = date('Y');
    $postContenu = ($post->post_content);

    // Récupération du texte pour le footer

    $template_id=get_post_meta($postId, '_used_template_id',true );
    $associeted_departement=get_post_meta($template_id, '_template_associated_department_id', true);
       if (!$associeted_departement) {
        $associeted_departement = 'default';
    }
    else{
            $associeted_departement = (string) $associeted_departement;
  
    }/**/
    
    $crm_footer_departments = get_option('_crm_footer_departments', []);
    $footerText = "";
    
    if (is_array($crm_footer_departments) ){
        if( isset($crm_footer_departments[$associeted_departement])) {
        $footerText = $crm_footer_departments[$associeted_departement];
        }else{
            $footerText = $crm_footer_departments['default'];

        }
    }
   

    $cssFilePath = plugin_dir_path(__FILE__) . '../../assets/css/pdf-css-file.css';
    $cssStyles = null;
    if (file_exists($cssFilePath)) {
        $cssStyles = file_get_contents($cssFilePath);
    }



    $html = "
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
        .content{
        margin-bottom:10px;
        }
            $cssStyles
          
        </style>
    </head>
    <body>
        <div class='content'>
            $postContenu
        </div>
       
    </body>
    </html>
    ";

    // Crée l'objet Dompdf avec les options
    $options = new Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isPhpEnabled', true);
    $options->set('isRemoteEnabled', true);
    $dompdf = new Dompdf($options);

    // Charge le HTML dans DomPDF
    $dompdf->loadHtml($html);

    $dompdf->setPaper('A4', 'portrait');

    $dompdf->render();

    $canvas = $dompdf->getCanvas();
    $pageCount = $canvas->get_page_count();


$canvas->page_script(function ($pageNumber, $pageCount, \Dompdf\Canvas $canvas) use ($footerText) {
    $pageWidth = $canvas->get_width();
    $pageHeight = $canvas->get_height();
   $footerMargin = 5; 
    $footerLineY = $pageHeight - 50 ; 
    
    $lineColor = [0.6, 0.6, 0.6]; 
    $canvas->line(20, $footerLineY, $pageWidth - 20, $footerLineY, $lineColor, 1);

    $font = 'Arial, sans-serif'; // Utilisation de Arial, sans-serif
    $fontSize = 9;
    $footerTextPlain = str_replace(['<br>', '<br/>', '<br />', '<p>', '</p>'], "\n", $footerText);
$footerTextPlain = strip_tags($footerTextPlain);
$footerTextPlain = preg_replace('/\r\n|\r|\n/', "\n", $footerTextPlain); // Normaliser
$footerTextPlain = trim($footerTextPlain);
$lines = array_filter(array_map('trim', explode("\n", $footerTextPlain))); // Supprimer les lignes vides
    $lineHeight = 12;
    $color = [0.32, 0.32, 0.32]; 

    foreach ($lines as $i => $line) {
        $textWidth = $canvas->get_text_width($line, $font, $fontSize);
        $startX = ($pageWidth - $textWidth) / 2; // Centré
        $canvas->text($startX, $footerLineY + 5 + ($i * $lineHeight), $line, $font, $fontSize, $color);
    }

    // Numéro de page
    $pageText = 'page ' . $pageNumber . ' sur ' . $pageCount;
    $textWidth = $canvas->get_text_width($pageText, $font, $fontSize);
    $canvas->text($pageWidth - $textWidth - 20, $pageHeight - 15 - $footerMargin, $pageText, $font, $fontSize, $color);

});


    $output = $dompdf->output();

    // Chemin de stockage des fichiers PDF
    $upload_dir = wp_upload_dir();
    //$custom_dir = $upload_dir['basedir'] . '/documents-crm';
    $custom_dir = $upload_dir['basedir'] . "/documents-crm/$year/$user_login";
    if (!file_exists($custom_dir)) {
        mkdir($custom_dir, 0755, true);
    }

    $file_path = $custom_dir . '/' . $filename1;
    file_put_contents($file_path, $output);

 $pdf_url = $upload_dir['baseurl'] . "/documents-crm/$year/$user_login/$filename1";
   return $pdf_url;
    //return $upload_dir['baseurl'] . '/documents-crm/' . $filename;
}

/**
 * Gère la génération et l'enregistrement de documents basés sur une template, avec prise en charge de la génération de PDF et de pièces jointes.
 *
 * Cette fonction effectue les tâches suivantes :
 * 1. Récupère et valide les données de la requête AJAX, notamment l'ID du modèle, l'ID de l'utilisateur, les variables et le titre du document.
 * 2. Remplace les variables dans le contenu du modèle par les valeurs fournies.
 * 3. Crée un nouveau post WordPress de type `crm_events_list` pour stocker le document généré.
 * 4. Si autorisé, génère une version PDF du document et enregistre son URL en tant que métadonnée.
 * 5. Gère l'ajout de fichiers supplémentaires en les téléchargeant dans un répertoire personnalisé et en enregistrant leurs URL.
 * 6. Permet la génération de documents associés à partir des modèles sélectionnés, en appliquant les remplacements de variables et en créant des posts supplémentaires de type `crm_events_list`.
 * 7. Met à jour les métadonnées des documents générés, y compris les dates d'expiration, la version du modèle, l'ID de l'utilisateur et les modèles associés.
 *
 * Paramètres (récupérés depuis `$_POST`) :
 * - `template_id` (int) : ID du modèle de base.
 * - `user_id` (int) : ID de l'utilisateur générant le document.
 * - `variables` (array) : Paires clé-valeur pour remplacer les variables dans le modèle.
 * - `doctitle` (string) : Titre du document généré.
 * - `selectedTemplates` (array) : Modèles supplémentaires pour générer des documents associés.
 * - `additional_files` (array) : Fichiers joints optionnels à télécharger.
 *
 * Métadonnées et comportement spécifique :
 * - Vérifie si le modèle autorise la génération de PDF (`_template_autorise_generation_pdf`).
 * - Calcule les dates d'expiration des documents générés à l'aide d'une fonction utilitaire.
 * - Traite et sécurise les téléchargements de fichiers pour empêcher les extensions non sûres.
 * - Génère des documents associés en appliquant les variables et en créant de nouveaux posts.
 *
 * Retourne :
 * - Envoie une réponse JSON contenant le statut et les détails des documents générés.
 *
 * Utilisation :
 * Cette fonction est déclenchée via un appel AJAX dans un environnement WordPress et est utilisée pour créer et gérer dynamiquement des documents liés au CRM.
  * @return void
*/


function ajax_save_generated_event() {

    $template_id = intval($_POST['template_id']);
    $user_id = intval($_POST['user_id']);
    $doctitle = $_POST['doctitle'];
    $selectedTemplates=$_POST['selectedTemplates'];
    $template_version = get_post_meta($template_id, '_template_version', true);
    $template_autorise_generation_pdf = get_post_meta($template_id, '_template_autorise_generation_pdf', true);
    $user_info = get_userdata($user_id);
    $vosfactures_id=get_user_meta($user_id, 'vosfactures_id',true);
    $user_login = $user_info->user_login??$vosfactures_id;
   if (empty($user_login)) {
        $user_login= $user_id;
        
    }
    $selected_tags=$_POST['selected_tags']??[];
    $event_date=$_POST['event_date'];
    $event_dure=$_POST['event_dure'];
    $year = date('Y');
    $rawVariables = $_POST['variables']; 
    $cleanJson = stripslashes($rawVariables);
    $variables = json_decode($cleanJson, true); 
   // wp_send_json_error([    'variables' => $variables ,'rr'=>getType($variables),'$cleanJson'=>$cleanJson,'zzz'=>$cleanJson]);

    if (isset($variables['undefined'])) {
        unset($variables['undefined']);
    }

    $formattedDate = date('y') . date('m');
    $template_post = get_post($template_id);
    $contenu = $template_post->post_content;
    if (isset($variables['display_user_bio@'])) {
        $variables['display_user_bio'] = $variables['display_user_bio@'];
        unset($variables['display_user_bio@']);
    }
    
    if (isset($variables['display_author_bio@'])) {
        $variables['display_author_bio'] = $variables['display_author_bio@'];
        unset($variables['display_author_bio@']);
    }
    $documents_associe_vf=[];
    foreach ($variables as $variable => $value) {
        
            if($variable=="document_name"|| $variable === 'event_name'){
                $value=$doctitle;
            }
            if($variable=='devis'||$variable=='facture'||$variable=='factures-echues'){
               if(get_option('vosfactures_sync_enabled') === 'yes' && !empty($vosfactures_id)) {

               if ($variable=='devis') {
                    $devis = event_get_devis_var_value($vosfactures_id);
                    if ($devis) {
                        $value= $devis['html'];
                        $documents_associe_vf[] = $devis;
                    } else {
                        $value= '';
                       
                    }
                } /**/
            
                if ($variable=='facture') {
                    $facture = event_get_facture_var_value($vosfactures_id);
                    if ($facture) {

                        $value= $facture['html'];
                        $documents_associe_vf[] = $facture;
                        
                    } else {
                        $value= '';
                    }
                }
            
                if ($variable=='factures-echues') {
                    $factures = event_get_factures_echues_var_value($vosfactures_id);
                    if ($factures) {
                        
                        $value= $factures['html'];
                        $documents_associe_vf = array_merge($documents_associe_vf, $factures['pdfs']);
                    } else {
                        $value= '';
                    }
                }/**/
            
            } 
            else{

                $value="";
            } 
            }
            if (strpos($variable, '@') !== false||$variable == "display_author_bio"||$variable == "display_user_bio"||$variable=='devis'||$variable=='facture'||$variable=='factures-echues') {
                // Insérer directement du HTML si '#' est présent
                $regex = "/\{" . preg_quote($variable, '/') . "\}/";
                $contenu = preg_replace($regex, $value, $contenu); 
            } 
           
            
            else {
            
            $regex = "/\{" . preg_quote($variable, '/') . "\}/";
            $contenu = preg_replace($regex,   esc_html($value) , $contenu); 
            }
    }
    
    $post_id = wp_insert_post([
        'post_title'   => $doctitle,
        'post_type'    =>  'crm_docs_gen',
        'post_content' => $contenu,
        'post_status'  => 'publish',
    ]);
    update_post_meta($post_id, '_used_template_id', $template_id);
    $documents_associe=[];
    $post_info=[];
    if ($post_id && !is_wp_error($post_id)) {
        $post_info=['post_id' => $post_id,'post_title'=>$doctitle];

        update_post_meta($post_id, '_generated_event_user_id',$user_id);
        if($template_autorise_generation_pdf&&$template_autorise_generation_pdf=="on")
        {

            $pdf_url = generate_pdf($post_id,$contenu, $doctitle . '.pdf');
            update_post_meta($post_id, '_pdf_url', $pdf_url);
            $post_info['file_url'] = $pdf_url;
        }
        else{

            update_post_meta($post_id, '_pdf_url', null);
          
        }
        if (!empty($documents_associe_vf)) {
            foreach($documents_associe_vf as $doc){
                if ($doc) {
                    //'date' => $f['date'],
                    event_vosfactures__download_and_attach_pdf(
                        $doc['pdf_url'],
                        $doc['original_name'], 
                        $doc['doctitle'],      // doctitle
                        $user_login,
                        $post_id
                    );
                }
            }
            update_post_meta($post_id, '_documents_associes_vosfactures', $documents_associe_vf);
        }
        update_post_meta($post_id, '_generated_event_tags', $selected_tags);
        update_post_meta($post_id, '_used_template_version', $template_version);
        update_post_meta($post_id, '_generated_event_vars', $variables);
        update_post_meta($post_id, '_generated_event_date', $event_date);
        update_post_meta($post_id, '_generated_event_dure', $event_dure);
        $connected_user_id = get_current_user_id();
        $modification_date = current_time('mysql');
    
        $associated_users=$_POST['associated_users']??[];

        update_post_meta($post_id, '_generated_event_associated_users', $associated_users);
        /*update_post_meta($post_id, '_date_event_modified_by', $connected_user_id);
        update_post_meta($post_id, '_date_event_modified_date', $modification_date);*/
        ///////////////////////////////////
        //selectedTemplates:selectedTemplates 
        $date_expiration_event_principale=calculer_date_expiration($template_id,$post_id);
        update_post_meta($post_id, '_generated_event_expiration_date', $date_expiration_event_principale['date_expiration']);
        update_post_meta($post_id, '_generated_event_expiration_date_timestamp', $date_expiration_event_principale['date_expiration_timestamp']);
        /////////////////
        $autorise_documents_joints = get_post_meta($template_id, '_template_autorise_documents_joints', true);
        $uploaded_files=  get_post_meta($post_id, '_generated_event_pieces_joints', true);
        if (!is_array($uploaded_files)) {
            $uploaded_files = [];
        }
        if ($autorise_documents_joints && $autorise_documents_joints === "on" && isset($_FILES['additional_files'])) {
             $file_count = count($_FILES['additional_files']['name']);
            $upload_dir = wp_upload_dir();

            $custom_dir = $upload_dir['basedir'] . "/documents-crm/$year/$user_login";
            //$custom_dir = $upload_dir['basedir'] . '/documents-crm';

            
                if (!file_exists($custom_dir)) {
                    mkdir($custom_dir, 0755, true);
                }
        
                for ($i = 0; $i < $file_count; $i++) {
                    $original_name = $_FILES['additional_files']['name'][$i];
                    $tmp_name = $_FILES['additional_files']['tmp_name'][$i];
                    $file_ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
        
                    // Vérification des extensions interdites
                    $forbidden_extensions = ['php', 'js', 'exe', 'bat', 'sh'];
                    if (in_array($file_ext, $forbidden_extensions)) {
                        continue; // Ignorer ce fichier
                    }
        
                    // Génération du nom sécurisé
                    $safe_name = sanitize_file_name($original_name);
                     $new_name = "{$doctitle} - {$safe_name}";
                    $new_name = preg_replace('/[^a-zA-Z0-9._-]/', '', $new_name); 
                    $target_file = $custom_dir . '/' . $new_name;
        
                    if (move_uploaded_file($tmp_name, $target_file)) {
                        $uploaded_files[] = $upload_dir['baseurl'] . "/documents-crm/$year/$user_login/$new_name";
                    }
                }
        
             
        
            if (!empty($uploaded_files)) {
                update_post_meta($post_id, '_generated_event_pieces_joints', $uploaded_files);
            }

        }
    
        ///////////////////
              
        if(!empty($selectedTemplates)){

            //$templates = array_map('intval', $_POST['selectedTemplates']);
            $nouveaux_documents = [];
            foreach ($selectedTemplates as $associe) {
                $associe_id= $associe['id'];
                $nom_doc=$associe['nom_doc'];
                $template_post = get_post($associe_id);
                $associe_autorise_generation_pdf = get_post_meta($associe_id, '_template_autorise_generation_pdf', true);
    
                if (!$template_post) {
                    continue;
                }

                $templateRacine = get_post_meta($associe_id, '_racine', true);
                $formattedDate = date('y') . date('m');;

            
                $compteur = count(get_posts([
                    'post_type'   =>  'crm_docs_gen',
                    'meta_key'    => '_used_template_id',
                    'meta_value'  => $associe_id,
                    'numberposts' => -1,
                ]));

                $template_version = get_post_meta($associe_id, '_template_version', true);
                
                //$compteurFormate = str_pad($compteur, 4, '0', STR_PAD_LEFT);
                $compteurFormate = $compteur; 
                $generatedPostTitle = $templateRacine .'-' . $formattedDate. '-'.$compteurFormate;
                $used_values = [];
                // Remplacer les variables par les valeurs
                $associeContenu = $template_post->post_content;
                
                    preg_match_all('/\{([\w]+)\}/', $associeContenu, $matches);
                    $used_variables = $matches[1];

                    // Associer les valeurs correspondantes
                
                    foreach ($used_variables as $variable) {
                        if (isset($variables[$variable])) {
                            if($variable=="reference_template")
                            {
                                $used_values[$variable]=$templateRacine.'-' . $formattedDate.'-'.$compteurFormate;
                            }
                            elseif ($variable === 'template_name') {
                                $used_values[$variable]= get_the_title($associe_id);
                            }
                            elseif($variable=="document_name"){
                                $used_values[$variable]=$nom_doc;
                            }
                            elseif ($variable === 'creation_date') {
                                $date_format = get_option('date_format');

                                $date_creation = date_i18n($date_format, current_time('timestamp')); 
                       
                                $used_values[$variable] = $date_creation;
                        }
                            else{

                            $used_values[$variable] = $variables[$variable];
                            }
                        }
                    }
                    foreach ($variables as $variable => $value) {
                        if($variable=="reference_template")
                        {
                            $value=$templateRacine.'-' . $formattedDate.'-'.$compteurFormate;
                        }
                        elseif ($variable === 'template_name') {
                            $value= get_the_title($associe_id);
                          }
                          elseif($variable=="document_name"){
                            $value=$nom_doc;
                        }
                          elseif ($variable === 'creation_date') {
                            $date_format = get_option('date_format');

                                $date_creation = date_i18n($date_format, current_time('timestamp')); 
                       
                                $value = $date_creation;
                        }
                        $regex = "/\{" . preg_quote($variable, '/') . "\}/";
                        $associeContenu = preg_replace($regex,  esc_html($value) , $associeContenu);                    
                    }
               

                // Ajouter un nouveau post avec ses métadonnées
                $nouveau_document_id = wp_insert_post([
                    'post_type' =>  'crm_docs_gen',
                    //'post_title' => $generatedPostTitle,
                    'post_title' => $nom_doc,
                    'post_content' => $associeContenu,
                    'post_status' => 'publish',
                    'post_author' => get_current_user_id(),
                ]);

                if ($nouveau_document_id) {
                    $pdf_url1=null;
                    if($associe_autorise_generation_pdf&&$associe_autorise_generation_pdf=="on")
                    { 
                        //$pdf_url1 = generate_pdf($nouveau_document_id,$associeContenu, 'generated_event_' . $associe_id . '.pdf');
                        $pdf_url1 = generate_pdf($nouveau_document_id,$associeContenu, $nom_doc.'.pdf');
                       update_post_meta($associe_id, '_pdf_url', $pdf_url1);
               
                    }
                    else{
                        update_post_meta($associe_id, '_pdf_url', null);

                    }

               
                    $documents_associe[]=['post_id' => $nouveau_document_id,
                    'post_title'=>$nom_doc,
                    'file_url'=>$pdf_url1
                    ];

                    $template_expire_dans=get_post_meta($associe_id, '_template_expire_dans');
                    $date_expiration_doc=calculer_date_expiration($associe_id,$nouveau_document_id);
                    add_post_meta($nouveau_document_id, '_used_template_version', $template_version);
                    add_post_meta($nouveau_document_id, '_generated_event_user_id', $user_id);
                    add_post_meta($nouveau_document_id, '_used_template_id', $associe_id);
                    add_post_meta($nouveau_document_id, '_generated_event_vars', wp_json_encode($used_values));
                    update_post_meta($nouveau_document_id, '_generated_event_expiration_date_timestamp', $date_expiration_doc['date_expiration_timestamp']);
       
                    add_post_meta($nouveau_document_id, '_generated_event_expiration_date', $date_expiration_doc['date_expiration']);
                    $nouveaux_documents[] = $nouveau_document_id;
                }
            }

            if (!empty($nouveaux_documents)) {
                update_post_meta($post_id, 'events_associes_list', $nouveaux_documents);
            }

        }
        if($_POST['send_event_by_mail']=="1"){

            $result=crm_envoyer_emails_evenement(['event_id'=>$post_id,'recipients'=>$_POST['recipients'],'send_attachments_via_link'=>$_POST['send_attachments_via_link']]);
           
            if ($result['success']) {
                $hashedId=crm_events_generate_user_hash($user_id);
                $url = "crm-customer/$hashedId";
            wp_send_json_success(['url_redirection'=>$url,'user_id'=>$user_id,'hashedId'=>$hashedId]);
            } else {
                wp_send_json_error($result);
            }
        }
        else{
            $hashedId=crm_events_generate_user_hash($user_id);
            $url = "crm-customer/$hashedId";
        wp_send_json_success(['url_redirection'=>$url,'user_id'=>$user_id,'hashedId'=>$hashedId]);
        }
                //////////////////wp_send_json_success(['post_info'=>$post_info,'documents_associe'=>$documents_associe]);
               
    } 
    else {
        
        wp_send_json_error(['message' => 'Erreur lors de la création du document.']);
    }
}
add_action('wp_ajax_save_generated_event', 'ajax_save_generated_event');

/**
 * Calcule la date d'expiration d'un document basé sur un modèle (template).
 *
 * Cette fonction détermine la date d'expiration en fonction de la durée de validité (`_template_expire_dans`) 
 * spécifiée pour le modèle. Elle prend en compte la date de création du modèle et la date d'utilisation du document.
 * Si la durée d'expiration est définie et valide, la date d'expiration est calculée. Sinon, elle renvoie une expiration illimitée.
 *
 * @param int $template_id L'ID du modèle (template).
 * @param int $document_id L'ID du document.
 * @return array Un tableau contenant :
 * - `date_expiration_timestamp` : Le timestamp de la date d'expiration, ou PHP_INT_MAX si illimité.
 * - `date_expiration` : La date d'expiration au format 'Y-m-d', ou `null` si illimité.
 */

function calculer_date_expiration($template_id,$document_id) {
    // Récupérer la valeur de `_template_expire_dans`
    $template_post = get_post($template_id);
    $document_post = get_post($document_id);

    if (!$template_post || !$document_post) {
        return [
            'error' => 'Template ou document introuvable'
        ];
    }

    // Récupérer les dates de création
    $date_creation_template = $template_post->post_date; 
    $date_creation_event = $document_post->post_date; 

    $template_expire_dans = get_post_meta($template_id, '_template_expire_dans', true);

   
    if ($template_expire_dans && intval($template_expire_dans) > 0) {
        $template_expire_dans = intval($template_expire_dans); 

        $timestamp_creation_event = strtotime($date_creation_event);

      
        $jours_restants=$template_expire_dans;
        $date_expiration = date('Y-m-d', $timestamp_creation_event + ($jours_restants * 60 * 60 * 24));
        $date_expiration_timestamp = strtotime($date_expiration);
        return [
           'date_expiration_timestamp' => $date_expiration_timestamp,
            'date_expiration' => $date_expiration
        ];
    }

    // Pas d'expiration (0 ou non défini)
    return [
      //  'jours_restants' => 'Illimité',
      'date_expiration_timestamp' => PHP_INT_MAX,
        'date_expiration' => null
    ];
}

/**
 * Enfile les scripts et les styles nécessaires pour le plugin.
 *
 * Cette fonction charge les fichiers JavaScript et CSS nécessaires au fonctionnement 
 * du plugin. Elle inclut également les bibliothèques externes, comme Quill.js, et 
 * fournit des variables JavaScript via `wp_localize_script` pour permettre la communication 
 * AJAX sécurisée avec le serveur.
 *
 * - `crm-documents-shortcode` : Script principal du plugin pour gérer les shortcodes.
 * - `quill-css` et `quill-js` : Bibliothèque Quill.js pour fournir un éditeur de texte enrichi.
 * - `mon-plugin-style` : Feuille de style CSS spécifique au plugin.
 * - Les données localisées dans `ajax_object` :
 *   - `ajax_url` : L'URL pour effectuer des requêtes AJAX vers WordPress.
 *   - `security` : Un nonce pour sécuriser les requêtes AJAX.
 *
 * @return void
 */

function mon_plugin_enqueue_scripts() {
 
    wp_enqueue_style('quill-css', 'https://cdn.quilljs.com/1.3.6/quill.snow.css');
    wp_enqueue_script('quill-js', 'https://cdn.quilljs.com/1.3.6/quill.min.js', array(), null, true);
     wp_localize_script(
        'crm-documents-shortcode',
        'ajax_object',
        array('ajax_url' => admin_url('admin-ajax.php'),
        'security' => wp_create_nonce('delete-document-nonce'),)
    );

   
}
add_action('wp_enqueue_scripts', 'mon_plugin_enqueue_scripts');



function get_file_icon($file_extension)
{
    switch ($file_extension) {
        case 'pdf':
            $icon_url = plugin_dir_url(__FILE__) . '../../assets/icons/pdf-icon.svg';
            break;
        case 'doc':
        case 'docx':
            $icon_url = plugin_dir_url(__FILE__) . '../../assets/icons/word-icon.svg';
            break;
        case 'xls':
        case 'xlsx':
            $icon_url = plugin_dir_url(__FILE__) . '../../assets/icons/excel-icon.svg';
            break;
        case 'jpg':
        case 'jpeg':
        case 'png':
            $icon_url = plugin_dir_url(__FILE__) . '../../assets/icons/image-icon.svg';
            break;
        case 'zip':
        case 'rar':
            $icon_url = plugin_dir_url(__FILE__) . '../../assets/icons/zip-icon.svg';
            break;
        default:
            $icon_url = plugin_dir_url(__FILE__) . '../../assets/icons/image-icon.svg';
            break;
    }
    return $icon_url;

}


/**
 * Génère un hash unique pour un utilisateur donné en utilisant une clé secrète.
 *
 * Cette fonction utilise l'algorithme HMAC-SHA256 pour créer un hash sécurisé basé sur l'ID de l'utilisateur 
 * et une clé secrète prédéfinie. Le hash peut être utilisé pour identifier de manière unique l'utilisateur 
 * dans des contextes sécurisés, comme la génération de liens temporaires, l'authentification ou d'autres 
 * mécanismes nécessitant une sécurité accrue.
 *
 * @param mixed $user_id L'ID de l'utilisateur pour lequel le hash doit être généré.
 * @return string Le hash généré sous forme de chaîne.
 */
function crm_events_generate_user_hash($user_id) {
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
    return hash_hmac('sha256', $user_id, $secret_key);
}



/**
 * Fonction pour récupérer l'ID d'un post à partir de son titre dans un type de post spécifique.
 * 
 * Cette fonction utilise la base de données WordPress pour rechercher un post dans le type de post "crm_events" 
 * avec un titre donné, et renvoie l'ID de ce post s'il est publié.
 * 
 * 1. Utilise la variable globale `$wpdb` pour exécuter une requête SQL sécurisée.
 * 2. La requête cherche dans la table `wp_posts` où le `post_title` correspond au titre fourni, le `post_type` est "crm_events" et le `post_status` est 'publish'.
 * 3. Si un post est trouvé, l'ID du post est renvoyé, sinon `null` est retourné.
 * 
 * @param string $title Le titre du post recherché.
 * @return int|null L'ID du post trouvé ou `null` si aucun post n'a été trouvé.
 */
function get_post_id_from_title($title) {
    global $wpdb;
    $post_type="crm_events";

    // Requête pour récupérer l'ID du post
    $post_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} 
             WHERE post_title = %s 
             AND post_type = %s 
             AND post_status = 'publish' 
             LIMIT 1",
            $title,
            $post_type
        )
    );

    return $post_id ? (int) $post_id : null;
}


/**
 * Gère la suppression d'un document via une requête AJAX sécurisée.
 *
 * Cette fonction est utilisée pour supprimer un document à partir de son ID. Elle 
 * effectue les étapes suivantes :
 * 
 * - Vérifie la validité du nonce envoyé pour sécuriser la requête AJAX.
 * - Vérifie que l'ID du document est fourni et est un entier valide.
 * - Récupère l'URL du fichier PDF associé au document (métadonnée `_pdf_url`).
 * - Traduit l'URL du fichier en chemin absolu sur le serveur et supprime le fichier physique.
 * - Supprime le post WordPress associé au document de manière définitive.
 * - Renvoie une réponse JSON en cas de succès ou d'erreur.
 *
 * Réponses possibles :
 * - Succès : `{ success: true, data: { message: "Document supprimé avec succès." } }`
 * - Erreur : `{ success: false, data: { message: "Document non trouvé." } }`
 *
 * @return void
 */
function delete_event_handler() {
    //check_ajax_referer('delete-document-nonce', 'security');
    //wp_send_json_success($_POST['document_id']);
    if (isset($_POST['event_id']) && is_numeric($_POST['event_id'])) {
        $event_id = intval($_POST['event_id']);
        $pdf_url =get_post_meta($document_id, '_pdf_url', true);
        $attachements =get_post_meta($event_id, '_generated_event_pieces_joints', true);

        if ($pdf_url) {
            $pdf_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $pdf_url);
            if (file_exists($pdf_path)) {
                unlink($pdf_path);
            }
        }
      
        if(is_array($attachements)&&count($attachements)>0){
            foreach($attachements as $url){
                 $pdf_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $url);
            if (file_exists($pdf_path)) {
                unlink($pdf_path);
            }
            }
        }

        wp_delete_post($event_id, true);
        wp_send_json_success(['message' => 'Évènement supprimé avec succès.']);
    } else {
        wp_send_json_error(['message' => 'Évènement non trouvé.']);
    }

    exit;
}
add_action('wp_ajax_delete_event', 'delete_event_handler');



/**
 * formater une date selon les paramètres de configuration de WordPress
 *
 * @return void
 */
function format_date_wp($date) {
    $date_format = get_option('date_format');

    $timestamp = is_numeric($date) ? $date : strtotime($date);

    return date_i18n($date_format, $timestamp);
}

function event_get_devis_var_value($client_id) {
    $devis = event_get_vosfactures_documents('devis', $client_id);
    if (empty($devis)) return null;

     $ref = $devis['reference'];
    $url = $devis['pdf_url']; 

    
    return [
        'html' => '<a href="' . esc_url($url) . '">Pour visualiser et signer votre devis référence ' . esc_html($ref) . ' cliquez ici</a>',
        'pdf_url' => $pdf,
        'reference' => $devis['reference'],
        'date' => $devis['date'],
        'montant' => $devis['montant'],
        'original_name' => $devis['original_name'] ,
        'doctitle' => $devis
    ];
}

function event_get_facture_var_value($client_id) {
    $facture = event_get_vosfactures_documents('facture', $client_id);
    if (empty($facture)) return null;

    $ref = $facture['reference'];
    $pdf = $facture['pdf_url'];

    return [
        'html' => '<a href="' . esc_url($pdf) . '">Pour visualiser et régler votre facture référence ' . esc_html($ref) . ' cliquez ici</a>',
        'pdf_url' => $pdf,
        'reference' => $facture['reference'],
        'date' => $facture['date'],
        'montant' => $facture['montant'],
        'original_name' => $facture['original_name'] ,
        'doctitle' => $facture['doctitle']
    ];
}

function event_get_factures_echues_var_value($client_id) {
    $factures = event_get_unpaid_factures($client_id);
    if (!$factures) return null;

    $html = '<table>';
    $html .= '<thead><tr><th>Référence</th><th>Date</th><th>Montant</th><th>Régler</th></tr></thead><tbody>';

    $pdfs = [];

    foreach ($factures as $f) {
        $ref = $f['reference'];
        $date = $f['date'];
        $montant = $f['montant'];
        $invoice_id=$f['id'];
        $local_redirect_url = site_url('/vos-facture-paiment/' . $invoice_id);

        $pdfs[] = ['pdf_url'=>$f['pdf_url'],
    'reference'=>$f['reference'],
    'date' => $f['date'],
    'montant' => $f['montant'],
    'original_name' => $f['original_name'] ,
    'doctitle' => $f['doctitle']];

        $html .= "<tr>
            <td>{$ref}</td>
            <td>{$date}</td>
            <td>{$montant} €</td>
            <td><a href='{$local_redirect_url}'>Régler</a></td>
        </tr>";
    }

    $html .= '</tbody></table>';

    return [
        'html' => $html,
        'pdfs' => $pdfs
    ];
}
function event_get_unpaid_factures($client_id) {
    $api_key = get_option('vosfactures_api_key');
    $base_url = rtrim(get_option('vosfactures_api_url'), '/') . '/';

    $url = $base_url . "invoices.json?api_token={$api_key}&client_id={$client_id}&payment_status=issued&kind=vat";
    
    $response = wp_remote_get($url);
    
    if (is_wp_error($response)) {
        return null;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
//return $data;
    if (empty($data)) return null;

    $factures = [];
    foreach ($data as $item) {
       /* $factures[] = [
            'reference' => $item['number'],
            'id' => $item['id'],
            'date' => $item['issue_date'],
            'montant' => $item['price_gross'],
            'pdf_url' => $item['view_url']
        ];*/
        $factures[] = [
            'reference' => $item['number'],
            'id' => $item['id'],
            'date' => $item['issue_date'],
            'montant' => $item['price_gross'],
            'pdf_url' => $item['view_url'],
            'original_name' => $item['number'] . '.pdf',
            'doctitle' => 'Facture non payée'
        ];
    }

    return $factures;
}
function event_get_vosfactures_documents($type, $client_id) {
    $api_key = get_option('vosfactures_api_key');
    $base_url = rtrim(get_option('vosfactures_api_url'), '/') . '/';
    
    $url = $base_url . "invoices.json?api_token={$api_key}&client_id={$client_id}&per_page=1&sort=issue_date&direction=desc";
    
    // Type = devis ou facture
    if ($type === 'devis') {
        $url .= '&kind=estimate';
    } elseif ($type === 'facture') {
        $url .= '&kind=vat'; 
    }

    $response = wp_remote_get($url);
    
    if (is_wp_error($response)) {
        return null;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    if (empty($data)) return null;

    $documents = [];
    foreach ($data as $item) {
        
        $documents[] = [
            'reference' => $item['number'],
            'date' => $item['issue_date'],
            'montant' => $item['price_gross'],
            'pdf_url' => $item['view_url'],
            'original_name' => $item['number'] . '.pdf',
            'doctitle' => ucfirst($type)
        ];
    }

    return !empty($documents)?$documents[0]:[];
}
function event_vosfactures__download_and_attach_pdf($pdf_url, $original_name, $doctitle, $user_login, $post_id) {
    // Obtenir infos d’upload
    $upload_dir = wp_upload_dir();
    $year = date('Y');
    $custom_dir = $upload_dir['basedir'] . "/documents-crm/$year/$user_login";
    $custom_url = $upload_dir['baseurl'] . "/documents-crm/$year/$user_login";

    // Créer dossier si nécessaire
    if (!file_exists($custom_dir)) {
        mkdir($custom_dir);
    }

    // Nettoyer nom de fichier
    $safe_name = sanitize_file_name($original_name);
    $new_name = "{$doctitle} - {$safe_name}";
    $new_name = preg_replace('/[^a-zA-Z0-9._-]/', '', $new_name);

    $target_file = $custom_dir . '/' . $new_name;
    $target_url = $custom_url . '/' . $new_name;
    $pdf_url=$pdf_url.'.pdf';
    // Télécharger le fichier depuis l’URL
    $api_key = get_option('vosfactures_api_key');

    $response = wp_remote_get($pdf_url, [
        'timeout' => 20,
        'headers' => [
            'Authorization' => 'Token token=' . $api_key,
            'Accept' => 'application/pdf',
        ],
    ]);

    if (is_wp_error($response)) {
        return false;
    }

    $pdf_content = wp_remote_retrieve_body($response);

    if (empty($pdf_content)) {
        return false;
    }

    // Écrire le fichier localement
    $written = file_put_contents($target_file, $pdf_content);

    if ($written === false) {
        return false;
    }

    // Ajouter dans la méta du post
    $uploaded_files = get_post_meta($post_id, '_generated_event_pieces_joints', true);
    if (!is_array($uploaded_files)) {
        $uploaded_files = [];
    }

    $uploaded_files[] = $target_url;
    update_post_meta($post_id, '_generated_event_pieces_joints', $uploaded_files);

    return true;
}

function redirection_vofacture_shortcode_function($atts) {
   
    $current_url = trim($_SERVER['REQUEST_URI'], '/');
    if (!preg_match('#^vos-facture-paiment/([0-9]{9,})$#', $current_url, $matches)) {
        return ''; 
    }

    $trackinginvoice = $matches[1];
    return '<script>
    document.addEventListener("DOMContentLoaded", function () {
        const pathParts = window.location.pathname.split("/").filter(Boolean);
        const idx = pathParts.indexOf("vos-facture-paiment");
        if (idx !== -1 && pathParts[idx + 1]) {
            const invoiceId = pathParts[idx + 1];
            const redirectUrl = "https://portail-client.vosfactures.fr/banking/payments/new?from_index=no&invoice_id=" + invoiceId;
            window.location.href = redirectUrl;
        }
    });
</script>';
        
   

 
   
}

add_shortcode('redirection_vofacture_shortcode', 'redirection_vofacture_shortcode_function');
/**
 * Fonction qui crée une règle de réécriture personnalisée pour rediriger vers 
 * la page de paiement d'une facture avec un identifiant de facture unique.
 * Cette règle permet de capturer l'ID de la facture et de l'utiliser dans l'URL 
 * de la page "vos-facture-paiment" pour afficher les informations de paiement.
 */
add_action('init', 'crm_events_vf_custom_rewrite_rule', 10, 0);
function crm_events_vf_custom_rewrite_rule() {
    add_rewrite_rule(
        '^vos-facture-paiment/([0-9]{9,})?$',  
        'index.php?pagename=vos-facture-paiment&trackinginvoice=$matches[1]', 
        'top'
    );
    flush_rewrite_rules();  
}
/**
 * Fonction qui crée une la page de tracking si n'existe pas
 */
function create_vosfacture_redirect_page() {
    $slug = 'vos-facture-paiment';
    $page = get_page_by_path($slug);

    if (!$page) {
        wp_insert_post([
            'post_title'   => 'Redirection Paiement Facture',
            'post_name'    => $slug,
            'post_content' => '[redirection_vofacture_shortcode]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ]);
    }
}
add_action('init', 'create_vosfacture_redirect_page');