<?php 

add_shortcode('tracking_mails_list', 'crm_afficher_tracking_list');

function crm_afficher_tracking_listoo($atts) {
    wp_enqueue_script('shortcode-list-logs-js', plugin_dir_url(__FILE__) . 'shortcode_crm_event_logs_list.js', array(), '1.0', true);
    //wp_enqueue_style('shortcode-list-logs-css', plugin_dir_url(__FILE__) . 'shortcodes.css', array(), '1.0', true);
    //wp_enqueue_style('shortcode-list-logs-css', plugin_dir_url(__FILE__) . '../../global.css', array(), '1.0', true);
    
    wp_enqueue_script('shortcode-list-logs-data-table-js', plugin_dir_url(__FILE__) . '../../assets/js/jquery.dataTables.js', array(), '1.0', true);
    wp_enqueue_script('shortcod-list-logs-data-table-responsive-js', plugin_dir_url(__FILE__) . '../../assets/js/dataTables.responsive.min.js', array(), '1.0', true);
    wp_enqueue_style('shortcode-list-logs-data-table-css', plugin_dir_url(__FILE__) . '../../assets/styles/jquery.dataTables.css', array(), '1.0', 'all');
    wp_enqueue_style('shortcode-list-logs-data-table-responsive-css', plugin_dir_url(__FILE__) . '../../assets/styles/responsive.dataTables.min.css', array(), '1.0', 'all');
    
  
    $searchIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/recherche.svg';
    $atts = shortcode_atts([
        'count' => 10,  
    ], $atts, 'tracking_mails_list');

   
    $args = [
        'post_type' => 'crm_docs_gen', 
        'posts_per_page' => -1,
        'meta_query' => [
            [
                'key' => '_event_list_mail',
                'compare' => 'EXISTS',
            ]
        ]
    ];

    $query = new WP_Query($args);
    if (!$query->have_posts()) {
        return '<p>Aucun tracking trouvé.</p>';
    }

    
    $authors_uniques = [];

        foreach ($query->posts as $post) {
           
            $event_id = $post->ID;
             $logs = get_post_meta($event_id, '_event_list_mail', true);
       
            $eventUserId = get_post_meta($event_id, '_generated_event_user_id', true);
            $userDocId = !empty($eventUserId) ? $eventUserId : get_post_meta($event_id, '_generated_doc_user_id', true);
            $user_info = get_userdata($userDocId);
            if ($user_info && !empty($user_info->display_name)) {
                $user_name = $user_info->display_name;
                if (!isset($authors_uniques[$userDocId])) {
                    $authors_uniques[$userDocId] = $user_name;
                }
            }
       
    }
    
  
    
    $count = isset($atts['count']) ? $atts['count'] : 10;
    $output = '<div class="sy-crm-event-table-container">
    
    <div class="sy-crm-event-table-header"style="margin-bottom:15px">
    <div class="crm-table-header-quick-filter">
            <input type="text" id="sy-crm-events-logs-table-header-filter" value="" placeholder="Rechercher...">
            <button>  
                <img src="' . esc_url($searchIconUrl) . '" alt="Rechercher">
            </button>
        </div>

    ';
    $output .= '<select id="sy-crm-events-logs-table-author-filter" class="sy-crm-event-table-select-filter "style="max-width:300px">
    <option value="">Tous les utilisateurs</option>';
    foreach ($authors_uniques as $id => $name) {
        $output .= '<option value="' . esc_attr($name) . '">' . esc_html($name) . '</option>';
    }
    $output .= '</select></div>';
    

    $output .= '<table class="sy-crm-event-table "data-count="' . esc_html($count) . '" id="sy-crm-events-logs-table"style="width:100%;"><thead><tr><th>Tiers</th><th>Titre</th><th>Envoyé le</th><th>Dernière ouverture</th></tr></thead><tbody>';

    while ($query->have_posts()) {
        $query->the_post();
        $event_id = get_the_ID();
        $event_title = get_the_title();
        $logs = get_post_meta($event_id, '_event_list_mail', true);
        $date_format = get_option('date_format');
        $eventUserId = get_post_meta($event_id, '_generated_event_user_id', true);
        $userDocId = !empty($eventUserId) ? $eventUserId : get_post_meta($event_id, '_generated_doc_user_id', true);
        $user_info = get_userdata($userDocId);
       
        $user_name=$user_info->display_name;
        $company_name = get_user_meta($userDocId, 'billing_company', true);
        $nomAffiche=$company_name?$company_name:$user_name;
       
        $hashedId=  crm_events_generate_user_hash($userDocId);  
        $link=home_url('crm-customer/' . $hashedId.'?event='.$event_id);
        $linkProp=home_url('crm-customer/' . $hashedId);
        $datetime_format = 'd-m-y H:i';
        if (is_array($logs)) {
            $dernier_log_entry = null;
            $dernier_log_timestamp = null;
        
            foreach ($logs as $entry) {
                $date_ouverture = $entry['date_ouverture'] ?? null;
                $timestamp_log = $date_ouverture ? strtotime($date_ouverture) : null;
        
                // Check reouvertures
                $reouvertures = $entry['reouvertures'] ?? [];
                if (!empty($reouvertures) && is_array($reouvertures)) {
                    foreach ($reouvertures as $reopen) {
                        if (!empty($reopen['date'])) {
                            $reopen_time = strtotime($reopen['date']);
                            if ($reopen_time > $timestamp_log) {
                                $timestamp_log = $reopen_time;
                                $entry['date_ouverture'] = $reopen['date']; // Update to latest reouverture
                            }
                        }
                    }
                }
        
                if ($timestamp_log && ($dernier_log_timestamp === null || $timestamp_log > $dernier_log_timestamp)) {
                    $dernier_log_timestamp = $timestamp_log;
                    $dernier_log_entry = $entry;
                }
            }
        
            if ($dernier_log_entry) {
                $user_email = esc_html($dernier_log_entry['email'] ?? 'inconnu');
                $date_envoi = $dernier_log_entry['date_envoi'] ?? null;
                $timestamp_envoi = $date_envoi ? strtotime($date_envoi) : null;
        
                $output .= '<tr>';
                $output .= "<td data-url=' " . esc_url($linkProp) . "' class='sy-crm-events-logs-table-detail-cell'>" . $nomAffiche . "</td>";
                $output .= "<td data-url='" . esc_url($link) . "' class='sy-crm-events-logs-table-detail-cell' >" . $event_title . "</td>";
                $output .= "<td data-url='" . esc_url($link) . "' class='sy-crm-events-logs-table-detail-cell' data-order='" . esc_attr($timestamp_envoi) . "'>" . ($timestamp_envoi ? esc_html(date_i18n($datetime_format, $timestamp_envoi)) : '-') . "</td>";
                $output .= "<td data-url='" . esc_url($link) . "' class='sy-crm-events-logs-table-detail-cell' data-order='" . esc_attr($dernier_log_timestamp) . "'>" . esc_html(date_i18n($datetime_format, $dernier_log_timestamp)) . "</td>";
                $output .= '</tr>';
            }
        }
        
    }

    wp_reset_postdata();
    $output .= '</tbody></table>';
    return $output;
}

function crm_afficher_tracking_list($atts) {
    wp_enqueue_script('shortcode-list-logs-js', plugin_dir_url(__FILE__) . 'shortcode_crm_event_logs_list.js', array(), '1.0', true);
    //wp_enqueue_style('shortcode-list-logs-css', plugin_dir_url(__FILE__) . 'shortcodes.css', array(), '1.0', true);
    //wp_enqueue_style('shortcode-list-logs-css', plugin_dir_url(__FILE__) . '../../global.css', array(), '1.0', true);
    wp_enqueue_script('shortcode-list-logs-data-table-js', plugin_dir_url(__FILE__) . '../../assets/js/jquery.dataTables.js', array(), '1.0', true);
    wp_enqueue_script('shortcod-list-logs-data-table-responsive-js', plugin_dir_url(__FILE__) . '../../assets/js/dataTables.responsive.min.js', array(), '1.0', true);
    wp_enqueue_style('shortcode-list-logs-data-table-css', plugin_dir_url(__FILE__) . '../../assets/styles/jquery.dataTables.css', array(), '1.0', 'all');
    wp_enqueue_style('shortcode-list-logs-data-table-responsive-css', plugin_dir_url(__FILE__) . '../../assets/styles/responsive.dataTables.min.css', array(), '1.0', 'all');

    $searchIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/recherche.svg';
    $atts = shortcode_atts([
        'count' => 10,  
    ], $atts, 'tracking_mails_list');

    // Get the current logged-in user ID and their roles
    $current_user_id = get_current_user_id();
    $current_user = wp_get_current_user();
    $user_roles = $current_user->roles;

    // Set up the arguments for the WP_Query
    $args = [
        'post_type' => 'crm_docs_gen', 
        'posts_per_page' => -1,
        'meta_query' => [
            [
                'key' => '_event_list_mail',
                'compare' => 'EXISTS',
            ]
        ]
    ];
    if (!is_user_logged_in()) {
        return ''; // Retourner une chaîne vide si l'utilisateur n'est pas connecté
    }

    // Modify the query based on user role
    if (in_array('utilisateur_crm', $user_roles)||in_array('administrator', $user_roles) || in_array('responsable_crm', $user_roles)) {
    
        if (in_array('utilisateur_crm', $user_roles)) {
            $args['author'] = $current_user_id;
        }

    $query = new WP_Query($args);
    if (!$query->have_posts()) {
        return '<p>Aucun tracking trouvé.</p>';
    }

    $authors_uniques = [];
    foreach ($query->posts as $post) {
        $event_id = $post->ID;
        $post_author_id = get_post_field('post_author', $event_id);
        $author_name = get_the_author_meta('display_name', $post_author_id);
    
        if (!array_key_exists($post_author_id, $authors_uniques)) {
            $authors_uniques[$post_author_id] = $author_name;
        }
    }

    $count = isset($atts['count']) ? $atts['count'] : 10;
    $output = '<div class="sy-crm-event-table-container">
    <div class="sy-crm-event-table-header"style="margin-bottom:15px">
    <div class="crm-table-header-quick-filter">
            <input type="text" id="sy-crm-events-logs-table-header-filter" value="" placeholder="Rechercher...">
            <button>  
                <img src="' . esc_url($searchIconUrl) . '" alt="Rechercher">
            </button>
        </div>
    ';
    if (!in_array('utilisateur_crm', $user_roles)) {
       
    $output .= '<select id="sy-crm-events-logs-table-author-filter" class="sy-crm-event-table-select-filter "style="max-width:300px">
    <option value="">Tous les utilisateurs</option>';
    /**/foreach ($authors_uniques as $author_id=> $name) {
        $selected = ($author_id == $current_user_id) ? ' selected' : '';
        $output .= '<option value="' . esc_attr($name) . '"' . $selected . '>' . esc_html($name) . '</option>';
       }

    $output .= '</select>';
    }
    $output .= '</div><table class="sy-crm-event-table "data-count="' . esc_html($count) . '" id="sy-crm-events-logs-table"style="width:100%;"><thead><tr><th>Tiers</th><th>Titre</th><th>Envoyé le</th><th>Dernière ouverture</th></tr></thead><tbody>';

    while ($query->have_posts()) {
        $query->the_post();
        $event_id = get_the_ID();
        $event_title = get_the_title();
        $logs = get_post_meta($event_id, '_event_list_mail', true);
        $date_format = get_option('date_format');
        $eventUserId = get_post_meta($event_id, '_generated_event_user_id', true);
        $userDocId = !empty($eventUserId) ? $eventUserId : get_post_meta($event_id, '_generated_doc_user_id', true);
        $user_info = get_userdata($userDocId);
       
        $user_name = $user_info->display_name;
        $company_name = get_user_meta($userDocId, 'billing_company', true);
        $nomAffiche = $company_name ? $company_name : $user_name;
       
        $hashedId = crm_events_generate_user_hash($userDocId);  
        $link = home_url('crm-customer/' . $hashedId . '?event=' . $event_id);
        $linkProp = home_url('crm-customer/' . $hashedId);
        $datetime_format = 'd-m-y H:i';
        $post_author_id = get_post_field('post_author', $event_id);
        $author_name =get_the_author_meta('display_name', $post_author_id);
       
        if (is_array($logs)) {
            $dernier_log_entry = null;
            $dernier_log_timestamp = null;
        
            foreach ($logs as $entry) {
                $date_ouverture = $entry['date_ouverture'] ?? null;
                $timestamp_log = $date_ouverture ? strtotime($date_ouverture) : null;

                // Check reouvertures
                $reouvertures = $entry['reouvertures'] ?? [];
                if (!empty($reouvertures) && is_array($reouvertures)) {
                    foreach ($reouvertures as $reopen) {
                        if (!empty($reopen['date'])) {
                            $reopen_time = strtotime($reopen['date']);
                            if ($reopen_time > $timestamp_log) {
                                $timestamp_log = $reopen_time;
                                $entry['date_ouverture'] = $reopen['date']; // Update to latest reouverture
                            }
                        }
                    }
                }

                if ($timestamp_log && ($dernier_log_timestamp === null || $timestamp_log > $dernier_log_timestamp)) {
                    $dernier_log_timestamp = $timestamp_log;
                    $dernier_log_entry = $entry;
                }
            }

            if ($dernier_log_entry) {
                $user_email = esc_html($dernier_log_entry['email'] ?? 'inconnu');
                $date_envoi = $dernier_log_entry['date_envoi'] ?? null;
                $timestamp_envoi = $date_envoi ? strtotime($date_envoi) : null;

                $output .= '<tr data-auteur="' . esc_attr($author_name) . '">';
                $output .= "<td data-url=' " . esc_url($linkProp) . "' class='sy-crm-events-logs-table-detail-cell'>" . $nomAffiche . "</td>";
                $output .= "<td data-url='" . esc_url($link) . "' class='sy-crm-events-logs-table-detail-cell' >" . $event_title . "</td>";
                $output .= "<td data-url='" . esc_url($link) . "' class='sy-crm-events-logs-table-detail-cell' data-order='" . esc_attr($timestamp_envoi) . "'>" . ($timestamp_envoi ? esc_html(date_i18n($datetime_format, $timestamp_envoi)) : '-') . "</td>";
                $output .= "<td data-url='" . esc_url($link) . "' class='sy-crm-events-logs-table-detail-cell' data-order='" . esc_attr($dernier_log_timestamp) . "'>" . esc_html(date_i18n($datetime_format, $dernier_log_timestamp)) . "</td>";
                $output .= '</tr>';
            }
        }
    }

    wp_reset_postdata();
    $output .= '</tbody></table>';
    return $output;
}
else
{
    return '';
}
}
