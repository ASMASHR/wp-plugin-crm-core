<?php
/**
 * Le shortcode [crm_notes] Génère une note à partir d'une template par defaut.
 *
 *
 * Paramètres :
 * - title (string) : Le texte affiché sur le bouton pour générer le document. Par défaut : 'Memo' et peut être vide.
 * - ico (lien) : L'icone affiché avant le text sur le bouton pour générer le document. Par défaut : vide.
 *
 * Le formulaire de génération de document inclut :
 * - Un bouton pour afficher le sidebar.
 * - La possibilité d'afficher les champs nécessaires pour le template ajouté par defaut .
 * - Un bouton pour générer la note une fois que tous les champs sont remplis.
 *
 * @param mixed $atts Les attributs passés au shortcode, y compris 'ico' et 'title'.
 * @return bool|string Le contenu HTML du formulaire pour générer un document, ou un message d'erreur en cas de problème.
 */
function shortcode_generation_notes($atts) {
    
    $atts = shortcode_atts([
        'title' => 'Memo', 
        'ico' => '', 
    ], $atts, 'crm_notes');
    ob_start();
   
    $infoIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/info-icon.svg';
    $addIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/add-memo-icon.svg';
    $current_url = $_SERVER['REQUEST_URI'];
    $user_id=null;
    $button_class = strtolower(preg_replace('/[^a-z0-9]+/', '-', $atts['title'])); 
    $default_template_id=get_option( 'crm_document_plugin_default_template');
    
    if (strpos($current_url, 'crm-customer/') !== false) {
        $hashedId = get_hashed_id_from_url(); 
        $user_id = $hashedId ? get_user_id_from_hash($hashedId) : null;
    
        if (!$user_id) {
            $output= '<p>ID utilisateur invalide ou expiré.</p>';
            return $output; 
        }
    }
    else
    {
        return '' ;
    }

    
    $current_user = wp_get_current_user();

    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $roles = $current_user->roles;
    $user_crm_can_edit=is_array($associates_users) && in_array($current_user->ID, $associates_users);
    $user_role = get_userdata($user_id)->roles[0];

    $user_mail =get_userdata($user_id)->user_email ;
    $access_by_role = [
        'tiers',
        'utilisateur_crm',
        'responsable_crm',
        'non_qualifie',
        'hors_cible',
        'prospect',
        'customer',
        'fournisseur',
    ];
    if (!in_array($user_role,$access_by_role)){
        return '';
    }
    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_event_tags';
    $tags = $wpdb->get_results("SELECT * FROM $table_name WHERE status = 1");
  
$return_path   = get_option('crm_event_return_path', '');
$list_unsub    = get_option('crm_event_list_unsubscribe', '');
$smtp_host = get_option('crm_smtp_default_host', '');
$smtp_login = get_option('crm_smtp_default_email', '');
$smtp_port = get_option('crm_smtp_default_port', '');
$smtp_password = get_option('crm_smtp_default_password', '');

$custom_smtp   = !empty($smtp_host) && !empty($smtp_login) && !empty($smtp_port) && !empty($smtp_password);

$competed_smtp_data = !empty($return_path) && !empty($list_unsub)&&$custom_smtp ;

$user_can_send_email =get_user_meta($current_user->ID, 'user_can_send_email', true);    
    if (in_array('responsable_crm', $roles) || in_array('administrator', $roles) || $current_user->ID === $user_id||$user_crm_can_edit) {
    ?>
    <div id="gen-note-app">
     
        <button id="sy-crm-event-show-note-sidebar-btn" 
         data-user-id="<?php echo esc_attr($user_id); ?>"  
         data-template-id="<?php echo esc_attr($default_template_id); ?>" 
         class="sy-crm-event-button sy-crm-event-note-btn" data-user-id="<?php echo $user_id ? $user_id : ''; ?>">
         <?php echo '<img src="' . (!empty($atts['ico']) ? esc_url($atts['ico']) : $addIconUrl) . '">';?>

            <?php echo ($atts['title']=="Memo")? 'Memo' : esc_html($atts['title']) ; ?>
        </button>

       
        <div id="sy-crm-event-note-sidebar"class="sy-crm-event-sidebar sy-crm-event-note-sidebar" style="display:none;">
            <div class="sy-crm-event-sidebar-header">
                    <h5 class="">Ajouter une note</h5>
                    <button class="sy-crm-event-sidebar-header-btn discard-note-sidebar">X</button>
            </div>
            <div class="sy-crm-event-sidebar-content">
                <div id="sy-crm-event-note-sidebar-notif"></div>
                    <input type="text" value="<?php echo ($user_id?$user_id : '') ; ?>" id="sy-crm-event-note-sidebar-user-id" hidden>
                    <input type="text" value="<?php echo ($default_template_id?$default_template_id : '') ; ?>" id="sy-crm-event-note-sidebar-template-id" hidden>
                    <div class="sy-crm-event-sidebar-content-top">
                        <div class="sy-crm-event-sidebar-title">
                                <input class="crm-doc-input"type="text"id="note-title">    
                                <div class=" text-error"style="display:none">Le titre est obligatoire</div>
                        
                        </div>
                        <div class="crm_events_tags_container">
                    

                                <div class="crm_events_tags_list">
                                    <?php if (!empty($tags)) {
                                        foreach ($tags as $tag) {
                                            // Affichage des tags sous forme de span
                                            echo '<span class="crm_events_tags_tag event_tag "' . esc_html(sanitize_title($tag->tag_name)). '" data-id="' . esc_attr($tag->id) . '"style="'. esc_html($tag->tag_style) . '">' . esc_html($tag->tag_name) . '</span>';
                                        }
                                    }
                                    ?>

                                </div>
                                <div class="crm_events_tags_selected_list"></div>
                        </div>

                    </div>
                    <div class="sy-crm-event-sidebar-content-row">
                        <div class="sy-event-sidebar-content-container">
                            <label for="sy-crm-event-note-sidebar-date">Date :</label>
                            <input class="crm-event-input" value="" id="sy-crm-event-note-sidebar-date" type="date"></input>
                            <div class=" text-error" style="display:none;">La date de l\'évènement est requise.</div>
                        </div>
                        <div class="sy-event-sidebar-content-container">
                            <div class="sy-event-sidebar-custom-label">
                            <label for="sy-crm-event-note-sidebar-duration">Durée : </label>
                                <span class="sy-event-sidebar-custom-info-container">
                                <img  src="<?php echo $infoIconUrl ; ?>" >
                                <span class="sy-event-sidebar-custom-info-tooltip" style="display: none;">Format attendu : nbheure h nb min (ex: 28h15).</span>
                                </span>
                            </div>
                            <input class="event-duration-input crm-event-input" value="" id="sy-crm-event-note-sidebar-duration" type="text" placeholder="Durée"></input>
                            <div class=" text-error" style="display:none;">La durée de l\'évènement est requise.</div>
                        </div>

                    </div>
                    <div class="duration-warning"></div>

                    <!--<p class="variables__container_title">Champs nécessaire :</p>-->
                    <div id="sy-crm-event-note-sidebar-vars"class="sy-event-sidebar-content-bottom">

                    </div>
                    <div id="sy-crm-event-note-sidebar-options" style="display:none;">
                    <div id="upload-events-container">
                            <label for="sy-crm-event-note-sidebar-options-files"class="crm-doc-label">Ajouter des pièces joints :</label>
                            <input type="file" id="sy-crm-event-note-sidebar-options-files" name="additional_events[]" multiple accept=".pdf,.xls,.xlsx,.doc,.docx,.txt,.jpg,.png,.jpeg,.zip">
                        </div>
                        <div class=" text-error"></div>
                    </div>
                    <?php if($competed_smtp_data &&$user_can_send_email==1):?>
            
                    <div class="sy-crm-event-mail-top-wrapper">
                         <div class="form-row" >

                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" id="sy-crm-event-note-send-email-checkbox" name="send_email">
                                <label class="form-check-label" for="sy-crm-event-note-send-email-checkbox">
                                    Envoyer le contenu par mail
                                </label>
                            </div>
                        </div>
                        <div class="form-row m-15"id="sy-crm-event-note-send-email-section-attachment-option"style="display:none">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="sy-crm-event-note-send-mail-form-send-attachments-via-link" name="send_attachments_via_link" value="1">
                                    <label class="form-check-label" for="sy-crm-event-note-send-mail-form-send-attachments-via-link">
                                        Envoyer les fichiers par lien
                                    </label>
                                </div>
                            </div>
                    </div>
                   

                        <div id="sy-crm-event-note-send-email-section" class="sy-crm-event-email-section"style="display:none;">
                            <label>Destinataires :</label>
                            <div id="sy-crm-event-note-mail-recipients-wrapper" class="sy-crm-event-mail-recipients-wrapper">
                                <div class="recipient-group">
                                    <div class="recipient-group-top">
                                        <input type="email" name="sy-crm-event-note-recipients[]" class="sy-crm-event-note-recipient-input" value="<?php echo $user_mail ; ?>">
                                    </div>
                                </div>
                            </div>

                            <button type="button" class="sy-crm-event-button sy-crm-event-recipient-button sy-crm-event-note-add-recipient-btn">+ Ajouter</button>

                            
                        </div>
                    <?php endif;?>
                
            </div>
            <div class="sy-crm-event-sidebar-footer">
                    <button type="button" class="discard-note-sidebar">Fermer</button>
                            
                    <button type="submit"class="sy-crm-event-sidebar-footer-submit-btn " id="sy-crm-event-note-sidebar-submit-btn">Générer</button>
                        
                       
                        
            </div>
            
        </div>
        

    </div>
    

    <?php
    }
    else{
        return '' ;
    }
    return ob_get_clean();
}
//add_shortcode('crm_notes', 'shortcode_generation_notes');

function shortcode_crm_notes_enqueue_scripts() {
    
    wp_enqueue_script(
        'shortcode_crm_notes',
        plugin_dir_url(__FILE__) . 'shortcode_crm_notes.js',
        array('jquery'),
        null,
        true
    );
    wp_localize_script(
        'shortcode_crm_notes',
        'ajax_object',
        array('ajax_url' => admin_url('admin-ajax.php'))
    );

}
add_action('wp_enqueue_scripts', 'shortcode_crm_notes_enqueue_scripts');