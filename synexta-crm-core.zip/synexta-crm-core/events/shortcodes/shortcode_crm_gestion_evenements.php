<?php
/**
 * Le shortcode [crm_gestion_evenements] utilisé pour afficher une liste des events générés dans le CRM.
 * Ce shortcode permet de récupérer et d'afficher les events générés par l'utilisateur actuel ou ceux associés à un utilisateur spécifique,
 * en fonction de l'URL ou des rôles de l'utilisateur. Il inclut des filtres par template et utilisateur, ainsi que des options de tri dynamiques.
 * 
 * Fonctionnalités principales :
 * 1. **Filtrage par template** : Permet de filtrer les events en fonction d'un template spécifique.
 * 2. **Gestion des rôles d'utilisateur** : Affiche les events en fonction des rôles de l'utilisateur (utilisateur_crm, administrateur, responsable_crm, etc.).
 * 3. **Filtrage par utilisateur spécifique** : Si l'URL contient un identifiant d'utilisateur, seuls les events associés à cet utilisateur sont affichés.
 * 4. **Critères de récupération des events** : Récupère les events en fonction de l'ID du template et de l'ID de l'utilisateur.
 * 5. **Tri des events** : Permet de trier les events par date, avec des options pour inverser l'ordre du tri.
 * 6. **Affichage sous forme de tableau** : Affiche les events sous forme de tableau avec des liens vers les PDF associés.
 * 7. **Modification via Sidebar** : Ajoute une sidebar qui permet à l'utilisateur de modifier le contenu des events, gérer les events qui lui sont attachés, et régénérer le event PDF. 

 * 8. **URL de tri dynamique** : Permet de modifier dynamiquement l'ordre de tri des events via l'interface.
 * 
 * @param mixed $atts Attributs du shortcode (ex. 'nom_template' pour filtrer par template).
 * @return string Tableau HTML contenant les events générés ou un message si aucun event n'est trouvé.
*/
function crm_list_events_generes_shortcode($atts) {
    $atts = shortcode_atts(array(
        'nom_template' => '',
        'count' => 10, 
        'liste'=>"oui",
        'generer'=>"oui",
    ), $atts, 'crm_gestion_evenements');
    $template_id=null;
    if (!empty($atts['nom_template'])) {
        $template_id=get_post_id_from_title($atts['nom_template']); 
    }
    $current_user = wp_get_current_user();
    $current_user_roles = $current_user->roles;
    $current_user_id = $current_user->ID;
    
    $current_url = $_SERVER['REQUEST_URI'];
    $user_id = null;

    // Vérification de l'ID utilisateur dans l'URL pour crm-customer
    if (strpos($current_url, 'crm-customer/') !== false) {
        $hashedId = get_hashed_id_from_url();
        $user_id = $hashedId ? get_user_id_from_hash($hashedId) : null;
		$tiersId=$user_id;
        if (!$user_id || !get_userdata($user_id)) {
            return '<p>ID utilisateur invalide ou expiré.</p>';
        }
    }

    else
    {
        return '' ;
    }
	$tiersId=$user_id;
    $user_role = get_userdata($user_id)->roles[0];
    $access_by_role = [
        'tiers',
        'utilisateur_crm',
        'responsable_crm',
        'non_qualifie',
        'hors_cible',
        'prospect',
        'customer',
        'fournisseur',
    ];
    if (!in_array($user_role,$access_by_role)){
        return '';
    }
    $addbtn=false;
    $displayList=false;
    if (!empty($atts['generer'])&&$atts['generer']=="oui") {
        $addbtn=true;
    }
    if (!empty($atts['liste'])&&$atts['liste']=="oui") {
        $displayList=true;
    }
    $meta_query = array();
    
    if($template_id){
        $meta_query[] = array(
            'key' => '_used_template_id',
            'value' => $template_id,
            'compare' => 'IN',
        );
    }
    if (in_array('utilisateur_crm', $current_user_roles)) {
        $associated_user_ids = array($current_user_id);

        $all_users = get_users(array(
            'meta_query' => array(
                array(
                    'key' => 'user_status',
                    'value' => array('ACTIF', 'actif', 'active'),
                    'compare' => 'IN',
                ),
            ),
        ));

        foreach ($all_users as $user) {
            $associer_crm = get_user_meta($user->ID, 'associer_crm', true);
            if ($associer_crm && in_array($current_user_id,  $associer_crm)) {
                $associated_user_ids[] = $user->ID;
            }
        }

        // Ajouter les critères de récupération
        $meta_query[] = array(
            'key' => '_generated_event_user_id',
            'value' => $associated_user_ids,
            'compare' => 'IN',
        );
    } 
    elseif (!in_array('administrator', $current_user_roles) && !in_array('responsable_crm', $current_user_roles)) {
        // Si l'utilisateur n'est ni administrateur ni responsable, récupérer seulement ses events
        $meta_query[] = array(
            'key' => '_generated_event_user_id',
            'value' => $current_user_id,
            'compare' => '=',
        );
        $addbtn=false;
    }
   

    if ($user_id) {

        $meta_query = array(array(
            'key' => '_generated_event_user_id',
            'value' => $user_id,
            'compare' => '=',
        ));
        
    }
     $count = isset($atts['count']) ? $atts['count'] : 10;
           
    $args = array(
        'post_type' => 'crm_docs_gen',
        'posts_per_page' => -1, 
        //'posts_per_page' => $atts['count'],  
        'post_status' => 'publish',
        'meta_query' => $meta_query,
        //'offset' => $offset,
        'orderby' => 'date',
        'order' => 'DESC',
    );
    
   
    $events = get_posts($args);
       
    if (isset($_GET['event'])) {
        $evenement = intval($_GET['event']);
         
            echo "<script>
                jQuery(event).ready(function($) {
                 $('#generated_event_list').parent().addClass('opnedAcc')
                    const currentTd = $('.event-info-cell[data-id=\"$evenement\"]').first();
                  
                      let parentDiv = $('#generated_event_list').parent();
         
                    setTimeout(function() {
                         parentDiv.css('max-height', '522px');
                        parentDiv.css('display', 'block ');
                        parentDiv.css('transition', 'max-height 0.4s ease-in-out');
                            currentTd.trigger('click');
                    }, 1000);
                });
            </script>
    ";
    }
  

  
    // Construction des URLs pour le tri
    $base_url = strtok($_SERVER['REQUEST_URI'], '?');

    
    // Construction du tableau de sortie
    $output = crm_table_output($events,$count,$tiersId, $current_user_roles,$addbtn,$displayList);
    return $output;
    
}
add_shortcode('crm_gestion_evenements', 'crm_list_events_generes_shortcode');


function crm_list_events_generes_init_resources(){
    wp_enqueue_script('shortcode-list-events-js', plugin_dir_url(__FILE__) . 'shortcode_crm_gestion_evenements.js', array(), '1.0', true);
//wp_enqueue_style('shortcode-list-events-css', plugin_dir_url(__FILE__) . 'shortcodes.css', array(), '1.0', true);
//wp_enqueue_style('shortcode-list-logs-css', plugin_dir_url(__FILE__) . '../../global.css', array(), '1.0', true);
   
wp_enqueue_script('shortcode-list-events-data-table-js', plugin_dir_url(__FILE__) . '../../assets/js/jquery.dataTables.js', array(), '1.0', true);
wp_enqueue_script('shortcod-list-events-data-table-responsive-js', plugin_dir_url(__FILE__) . '../../assets/js/dataTables.responsive.min.js', array(), '1.0', true);
wp_enqueue_style('shortcode-list-events-data-table-css', plugin_dir_url(__FILE__) . '../../assets/styles/jquery.dataTables.css', array(), '1.0', 'all');
wp_enqueue_style('shortcode-list-events-data-table-responsive-css', plugin_dir_url(__FILE__) . '../../assets/styles/responsive.dataTables.min.css', array(), '1.0', 'all');

}
function crm_list_events_generes_get_tags_from_db() {

    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_event_tags';
    return $wpdb->get_results("SELECT * FROM $table_name WHERE status = 1");
}

function crm_list_events_generes_get_users_for_roles($roles) {
    return get_users(['role__in' => $roles]);
}
function crm_list_events_generes_load_edit_sidebar($competed_smtp_data ,$user_can_send_email,$user_mail){
     $infoIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/info-icon.svg';
    $nextIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/next.svg';
    $previousIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/previous.svg';
    $tags=crm_list_events_generes_get_tags_from_db();
    $output='';
    $output .= '
    <div class="sy-crm-event-sidebar" id="sy-crm-event-edit-sidebar"style="display:none;">
    <form id="sy-crm-event-edit-sidebar-form" novalidate>
        <div class="sy-crm-event-sidebar-header">
            <h5 class=""> <span id="crm-event-sidebar-header-title"></span></h5>
            <button class="sy-crm-event-sidebar-header-btn discard-sidebar">X</button>
        </div>
        <div class="crm-event-sidebar-msg"id="sy-crm-event-edit-sidebar-notif"></div>
        <div class="sy-crm-event-sidebar-content"> 
                
            <div class="sy-crm-event-edit-sidebar-content-top">
                <div class="sy-crm-event-sidebar-content-top-left">
                    <div class="sy-crm-event-sidebar-content-row">
                        <a id="sy-crm-event-edit-sidebar-tier" href=""class="sy-crm-event-edit-sidebar-tier"></a>
                    </div>
                    <input type="text" id="sy-crm-event-edit-sidebar-event-id" name="generated_event_id" class="form-control" style="display:none"value="" readonly />
                     
                        <input type="text" id="sy-crm-event-edit-sidebar-event-title"data-original-value="" name="generated_event_title"  class="crm-doc-title"value="" />
                        <div class="crm_events_tags_container">
                            
                        <div class="crm_events_tags_list  " style="display:none">';
                            if (!empty($tags)) {
                                foreach ($tags as $tag) {
                                    $output .= '<span class="crm_events_tags_tag  event_tag " ' . esc_html(sanitize_title($tag->tag_name)).'" data-id="' . esc_attr($tag->id) . '"style="'. esc_html($tag->tag_style) . '">' . esc_html($tag->tag_name) . '</span>';
                                }
                            }
                    
                    $output .= '
                        </div>
                        <div class="crm_events_tags_selected_list crm_events_tags_selected_list_edit_sideBar "data-initial-tags=""></div>
                        </div>
            
                        <div class="text-error"></div>
                    <div class="sy-crm-event-sidebar-content-row creator-date-container">
                        <p id="sy-crm-event-edit-sidebar-creation-date"class="crm-doc-sysdetail"></p>
                        <p id="sy-crm-event-edit-sidebar-creator"class="crm-doc-sysdetail"></p>
                    </div>
                    <div class="sy-crm-event-sidebar-content-row date-duration-container">
                        <div class="sy-event-sidebar-content-container">
                            <label for="sy-crm-event-edit-sidebar-date">Date de l\'évènement :</label>
                            <input class="crm-event-input" value="" id="sy-crm-event-edit-sidebar-date" type="date"></input>
                            <div class="text-error" style="display:none;">La date de l\'évènement est requise.</div>
                        </div>
                        <div class="sy-event-sidebar-content-container">
                            <div class="sy-event-sidebar-custom-label">
                            <label for="sy-crm-event-edit-sidebar-duration">Durée : </label>
                                <span class="sy-event-sidebar-custom-info-container">
                                <img  src="' . esc_url($infoIconUrl) . '" >
                                <span class="sy-event-sidebar-custom-info-tooltip" style="display: none;">Format attendu : nbheure h nb min (ex: 28h15).</span>
                                </span>
                            </div>
                            <input class="crm-event-input event-duration-input" value="" id="sy-crm-event-edit-sidebar-duration" type="text" placeholder="Durée"></input>
                            <div class="text-error" style="display:none;">La durée est requise.</div>
                        </div>
                    </div>
                    <div class="duration-warning"></div>
            
                    <div class="sy-crm-event-sidebar-content-row">
                <div id="sy-crm-event-edit-sidebar-association-users-options"class="sy-crm-event-sidebar-association-users-options"style="display:none;">
                            <label for="">Associer l\'évènement à des utilisateurs : </label>
                            <div class="sy-crm-event-edit-sidebar-association-users-container">
                            <div id="sy-event-edit-sidebar-users-list-trigger" class="sy-event-sidebar-users-list-trigger"data-edit="0">';
                            $users = get_users([ 'role__in' => ['responsable_crm','utilisateur_crm']]);
                            foreach ($users as $user) {
                                $output .= '<span class="sy-event-edit-sidebar-users-list-selected-item" data-id="' . $user->ID . '">' . esc_html($user->display_name) . '</span>';
                            }
                            
                            $output .='</div>
    
                            <div id="sy-event-edit-sidebar-users-list" class="sy-event-sidebar-users-dropdown-list">';
                            foreach ($users as $user) {
                                $output .= '<div class="sy-event-edit-sidebar-users-list-item" data-id="' . $user->ID . '">' . esc_html($user->display_name) . '</div>';
                            }
                            
                            $output .='</div></div>
                </div>
            </div>
                    <div id="sy-crm-event-edit-sidebar-content"></div>
                    
                    <div class=""id="sy-crm-event-edit-sidebar-version" style="display:none;">
                        <p><strong>La version du template utilisé dans la création de ce event a été modifiée. Voulez-vous vraiment modifier le contenu de ce event ?</strong></p>
                    </div>
        
                    <div id="sy-crm-event-edit-sidebar-vars-container"style="display:none;">
                        <!-- Conteneur pour les variables -->
                        
                        <p class="sy-crm-event-edit-sidebar-vars-title">Données à modifier :</p>
                        <div id="sy-crm-event-edit-sidebar-vars" ></div>
                    </div>
                </div>
                <div class="sy-crm-event-sidebar-content-top-right"style="">
                    <!-- Conteneur pour les pièces jointes -->
                    <div id="sy-crm-event-edit-sidebar-options" style="display:none;"></div>
                    <div id="sy-crm-event-edit-sidebar-options-new" style="display:none;" >
                        
                            <label for="sy-crm-event-edit-sidebar-options-new-attachment">Ajouter un fichier :</label>
                            <input type="file" id="sy-crm-event-edit-sidebar-options-new-attachment" name="new-attachment[]" multiple />
                        
                    </div>
                    <div id="sy-crm-event-edit-sidebar-options-historique-emails" style="display:none;margin-top: 15px;" >
                        
                           
                    </div>
                    
                    
                </div>
            </div>
            <div class="sy-crm-event-sidbar-content-bottom">';
            if($competed_smtp_data &&$user_can_send_email==1)
            {
            $output .= '

            <div id="sy-crm-edit-event-send-email-section-container">
                        
                    <div class="sy-crm-event-mail-top-wrapper">
                        <div class="form-row">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" id="sy-crm-edit-event-send-email-checkbox" name="send_email">
                                <label class="form-check-label" for="sy-crm-edit-event-send-email-checkbox">
                                    Envoyer le contenu par mail
                                </label>
                            </div>
                        </div>
                        <div class="form-row m-15"id="sy-crm-edit-event-send-mail-options"style="display:none">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="sy-crm-edit-event-send-mail-form-send-attachments-via-link" name="send_attachments_via_link" value="1">
                                <label class="form-check-label" for="sy-crm-edit-event-send-mail-form-send-attachments-via-link">
                                    Envoyer les fichiers par lien
                                </label>
                            </div>
                        </div>
                    </div>

                        <div id="sy-crm-edit-event-send-email-section"class="sy-crm-event-email-section" style="display:none;">
                            <label>Destinataires :</label>
                            <div id="sy-crm-edit-event-mail-recipients-wrapper" class="sy-crm-event-mail-recipients-wrapper">
                                <div class="recipient-group">
                                    <div class="recipient-group-top">
                                        <input type="email" name="sy-crm-edit-event-recipients[]" class="sy-crm-edit-event-recipient-input" value="' .$user_mail.'">
                                    </div>
                                </div>
                            </div>

                            <button type="button" class="sy-crm-event-button sy-crm-event-recipient-button sy-crm-edit-event-add-recipient-btn">+ Ajouter</button>

                        </div>
                    </div>
                    ';}
                   
                    $output .= '   

            </div>
                        
                        

        <div class="sy-crm-event-edit-sidebar-footer">
            <button type="button" class="sy-crm-event-button event-info-cell sy-crm-event-prev-button " id="sy-crm-event-edit-sidebar-pev-button">
            <img src="' . esc_url($previousIconUrl) . '"></button>
            
            <div class="sy-crm-event-edit-sidebar-footer-center">
                <button type="button" class="sy-crm-event-button discard-btn" id="generate_event_edit_discard">Fermer</button>';
                if($competed_smtp_data &&$user_can_send_email==1)
                {
                $output .= '
                <button type="button" class="sy-crm-event-button btn btn-primary crm-form-btn sy-crm-event-envoi-button"id="generate_event_envoi_btn">Envoyer</button>';
                                }              
                                
                $output .= '  <button type="button" class="sy-crm-event-button btn btn-primary crm-form-btn"id="generate_event_confirm_edit_btn"style="display:none">Editer</button>

                <button type="button" class="sy-crm-event-button btn btn-primary crm-form-btn"id="sy-crm-event-edit-sidebar-confirm-edit-btn" data-id="">Editer</button>
                <button type="submit" class="sy-crm-event-button btn btn-primary crm-form-btn"id="sy-crm-event-edit-sidebar-submit-btn"style="display:none;" disabled>Sauvegarder</button>
                <button type="button" class="sy-crm-event-button btn btn-secondary crm-form-btn crm-event-delete-event" id="sy-crm-event-edit-sidebar-delete-btn"data-id=""data-notif-container="sy-crm-event-edit-sidebar-notif">Supprimer</button>
                
            </div>
            <button type="button" id="sy-crm-event-edit-sidebar-next-button"class="sy-crm-event-button event-info-cell sy-crm-event-next-button " data-id="">
                <img src="' . esc_url($nextIconUrl) . '">
            </button>
            
        </div>
        </div>
    </form>
    </div>
    ';

   
   

    return $output;
}
function crm_list_events_generes_load_sendEmails_sidebar($user_mail){
    $output='';
    $output.='
    <div class="sy-crm-event-sidebar" id="sy-crm-event-send-mail-sidebar"style="display:none;">
    <form id="sy-crm-event-send-mail-form" novalidate>
        <div class="sy-crm-event-sidebar-header">
            <h5 class="">Envoyer le contenu de l\'événement par email</h5>
            <button class="sy-crm-event-send-mail-header-btn discard-sidebar">X</button>
        </div>
        <div class="sy-crm-event-send-mail-sidebar-msg"id="sy-crm-event-send-mail-sidebar-notif"></div>

        
        <div class="sy-crm-event-send-mail-content"> 
        <label>Contenu de l\'evenement :</label>
        <div id="sy-crm-event-mail-content-preview"></div>
        <hr>
        <div class="sy-crm-event-email-section">
        <div class="form-row m-15"id="sy-crm-event-send-mail-form-send-attachments-via-link-container">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="sy-crm-event-send-mail-form-send-attachments-via-link" name="send_attachments_via_link" value="1">
                <label class="form-check-label" for="sy-crm-event-send-mail-form-send-attachments-via-link">
                    Envoyer les fichiers par lien
                </label>
            </div>
        </div>
        <label>Destinataires :</label>
         <div id="sy-crm-event-mail-recipients-wrapper"class="sy-crm-event-mail-recipients-wrapper">
   
        <div class="recipient-group">
            <div class="recipient-group-top">
                <input type="email" name="recipients[]" class="recipient-input" value="'.$user_mail.'" required>
            </div>
        </div>

        
</div>
<button type="button" class="sy-crm-event-button sy-crm-event-recipient-button add-recipient-btn">+ Ajouter</button>
</div>
<input type="hidden" id="sy-crm-event-mail-sidebar-event-id"value=""/>
<div id="sy-crm-event-send-mail-sidebar-notif"></div>
<div class="sy-crm-event-sidebar-footer">
            <button type="button" class="sy-crm-event-button discard-send-event-by-mail-sidebar">Fermer</button>
                    
            <button type="submit" class="sy-crm-event-button sy-crm-send-mail-submit-btn">Envoyer</button>     
                
    </div>

                        </div>
                        </form></div>
                        
   ';


    return $output;
}
function crm_list_events_generes_load_add_sidebar($user,$user_roles,$competed_smtp_data ,$user_can_send_email,$user_mail){
    $infoIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/info-icon.svg';
    $tags=crm_list_events_generes_get_tags_from_db();
   
    $output = '
    <div class="sy-crm-event-sidebar sy-crm-event-add-sidebar"id="sy-crm-event-add-sidebar"style="display:none;">
<div class="sy-crm-event-sidebar-header">
        <h5 class="">Ajouter un évènement</h5>
        <button class="sy-crm-event-sidebar-header-btn discard-add-event-sidebar">X</button>
</div>
<div class="sy-crm-event-sidebar-content">

    <div id="sy-crm-event-add-sidebar-notif"></div>

    <div class="sy-crm-event-add-sidebar-templates-container">
        <select id="sy-crm-event-add-sidebar-templates-select"class="crm-doc-select">
    
            <option value="">-- Sélectionnez un template --</option>';
            
                       
            $templates = get_posts([
                'post_type' => 'crm_documents',
                'numberposts' => -1,
            ]);

            $selected_template = get_option('crm_don_default_template', '');
            if (is_plugin_active('synexta-crm-don/synexta-crm-don.php') && !empty($selected_template)) {
                
                $templates = array_filter($templates, function($template) use ($selected_template) {
                    return $template->ID != $selected_template;
                });
            }
            
            foreach ($templates as $template) {

                $roles_selectionnes = get_post_meta($template->ID, '_template_roles_acces', true);
                $roles_selectionnes = $roles_selectionnes ? json_decode($roles_selectionnes, true):[];
                if (array_intersect($roles_selectionnes, $user->roles) || in_array("administrator", $user_roles) || in_array("responsable_crm", $user_roles)) {
                    $output .= '<option value="' . esc_attr($template->ID) . '">' . 
                    esc_html($template->post_title) . 
                    '</option>';
                }
            }
            
        $output .='</select>
    </div>
  
    <div id="sy-crm-event-add-sidebar-template-content" style="display:none;">
    
        <div class="sy-crm-event-sidebar-content-top">
            <div class="sy-crm-event-sidebar-title">
            <label for="sy-crm-event-sidebar-title-input">Titre * :</label>
                <input class="crm-doc-input"value="" id="sy-crm-event-sidebar-title-input" type="text" ></input>
                <div class="text-error" style="display:none;">Le titre est requis.</div>
            </div>
            <div class="crm_events_tags_container">
       
            <div class="crm_events_tags_list">';
               if (!empty($tags)) {
                    foreach ($tags as $tag) {
                        $output .= '<span class="crm_events_tags_tag event_tag "' . esc_html(sanitize_title($tag->tag_name)) . '" data-id="' . esc_attr($tag->id) . '"style="'. esc_html($tag->tag_style) . '">' . esc_html($tag->tag_name) . '</span>';
                    }
                }
                

                $output .='</div>
            <div class="crm_events_tags_selected_list"></div>
            </div>
        </div>
        <div class="sy-crm-event-sidebar-content-row">
            <div class="sy-event-sidebar-content-container">
                <label for="sy-crm-event-add-sidebar-date">Date de l\'évènement :</label>
                <input class="crm-event-input" value="" id="sy-crm-event-add-sidebar-date" type="date"></input>
                <div class="text-error" style="display:none;">La date de l\'évènement est requise.</div>
            </div>
            <div class="sy-event-sidebar-content-container">
                    <div class="sy-event-sidebar-custom-label">
                        <label for="sy-crm-event-add-sidebar-duration">Durée : </label>
                        <span class="sy-event-sidebar-custom-info-container">
                        <img  src="' . esc_url($infoIconUrl) . '" >
                        <span class="sy-event-sidebar-custom-info-tooltip" style="display: none;">Format attendu : nbheure h nb min (ex: 28h15).</span>
                        </span>
                    </div>
                    <input class="crm-event-input event-duration-input" value="" id="sy-crm-event-add-sidebar-duration" type="text" placeholder="Durée"></input>
                    <div class="text-error" style="display:none;">La durée de l\'évènement est requise.</div>

                    
            </div>
        </div>
        <div class="duration-warning"></div>
        <div class="sy-crm-event-sidebar-content-row">
            <div id="sy-crm-event-add-sidebar-association-users-options"class="sy-crm-event-sidebar-association-users-options"style="display:none;">
                        <label for="">Associer l\'évènement à des utilisateurs : </label>
                        <div class="sy-crm-event-add-sidebar-association-users-container">
                        <div id="sy-event-add-sidebar-users-list-trigger" class="sy-event-add-sidebar-users-list-trigger"></div>

                        <div id="sy-event-add-sidebar-users-list" class="sy-event-sidebar-users-dropdown-list">';
                        $users = get_users([ 'role__in' => ['responsable_crm','utilisateur_crm']]);
                        foreach ($users as $user) {
                            $output .= '<div class="sy-event-add-sidebar-users-list-item" data-id="' . $user->ID . '">' . esc_html($user->display_name) . '</div>';
                        }
                        
                        $output .='</div></div>
            </div>
        </div>

        <div id="sy-crm-event-add-sidebar-vars"class="sy-event-sidebar-content-bottom"></div>
        
        
    <div id="gen-event-sidebar-associated-templates"class="gen-event-sidebar-associated-templates" style="display: none;"></div>
        
    <div id="sy-crm-event-add-sidebar-options" style="display:none;">
     
        <label for="sy-crm-event-add-sidebar-options-files"class="crm-doc-label">Ajouter des pièces joints :</label>
        <input type="file" id="sy-crm-event-add-sidebar-options-files" name="additional_events[]" multiple accept=".pdf,.xls,.xlsx,.doc,.docx,.txt,.jpg,.png,.jpeg,.zip">
                
                <div class="text-error"></div>
    </div>';
    if($competed_smtp_data &&$user_can_send_email==1)
    {
    $output .= '<div class="sy-crm-event-mail-top-wrapper">
    <div class="form-row">
        <div class="form-check mb-2">
            <input class="form-check-input" type="checkbox" id="sy-crm-new-event-send-email-checkbox" name="send_email">
            <label class="form-check-label" for="sy-crm-new-event-send-email-checkbox">
                Envoyer le contenu par mail
            </label>
        </div>
    </div>
    <div class="form-row m-15"id="sy-crm-event-add-send-email-section-attachment-option"style="display:none;">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="sy-crm-new-event-send-mail-form-send-attachments-via-link" name="send_attachments_via_link" value="1">
                <label class="form-check-label" for="sy-crm-new-event-send-mail-form-send-attachments-via-link">
                    Envoyer les fichiers par lien
                </label>
            </div>
        </div>
    </div>

    <div id="sy-crm-new-event-send-email-section" class="sy-crm-event-email-section"style="display:none;">
        <label>Destinataires :</label>
        <div id="sy-crm-new-event-mail-recipients-wrapper" class="sy-crm-event-mail-recipients-wrapper">
            <div class="recipient-group">
                <div class="recipient-group-top">
                    <input type="email" name="sy-crm-new-event-recipients[]" class="sy-crm-new-event-recipient-input" value="' .$user_mail.'">
                </div>
            </div>
        </div>

        <button type="button" class="sy-crm-event-button sy-crm-event-recipient-button sy-crm-new-event-add-recipient-btn">+ Ajouter</button>

        
    </div>';
    }
    $output .='</div></div>
    <div class="sy-crm-event-sidebar-footer">
            <button type="button" class="sy-crm-event-button discard-add-event-sidebar">Fermer</button>
                    
            <button type="submit"class="sy-crm-event-button sy-crm-event-sidebar-footer-submit-btn" id="sy-crm-new-event-sidebar-submit-btn">Générer</button>
                
               
                
    </div>

    

    <div id="templates-list-error"></div>
</div>';
    

    return $output;
}
function crm_list_events_generes_load_events_list($items, $user_roles, $tiersId, $current_user, $competed_smtp_data, $user_can_send_email,$user_mail,$count) {
    $pdfIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/pdf-icon.svg';
    $trashIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/trash-icon.svg';
    $eyeIcon = plugin_dir_url(__FILE__) . '../../assets/icons/eye.svg';
    $mailIcon = plugin_dir_url(__FILE__) . '../../assets/icons/email.svg';
    $generatePdfIcon = plugin_dir_url(__FILE__) . '../../assets/icons/generate-pdf.svg';

    $output = '';
    if (empty($items)) {
        $output .= '<p>Aucun événement généré.</p>';
        return $output;
    }

    // 1. Grouper les événements par année
    $events_temp = [];
    foreach ($items as $item) {
        $date_meta = get_post_meta($item->ID, '_generated_event_date', true) ?: get_post_meta($item->ID, '_generated_doc_date', true);
        $year = !empty($date_meta) ? date('Y', strtotime($date_meta)) : null;
        if ($year) {
            $events_temp[$year][] = $item;
        } else {
            $events_temp['no_date'][] = $item;
        }
    }

    // Trier les années (du plus récent au plus ancien)
    $years = array_filter(array_keys($events_temp), 'is_numeric');
    rsort($years);

    $events_by_year = [];
    $current_year = date('Y');
    $N = null;
    $N1 = null;

    // Sélectionner N (année la plus récente <= année actuelle) et N-1
    foreach ($years as $year) {
        if ($year <= $current_year && $N === null) {
            $N = $year;
        } elseif ($N !== null && $N1 === null) {
            $N1 = $year;
        }
    }

    if ($N) $events_by_year[$N] = $events_temp[$N];
    if ($N1) $events_by_year[$N1] = $events_temp[$N1];

    // Reste = archives
    foreach ($events_temp as $year => $items_in_year) {
        if ($year !== $N && $year !== $N1 && is_numeric($year)) {
            $events_by_year['archives'] = array_merge($events_by_year['archives'] ?? [], $items_in_year);
        }
    }

    // Ajouter les éléments sans date dans les archives
    if (isset($events_temp['no_date'])) {
        $events_by_year['archives'] = array_merge($events_by_year['archives'] ?? [], $events_temp['no_date']);
    }

    // 2. Générer les onglets
    $output .= '<div class="event-tabs-container">';
    $output .= '<div class="tabs-container event-tabs">';
    if ($N) {
        $output .= '<button class="event-tab-btn tab-button active-tab" data-tab="tab_' . $N . '">' . $N . '</button>';
    }
    if ($N1) {
        $output .= '<button class="event-tab-btn  tab-button" data-tab="tab_' . $N1 . '">' . $N1 . '</button>';
    }
    if (!empty($events_by_year['archives'])) {
        $output .= '<button class="event-tab-btn  tab-button" data-tab="tab_archives">Archives</button>';
    }
    $output .= '</div>';
    $output .= '</div>';

    // 3. Contenu des onglets
    $tabs = [];
    if ($N) $tabs['tab_' . $N] = $events_by_year[$N];
    if ($N1) $tabs['tab_' . $N1] = $events_by_year[$N1];
    if (!empty($events_by_year['archives'])) $tabs['tab_archives'] = $events_by_year['archives'];

    $tags = crm_list_events_generes_get_tags_from_db();

    foreach ($tabs as $tab_id => $tab_items) {
        $is_active = ($tab_id === 'tab_' . $N) ? 'style="display:block;"' : 'style="display:none;"';
        $output .= '<div class="event-tab-content" id="' . esc_attr($tab_id) . '" ' . $is_active . '>';
        $output .= '<table class="sy-crm-event-table sy-crm-event-table-user-events" data-count="' . $count . '"style="width:100%;">';
        $output .= '<thead><tr><th>Date</th><th>Type</th><th>Titre</th><th>Doc.</th><th>Actions</th></tr></thead><tbody>';

        foreach ($tab_items as $index => $item) {

            $author_id=get_post_field('post_author', $item->ID);
            $dateCreation = strtotime(get_post_field('post_date', $item->ID));

            $differenceInDays = (time() - $dateCreation) / (60 * 60 * 24); 
                
            if(in_array('administrator', $user_roles)|| in_array('responsable_crm', $user_roles)){
                
                $can_delete=true;
                
            }
            elseif(in_array('utilisateur_crm', $user_roles)){
                $associer_crm = get_user_meta($tiersId, 'associer_crm', true);
                $can_delete=(   ($associer_crm && in_array($current_user->ID,  $associer_crm)&&$differenceInDays<7&&$author_id==$current_user->ID));
                
            }
            else{
                
            // $can_delete=($current_user->ID==$user_id&&$differenceInDays<7);
                $can_delete=false;
            }
            //

            $class_names = [];
            $tagSpans="";
            $generated_event_tags = get_post_meta($item->ID, '_generated_event_tags', true);
            $generated_event_tags = is_array($generated_event_tags) ? $generated_event_tags : [];
           
            
            foreach ($tags as $tag) {
                if (in_array($tag->id, $generated_event_tags)) {
                    $class_name = 'event_tag '.sanitize_title($tag->tag_name);
                    $tagSpans .= '  <span class="' . esc_attr($class_name) . '"style="' . esc_attr($tag->tag_style) . '">' . esc_html($tag->tag_name) . '</span>  ';
                }
            }
            
            
            $template_id = get_post_meta($item->ID, '_used_template_id', true);
            $precedentItemId = null;
            $suivantItemId = null;
        
            // Vérifie si un élément précédent existe
            if (isset($tab_items[$index - 1])) {
                $precedentItemId = $tab_items[$index - 1]->ID;
            }
        
            // Vérifie si un élément suivant existe
            if (isset($tab_items[$index + 1])) {
                $suivantItemId = $tab_items[$index + 1]->ID;
            }
            $template_name = get_the_title($template_id);
            $name = get_the_title($item->ID);
            $date_meta = get_post_meta($item->ID, '_generated_event_date', true);

            $template_autorise_generation_pdf = get_post_meta($template_id, '_template_autorise_generation_pdf', true);


            $date_format = get_option('date_format');
            $date_meta =get_post_meta($item->ID, '_generated_event_date', true)??get_post_meta($item->ID, '_generated_doc_date', true);

            $formatted_date = !empty($date_meta) ? format_date_wp($date_meta) : "";
            $pdf_url = get_post_meta($item->ID, '_pdf_url', true);
            $generated_event_pieces_joints = get_post_meta($item->ID, '_generated_event_pieces_joints', true);

            $userDocId = get_post_meta($item->ID, '_generated_event_user_id', true);
            $user_info = get_userdata($userDocId);
            $company_name = get_user_meta($userDocId, 'billing_company', true);
            $user_name = $company_name ?: ($user_info ? $user_info->last_name . ' ' . $user_info->first_name : '');
            $user_mail =$user_info ? $user_info->user_email :'';
            $expiration_date = get_post_meta($item->ID, '_generated_event_expiration_date', true);
             $today = date('Y-m-d'); 
            $class_edit="event-info-cell";
            $class_tr="";
            if ($expiration_date) {
                if ($expiration_date < $today) {
                    $class_tr.=' crm_expired_event';
                }
            }
            $output .= '<tr  data-id="' . esc_attr($item->ID) . '" data-precedent="' . esc_attr($precedentItemId) . '" data-suivant="' . esc_attr($suivantItemId) . '"class="' . esc_attr($class_tr) . '">
                            <td class="' . $class_edit . '" data-id="' . esc_attr($item->ID) . '" data-precedent="' . esc_attr($precedentItemId) . '" data-suivant="' . esc_attr($suivantItemId) . '"data-order="' . date('Y-m-d', strtotime($date_meta)) . '">' . esc_html($formatted_date) . '</td>';

           

            $output .= '<td class="' . $class_edit . '" data-id="' . esc_attr($item->ID) . '"data-precedent="' . esc_attr($precedentItemId) . '" data-suivant="' . esc_attr($suivantItemId) . '">' . esc_html($template_name) . '</td>
                        <td class="' . $class_edit . '" data-id="' . esc_attr($item->ID) . '"data-precedent="' . esc_attr($precedentItemId) . '" data-suivant="' . esc_attr($suivantItemId) . '"><span class="eventtitle">' . esc_html($name) . $tagSpans. '</span></td>
                        ';

            
                $output .= '<td>';
            if ($pdf_url||(!empty($generated_event_pieces_joints) && is_array($generated_event_pieces_joints))) {
                if($pdf_url){

                     $output .= '<a href="' . esc_url($pdf_url) . '" target="_blank">
                                <img src="' . esc_url($pdfIconUrl) . '" alt="PDF" style="width: 20px; height: 20px;">
                            </a>';
                }
                if(!empty($generated_event_pieces_joints) && is_array($generated_event_pieces_joints)){
                    foreach ($generated_event_pieces_joints as $key => $file) {
                
                        $file_extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                        $icon_url=get_file_icon($file_extension);
                        $output .= '<a href="' . $file . '" target="_blank">
                                            <img src="' . $icon_url . '"  file" style="width: 20px; height: 20px; margin-right: 5px;">
                                            
                                        </a>
                                    ';
                    } 

                }
               
            }
            else{
                $output .= '--';

            }
                $output .= '</td>';

            

            $output .= '<td>';
                $output .= '<div class="sy-crm-event-table-menu">
                <div class="sy-crm-event-table-menu-left">
                
                    <a href="#" class="sy-crm-event-table-menu-detail-btn" data-id="' . esc_attr($item->ID) . '"title="Voir les détails"><img src="' . esc_html($eyeIcon) . '" ></a>
                    ';
                    if($competed_smtp_data &&$user_can_send_email==1)
                    {
                        $output .= ' <a href="#" class="sy-crm-event-table-menu-send-mail-btn"data-mail="' . esc_attr($user_mail).'" data-id="' . esc_attr($item->ID) . '"title="Envoyer par e-mail"><img src="' . esc_html($mailIcon) . '" >  </a>';
                    }
                    if($template_autorise_generation_pdf&&$template_autorise_generation_pdf=="on"){
                         $output .= ' <a href="#" class="sy-crm-event-table-action-generate" title="Regénérer le pdf" data-id="' . esc_attr($item->ID) . '"title="Regénérer le PDF">
                                            <img src="' . esc_html($generatePdfIcon) .'" >  
                                        </a>';
                        
                    }
                    $output .= '</div>';
                    if ($can_delete) {
                        $output .= '<a href="#" class="crm-event-delete-event" data-id="' . esc_attr($item->ID) . '"data-notif-container="generate_event_notification"title="Supprimer l’événement">
                                        <img src="' . esc_url($trashIconUrl) . '" alt="Supprimer" >
                                    </a>'; 
                    }

           

            $output .= '</div></td></tr>';
        
        }

        $output .= '</tbody></table></div>';
    }
   
    return $output;
}



function crm_table_output($items,$count,$tiersId, $user_roles,$addbtn,$displayList) {
    //$can_delete = in_array('administrator', $user_roles) || in_array('responsable_crm', $user_roles) || in_array('utilisateur_crm', $user_roles);
  
    $current_user = wp_get_current_user();
    $current_user_id = $current_user->ID;
   
//
    crm_list_events_generes_init_resources();


    $tags = crm_list_events_generes_get_tags_from_db();

    $searchIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/recherche.svg';
    $addIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/add-icon.svg';

    $addNoteIconUrl=plugin_dir_url(__FILE__) . '../../assets/icons/add-memo-icon.svg';
    $default_template_id=get_option( 'crm_document_plugin_default_template');
    
    $user = get_userdata($tiersId);
    $user_mail =$user->user_email ;
    $return_path   = get_option('crm_event_return_path', '');
    $list_unsub    = get_option('crm_event_list_unsubscribe', '');
    $smtp_host = get_option('crm_smtp_default_host', '');
    $smtp_login = get_option('crm_smtp_default_email', '');
    $smtp_port = get_option('crm_smtp_default_port', '');
    $smtp_password = get_option('crm_smtp_default_password', '');

    $custom_smtp   = !empty($smtp_host) && !empty($smtp_login) && !empty($smtp_port) && !empty($smtp_password);

    $competed_smtp_data = !empty($return_path) && !empty($list_unsub)&&$custom_smtp ;

    $user_can_send_email =get_user_meta($current_user->ID, 'user_can_send_email', true);   
   
    $output = '<div id="generated_event_list">
    <div id="generate_event_notification"></div>';

    if($displayList==true)
    {
        $output.=crm_list_events_generes_load_edit_sidebar($competed_smtp_data ,$user_can_send_email,$user_mail);
        $output.=crm_list_events_generes_load_sendEmails_sidebar($user_mail);
    } 
    if ($addbtn == true) {
        $output.=crm_list_events_generes_load_add_sidebar($user,$user_roles,$competed_smtp_data ,$user_can_send_email,$user_mail);

       
        }
      

    // Générer le tableau
    $output .= '<div class="sy-crm-event-table-container crm-events-table ">';
    if($displayList==true)
        { 
            $output .= ' <div class="sy-crm-event-table-header">
            <div class="sy-crm-event-header-filters">
            <div class="crm-table-header-quick-filter">
            <input type="text" id="quick-filter-events-input" value="" placeholder="Rechercher...">
            <button id="filter-events-btn">  
                <img src="' . esc_url($searchIconUrl) . '" alt="Rechercher">
            </button>
        </div>';
            $output .= '<select id="filter-events-tag" class="sy-crm-event-table-select-filter">
        <option value="">Tous les tags</option>';
        foreach ($tags as $tag) {
            
            
            $output .= '<option value="' . esc_attr($tag->tag_name) . '" >' . esc_html($tag->tag_name) . '</option>';
        }
        $output .= '</select></div>';
        
    }
        
    if ($addbtn == true) {
        $output .= '<div class="sy-crm-event-header-btn"><button id="sy-crm-event-show-add-sidebar-btn" class="sy-crm-event-button sy-crm-event-generate-btn" data-user-id="' . ($tiersId ? $tiersId : '') . '">
                <img src="' . esc_url($addIconUrl) . '" alt="Rechercher">
                <span>Créer doc</span>
        </button>';
        $output .= '<button id="sy-crm-event-add-note-btn" class="sy-crm-event-button sy-crm-event-generate-btn" data-user-id="' . ($tiersId ? $tiersId : '') . '"data-defaulte-template="' . ($default_template_id ? $default_template_id : '') . '">
                <img src="' . esc_url($addNoteIconUrl) . '" alt="Rechercher">
                <span>Note</span>
        </button></div>';
    }
    $output .=    '</div>';

    if($displayList==true)
    {
        $output .=    crm_list_events_generes_load_events_list($items, $user_roles, $tiersId, $current_user, $competed_smtp_data, $user_can_send_email,$user_mail,$count);

    }
    $output .= '</div></div>';
              
    return $output;
}

/**
 * Récupère les détails d'un document et retourne une réponse JSON.
 *
 * Cette fonction est utilisée pour obtenir les informations d'un document, y compris 
 * son contenu, ses pièces jointes, les métadonnées associées, et les variables utilisées.
 * Elle est principalement utilisée dans le cadre d'une requête AJAX.
 *
 * Étapes principales :
 * - Vérifie si l'ID du document est fourni et valide.
 * - Récupère le contenu du document, ainsi que ses pièces jointes, métadonnées et variables.
 * - Traite les variables du document en les comparant aux métadonnées utilisateur.
 * - Prépare une réponse JSON avec les informations nécessaires.
 * - Renvoie une réponse JSON de succès ou d'erreur selon le cas.
 *
 * Données retournées dans la réponse JSON (en cas de succès) :
 * - `title` : Titre du document.
 * - `attachments` : Liste des pièces jointes associées au document.
 * - `content` : Contenu du document avec les sauts de page remplacés par `[Saut_page]`.
 * - `acceptAttachement` : Indique si les pièces jointes sont autorisées pour ce document.
 * - `variables_document` : Variables générées pour le document, décodées en tableau.
 * - `template_version` : Version du modèle utilisé pour générer le document.
 * - `event_version` : Version du modèle spécifiquement utilisée pour ce document.
 * - `variables_template` : Variables disponibles dans le contenu du modèle.
 * - `pre_filled` : Variables pré-remplies basées sur les métadonnées utilisateur.
 * - `racine` : Métadonnée `_racine` du modèle.
 * - `compteur` : Nombre total de documents générés à partir de ce modèle.
 *
 * Données en cas d'erreur :
 * - `wp_send_json_error` : Renvoie un message d'erreur si l'ID ou le document est invalide.
 *
 * @return void
 */
function get_event_details() {
    $document_id = isset($_POST['document_id']) ? intval($_POST['document_id']) : 0;

    $date_format = get_option('date_format');

    $date_creation = get_the_date($date_format, $document_id);
    $current_user = wp_get_current_user();
    $user_roles = $current_user->roles;
    $can_edit=false;
    $can_delete=false;
 
    if (!$document_id) {
        crm_core_update_logs_option(
            'Shortcode gestion des évènements: Recuperation d\'un evenement',
            'Id invalide',
            $current_user->ID,
            ['event_id'=>$document_id,
                   ]
        );
        wp_send_json_error('ID de document invalide.');
    }

    $document = get_post($document_id);
    if (!$document) {
        crm_core_update_logs_option(
            'Shortcode gestion des évènements: Recuperation d\'un evenement',
            'Evènement introuvable.',
            $current_user->ID,
            ['event_id'=>$document_id,
                   ]
        );
        
        wp_send_json_error('Evènement introuvable.');
    }
    //<div style="page-break-before: always;"></div>
                    
    $attachments = get_post_meta($document_id, '_generated_event_pieces_joints', true)!=""?get_post_meta($document_id, '_generated_event_pieces_joints', true):get_post_meta($document_id, '_generated_doc_pieces_joints', true);
    $template_id=get_post_meta($document_id, '_used_template_id', true);
    $acceptAttachement=get_post_meta($template_id, '_template_autorise_documents_joints', true);
    $template_version=get_post_meta($template_id, '_template_version', true);
    $event_version=get_post_meta($document_id, '_used_template_version', true);
    
    //$user_id= get_post_meta($document_id, '_generated_event_user_id', true);
    $eventUserId = get_post_meta($document_id, '_generated_event_user_id', true);
    $user_id = !empty($eventUserId) ? $eventUserId : get_post_meta($document_id, '_generated_doc_user_id', true);
   
    $nom_societe =get_user_meta($user_id, 'billing_company', true);
    $first_name =get_user_meta($user_id, 'first_name', true);
    $last_name = get_user_meta($user_id, 'last_name', true);
    $typeCompte = get_user_meta($user_id, 'user_type', true);
    if($typeCompte=="entreprise")
   {
           $prenom_nom=$nom_societe .' - '. $first_name.' '.$last_name;
    }
    else{
        $prenom_nom=$first_name.' '.$last_name;
    }
  
$variables_document = get_post_meta($document_id, '_generated_event_vars', true)!=""?get_post_meta($document_id, '_generated_event_vars', true):get_post_meta($document_id, '_generated_doc_vars', true);
//$cleanJson = stripslashes(($variables_document));
 $variables_document_array =$variables_document;
if (!is_array($variables_document)) {
    $variables_document_array=[];
    $template_content = get_post_field('post_content', $template_id);
    preg_match_all('/\{([^\}]+)\}/', $template_content, $matches);
    $variables_template = array_unique($matches[1]);
    foreach ($variables_template as $variable) {
            $variables_document_array[$variable] = '';
        
    }
    //wp_send_json_error('Problème lors de recuperation des variables.');
 }


if (!($template_version == $event_version)) {
    $template_content = get_post_field('post_content', $template_id);
    preg_match_all('/\{([^\}]+)\}/', $template_content, $matches);
    $variables_template = array_unique($matches[1]);
    $pre_filled = [];
    foreach ($variables_document_array as $key => $value) {
        if (!in_array($key, $variables_template)) {
            unset($variables_document_array[$key]);
        }
    }
    foreach ($variables_template as $variable) {
        $clean_variable = preg_replace('/[\*\#\@\|]/', '', $variable);
    
        if (strpos($variable, '|') !== false) {
            $parts = explode('|', $variable);
            $clean_variable = ltrim($parts[0], '*'); // Retirer '*' s'il existe dans la première partie
        }
        $meta_value = get_user_meta($user_id, $clean_variable, true);
    
        $meta_value = get_user_meta($user_id, $variable, true);
        
            if ($clean_variable == "display_author_bio") { 
                $meta_value = get_user_meta($current_user->ID, 'description', true);
               
                $pre_filled[$variable] = $meta_value;  
            }
            if ($clean_variable == "display_user_bio") { 
                $meta_value = get_user_meta($user_id, 'description', true);
                $pre_filled[$variable] = $meta_value;  
            }
            if ($clean_variable == "creation_date") { 
                
                $pre_filled[$variable] = $date_creation;  
            }  
            
       
    }
    foreach ($variables_template as $variable) {
        if (!array_key_exists($variable, $variables_document_array)) {
            $variables_document_array[$variable] = $pre_filled[$variable] ?? '';
            if($variable=="creation_date"){
                $variables_document_array[$variable] = $date_creation;
            }
        }
    }

}
    //$entreprise_affichee = !empty($nom_societe) ? $nom_societe :( $user->display_name?$user->display_name:$prenom_nom);
    $hashedId=  crm_events_generate_user_hash($user_id);   
    $author_id = get_post_field('post_author', $document_id);  
    $author_email = get_the_author_meta('user_email', $author_id);
    //gestion des droits
    $dateCreation = strtotime(get_post_field('post_date', $document_id));
    
        // Calculer la différence en jours entre aujourd'hui et la date de création
    $differenceInDays = (time() - $dateCreation) / (60 * 60 * 24); // Conversion en jours
        
    if(in_array('administrator', $user_roles)|| in_array('responsable_crm', $user_roles)){
        $can_edit=true;
        $can_delete=true;
        
    }
    elseif(in_array('utilisateur_crm', $user_roles)){
        $associer_crm = get_user_meta($user_id, 'associer_crm', true);
        $can_edit=(($current_user->ID==$user_id&&$differenceInDays<7)||
        ($associer_crm && in_array($current_user->ID,  $associer_crm)&&$differenceInDays<7&&$author_id==$current_user->ID));
        $can_delete=(($current_user->ID==$user_id&&$differenceInDays<7)||
        ($associer_crm && in_array($current_user->ID,  $associer_crm)&&$differenceInDays<7&&$author_id==$current_user->ID));
        
    }
    else{
        
        $can_edit=($current_user->ID==$user_id&&$differenceInDays<7);
        $can_delete=($current_user->ID==$user_id&&$differenceInDays<7);

    }
    //fin gestions droits
    
    //wp_send_json_error([$attachments,gettype($attachments)]);
    //tag list
    //$taglist= get_post_meta($document_id, '_generated_event_tags', true);
    $taglist = get_post_meta($document_id, '_generated_event_tags', true)!=""?get_post_meta($document_id, '_generated_event_tags', true):(get_post_meta($document_id, '_generated_doc_tags', true)??[]);
          
    $tags_data = [];

if (!empty($taglist) && is_array($taglist)) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_event_tags';

    // Récupérer les tags correspondant aux IDs dans $taglist
    $placeholders = implode(',', array_fill(0, count($taglist), '%d'));
    $query = $wpdb->prepare("SELECT id, tag_name,tag_style FROM $table_name WHERE id IN ($placeholders) AND status = 1", ...$taglist);
    $tags = $wpdb->get_results($query);

    foreach ($tags as $tag) {
        $tags_data[] = [
            'id' => $tag->id,
            'tagName' => $tag->tag_name,
            'style' => $tag->tag_style
        ];
    }
}

$history_mails = get_post_meta($document_id, '_event_list_mail', "");
$time_format = get_option('time_format');  
$history_mails_flattened = [];
//$datetime_format = $date_format . ' ' . $time_format;

$datetime_format = 'd-m-y H:i';
// Formater les dates dans l'historique des mails
if($history_mails!=""){

    foreach ($history_mails as $mails) {
        foreach ($mails as &$mail) {
            if (isset($mail['date_envoi']) && !empty($mail['date_envoi'])) {
                $timestamp = strtotime($mail['date_envoi']);
            if ($timestamp) {
                $mail['date_envoi_formatted'] = date_i18n($datetime_format, $timestamp);
                    $mail['date_envoi_raw'] = $mail['date_envoi'];
             
            }

            }  
            if (isset($mail['date_ouverture']) && !empty($mail['date_ouverture'])) {
                $timestamp = strtotime($mail['date_ouverture']);
                if ($timestamp) {  
                    $mail['date_ouverture_formatted'] = date_i18n($datetime_format, $timestamp);
                    $mail['date_ouverture_raw'] = $mail['date_ouverture'];
           
                }

            }
            if (isset($mail['reouvertures']) && is_array($mail['reouvertures'])) {
              
                $formatted_reouvertures = [];

                foreach ($mail['reouvertures'] as $reouverture) {
                    if (isset($reouverture['date']) && !empty($reouverture['date'])) {
                        $timestamp = strtotime($reouverture['date']);
                        if ($timestamp) {
                            $formatted_reouvertures[] = [
                                'date' => date_i18n($datetime_format, $timestamp),
                                'ip' => $reouverture['ip'] ?? '',
                                'date_raw' => $reouverture['date'],
                            ];
                        }
                    }
                }
            
                $mail['reouvertures'] = $formatted_reouvertures;

            }
            if (isset($mail['documents_ouverts']) && is_array($mail['documents_ouverts'])) {
                $formatted_ouvertures = [];
            
                foreach ($mail['documents_ouverts'] as $doc) {
                    if (isset($doc['date']) && !empty($doc['date'])) {
                        $timestamp = strtotime($doc['date']);
                        if ($timestamp) {
                            $formatted_ouvertures[] = [
                                'date' => date_i18n($datetime_format, $timestamp),
                                'ip' => $doc['ip'] ?? '',
                                'fichiers' => $doc['fichiers'] ?? '',
                                'date_raw' => $doc['date'],
                            ];
                        }
                    }
                }
            
                $mail['documents_ouverts'] = $formatted_ouvertures;
            }
            $history_mails_flattened[] = $mail;
        }
    }

}
$date_now = date_i18n($date_format, current_time('timestamp')); 
    $response = array(
        'title' => $document->post_title,
        'attachments'=>$attachments,
        'tiers'=>$prenom_nom,
        'creator'=>$author_email,
        //'dateCreation' => date('d/m/y à H:i', strtotime(get_post_field('post_date', $document_id))),
       // 'dateCreation' => format_date_wp(get_the_date('F j, Y', $document_id)),
        'dateCreation' =>$date_creation,
      
        'acceptAttachement'=>$acceptAttachement,
        'variables_event'=>$variables_document_array,
        //'variables_document'=>json_decode($cleanJson,true),
        //'variables_template'=>$variables_template,
        'template_version'=>$template_version,
        'event_version'=>$event_version,
        //'pre_filled'=>$pre_filled,
        'FicheTiers'=>home_url('crm-customer/' . $hashedId),
        'racine' => get_post_meta($template_id, '_racine', true),
        'compteur' => count(get_posts([
            'post_type'   =>'crm_docs_gen',
            'meta_key'    => '_used_template_id',
            'meta_value'  => $template_id,
            'numberposts' => -1,
        ])),
        'plugin_base_url'=> plugin_dir_url(__FILE__) . '../../assets/icons/',
        'eventContent'=>$document->post_content,
        'canEdit'=>$can_edit,
        'canDelete'=>$can_delete,
        'tags_data'=>$tags_data,
        'associated_users'=>get_post_meta($document_id, '_generated_event_associated_users',true)&&get_post_meta($document_id, '_generated_event_associated_users',true)!=""?get_post_meta($document_id, '_generated_event_associated_users',true):[],
   
        'event_date'=>(get_post_meta($document_id, '_generated_event_date',true)),        
        'event_dure'=>get_post_meta($document_id, '_generated_event_dure',true),
        'generatedPdf'=>get_post_meta($document_id, '_pdf_url',''),

        'date_now'=>$date_now,
        'history_mails'=>$history_mails_flattened,
        'history_mailsxxxx'=>$history_mails,
    );

    wp_send_json_success($response);
}
add_action('wp_ajax_get_event_details', 'get_event_details');


/**
 * Fonction pour modifier le contenu d'un document généré via une requête AJAX.
 * 
 * 1. Récupère les données envoyées dans la requête, telles que l'ID du document, le titre, le contenu, et les variables associées.
 * 2. Valide et met à jour le titre, le contenu, et les métadonnées du document généré.
 * 3. Gère les pièces jointes supplémentaires ajoutées via la requête.
 * 4. Supprime et régénère le fichier PDF associé si nécessaire.
 * 5. Renvoie une réponse JSON pour indiquer le succès ou l'échec de l'opération.
 */
function edit_generated_post_content() {
    $document_id = isset($_POST['generated_event_id']) ? intval($_POST['generated_event_id']) : 0;
    $title = isset($_POST['generated_event_title']) ? sanitize_text_field($_POST['generated_event_title']) : '';
    $content = isset($_POST['content']) ? nl2br($_POST['content']) : '';
    $event_date=$_POST['event_date'];
    $event_dure=$_POST['event_dure'];
    $selected_tags=$_POST['selected_tags']??[];
    $associated_users=$_POST['associated_users']??[];
    $current_user = wp_get_current_user();
    
    update_post_meta($document_id, '_generated_event_associated_users', $associated_users);
    //$generatePdf = isset($_POST['generatePdf']) ? ($_POST['generatePdf']) : '';
    $rawVariables=$_POST['variables'];
    $cleanJson = stripslashes($rawVariables);
    $variables = json_decode($cleanJson, true); 
   
    if (isset($variables['undefined'])) {
        unset($variables['undefined']);
    }

    if (!$document_id) {
        crm_core_update_logs_option(
            'Shortcode gestion des évènements: Edition d\'un evenement',
            'Evènement introuvable.',
            $current_user->ID,
            ['event_id'=>$document_id,
                   ]
        );
        wp_send_json_error('ID invalide.');
    }
   // $user_id=get_post_meta($document_id, '_generated_event_user_id',true);
    $eventUserId = get_post_meta($document_id, '_generated_event_user_id', true);
    $user_id = !empty($eventUserId) ? $eventUserId : get_post_meta($document_id, '_generated_doc_user_id', true);
   
    $user_info = get_userdata($user_id);
    $vosfactures_id=get_user_meta($user_id, 'vosfactures_id',true);
    $user_login = $user_info->user_login??$vosfactures_id;

    update_post_meta($document_id, '_generated_event_tags', $selected_tags);

    $year = date('Y');
    //$content = str_replace('[Saut_page]', '<div style="page-break-before: always;"></div>', $content);
    $doc_url=get_post_meta($document_id, '_pdf_url', true);
    $template_id=get_post_meta($document_id, '_used_template_id', true);
    $template_autorise_generation_pdf = get_post_meta($template_id, '_template_autorise_generation_pdf', true);
   
    $template = get_post($template_id);
    
    $templateContent = $template->post_content;
    $contenu=$templateContent;
    $template_version=get_post_meta($template_id, '_template_version', true);
    if (isset($variables['display_author_bio@'])) {
        $variables['display_author_bio'] = $variables['display_author_bio@'];
        unset($variables['display_author_bio@']);
    }
    if (isset($variables['display_author_bio@@'])) {
        $variables['display_author_bio'] = $variables['display_author_bio@@'];
        unset($variables['display_author_bio@@']);
    }
    if (isset($variables['display_author_bio@@@'])) {
        $variables['display_author_bio'] = $variables['display_author_bio@@@'];
        unset($variables['display_author_bio@@@']);
    }
    //wp_send_json_error(($variables));
    foreach ($variables as $variable => $value) {
        if($variable=="document_name"||$variable=="document_name*"){
            $value=$title;
        }
        if($variable=='devis'||$variable=='facture'||$variable=='factures-echues'){
            if(get_option('vosfactures_sync_enabled') === 'yes' && !empty($vosfactures_id)) {

             if ($variable=='devis') {
                 $devis = event_get_devis_var_value($vosfactures_id);
                 if ($devis) {
                     $value= $devis['html'];
                     $documents_associe_vf[] = $devis;
                 } else {
                     $value= '';
                    
                 }
             }/**/
         
             if ($variable=='facture') {
                 $facture = event_get_facture_var_value($vosfactures_id);
                 if ($facture) {

                     $value= $facture['html'];
                     $documents_associe_vf[] = $facture;
                     
                 } else {
                     $value= '';
                 }
             }
         
             if ($variable=='factures-echues') {
                 $factures = event_get_factures_echues_var_value($vosfactures_id);
                 if ($factures) {
                     
                     $value= $factures['html'];
                     $documents_associe_vf = array_merge($documents_associe_vf, $factures['pdfs']);
                 } else {
                     $value= '';
                 }
             }/**/
         
         } 
         else{

             $value="";
         } 
         }
         if (strpos($variable, '@') !== false||$variable == "display_author_bio"||$variable == "display_user_bio"||$variable=='devis'||$variable=='facture'||$variable=='factures-echues') {
            
            // Insérer directement du HTML si '#' est présent
            $regex = "/\{" . preg_quote($variable, '/') . "\}/";
            $newContenu = preg_replace($regex, $value, $contenu); 
        } 
        else {
        
        $regex = "/\{" . preg_quote($variable, '/') . "\}/";
        $newContenu = preg_replace($regex,  esc_html($value) , $contenu);

   }

    $contenu = $newContenu;
    }
    update_post_meta($document_id, '_used_template_version', $template_version);
   
    update_post_meta($document_id, '_generated_event_vars', $variables);
    update_post_meta($document_id, '_generated_event_user_id', $user_id);
    delete_post_meta($document_id, '_generated_doc_vars');
    delete_post_meta($document_id, '_generated_doc_user_id');

    // Mettre à jour le titre et le contenu du post
    $post_data = array(
        'ID' => $document_id,
        'post_title' => $title,
        'post_content' => $contenu
    );
    wp_update_post($post_data);

    if (!empty($documents_associe_vf)) {
        foreach($documents_associe_vf as $doc){
            if ($doc) {
                //'date' => $f['date'],
                event_vosfactures__download_and_attach_pdf(
                    $doc['pdf_url'],
                    $doc['original_name'], 
                    $doc['doctitle'],      
                    $user_login,
                    $document_id
                );
            }
        }
    }
    // Gérer les nouvelles pièces jointes
    $attachments = get_post_meta($document_id, '_generated_event_pieces_joints', true)!=""?get_post_meta($document_id, '_generated_event_pieces_joints', true):get_post_meta($document_id, '_generated_doc_pieces_joints', true);

    delete_post_meta($document_id, '_generated_doc_pieces_joints');
    if (!$attachments) {
        $attachments = [];
    }
    //wp_send_json_error(get_post_meta($document_id, '_generated_event_pieces_joints', true));
   
    if (isset($_FILES['additional_files'])) {
        $uploaded_files = [];
        $file_count = count($_FILES['additional_files']['name']);
        $upload_dir = wp_upload_dir();
        //$custom_dir = $upload_dir['basedir'] . '/documents-crm';

        $custom_dir = $upload_dir['basedir'] . "/documents-crm/$user_login/$year";
        
            if (!file_exists($custom_dir)) {
                mkdir($custom_dir, 0755, true);
            }
    
            for ($i = 0; $i < $file_count; $i++) {
                $original_name = $_FILES['additional_files']['name'][$i];
                $tmp_name = $_FILES['additional_files']['tmp_name'][$i];
                $file_ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
    
                $forbidden_extensions = ['php', 'js', 'exe', 'bat', 'sh'];
                if (in_array($file_ext, $forbidden_extensions)) {
                    continue; 
                }
    
                // Génération du nom sécurisé
                $safe_name = sanitize_file_name($original_name);
                 $new_name = "{$title} - {$safe_name}";
                $new_name = preg_replace('/[^a-zA-Z0-9._-]/', '', $new_name); 
                $target_file = $custom_dir . '/' . $new_name;
    
                if (move_uploaded_file($tmp_name, $target_file)) {
                    $attachments[] = $upload_dir['baseurl'] . "/documents-crm/$user_login/$year/$new_name";
                }
            }
    
         
    
        if (!empty($attachments)) {
            update_post_meta($document_id, '_generated_event_pieces_joints', $attachments);
        }

    }

     if($template_autorise_generation_pdf&&$template_autorise_generation_pdf=="on"){
        if ($doc_url) {
            $pdf_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $doc_url);
            if (file_exists($pdf_path)) {
                unlink($pdf_path);
            }
        }
        //$pdf_url = generate_pdf($document_id,$content, 'generated_event_' . $document_id . '.pdf');
        $pdf_url = generate_pdf($document_id,$content, $title . '.pdf');

        update_post_meta($document_id, '_pdf_url', $pdf_url);
           

    }
  /*  $current_event_date = get_post_meta($document_id, '_generated_event_date', true);
    $current_event_dure = get_post_meta($document_id, '_generated_event_dure', true);
    
    // Vérifie si les valeurs ont changé
    if ($event_date !== $current_event_date || $event_dure !== $current_event_dure) {
        // Met à jour les nouvelles valeurs
       
        // Enregistre l'ID de l'utilisateur et la date de modification
        $connected_user_id = get_current_user_id();
        $modification_date = current_time('mysql');
    
        update_post_meta($document_id, '_date_event_modified_by', $connected_user_id);
        update_post_meta($document_id, '_date_event_modified_date', $modification_date);
    }*/
     update_post_meta($document_id, '_generated_event_date', $event_date);
    update_post_meta($document_id, '_generated_event_dure', $event_dure);
    
    if($_POST['send_event_by_mail']=="1"){

        $result=crm_envoyer_emails_evenement(['event_id'=>$document_id,'recipients'=>$_POST['recipients'],'send_attachments_via_link'=>$_POST['send_attachments_via_link']]);
       
        if ($result['success']) {
            
            wp_send_json_success('Evènement mis à jour avec succès et emails envoyé avec succes');
        } else {
            wp_send_json_error($result);
        }
    }
    else{
        
    wp_send_json_success('Evènement mis à jour avec succès.');
    }
    
}
add_action('wp_ajax_edit_generated_post_content', 'edit_generated_post_content');

add_action('wp_ajax_update_event_duration', 'update_event_duration');
function update_event_duration(){
    $event_id = isset($_POST['event_id']) ? intval($_POST['event_id']) : 0;
    $event_dure = isset($_POST['duration']) ? sanitize_text_field($_POST['duration']) : 0;
    $current_user = wp_get_current_user();
    
    if (!$event_id) {
        crm_core_update_logs_option(
            'Shortcode gestion des évènements: Edition d\'un evenement',
            'Evènement introuvable.',
            $current_user->ID,
            ['event_id'=>$event_id,
                   ]
        );
        wp_send_json_error('ID  invalide.');
    }
    if (!$event_dure) {
        crm_core_update_logs_option(
            'Shortcode gestion des évènements: Edition d\'un evenement',
            'Evènement introuvable.',
            $current_user->ID,
            ['event_id'=>$event_id,
            'event_dure'=>$event_dure
                   ]
        );
        wp_send_json_error('durée  invalide.');
    }
     update_post_meta($event_id, '_generated_event_dure', $event_dure);
       
     wp_send_json_success('Evènement mis à jour avec succès et emails envoyé avec succes');
    
  
}
function delete_attachement() {
    // check_ajax_referer('deleteDocumentNonce', 'security');
     //wp_localize_script('your-script-handle', 'deleteDocumentNonce', wp_create_nonce('delete-document-nonce'));
     $current_user = wp_get_current_user();
    
     if (isset($_POST['event_id']) && is_numeric($_POST['event_id']) && isset($_POST['attachement_url'])) {
         $event_id = intval($_POST['event_id']);
         $attachment_url = sanitize_text_field($_POST['attachement_url']);
 
         // Récupère les pièces jointes existantes
         $generated_event_pieces_joints = get_post_meta($event_id, '_generated_event_pieces_joints', true);
 
         if (is_array($generated_event_pieces_joints)) {
             // Supprime l'URL du tableau
             $generated_event_pieces_joints = array_filter($generated_event_pieces_joints, function ($url) use ($attachment_url) {
                 return $url !== $attachment_url;
             });
 
             // Supprime le fichier du serveur
             $upload_dir = wp_upload_dir();
             $file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $attachment_url);
             if (file_exists($file_path)) {
                 unlink($file_path);
             }
 
             // Met à jour les pièces jointes
             update_post_meta($event_id, '_generated_event_pieces_joints', $generated_event_pieces_joints);
 
             wp_send_json_success(['message' => 'Atachement supprimé avec succès.']);
         } else {
            crm_core_update_logs_option(
                'Shortcode gestion des évènements: Supprestion des pieces jointes d\'un evenement',
                'Pièce jointe trouvée pour cet évènement.',
                $current_user->ID,
                ['event_id'=>$event_id,
                'attachement_url'=>$_POST['attachement_url']
                       ]
            );
             wp_send_json_error(['message' => 'Aucune pièce jointe trouvée pour cet évènement.']);
         }
     } else {
        crm_core_update_logs_option(
            'Shortcode gestion des évènements : Suppression des pièces jointes d\'un évènement',
    'ID de l\'évènement ou URL de l\'attachement manquant',
   
            $current_user->ID,
            ['event_id'=>$_POST['event_id'],
            'attachement_url'=>$_POST['attachement_url']
                   ]
        );
         wp_send_json_error(['message' => 'Requête invalide.']);
     }
 
     exit;
 }
add_action('wp_ajax_delete_attachement', 'delete_attachement');
 
 function crm_event_regenerate_pdf() {
    $current_user = wp_get_current_user();
    
      if (isset($_POST['event_id']) && is_numeric($_POST['event_id']) ) {
          $event_id = intval($_POST['event_id']);
          $attachment_url = sanitize_text_field($_POST['attachement_url']);
          $doc_url=get_post_meta($event_id, '_pdf_url', true);
        
        $event = get_post($event_id);
        $title=$event->post_title;
        $content = $event->post_content;
        $template_id=get_post_meta($event_id, '_used_template_id', true);
   
        $template = get_post($template_id);
        
        $templateContent = $template->post_content;
        $contenu=$templateContent;

        $variables=get_post_meta($event_id, '_generated_event_vars',true);
        if(!$variables){
            $variables=get_post_meta($event_id, '_generated_doc_vars',true);
            update_post_meta($event_id, '_generated_event_vars',$variables);
            delete_post_meta($event_id, '_generated_doc_vars');
       
        }
        foreach ($variables as $variable => $value) {
            if($variable=="document_name"||$variable=="document_name*"){
                $value=$title;
            }
            /*if (strpos($variable, '@') !== false) {*/
            if (strpos($variable, '@') !== false||$variable == "display_author_bio"||$variable == "display_user_bio") {
                
                // Insérer directement du HTML si '#' est présent
                $regex = "/\{" . preg_quote($variable, '/') . "\}/";
                $newContenu = preg_replace($regex, $value, $contenu); 
            } 
            else {
            
            $regex = "/\{" . preg_quote($variable, '/') . "\}/";
            $newContenu = preg_replace($regex,  esc_html($value) , $contenu);
    
       }
    
        $contenu = $newContenu;
        }

        $template_version=get_post_meta($template_id, '_template_version', true);
        update_post_meta($event_id, '_used_template_version', $template_version);
        $post_data = array(
            'ID' => $event_id,
            'post_title' => $title,
            'post_content' => $contenu
        );
        wp_update_post($post_data);
       
        if ($doc_url) {
            $pdf_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $doc_url);
            if (file_exists($pdf_path)) {
                unlink($pdf_path);
            }
        }
        //$pdf_url = generate_pdf($document_id,$content, 'generated_event_' . $document_id . '.pdf');
        $pdf_url = generate_pdf($event_id,$content, $title . '.pdf');

            update_post_meta($event_id, '_pdf_url', $pdf_url);
           
  
            wp_send_json_success($event_id);
         
      } else {
        crm_core_update_logs_option(
            'Shortcode gestion des évènements : regeneration du pdf',
    'ID de l\'évènement manquant',
   
            $current_user->ID,
            ['event_id'=>$_POST['event_id']
                   ]
        );
          wp_send_json_error(['message' => 'Requête invalide.']);
      }
  
      exit;
 }
  add_action('wp_ajax_crm_event_regenerate_pdf', 'crm_event_regenerate_pdf');
  add_action('wp_ajax_get_event_mail_data', 'get_event_mail_data_callback');
function get_event_mail_data_callback() {
    $event_id = intval($_POST['event_id']);
    $current_user = wp_get_current_user();
    $bio = get_user_meta($current_user->ID, 'description', true);

    $html = apply_filters('the_content', get_post_field('post_content', $event_id));
    //$html .= "<hr><div><strong>Bio de l'expéditeur :</strong><br>" . wpautop($bio) . "</div>";

    $email_tiers = get_post_meta($event_id, '_generated_event_tiers_email', true);
    $documents = get_post_meta($event_id, '_generated_event_pieces_joints', true);
    $pdf_url= get_post_meta($event_id, '_pdf_url', true);
    $attachements=!empty($documents)||$pdf_url!="";
  

    wp_send_json_success([
        'email' => $email_tiers,
        'htmlContent' => $html,
        'attachements'=>$attachements
    ]);
}
  
add_action('wp_ajax_send_event_to_emails', 'send_event_to_emails_callback');

function send_event_to_emails_callback() {
    $result = crm_envoyer_emails_evenement($_POST);

    if ($result['success']) {
        
        wp_send_json_success([
            'message' => $result['message'] ?? 'Email envoyé avec succès.',
        ]);
    } else {
        wp_send_json_error($result);
    }
}


function crm_events_generate_post_hash($post_id) {
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
    return hash_hmac('sha256', $post_id, $secret_key);
}

// Fonction pour récupérer l'ID de l'événement à partir du hash
function crm_events_get_post_id_from_hash($hash) {
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
    $args = ['post_type' => 'crm_docs_gen', 'posts_per_page' => -1];
   
    foreach (get_posts($args) as $post) {
        if ($hash === hash_hmac('sha256', $post->ID, $secret_key)) {
            return $post->ID;
        }
    }

    return false; 
}
function download_event_documents_shortcode($atts) {
    $atts = shortcode_atts(['text' => 'Télécharger les pièces jointes'], $atts, 'download_event_documents');

    $current_url = trim($_SERVER['REQUEST_URI'], '/');
    if (!preg_match('#^event-documents/([a-f0-9]{64,})/([a-f0-9]{13,})$#', $current_url, $matches)) {
        return ''; 
    }

    $hashed_event_id = $matches[1];
    $hashedtrackingId = $matches[2];

    $event_id = crm_events_get_post_id_from_hash($hashed_event_id);
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
   
    
       
    
    if (!$event_id) return 'Erreur de lien.';


 
    $documents = get_post_meta($event_id, '_generated_event_pieces_joints', true);
    $pdf_url   = get_post_meta($event_id, '_pdf_url', true);

    if (empty($documents) && !$pdf_url) return ''; 

    $html = "<div style='text-align:center; max-width:700px; margin:auto;'>";
    $html .= "<p style='font-weight:bold;'>" . esc_html($atts['text']) . "</p>";
    $html .= "<table style='width:100%; border-collapse: collapse;'>";

    // Fonction pour générer une ligne de fichier
    $generateRow = function($url) use ($event_id, $hashedtrackingId) {

        $file_info = pathinfo($url);
        $file_ext  = strtolower($file_info['extension'] ?? '');

        $file_name = $file_info['filename'] ?? basename($url);
        $file_name_with_ext=$file_name.$file_ext;
        $icon_url  = get_file_icon($file_ext); 

        return '<tr class="download-row" data-url="' . esc_url($url) . '" data-event="' . esc_attr($event_id) . '" data-tracking="' . esc_attr($hashedtrackingId) . '" data-filename="' . esc_attr($file_name_with_ext) . '" style="cursor: pointer; border-bottom: 1px solid #ddd;">
                <td style="padding: 10px; width: 20px;">
                    <img src="' . esc_url($icon_url) . '" alt="' . esc_attr($file_ext) . '" style="width: 20px; height: 20px;">
                </td>
                <td style="padding: 10px; text-align: left; color:#0073aa;">
                    ' . esc_html($file_name) . '
                </td>

                <td style="padding: 10px; text-align: left; color:#0073aa;">
                    Télécharger
                </td>
            </tr>';
    };

    // Ajout du PDF principal s’il existe
    if ($pdf_url) {
        $html .= $generateRow($pdf_url);
    }

    // Ajout des autres documents
    if (!empty($documents) && is_array($documents)) {
        foreach ($documents as $file) {
            $html .= $generateRow($file);
        }
    }

    $html .= "</table></div>";
    $html .= "
<script>

jQuery(document).ready(function($) {
    $(document).on('click', '.download-row', function() {
        let url = $(this).data('url');
        const eventId = $(this).data('event');
        const trackingId = $(this).data('tracking');
        const fileName = $(this).data('filename');
if (url.startsWith('http://')) {
            url = url.replace('http://', 'https://');
        }
        // Appel AJAX
        $.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'log_file_download',
                event_id: eventId,
                tracking_id: trackingId,
                file_name: fileName
            },
            success: function(response) {
                const link = document.createElement('a');
        link.href = url;
        link.download = 'download';
        link.setAttribute('download', fileName); 

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
            },
            error: function(xhr, status, error) {
                console.error('Erreur AJAX:', error);
            }
        });

        
    });
});

</script>
";

    return $html;
}

add_shortcode('download_event_documents', 'download_event_documents_shortcode');
function crm_events_custom_rewrite_rule() {
    add_rewrite_rule(
        '^event-documents/([a-f0-9]{64,})/([a-f0-9]{13,})/?$',  
        'index.php?pagename=event-documents&hashedEventId=$matches[1]&hashedtrackingId=$matches[2]', 
        'top'
    );
    flush_rewrite_rules();  // Permet de mettre à jour les règles de réécriture
}

add_action('init', 'crm_events_custom_rewrite_rule', 10, 0);
function create_event_documents_page() {
    $slug = 'event-documents';
    $page = get_page_by_path($slug);

    if (!$page) {
        wp_insert_post([
            'post_title'   => 'Vos documents',
            'post_name'    => $slug,
            'post_content' => '[download_event_documents]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ]);
    }
}
add_action('init', 'create_event_documents_page');
//tracking ouverture des emails




add_action('init', function () {
    if (
        isset($_GET['event_id'], $_GET['tracking_id']) &&
        strpos($_SERVER['REQUEST_URI'], '/email-open-tracker') !== false
    ) {
        $event_id = intval($_GET['event_id']);
        $tracking_id = sanitize_text_field($_GET['tracking_id']);
        $current_time = current_time('mysql');
        $now = strtotime($current_time);
           

        // Prioriser l'utilisation de l'en-tête X-Forwarded-For pour obtenir l'IP réelle
        $ip = $_SERVER['REMOTE_ADDR'];
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $forwarded_ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim(end($forwarded_ips));
        }


        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $ip_parts = explode('.', $ip);
        $masked_ip = count($ip_parts) === 4 ? "{$ip_parts[0]}.{$ip_parts[1]}.{$ip_parts[2]}.**" : $ip;
        $tracking_found = false;
        
        // Liste des User Agents et IPs suspects
        $suspicious_user_agents = ['Googlebot', 'Bingbot', 'facebookexternalhit', 'GoogleImageProxy'];
        $proxy_ips = ['66.249.92.*']; // Exemple d'IPs à ignorer , '142.250.32.*'

        if ($event_id && $tracking_id) {
            $log = get_post_meta($event_id, '_event_list_mail', true);

            if (is_array($log)) {
                foreach ($log as &$entry) {
                    if ($entry['tracking_id'] === $tracking_id) {
                        $tracking_found = true;
                        break;
                    }
                }
                if (!$tracking_found) {
                    error_log("❌ tracking_id $tracking_id non trouvé pour event $event_id");
                }
                foreach ($log as &$entry) {
                    if ($entry['tracking_id'] === $tracking_id) {
                        if (in_array($user_agent, $suspicious_user_agents) || fnmatch($proxy_ips[0], $ip) || fnmatch($proxy_ips[1], $ip)) {
                            header('Content-Type: image/png');
                            echo base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR4nGNgYGD4DwABBAEAgiN1ZQAAAABJRU5ErkJggg==');
                            exit;
                        }/**/

                        if (!isset($entry['etat']) || $entry['etat'] !== 'lu') {
                            $entry['etat'] = 'lu';
                            $entry['date_ouverture'] = $current_time;
                            $entry['ip_ouverture'] = $masked_ip;
                        }
                        $first_open_time = isset($entry['date_ouverture']) ? strtotime($entry['date_ouverture']) : 0;
                        $initial_ip_prefix = implode('.', array_slice(explode('.', $entry['ip_ouverture']), 0, 3));
                        $current_ip_prefix = implode('.', array_slice(explode('.', $masked_ip), 0, 3));

                        $should_add_reopen = false;

                        /*if (!isset($entry['reouvertures']) || !is_array($entry['reouvertures'])) {
                            $entry['reouvertures'] = [];
                        }

                       
                        if (empty($entry['reouvertures'])) {
                            if ($current_ip_prefix !== $initial_ip_prefix || ($now - $first_open_time) > (2 * 60 * 60)) {
                                $should_add_reopen = true;
                            }
                        } 
                        else {
                            foreach ($entry['reouvertures'] as $reopen) {
                                $reopen_ip_prefix = implode('.', array_slice(explode('.', $reopen['ip']), 0, 3));
                                $reopen_time = isset($reopen['date']) ? strtotime($reopen['date']) : 0;

                                if ($reopen_ip_prefix === $current_ip_prefix && ($now - $reopen_time) < (2 * 60 * 60)) {
                                    $should_add_reopen = false;
                                    break;
                                }
                            }

                            if ($should_add_reopen === false) {
                                if ($current_ip_prefix !== $initial_ip_prefix || ($now - $first_open_time) > (2 * 60 * 60)) {
                                    $should_add_reopen = true;
                                }
                            }
                        }

                        if ($should_add_reopen) {
                            $entry['reouvertures'][] = [
                                'date' => $current_time,
                                'ip' => $masked_ip,
                                '$should_add_reopen'=>$should_add_reopen
                            ];
                        }*/
                        if (!empty($entry['reouvertures'])) {
                            // Assume we should not add unless proven otherwise
                            $should_add_reopen = false;
                            foreach ($entry['reouvertures'] as $reopen) {
                                $reopen_ip_prefix = implode('.', array_slice(explode('.', $reopen['ip']), 0, 3));
                                $reopen_time = isset($reopen['date']) ? strtotime($reopen['date']) : 0;
                                
                                // If same IP and within 2 hours, do not add
                                if ($reopen_ip_prefix === $current_ip_prefix && ($now - $reopen_time) < (2 * 60 * 60)) {
                                    $should_add_reopen = false;
                                    break;
                                } else {
                                    // If different IP or more than 2 hours, we can add
                                    $should_add_reopen = true;
                                }
                            }
                        } else {
                            // Initial condition for adding a reopen
                            $should_add_reopen = ($current_ip_prefix !== $initial_ip_prefix || ($now - $first_open_time) > (2 * 60 * 60));
                        }
                        
                        
                        if ($should_add_reopen) {
                            $entry['reouvertures'][] = [
                                'date' => $current_time,
                                'ip' => $masked_ip,
                               // '$should_add_reopen'=>$should_add_reopen
                            ];
                        }
                       /* else{
                            $entry['reouvertures'][] = [
                                'date' => $current_time,
                                'ip' => $masked_ip,
                                'should_not_add'=>1,
                                '$should_add_reopen'=>$should_add_reopen
                            ];

                        }*/

                        break;
                    }
                }
                update_post_meta($event_id, '_event_list_mail', $log);
            }
        }

        header('Content-Type: image/png');
        echo base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR4nGNgYGD4DwABBAEAgiN1ZQAAAABJRU5ErkJggg==');
        exit;
    }
});

function crm_envoyer_emails_evenement($args = []) {
    $event_id = intval($args['event_id'] ?? 0);
    $recipients_raw = $args['recipients'] ?? [];
    $recipients = is_array($recipients_raw) ? $recipients_raw : [$recipients_raw];
    $send_attachments_via_link = $args['send_attachments_via_link'] ?? false;
    $email_stats = get_option('crm_emails_sent_stats', []);
    if (!is_array($email_stats)) $email_stats = [];
    
    $now = current_time('mysql');
    $now_ts = strtotime($now);
    if (!$event_id || empty($recipients)) {
        return ['success' => false, 'message' => "Données manquantes"];
    }
    $email_stats = array_filter($email_stats, function ($entry) use ($now_ts) {
        return isset($entry['datetime']) && (strtotime($entry['datetime']) > ($now_ts - 7 * DAY_IN_SECONDS));
    });
    $current_user = wp_get_current_user();
    $email_style = get_option('crm_event_emails_style', '');
    $x_mailer = get_option('crm_event_x_mailer', 'CRM Mailer');
    $list_unsub = get_option('crm_event_list_unsubscribe', '');
    $subject = wp_strip_all_tags(html_entity_decode(get_the_title($event_id), ENT_QUOTES, 'UTF-8'));
    $html_content = apply_filters('the_content', get_post_field('post_content', $event_id));
    $current_user_mail = sanitize_email($current_user->user_email);
    $nom = $current_user->display_name;
    // SMTP config
    $smtp_host = get_option('crm_smtp_default_host', '');
    $smtp_login = get_option('crm_smtp_default_email', '');
    $smtp_port = get_option('crm_smtp_default_port', '');
    $smtp_password = get_option('crm_smtp_default_password', '');

    if (!$smtp_host || !$smtp_login || !$smtp_port || !$smtp_password) {
        return ['success' => false, 'message' => "Configuration SMTP manquante"];
    }

    require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
    require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
    require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';

    $log = get_post_meta($event_id, '_event_list_mail', true);
    if (!is_array($log)) $log = [];

    $document_urls = get_post_meta($event_id, '_generated_event_pieces_joints', true);
    $pdf_url = get_post_meta($event_id, '_pdf_url', true);

    $date = current_time('mysql');
    $current_user_ip = $_SERVER['REMOTE_ADDR'];
    $all_sent = true;
    $error_emails = [];
    $recipients[]=$current_user_mail;
    foreach ($recipients as$index=> $email) {
        $sanitized_email = sanitize_email($email);
        $tracking_id = uniqid();
        $unique_param = uniqid();
        $attachments = [];
        $email_stats[] = [
            'datetime' => $now,
            'user_id' => get_current_user_id(),
            'event_id' => $event_id
        ];
        // Contenu HTML de l’email avec pixel de suivi
        $html = "
        <!DOCTYPE html>
        <html lang='fr'>
        <head>
            <meta charset='UTF-8'>
            <title>" . esc_html($subject) . "</title>
            <style>{$email_style}
          </style>
        </head>
        <body style='background-image: url(\"" . esc_url(site_url("/email-open-tracker?event_id={$event_id}&tracking_id={$tracking_id}")) . "\");  background-size:0px 0px'>";
        if($email!=$current_user_mail){
            $html .= '<img src="' . site_url("/email-open-tracker?event_id={$event_id}&tracking_id={$tracking_id}") . '" width="1" height="1" style="width:1px;height:1px;opacity:0;visibility:hidden;" alt="." />';

            $html .= '<noscript>
            <img src="' . site_url("/email-open-tracker?event_id={$event_id}&tracking_id={$tracking_id}") . '" width="1" height="1" style="width:1px;height:1px;opacity:0;visibility:hidden;" alt="." />
        </noscript>';
        /*$html .= 'hi2
        <a href="' . site_url("/email-open-tracker?event_id={$event_id}&tracking_id={$tracking_id}") . '" >test by click </a>
    ';*/
       
        }
             $html .= "{$html_content}";

        if ((!empty($document_urls) && is_array($document_urls)) || $pdf_url) {
            if ($send_attachments_via_link) {
                $event_id_encrypted = crm_events_generate_post_hash($event_id);
                $download_link = site_url("/event-documents/{$event_id_encrypted}/{$tracking_id}");
                $html .= "<hr><p>Vous pouvez télécharger les pièces jointes ici :</p><a href='" . esc_url($download_link) . "' target='_blank'>Télécharger</a>";
            } else {
                if ($pdf_url) {
                    $file_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $pdf_url);
                    if (file_exists($file_path)) $attachments[] = $file_path;
                }
                foreach ((array)$document_urls as $doc_url) {
                    $file_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $doc_url);
                    if (file_exists($file_path)) $attachments[] = $file_path;
                }
            }
        }

        $html .= "</body></html>";
      
        $mailer = new PHPMailer\PHPMailer\PHPMailer(true);
        $listUnsubscribeURL  = get_option('crm_event_list_unsubscribe_url', '');

        
          try {
            $mailer->isSMTP();
            $mailer->Host = $smtp_host;
            $mailer->SMTPAuth = true;
            $mailer->Username = $smtp_login;
            $mailer->Password = $smtp_password;
            $mailer->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mailer->Port = intval($smtp_port);

            $mailer->CharSet = 'UTF-8';
            $mailer->setFrom($smtp_login, $nom ?: get_bloginfo('name'));
            $mailer->addReplyTo($current_user_mail);
            $mailer->addAddress($sanitized_email);
             $mailer->Subject = $subject;
            $mailer->isHTML(true);
            $mailer->Body = $html;
            if (!empty($x_mailer)) {
                $mailer->XMailer = $x_mailer;
            }
            if (!empty($list_unsub) || !empty($listUnsubscribeURL)) {
                $unsubscribeHeaders = [];
        
                if (!empty($list_unsub)) {
                    $email = sanitize_email($list_unsub);
                    $unsubscribeHeaders[] = "<mailto:$email?subject=unsubscribe>";
                }
        
                if (!empty($listUnsubscribeURL)) {
                    $unsubscribeHeaders[] = "<$listUnsubscribeURL>";
                }
        
                if (!empty($unsubscribeHeaders)) {
                    $mailer->addCustomHeader('List-Unsubscribe', implode(', ', $unsubscribeHeaders));
                    $mailer->addCustomHeader('List-Unsubscribe-Post', 'List-Unsubscribe=One-Click');
                }
            }
            foreach ($attachments as $att) {
                $mailer->addAttachment($att);
            }

            $mailer->send();
            $sent = true;
        } catch (Exception $e) {
            $sent = false;
        }
       if (trim(strtolower($sanitized_email)) !== trim(strtolower($current_user_mail))) {

        $log[] = [
            'tracking_id' => $tracking_id,
            'email' => $sanitized_email,
            'etat' => $sent ? 'envoyé' : 'échec',
            'date_envoi' => $date,
            'user_email' => $current_user_mail,
            'liens_documents' => $attachments,
            'user_bcc_ip' => $current_user_ip,
        ];
       }

        if (!$sent) {
            $all_sent = false;
            $error_emails[] = $sanitized_email;
        }

        usleep(300000); // Pause légère pour éviter l'effet spam
    }

    update_post_meta($event_id, '_event_list_mail', $log);

    update_option('crm_emails_sent_stats', $email_stats);
    if (!empty($error_emails)) {
        crm_core_update_logs_option(
            'Shortcode gestion des évènements: envoi des emails',
            'Échec d\'envoi de l\'email',
            $current_user->ID,
            $error_emails
        );
    }
    return $all_sent
        ? ['success' => true, 'message' => "Tous les emails ont été envoyés."]
        : ['success' => false, 'message' => "Certains emails ont échoué.", 'errors' => $error_emails];
}




add_action('phpmailer_init', 'crm_force_custom_smtp');
function crm_force_custom_smtp($phpmailer) {
    // Récupération des options SMTP
    $smtp_host       = get_option('crm_smtp_default_host', '');
    $smtp_login      = get_option('crm_smtp_default_email', '');
    $smtp_port       = get_option('crm_smtp_default_port', '');
    $smtp_password   = get_option('crm_smtp_default_password', '');
    $default_name    = get_option('crm_smtp_default_login', get_bloginfo('name'));
    $x_mailer        = get_option('crm_event_x_mailer', 'CRM Mailer');
    $list_unsub      = get_option('crm_event_list_unsubscribe', '');
    $listUnsubscribeURL  = get_option('crm_event_list_unsubscribe_url', '');


    // Vérification de la configuration SMTP
    if (!$smtp_host || !$smtp_login || !$smtp_port || !$smtp_password) {
        return; 
    }

    // Configuration de PHPMailer
    $phpmailer->isSMTP();
    $phpmailer->Host       = $smtp_host;
    $phpmailer->SMTPAuth   = true;
    $phpmailer->Username   = $smtp_login;
    $phpmailer->Password   = $smtp_password;
    $phpmailer->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
    $phpmailer->Port       = intval($smtp_port);

    // Informations d'envoi
    $phpmailer->From       = $smtp_login;
    $phpmailer->FromName   = $default_name;
    $phpmailer->CharSet    = 'UTF-8';

    // Headers personnalisés
    if (!empty($x_mailer)) {
        $phpmailer->XMailer = $x_mailer;
    }

    if (!empty($list_unsub) && !empty($listUnsubscribeURL)) {
        $unsubscribeHeaders = [];

        if (!empty($list_unsub)) {
            $email = sanitize_email($list_unsub);
            $unsubscribeHeaders[] = "<mailto:$email?subject=unsubscribe>";
        }

        if (!empty($listUnsubscribeURL)) {
            $unsubscribeHeaders[] = "<$listUnsubscribeURL>";
        }

        if (!empty($unsubscribeHeaders)) {
            $phpmailer->addCustomHeader('List-Unsubscribe', implode(', ', $unsubscribeHeaders));
            $phpmailer->addCustomHeader('List-Unsubscribe-Post', 'List-Unsubscribe=One-Click');
        }
    }
}






  add_action('wp_ajax_log_file_download', 'handle_file_download_tracking');
  add_action('wp_ajax_nopriv_log_file_download', 'handle_file_download_tracking');
  
  function handle_file_download_tracking() {
      $event_id = intval($_POST['event_id']);
      $tracking_id = ($_POST['tracking_id']);
      $file_name = ($_POST['file_name']);
  
      if (!$event_id || !$tracking_id || !$file_name) {
        crm_core_update_logs_option(
            'Shortcode gestion des évènements: suivi téléchargement des fichiers',
            'Demande invalide',
        '',
            ['event_id'=>$event_id,
            'tracking_id'=>$tracking_id,
            'file_name'=>$file_name
            ]
        );
          wp_send_json_error('Invalid request');
      }
  
      $ip_address = $_SERVER['REMOTE_ADDR'];
      $ip_parts = explode('.', $ip_address);
      $masked_ip = count($ip_parts) === 4 ? "{$ip_parts[0]}.{$ip_parts[1]}.{$ip_parts[2]}.**" : $ip_address;
      $current_time = current_time('mysql');
  
      $log = get_post_meta($event_id, '_event_list_mail', true);
  
      if (!empty($log) && is_array($log)) {
          foreach ($log as &$entry) {
              if ($entry['tracking_id'] === $tracking_id) {
                  if (!isset($entry['documents_ouverts'])) {
                      $entry['documents_ouverts'] = [];
                  }
  
                  $entry['documents_ouverts'][] = [
                      'date' => $current_time,
                      'ip' => $masked_ip,
                      'fichiers' => $file_name
                  ];
                  break;
              }
          }
          update_post_meta($event_id, '_event_list_mail', $log);
      }
  
      wp_send_json_success();
  }
  
 