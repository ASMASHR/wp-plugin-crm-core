  //shortcode note
  jQuery(document).ready(function($) {
              const noteLabelsArray = {
                  'user_status': 'Statut utilisateur',
                  'display_name': 'Nom affiché',
                  'nickname': 'Surnom',
                  'first_name': 'Prénom',
                  'last_name': 'Nom',
                  'description': 'Description',
                  'wc_last_active': 'Dernière activité WooCommerce',
                  'tax_no': 'Numéro fiscal',
                  'user_mailing': 'Adresse de messagerie utilisateur',
                  'shipping_first_name': 'Prénom (livraison)',
                  'shipping_last_name': 'Nom (livraison)',
                  'shipping_company': 'Entreprise (livraison)',
                  'shipping_address_1': 'Adresse 1 (livraison)',
                  'shipping_address_2': 'Adresse 2 (livraison)',
                  'shipping_city': 'Ville (livraison)',
                  'shipping_postcode': 'Code postal (livraison)',
                  'shipping_country': 'Pays (livraison)',
                  'shipping_state': 'Région/État (livraison)',
                  'shipping_phone': 'Téléphone (livraison)',
                  'shipping_email': 'E-mail (livraison)',
                  'billing_first_name': 'Prénom (facturation)',
                  'billing_last_name': 'Nom (facturation)',
                  'billing_company': 'Entreprise (facturation)',
                  'billing_address_1': 'Adresse 1 (facturation)',
                  'billing_address_2': 'Adresse 2 (facturation)',
                  'billing_city': 'Ville (facturation)',
                  'billing_postcode': 'Code postal (facturation)',
                  'billing_country': 'Pays (facturation)',
                  'billing_state': 'Région/État (facturation)',
                  'billing_phone': 'Téléphone (facturation)',
                  'billing_email': 'E-mail (facturation)',
                  'reference_template': 'Référence modèle',
                  'creation_date': 'Date de création',
                  'template_name': 'Nom template',
                  'display_author_name': 'Auteur',
                  'display_author_bio': 'Description de l\'auteur',
                  'display_user_bio': 'Description du client',
                  'civilte': 'Civilité',
              };
              let noteEditors = {};
              $('#sy-crm-event-show-note-sidebar-btn').click(function() {
                          const userId = $(this).data('user-id');
                          const templateId = $(this).data('template-id');
                          $('#sy-crm-event-note-send-email-section-attachment-option').hide();
                          $('#sy-crm-event-note-send-mail-form-send-attachments-via-link').removeAttr('checked')
                          $('#sy-crm-event-note-send-email-checkbox').removeAttr('checked');
                          $('#sy-crm-event-note-mail-recipients-wrapper .recipient-group:not(:first)').remove();
                          $('#sy-crm-event-note-send-email-section').hide();

                          if (templateId) {
                              $.get(ajax_object.ajax_url, {
                                          action: 'get_template_variables',
                                          template_id: templateId,
                                          user_id: userId
                                      },
                                      function(response) {
                                          if (response.success) {
                                              const container = $('#sy-crm-event-note-sidebar-vars');
                                              container.empty();
                                              const today = new Date();
                                              // const formattedDate = `${today.getDate().toString().padStart(2, '0')}-${(today.getMonth() + 1).toString().padStart(2, '0')}`; // JJ-MM
                                              const formattedDate = response.data.date_creation

                                              const variables = response.data.variables;
                                              let preFilled = response.data.pre_filled;
                                              const templateRacine = response.data.racine;
                                              const compteur = response.data.compteur || 1;
                                              const templateNom = noteDecodeHtmlEntities(response.data.templateNom);
                                              const creatorNom = response.data.creatorNom;
                                              const docTitle = ` Note du ${formattedDate} `;
                                              $('#note-title').val(docTitle);
                                              $('#sy-crm-event-note-sidebar-date').val(today.toISOString().split('T')[0])
                                              $('#sy-crm-event-note-sidebar-duration').val('');
                                              let hiddenChamps = [
                                                  'devis', 'factures-echues', 'facture',
                                                  'template_name', 'document_name', 'user_status', 'display_name', 'display_author_name', 'display_author_bio', 'first_name', 'last_name', 'display_user_bio',
                                                  'wc_last_active', 'tax_no', 'user_mailing', 'shipping_first_name', 'shipping_last_name', 'shipping_company',
                                                  'shipping_address_1', 'shipping_address_2', 'shipping_city', 'shipping_postcode',
                                                  'shipping_country', 'shipping_state', 'shipping_phone', 'shipping_email',
                                                  'reference_template', 'creation_date', 'billing_first_name', 'billing_last_name',
                                                  'billing_company', 'billing_address_1', 'billing_address_2', 'billing_city',
                                                  'billing_postcode', 'billing_country', 'billing_state', 'billing_phone',
                                                  'billing_email', 'civilite', 'don_ref', 'don_date', 'don_moyen', 'don_montant_nb', 'don_montant_txt', 'don_etat', 'don_etat', 'don_commentaire', 'est_annule'
                                              ];


                                              variables.forEach(variable => {

                                                          let cleanedVariable = variable.replace(/[*#@]/g, '').replace(/[*#@]/g, '').trim();
                                                          let value = preFilled[variable] || '';

                                                          // Tests sur la version nettoyée de la variable
                                                          if (cleanedVariable === 'reference_template') {
                                                              value = `${templateRacine}-${formattedDate}-${compteur}`;
                                                          } else if (cleanedVariable === 'template_name') {
                                                              value = `${templateNom}`;
                                                          } else if (cleanedVariable === 'creation_date') {
                                                              const day = today.getDate().toString().padStart(2, '0');
                                                              const month = (today.getMonth() + 1).toString().padStart(2, '0');
                                                              const year = today.getFullYear();
                                                              value = `${year}-${month}-${day}`;
                                                          } else if (cleanedVariable === 'event_name') {
                                                              value = docTitle;
                                                          }



                                                          const hiddenStyle = hiddenChamps.includes(variable) ? 'style="display:none;"' : '';
                                                          // const readOnlyAttr = readOnlyChamps.includes(variable) ? 'readonly' : '';
                                                          const readOnlyAttr = '';
                                                          if (variable.includes('@')) {
                                                              value = value.replace(/\r\n|\r|\n/g, '<br>');

                                                              let requiredChamp = variable.includes('*');
                                                              const labelText = (noteLabelsArray[variable.replace('@', '').replace('*', '').trim()] || variable.replace('@', '').replace('*', '').trim());
                                                              const sanitizedVariable = variable.replace(/'/g, '&#39;');
                                                              const sanitizedVariableId = variable.replace(/'/g, '&#39;').replace(/[@*]/g, 'a').replace(/\s+/g, '_');
                                                              container.append(`
                                                            <div class="variable__item" style="height:260px;">
                                                                <div style="height:260px; ">
                                                                <div id="${sanitizedVariableId}" name="${sanitizedVariable}" style="width: -webkit-fill-available; height:200px;" ${requiredChamp ? 'required' : ''}>${noteDecodeHtmlEntities(value)}</div>
                                                            </div></div>
                                                            <div class=" text-error" style=" display:none;">Ce champ est requis.</div>
                                                        `);
                                                              /* var quillVariable = new Quill(`#${sanitizedVariableId}`, {
                                                                      theme: "snow"
                                                                  });*/

                                                              noteEditors[sanitizedVariableId] = new Quill(`#${sanitizedVariableId}`, {
                                                                  theme: "snow",
                                                                  placeholder: `${labelText}${requiredChamp ? ' *' : ''}`,
                                                                  readOnly: readOnlyAttr

                                                              });



                                                          } else if (variable.includes('|')) {
                                                              const options = variable.split('|').slice(1);
                                                              const parts = variable.split('|');
                                                              let labelText = parts[0].trim();
                                                              let requiredChamp = labelText.includes('*');
                                                              labelText = labelText.replace(/[^a-zA-Z0-9\s]/g, ''); // Nettoyage
                                                              const sanitizedVariable = variable.replace(/'/g, '&#39;'); // Gestion des apostrophes

                                                              container.append(`
                                    <div class="variable__item"${hiddenStyle}>
                                        <select class="crm-doc-select" id="${sanitizedVariable}" name="${sanitizedVariable}" ${requiredChamp ? 'required' : ''}${readOnlyAttr}>
                                        <option value=""selected>${labelText}${requiredChamp ? ' *' : ''}</option>    
                                        ${options.map(option => `<option value="${option}">${option}</option>`).join('')}
                                        </select>
                                    </div>
                                    <div class=" text-error" style=" display:none;">Ce champ est requis.</div>
                                `);
                            } 
                            else if (variable.includes('#')) {
                                const cleanedVariable = variable.replace(/[*#@]/g, '').replace(/[*#@]/g, '').trim(); 
                                const labelText = noteLabelsArray[cleanedVariable] || cleanedVariable;
                                let requiredChamp = labelText.includes('*');
                                //labelText = labelText.replace(/[^a-zA-Z0-9\s]/g, '');
                                container.append(`
                                    <div class="variable__item"${hiddenStyle}>
                                        <label class="crm-doc-label"for="${variable}">${labelText} ${requiredChamp ? ' *' : ''} :</label>
                                        <input class="crm-doc-input"type="date" id="${variable}" name="${variable}" value="${value}"  ${requiredChamp ? 'required' : ''}${readOnlyAttr}/>
                                    </div>
                                    <div class=" text-error" style=" display:none;">Ce champ est requis.</div>
                                `);
                            } 
                            else {
                                const requiredChamp = variable.includes('*');
                                const cleanedVariable = variable.replace(/\*\s*/g,'');
                                    const labelText = noteLabelsArray[cleanedVariable] || cleanedVariable;
                                    const sanitizedVariable = cleanedVariable.replace(/'/g, '&#39;'); // Gestion des apostrophes

                                    if (requiredChamp) {
                                        //value = preFilled[cleanedVariable] || ''; 
                                        container.append(`
                                            <div class="variable__item"${hiddenStyle}>
                                                <input class="crm-doc-input"type="text" id="${variable}" name="${variable}" value="${value}" required ${readOnlyAttr}placeholder="${labelText} *"/>
                                            </div>
                                            <div class=" text-error" style=" display:none;">Ce champ est requis.</div>
                                        `);
                                                                        } else {
                                                                            //value = preFilled[variable] || '';
                                                                            container.append(`
                                            <div class="variable__item"${hiddenStyle}>
                                                <input class="crm-doc-input"type="text" id="${variable}" name="${variable}" value="${value}"placeholder="${labelText}" ${readOnlyAttr}/>
                                            </div>
                                        `);
                                    }
                                }
                });
                //
                const autoriseeventsJoints = response.data.autorise_documents_joints;
                const autorisepdf = response.data.template_autorise_generation_pdf;

                // Afficher le champ d'upload si l'option est activée
              
                if (autoriseeventsJoints === 'on') {

                   
                    $('#sy-crm-event-note-sidebar-options').slideDown(); 
                }
                else{
                    $('#sy-crm-event-note-sidebar-options').slideUp(); 
                }
                if($('#sy-crm-event-note-send-email-section-attachment-option').length>0)
                    {
                if(autoriseeventsJoints === 'on'||autorisepdf === 'on'){
                    $('#sy-crm-event-note-send-email-section-attachment-option').data('visibility','on'); 
                }
                else{
                    $('#sy-crm-event-note-send-email-section-attachment-option').slideUp().data('visibility','of'); 
                }
            }
    
                $("#sy-crm-event-note-sidebar").addClass("open").show();
            }
        },
                            )
                          }
                          else{
                            alert('Aucun template n’est défini comme modèle par défaut.')
                          }
                          

            });
            $('#sy-crm-event-note-sidebar-submit-btn').click(function () {
                let isValid = true;
                const variables = {};
                const docTitleInput = $('#note-title');
                if (!docTitleInput.val().trim()) {
                    isValid = false;
                    docTitleInput.parent().next('.text-error').show(); 
                } else {
                    docTitleInput.parent().next('.text-error').hide(); 
                }
                const editorContents = noteGetAllEditorContents(noteEditors);
                $('#sy-crm-event-note-sidebar-vars').find('input, select').each(function () {
                    const input = $(this);
                    const isRequired = input.prop('required'); 
                    
                    if (isRequired && !input.val().trim()) { 
                        isValid = false;
                        input.parent().next('.text-error').show();
                    } 
                    else {
                        input.parent().next('.text-error').hide();
                        const value = $(this).val() || ""; 
                        variables[input.attr('name')] = value;
                        
                                    
                    }
                });
            
                    for (const editorId in editorContents) {
                        if (editorContents.hasOwnProperty(editorId)) {
                            const $editorElement = $(`#${editorId}`);
                            const varName = $editorElement.attr('name');
                            const content = editorContents[editorId];
                    
                            const $errorMessageElement = $editorElement.parent().parent().next('.text-error');
                            if ($editorElement.attr('required') && (!content || content.trim() === '<p><br></p>')) {
                                isValid = false;
                                $editorElement.addClass('error'); 
                                
                                // Affiche le message d'erreur
                                $errorMessageElement.text('Ce champ est requis.').show();
                            } else {
                                $editorElement.removeClass('error');
                                
                                $errorMessageElement.text('').hide();
                            }
                    
                            variables[varName] = content;
                        }
                    }
                    
                    

                const filesData = new FormData();
                var selectedTags = [];
                    
                    $('#sy-crm-event-note-sidebar .crm_events_tags_selected').each(function() {
                        selectedTags.push($(this).data('id'));
                        filesData.append('selected_tags[]', $(this).data('id'));
                    });
                    let recipients=[];
                    let send_attachments_via_link = $('#sy-crm-event-note-send-mail-form-send-attachments-via-link').is(':checked') ? 1 : 0;
        
                    if($('#sy-crm-event-note-send-email-checkbox').is(':checked')){

                        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                        
                        // Supprimer les anciens messages d'erreur
                        $('#sy-crm-event-note-send-email-section .text-error').remove();
        
                        recipients = $('input[name="sy-crm-event-note-recipients[]"]').map(function () {
                            const value = $(this).val().trim();
        
                            if (!value) {
                                $(this).parent().after('<p class="text-error text-danger">Ce champ est requis</p>');
                                isValid = false;
                            } else if (!emailRegex.test(value)) {
                                $(this).parent().after('<p class="text-error text-danger">Adresse email invalide</p>');
                                isValid = false;
                            }
        
                            return value;
                        }).get();
                    }
                    const filesInput = $('#sy-crm-event-note-sidebar-options-files');
                if (filesInput.length > 0 && filesInput[0].files.length > 0) {
                const files = filesInput[0].files;
                for (let i = 0; i < files.length; i++) {
                    const file = files[i];

                    // Vérification des extensions interdites
                    const forbiddenExtensions = ['php', 'js', 'exe', 'bat', 'sh'];
                    const fileExtension = file.name.split('.').pop().toLowerCase();

                    if (forbiddenExtensions.includes(fileExtension)) {
                        isValid = false;
                        filesInput.parent().next('.text-error')
                            .text('Le fichier "' + file.name + '" a une extension non autorisée.')
                            .show();
                    } else {
                        filesData.append('additional_files[]', file); 
                        filesInput.parent().next('.text-error').hide(); 
                    }
                }
                }
                if (!isValid) return;

                recipients.forEach(email => {
                    filesData.append('recipients[]', email);
                });

                // Appel AJAX pour générer le event
                const doctitle = $('#note-title').val(); 
                const templateId =  $('#sy-crm-event-note-sidebar-template-id').val();
                
                const userId = $('#sy-crm-event-note-sidebar-user-id').val();
                filesData.append('action', 'save_generated_event');
                filesData.append('template_id', templateId);
                filesData.append('user_id', userId);
                filesData.append('variables', JSON.stringify(variables));
                filesData.append('doctitle', doctitle);
                filesData.append('event_dure',  $('#sy-crm-event-note-sidebar-duration').val());
                filesData.append('event_date', $('#sy-crm-event-note-sidebar-date').val());
                
                filesData.append('send_attachments_via_link', send_attachments_via_link);
                filesData.append('send_event_by_mail', $('#sy-crm-event-note-send-email-checkbox').is(':checked')?1:0);
               
                $("#sy-crm-event-note-sidebar").animate({ scrollTop: 0 }, 100, function() {

                        
                    $('#sy-crm-event-note-sidebar-notif').removeClass('text-success text-error').addClass('text-info').text('Traitement en cours...');
    
                })


                // Envoi de la requête AJAX avec $.ajax()
            $.ajax({
                    url: ajax_object.ajax_url,
                    type: 'POST',
                    data: filesData,
                    processData: false,
                    contentType: false, 
                    success: function (response) {

                        if (response.success) {
                            $("#sy-crm-event-note-sidebar").animate({ scrollTop: 0 }, 1000, function() {

                        
                            $('#sy-crm-event-note-sidebar-notif')
                                .text('Note ajouté avec succes.')
                                .addClass("text-success").removeClass(" text-error")
                                .fadeIn()
                                .delay(500)
                                .fadeOut(function() {
                                    location.reload();
                                });
                            })
                        } else {
                            $("#sy-crm-event-note-sidebar").animate({ scrollTop: 0 }, 1000, function() {

                            $('#sy-crm-event-note-sidebar-notif')
                                .text(response.data.message)
                                .removeClass("text-success").addClass(" text-error")
                                .fadeIn()
                                .delay(500)
                                .fadeOut();
                            })
                        }
                    },
                    error: function() {
                        $("#sy-crm-event-note-sidebar").animate({ scrollTop: 0 }, 1000, function() {

                        $('#sy-crm-event-note-sidebar-notif')
                            .text("Erreur lors de l\'ajout de la note.")
                            .removeClass("text-success").addClass(" text-error")
                            .fadeIn()
                            .delay(500)
                            .fadeOut();
                        })
                    }
                    
                });
            });
            function noteDecodeHtmlEntities(str) {
                var txt = document.createElement('textarea');
                txt.innerHTML = str;
                return txt.value;
            }
            function noteGetAllEditorContents(editorsList) {
                const editorContents = {};
                for (const id in editorsList) {
                    if (editorsList.hasOwnProperty(id)) {
                        editorContents[id] = editorsList[id].root.innerHTML; 
                    }
                }
                return editorContents;
            }
            $(document).on('change','#sy-crm-event-note-sidebar-options-files', function () {
                const filesInput = $('#sy-crm-event-note-sidebar-options-files');
                if($('#sy-crm-event-note-send-email-section-attachment-option').length>0)
                {
                    if ($('#sy-crm-event-note-send-email-checkbox').is(':checked')&&
                    (filesInput.length > 0 && filesInput[0].files.length > 0||$('#sy-crm-event-note-send-email-section-attachment-option').data('visibility')=='on')) {
                    $('#sy-crm-event-note-send-email-section-attachment-option').slideDown();

                }
                else{
                   

                    $('#sy-crm-event-note-send-email-section-attachment-option').slideUp();
                    

                }
                }
                
        
            })
            
$(document).on('change', '#sy-crm-event-note-send-email-checkbox', function () {
    if ($(this).is(':checked')) {
        $('#sy-crm-event-note-send-email-section').slideDown();
        $('#sy-crm-event-note-sidebar-submit-btn').text('Envoyer')
        if($('#sy-crm-event-note-send-email-section-attachment-option').data('visibility')=="on"){
            $('#sy-crm-event-note-send-email-section-attachment-option').slideDown();
                          
        }
        

    } else {
        $('#sy-crm-event-note-send-email-section').slideUp();
        $('#sy-crm-event-note-sidebar-submit-btn').text('Générer')
        $('#sy-crm-event-note-send-email-section-attachment-option').slideUp();
         
    }
});
$(document).on('click', '.sy-crm-event-note-add-recipient-btn', function () {
    $('#sy-crm-event-note-mail-recipients-wrapper').append(`
        <div class="recipient-group">
            <div  class="recipient-group-top">
            <input type="email" name="sy-crm-event-note-recipients[]" class="sy-crm-event-note-recipients" required>
            <button type="button" class="sy-crm-event-note-remove-recipient-btn">-</button>
            </div>
            
        </div>
    `);
});

// Retirer un champ
$(document).on('click', '.sy-crm-event-note-remove-recipient-btn', function () {
    $(this).closest('.recipient-group').remove();
});
$(document).on('input', 'input[name="sy-crm-event-note-recipients[]"]', function (e) {
    $(this).parent().next('.text-error').remove();
    });

})