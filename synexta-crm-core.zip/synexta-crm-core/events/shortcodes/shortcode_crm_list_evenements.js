jQuery(document).ready(function($) {
    $('#sy-crm-event-table-header-filter').on('keyup', function() {
        let value = $(this).val().toLowerCase();
        tableUserEvent.search(value).draw();
        tableOtherEvent.search(value).draw();
    });
    $('#filter-events-tag').on('change', function() {
        let value = $(this).val();
        tableUserEvent.search(value).draw();
        tableOtherEvent.search(value).draw();
    });

    $('.sy-crm-event-table-detail-cell').on('click', function() {
        var url = $(this).data('url');
        window.location.href = url;
    });
    //sy-crm-others-event-table
    var tableUserEvent = $('#sy-crm-user-event-table').DataTable({
        "paging": true,
        "searching": true,
        "ordering": true,
        "pageLength": $('#sy-crm-user-event-table').data('count'),

        "search": {
            "smart": false,
            "caseInsensitive": true
        },
        "searchDelay": 100,
        "columnDefs": [
            { "orderable": false, "targets": 3 },
            {
                "orderable": true,
                "targets": 1,
                "type": 'html'
            },
            { "responsivePriority": 1, "targets": [0, 1, 3, 2] },
            { "responsivePriority": 1, "targets": '_all' }
        ],
        "order": [
            [1, 'desc']
        ],
        "lengthChange": false,
        "info": true,
        "responsive": true,
        "pagingType": "full_numbers",
        "language": {
            "paginate": {
                "previous": "<",
                "next": ">",
                "first": "<<",
                "last": ">>"
            },
            "info": " _START_ - _END_ / _TOTAL_",
            "infoEmpty": "Aucun évènement disponible",
            "zeroRecords": "Aucun évènement correspondant trouvé",
            "emptyTable": "Aucun évènement trouvé",
            "infoFiltered": "(filtré à partir de _MAX_ entrées )"
        },
        /*"drawCallback": function() {
            $('.dataTables_paginate').appendTo('.sy-crm-event-table-info');
            $('#custom-info').html($('.dataTables_info').html());
        }*/
    });

    if ($('#sy-crm-user-event-table_filter').length > 0) {
        $('#sy-crm-user-event-table_filter').hide()
    }
    var tableOtherEvent = $('#sy-crm-others-event-table').DataTable({
        "paging": true,
        "searching": true,
        "ordering": true,
        "pageLength": $('#sy-crm-others-event-table').data('count'),
        "search": {
            "smart": false,
            "caseInsensitive": true
        },
        "searchDelay": 100,
        "columnDefs": [
            { "orderable": false, "targets": 3 },
            {
                "orderable": true,
                "targets": 1,
                "type": 'html'
            },
            { "responsivePriority": 1, "targets": [0, 1, 3, 2] },
            { "responsivePriority": 1, "targets": '_all' }
        ],
        "order": [
            [1, 'desc']
        ],
        "lengthChange": false,
        "info": true,
        "responsive": true,
        "pagingType": "full_numbers",
        "language": {
            "paginate": {
                "previous": "<",
                "next": ">",
                "first": "<<",
                "last": ">>"
            },
            "info": " _START_ - _END_ / _TOTAL_",
            "infoEmpty": "Aucun évènement disponible",
            "zeroRecords": "Aucun évènement correspondant trouvé",
            "emptyTable": "Aucun évènement trouvé",
            "infoFiltered": "(filtré à partir de _MAX_ entrées )"
        },
        /*"drawCallback": function() {
            $('.dataTables_paginate').appendTo('.sy-crm-event-table-info');
            $('#custom-info').html($('.dataTables_info').html());
        }*/
    });

    if ($('#sy-crm-others-event-table_filter').length > 0) {
        $('#sy-crm-others-event-table_filter').hide()
    }

})