<?php


// Définition des constantes
define('CRM_EVENTS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CRM_EVENTS_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once CRM_EVENTS_PLUGIN_DIR . 'crm-event-admin-models/crm-event-models.php';
require_once CRM_EVENTS_PLUGIN_DIR . 'configuration/crm-event-configuration.php';
require_once CRM_EVENTS_PLUGIN_DIR . 'configuration/crm-event-tags.php';
require_once CRM_EVENTS_PLUGIN_DIR . 'configuration/crm-event-departements.php';
require_once CRM_EVENTS_PLUGIN_DIR . 'configuration/crm-event-smtp.php';
require_once CRM_EVENTS_PLUGIN_DIR . 'crm-event-admin-list/crm-event-admin-list.php';

require_once plugin_dir_path(__FILE__) . '../includes/dompdf/autoload.inc.php';

require_once plugin_dir_path(__FILE__) .  'shortcodes/shortcode_global_functions.php';
require_once plugin_dir_path(__FILE__) . 'shortcodes/shortcode_crm_list_evenements.php';
require_once plugin_dir_path(__FILE__) . 'shortcodes/shortcode_crm_gestion_evenements.php';
//require_once plugin_dir_path(__FILE__) . 'shortcodes/shortcode_crm_notes.php';
require_once plugin_dir_path(__FILE__) . 'shortcodes/shortcode_crm_event_logs_list.php';


/**
 * Chargement des scripts et styles spécifiques au plugin
 */
function synexta_generation_events_crm_enqueue_admin_assets($hook_suffix) {
    wp_enqueue_style('synexta-crm-style', plugin_dir_url(__FILE__) . '/crm-event-admin-models/crm-event-models-style.css');
      
}
add_action('admin_enqueue_scripts', 'synexta_generation_events_crm_enqueue_admin_assets');
