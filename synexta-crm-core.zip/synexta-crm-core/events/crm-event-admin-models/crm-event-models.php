<?php

// Enregistrement du type de post personnalisé
function register_crm_events_post_type() {
    register_post_type('crm_documents', [
        'labels' => [
            'name'               => 'Modèles',
            'singular_name'      => 'Template CRM',
            'add_new'            => 'Ajouter un template',
            'add_new_item'       => 'Ajouter un template',
            'edit_item'          => 'Modifier le template',
            'new_item'           => 'Nouveau template',
            'view_item'          => 'Voir le template',
            'search_items'       => 'Rechercher des templates',
            'not_found'          => 'Aucun template trouvé',
            'not_found_in_trash' => 'Aucun template trouvé dans la Corbeille',
        ],
        'public'        => false,
        'show_ui'       => true,
        'has_archive'   => false,
        'menu_icon'     => 'dashicons-media-text',
        'supports'      => ['title', 'editor'],
        'rewrite'       => false,
       
        'show_in_menu'       => 'crm-dashboard',
       
    ]);
}
add_action('init', 'register_crm_events_post_type');

//
function render_generate_documents_page() {
    echo '<div class="wrap">';
    echo '<h1>Générer des Évènements</h1>';
    include CRM_EVENTS_PLUGIN_DIR . 'crm-event-admin-list/generation-functions.php';
    echo '</div>';
}

// Ajouter les metaboxes
function ajouter_metaboxes_crm_templates() {
    
    add_meta_box(
        'droits_utilisation',
        'Droits d\'utilisation',
        'afficher_metabox_droits_utilisation',
        'crm_documents',
        'advanced',
        'default'
    );add_meta_box(
        'metabox_variables',
        'Variables',
        'afficher_metabox_variables',
        'crm_documents',
        'advanced',
        'high'
    );

    add_meta_box(
        'metabox_racine_associes',
        'Racine et Associés',
        'afficher_metabox_racine_associes',
        'crm_documents',
        'normal',
        'high'
    );
    add_meta_box(
        'configuration_template',           
        'Configuration de la Template',     
        'afficher_metabox_configuration_template',  
        'crm_documents',                         
        'normal', 
        'high'                             
    );
}
add_action('add_meta_boxes', 'ajouter_metaboxes_crm_templates');
add_action('edit_form_after_title', function() {
    global $post, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'advanced', $post);
unset($wp_meta_boxes[get_post_type($post)]['advanced']);
},3,2);
// Metabox Variables
// Metabox pour afficher et gérer les variables
function afficher_metabox_variables($post) {
    wp_nonce_field('sauvegarder_template', 'template_nonce');
wp_enqueue_script(
        'crm-event-models',
        plugin_dir_url(__FILE__) . 'crm-event-models.js',
        array('jquery'),
        '1.0',
        true
    );
    wp_localize_script('crm-event-models', 'ajax_object', array(
        'ajax_url' => admin_url('admin-ajax.php')
    ));
    echo '<p><strong>Liste des variables Disponibles :</strong></p>';
    echo '<p>Les variables sélectionnées seront remplacées par les données de l\'utilisateur lors de la génération du document spécifique à un utilisateur.</p>';
    echo '<p>Cliquez sur le nom d\'une variable pour l\'insérer dans le modèle. Si vous souhaitez ajouter une nouvelle variable, cliquez sur "Ajouter".</p>';

    // Description des types de variables
    echo '<p><strong>Format des Variables :</strong></p>';
    echo '<ul>';
    echo '<li><strong>*</strong> : Indique que la variable est obligatoire et ne peut pas être vide.</li>';
    echo '<li><strong>@</strong> : Indique que la variable est un champ "texte long" avec une barre d\'édition riche (textarea).</li>';
    echo '<li><strong>|</strong> : Permet de définir un champ de type dropdown avec des choix spécifiques, séparés par des | (ex. {nom_variable|choix1|choix2|choix3}). La première valeur est le nom de la variable et les suivantes sont les options à afficher dans le dropdown.</li>';
    echo '<li><strong>#</strong> : Indique que la variable est un champ de type "date". Le format sera converti au format date de WordPress.</li>';
    echo '</ul>';
    echo '<p><strong>Exemples :</strong></p>';
    echo '<ul>';
    echo '<li><code>{nom_variable *}</code> : Un champ input obligatoire.</li>';
    echo '<li><code>{nom_variable *|choix1|choix2|choix3}</code> : Un champ dropdown avec des choix, et la variable est obligatoire.</li>';
    echo '<li><code>{nom_variable *@}</code> : Un champ de texte long (textarea) avec la variable obligatoire.</li>';
    echo '<li><code>{date_contrat#}</code> : Un champ de type date (facultatif) pour "date_contrat".</li>';
    echo '</ul>';
    $tags = [
        'template_name','document_name','user_status', 'display_name','display_author_name','display_author_bio', 'first_name', 'last_name', 'display_user_bio', 
        'wc_last_active', 'tax_no', 'user_mailing',  'shipping_first_name', 'shipping_last_name', 'shipping_company',
        'shipping_address_1', 'shipping_address_2', 'shipping_city', 'shipping_postcode',
        'shipping_country', 'shipping_state', 'shipping_phone', 'shipping_email',
        'reference_template', 'creation_date','billing_first_name', 'billing_last_name',
        'billing_company', 'billing_address_1', 'billing_address_2', 'billing_city',
        'billing_postcode', 'billing_country', 'billing_state', 'billing_phone',
        'billing_email','civilite','devis','facture','factures-echues' 
    ];
/**/
if (is_plugin_active('synexta-crm-don/synexta-crm-don.php')) {
    // Add donation-specific variables
    $donation_tags = [
        'don_ref', 'don_date', 'don_moyen', 'don_montant_nb', 'don_montant_txt', 'don_etat', 'don_etat','don_commentaire','est_annule'
    ];
    $tags = array_merge($tags, $donation_tags);
}
    $visible_tags = array_slice($tags, 0, 5);
    $hidden_tags = array_slice($tags, 5);

    echo '<div id="tags-container" class="tags-container">';
    foreach ($visible_tags as $tag) {
        echo "<span class='tag-item' data-tag='{$tag}'>{$tag}</span>";
    }
    echo '<span id="more-tags"class="more-tags-container" style="display: none;">';
    foreach ($hidden_tags as $tag) {
        echo "<span class='tag-item' data-tag='{$tag}'>{$tag}</span>";
    }
    echo '</span>';
    echo '<a href="#" id="show-more-tags">Afficher +</a>';
    echo '</div>';

    echo '<textarea name="variables_list" id="variables_list" rows="5" class="large-text" readonly hidden>';
    echo esc_textarea(json_encode([], JSON_PRETTY_PRINT));
    echo '</textarea>';

    echo '<p>Si une variable n\'est pas trouvée, vous pouvez l\'ajouter :</p>';
    echo '<button type="button" id="add_variable_button" class="button">Ajouter une Variable</button>';
    echo '<div id="variable_form" style="display:none; margin-top: 10px;">';
    echo '<p><strong>Nom de la variable :</strong> <input type="text" id="variable_name" class="regular-text"style="width:auto"></p>';
   // echo '<p><strong>Type de la variable :</strong> ';
    //echo '<select id="variable_type">';
    //echo '<option value="text">Texte</option>';
    //echo '<option value="number">Nombre</option>';
    //echo '<option value="date">Date</option>';
    //echo '</select></p>';
    echo '<button type="button" id="insert_variable" class="button">Ajouter</button>';
    echo '</div>';
}
function afficher_metabox_configuration_template($post) {
    // Sécurisation du formulaire
    wp_nonce_field('sauvegarder_configuration_template', 'configuration_template_nonce');

    // Nom de la metabox
    echo '<h3>Configuration de la Template</h3>';

    // Autoriser d'autres documents joints (par défaut décoché)
    $autoriser_documents = get_post_meta($post->ID, '_template_autorise_documents_joints', true);
    echo '<p><label for="autoriser_documents"><input type="checkbox" id="autoriser_documents" name="autoriser_documents" ' . checked($autoriser_documents, 'on', false) . '> Autoriser l’ajout de documents joints supplémentaires ?</label></p>';

    // Générer le PDF (par défaut coché)
    $generer_pdf = get_post_meta($post->ID, '_template_autorise_generation_pdf', true);
 
    $checked = (isset($generer_pdf) && $generer_pdf === 'on') ? 'checked' : '';

    echo '<p><label for="template_autorise_generation_pdf"><input type="checkbox" id="template_autorise_generation_pdf" name="template_autorise_generation_pdf" ' . $checked . '> Générer le PDF lors de la création du document ?</label></p>';
 // Générer le PDF (par défaut coché)
    $crm_document_default_template = get_option( 'crm_document_plugin_default_template');
    $is_default = false ;
    if($crm_document_default_template ==$post->ID){
        $is_default=true;

    }
    echo '<p><label for="default_template">
    <input type="checkbox" id="default_template"name="default_template" value="1" ' . checked($is_default, true, false) . ' /> 
    Définir comme modèle par défaut
</label></p>';


$departement_associe = get_post_meta($post->ID, '_template_associated_department_id', true);
$synchronisation_active = get_option('vosfactures_sync_enabled', false); 
$all_departments = []; 
$current_footers = get_footer_departments(); 
$used_departments = array_keys($current_footers);

if ($synchronisation_active == 'yes') {
    $departments_vf = get_option('_crm_vosfactures_departments', []);
    $departments_manual = get_option('_crm_departements_manuels', []);
    $all_departments = array_merge($departments_vf, $departments_manual);
} else {
    $all_departments = get_option('_crm_departements_manuels', []);
}

echo '<table class="form-table"><tbody>
<tr><th><label for="template_departement_id">Associer le model à un département :</label></th>';
echo '<td><select id="template_departement_id" name="template_departement_id">';
echo '<option value="">-- Aucun département --</option>';
foreach ($all_departments as $dept) {
    if(in_array($dept['id'],$used_departments)){
         $selected = ($departement_associe == $dept['id']) ? 'selected' : '';
    echo '<option value="' . esc_attr($dept['id']) . '" ' . $selected . '>' . esc_html($dept['nom_usage']) . '</option>';

    }
   }
echo '</select></td></tr></table>';
echo '<p style="margin-top: 0px; font-style: italic; color: #555;">
    Ce champ permet d\'associer ce modèle à un département spécifique. Le footer correspondant sera automatiquement ajouté dans le PDF généré. 
    Si aucun département n\'est sélectionné, le footer par défaut sera utilisé.
</p>';
}
// Metabox pour gérer les modèles associés
function afficher_metabox_racine_associes($post) {
    wp_nonce_field('sauvegarder_associes', 'associes_nonce');
    
    $racine = get_post_meta($post->ID, '_racine', true);
    $associes_list = get_post_meta($post->ID, '_associes_list', true);
    $associes_list = $associes_list ? json_decode($associes_list, true) : [];
    $current_version = get_post_meta($post->ID, '_template_version', true);
    $current_version = $current_version ? $current_version : 'version_' . date('d_m_Y') . '_0000';

    $expire_dans = get_post_meta($post->ID, '_template_expire_dans', true);
    $expire_dans = $expire_dans !== '' ? $expire_dans : 0;

    $associes = get_posts(['post_type' => 'crm_documents', 'numberposts' => -1]);
    
    echo '<table class="form-table">';
    echo '<tr>';
    echo '<th><label for="expire_dans">Expiration (en jours)</label></th>';
    echo '<td>';
    echo '<input type="number" id="expire_dans" name="expire_dans" value="' . esc_attr($expire_dans) . '" min="0" step="1">';
    echo '<p class="description">Définissez dans combien de jours ce template expirera. Par défaut : 0 (pas d\'expiration).</p>';
    echo '</td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th><label for="template_version">Version actuelle</label></th>';
    echo '<td><input type="text" id="template_version" value="' . esc_attr($current_version) . '" class="regular-text" readonly></td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th><label for="racine">Racine</label></th>';
    echo '<td><input type="text" name="racine" id="racine" value="' . esc_attr($racine) . '" class="regular-text"></td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th><label for="associes_list">Modèles Associés</label></th>';
    echo '<td>';
    echo '<div id="available-templates" style="margin-bottom: 10px; display:flex;flex-wrap:wrap;">';
    foreach ($associes as $associe) {
        if ($associe->ID != $post->ID) {
            echo "<span class='template-tag' data-id='{$associe->ID}'>{$associe->post_title}</span>";
        }
    }
    echo '</div>';
    echo '<div id="associated-templates" style="border: 1px dashed #ccc; padding: 10px; min-height: 40px;">';
    foreach ($associes_list as $id) {
        $associe = get_post($id);
        if ($associe) {
            echo "<span class='associated-template' data-id='{$associe->ID}'>{$associe->post_title} <span class='remove-template' style='color: red; cursor: pointer;'>×</span></span>";
        }
    }
    echo '</div>';
    echo '<input type="hidden" id="associes_list_input" name="associes_list" value="' . esc_attr(json_encode($associes_list)) . '">';
    echo '</td>';
    echo '</tr>';
    echo '</table>';
   
}
function afficher_metabox_droits_utilisation($post) {
    wp_nonce_field('sauvegarder_droits_utilisation', 'droits_utilisation_nonce');
    
    $roles_utilisateurs = wp_roles()->roles;
    $roles_selectionnes = get_post_meta($post->ID, '_template_roles_acces', true);
    $user_access = get_post_meta($post->ID, '_template_users_acces', true);
    $roles_selectionnes = $roles_selectionnes ? json_decode($roles_selectionnes, true) : ['responsable_crm','administrator','utilisateur_crm','prospect','customer','tiers'];
    
    echo '<table class="form-table">';
    echo '<tr>';
    echo '<th><label for="droits_utilisation">Droits d\'utilisation</label></th>';
    echo '<td>';
    echo '<p>Définissez qui peut utiliser ce modele en sélectionnant les rôles d\'utilisateur ci-dessous ( Tous les roles et type de fiches qui peuvent utiliser ce modele ):</p>';
    echo '<div id="available-roles"class="available-roles">';
    foreach ($roles_utilisateurs as $role_slug => $role_details) {
        if (!in_array($role_slug, $roles_selectionnes)) {
            
            echo "<span class='role-tag' data-role='{$role_slug}'>{$role_details['name']}</span>";
        }
    }
    echo '</div>';
    echo '<div id="selected-roles"class="selected-roles" >';
    foreach ($roles_selectionnes as $role_slug) {
        if (isset($roles_utilisateurs[$role_slug])) {
            echo "<span class='selected-role' data-role='{$role_slug}'>{$roles_utilisateurs[$role_slug]['name']} ";
            
                echo "<span class='remove-role' style='color: red; cursor: pointer;'>×</span>";
            
            echo "</span>";
        }
    }
    echo '</div>';
    echo '<input type="hidden" id="roles_utilisation_input" name="roles_utilisation" value="' . esc_attr(json_encode($roles_selectionnes)) . '">';
    echo '</td>';
    echo '</tr>';
    echo '<tr><th><label> Associé l\'évènement généré par ce model à des utilisateurs crm </label></th><td><label for="autoriser_user_access"><input type="checkbox" id="autoriser_user_access" name="autoriser_user_access" ' . checked($user_access, 'on', false) . '> Autoriser</label></td></tr>';

    echo '</table>';
}

// Sauvegarde des métadonnées
function sauvegarder_metadonnees($post_id) {
    if (!isset($_POST['template_nonce']) || !wp_verify_nonce($_POST['template_nonce'], 'sauvegarder_template')) {
        return;
    }
    if (!isset($_POST['associes_nonce']) || !wp_verify_nonce($_POST['associes_nonce'], 'sauvegarder_associes')) {
        return;
    }
    if (!isset($_POST['droits_utilisation_nonce']) || !wp_verify_nonce($_POST['droits_utilisation_nonce'], 'sauvegarder_droits_utilisation')) {
        return;
    }
    if (!isset($_POST['configuration_template_nonce']) || !wp_verify_nonce($_POST['configuration_template_nonce'], 'sauvegarder_configuration_template')) {
        return ;
    }/**/

    if (isset($_POST['template_departement_id'])) {
        update_post_meta($post_id, '_template_associated_department_id', $_POST['template_departement_id']);
    }
    //$racine=sanitize_text_field($_POST['racine']);
    
        $racine = !empty($_POST['racine'])?$_POST['racine']:sanitize_title($_POST['post_title']);  // 
        update_post_meta($post_id, '_racine', $racine);  //
    
        if (isset($_POST['expire_dans'])) {
            $expire_dans = intval($_POST['expire_dans']);
            update_post_meta($post_id, '_template_expire_dans', $expire_dans);
        }
            update_post_meta($post_id, '_associes_list', json_encode(array_map('intval', json_decode(stripslashes($_POST['associes_list']), true))));
            

        $current_version = get_post_meta($post_id, '_template_version', true);
        $current_version = $current_version ?: 'version_' . date('d_m_Y') . '_0000';

        // Extraire la partie de la version (jj, mm, aaaa) et le compteur (0000)
        preg_match('/version_(\d{2})_(\d{2})_(\d{4})_(\d{4})/', $current_version, $matches);

        if (!empty($matches)) {
            // Reconstruire la date à partir des matches
            $version_date = "{$matches[1]}_{$matches[2]}_{$matches[3]}";
            $current_count = (int)$matches[4];

            $current_date = date('d_m_Y');

            // Comparer les dates pour réinitialiser ou incrémenter le compteur
            if ($version_date !== $current_date) {
                $new_version = 'version_' . $current_date . '_0001';
            } else {
                $current_count++;
                $new_version = 'version_' . $current_date . '_' . str_pad($current_count, 4, '0', STR_PAD_LEFT);
            }
        } else {
            // Si la version actuelle n'est pas valide, définir une version initiale
            $new_version = 'version_' . date('d_m_Y') . '_0001';
        }
        if (isset($_POST['autoriser_documents'])) {
            update_post_meta($post_id, '_template_autorise_documents_joints', 'on');
        } else {
            update_post_meta($post_id, '_template_autorise_documents_joints', 'off');
        }
    
        if (isset($_POST['default_template']) && $_POST['default_template'] == '1') {
            update_option('crm_document_plugin_default_template', $post_id);
        }
        if (isset($_POST['template_autorise_generation_pdf'])) {
            update_post_meta($post_id, '_template_autorise_generation_pdf', 'on');
        } else {
            update_post_meta($post_id, '_template_autorise_generation_pdf', 'off');
        }

        // Mettre à jour la version dans le post_meta
        update_post_meta($post_id, '_template_version', $new_version);
        // Sauvegarder les rôles sélectionnés
        if (isset($_POST['roles_utilisation'])) {
            $roles_utilisation = array_map('sanitize_text_field', json_decode(stripslashes($_POST['roles_utilisation']), true));
            update_post_meta($post_id, '_template_roles_acces', json_encode($roles_utilisation));
        }
        if($_POST['autoriser_user_access']){
            update_post_meta($post_id, '_template_users_acces', $_POST['autoriser_user_access']);
        }
}
add_action('save_post', 'sauvegarder_metadonnees');
// Ajouter la metabox pour les droits d'utilisation


// Sauvegarder les droits d'utilisation




function charger_scripts_crm_templates() {
    
}
add_action('admin_enqueue_scripts', 'charger_scripts_crm_templates');

function disable_autosave_for_specific_post_type() {
    global $post;
    if (isset($post) && ($post->post_type === 'crm_documents'||$post->post_type === 'crm_docs_gen')) {
        wp_deregister_script('autosave');
    }
}
add_action('admin_enqueue_scripts', 'disable_autosave_for_specific_post_type');



add_action('before_delete_post', 'delete_default_option_on_post_delete');

function delete_default_option_on_post_delete($post_id) {
    $post_type = get_post_type($post_id);

    if ($post_type === 'crm_documents') {
        $default_template_id = get_option('crm_document_plugin_default_template');

        if ($default_template_id == $post_id) {
            update_option('crm_document_plugin_default_template', '');
           // delete_option('crm_document_plugin_default_template');
        }
    }
}