document.addEventListener("DOMContentLoaded", function() {
    const availableTemplates = document.querySelectorAll(".template-tag");
    const associatedTemplatesContainer = document.getElementById("associated-templates");
    const associesInput = document.getElementById("associes_list_input");

    // Fonction pour mettre à jour le champ caché avec les IDs des templates associés
    function updateAssociesInput() {
        const associatedTemplates = document.querySelectorAll(".associated-template");
        const ids = Array.from(associatedTemplates).map(template => template.dataset.id);
        associesInput.value = JSON.stringify(ids);
    }

    // Gérer le clic sur les tags disponibles pour les associer
    availableTemplates.forEach(template => {
        template.addEventListener("click", function() {
            const id = this.dataset.id;
            const name = this.textContent.trim();

            // Vérifier si le template est déjà associé
            if (document.querySelector(`.associated-template[data-id="${id}"]`)) {
                return;
            }

            // Ajouter le tag dans les associés
            const tag = document.createElement("span");
            tag.classList.add("associated-template");
            tag.dataset.id = id;
            tag.style.margin = "5px";
            tag.style.padding = "5px 10px";
            tag.style.background = "#d0f0d0";
            tag.style.border = "1px solid #8bc34a";
            tag.style.cursor = "pointer";
            tag.innerHTML = `${name} <span class="remove-template" style="color: red; cursor: pointer;">×</span>`;

            associatedTemplatesContainer.appendChild(tag);
            updateAssociesInput();

            // Ajouter l'événement de suppression
            const removeButton = tag.querySelector(".remove-template");
            removeButton.addEventListener("click", function() {
                tag.remove();
                updateAssociesInput();
            });
        });
    });

    // Gérer la suppression des tags associés
    const associatedTemplates = document.querySelectorAll(".associated-template");
    associatedTemplates.forEach(template => {
        const removeButton = template.querySelector(".remove-template");
        removeButton.addEventListener("click", function() {
            template.remove();
            updateAssociesInput();
        });
    });
    //////////////////
    const showMoreLink = document.getElementById("show-more-tags");
    const moreTags = document.getElementById("more-tags");

    if (showMoreLink) {
        showMoreLink.addEventListener("click", function(event) {
            event.preventDefault();
            moreTags.style.display = moreTags.style.display === "none" ? "flex" : "none";
            this.textContent = moreTags.style.display === "none" ? "Afficher +" : "Afficher -";
        });
    }

    const tags = document.querySelectorAll(".tag-item");
    const variablesListTextarea = document.getElementById("variables_list");
    const addVariableButton = document.getElementById("add_variable_button");
    const variableForm = document.getElementById("variable_form");
    const variableNameInput = document.getElementById("variable_name");
    //const variableTypeSelect = document.getElementById("variable_type");
    const insertVariableButton = document.getElementById("insert_variable");

    tags.forEach(tag => {
        tag.addEventListener("click", function() {
            const variableName = this.dataset.tag;
            let variables = JSON.parse(variablesListTextarea.value || "[]");
            if (!variables.find(v => v.name === variableName)) {
                variables.push({ name: variableName, type: "text" });
                variablesListTextarea.value = JSON.stringify(variables, null, 2);

                if (window.tinymce && tinymce.activeEditor) {
                    tinymce.activeEditor.execCommand("mceInsertContent", false, `{${variableName}}`);
                }
            }
        });
    });

    addVariableButton.addEventListener("click", function() {
        variableForm.style.display = variableForm.style.display === "none" ? "block" : "none";
    });

    insertVariableButton.addEventListener("click", function() {
        const variableName = variableNameInput.value.trim();
        //const variableType = variableTypeSelect.value;
        if (!variableName) {
            alert("Le nom de la variable est requis.");
            return;
        }

        let variables = JSON.parse(variablesListTextarea.value || "[]");
        variables.push(variableName);
        variablesListTextarea.value = JSON.stringify(variables, null, 2);

        if (window.tinymce && tinymce.activeEditor) {
            tinymce.activeEditor.execCommand("mceInsertContent", false, `{${variableName}}`);
        }

        variableNameInput.value = "";
        //variableTypeSelect.value = "text";
        variableForm.style.display = "none";
    });
    //////////////////////
    const availableRoles = document.getElementById('available-roles');
    const selectedRoles = document.getElementById('selected-roles');
    const rolesInput = document.getElementById('roles_utilisation_input');

    availableRoles.addEventListener('click', function(e) {
        if (e.target.classList.contains('role-tag')) {
            const role = e.target.dataset.role;
            const roleName = e.target.textContent;

            // Ajouter le rôle sélectionné
            const roleElement = document.createElement('span');
            roleElement.classList.add('selected-role');
            roleElement.dataset.role = role;
            roleElement.innerHTML = `${roleName} <span class="remove-role" style="color: red; cursor: pointer;">×</span>`;
            selectedRoles.appendChild(roleElement);

            // Retirer le tag du rôle sélectionné
            e.target.remove();

            // Mettre à jour les données dans l'input caché
            mettreAJourRoles();
        }
    });

    selectedRoles.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-role')) {
            const parent = e.target.parentElement;
            const role = parent.dataset.role;
            const roleName = parent.textContent.replace('×', '').trim();

            // Ajouter le tag du rôle dans la liste disponible
            const roleTag = document.createElement('span');
            roleTag.classList.add('role-tag');
            roleTag.dataset.role = role;
            roleTag.textContent = roleName;
            availableRoles.appendChild(roleTag);

            parent.remove();

            mettreAJourRoles();
        }
    });

    function mettreAJourRoles() {
        const roles = [];
        selectedRoles.querySelectorAll('.selected-role').forEach(role => {
            roles.push(role.dataset.role);
        });
        rolesInput.value = JSON.stringify(roles);
    }
    ///////////////
});