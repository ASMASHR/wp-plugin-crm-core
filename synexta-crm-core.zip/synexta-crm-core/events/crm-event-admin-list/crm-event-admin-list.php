<?php
// Enregistrement du type de post personnalisé
function register_crm_events_generes_post_type() {
    register_post_type('crm_docs_gen', [ 
        'labels' => [
            'name'               => 'Événements',
            'singular_name'      => 'événement',
            'add_new'            => 'Générer un événement',
            'add_new_item'       => 'Générer un événement',
            'edit_item'          => 'Modifier l\'événement',
            'new_item'           => 'Nouveau événement',
            'view_item'          => 'Voir l\'événement',
            'search_items'       => 'Rechercher des Événements',
            'not_found'          => 'Aucun événement trouvé',
            'not_found_in_trash' => 'Aucun événement trouvé dans la Corbeille',
        ],
        'public'        => false,
        'show_ui'       => true,
        'has_archive'   => false,
        'menu_icon'     => 'dashicons-media-text',
        'supports'      => ['title', 'editor'],
        'rewrite'       => true,
        'show_in_menu'       => 'crm-dashboard',
        'capabilities'  => [
            'create_posts' => 'do_not_allow', 
        ],
        'map_meta_cap' => true, 
    
    ]);
}
add_action('init', 'register_crm_events_generes_post_type');
function crm_docs_gen_columns($columns) {
    // Supprimer les colonnes non nécessaires
    unset($columns['date']);
    
    // Ajouter des colonnes personnalisées
    $columns['tiers_associe'] = 'Tiers associé';
    $columns['expire_dans']   = 'Expire le';
    $columns['cree_le']       = 'Créé le';
    $columns['taille']        = 'Taille';

    return $columns;
}
add_filter('manage_crm_docs_gen_posts_columns', 'crm_docs_gen_columns');

// Remplir les colonnes personnalisées
function crm_docs_gen_custom_column($column, $post_id) {
    switch ($column) {
        case 'tiers_associe':
            // Récupérer la valeur du champ personnalisé ou autre logique

            //$tiers_associe = get_post_meta($post_id, '_generated_event_user_id', true);

            $eventUserId = get_post_meta($post_id, '_generated_event_user_id', true);
            $tiers_associe = !empty($eventUserId) ? $eventUserId : get_post_meta($post_id, '_generated_doc_user_id', true);
            if ($tiers_associe) {
                $user = get_userdata($tiers_associe);
            
                if ($user) {
                    $first_name = get_user_meta($tiers_associe, 'first_name', true);
                    $last_name = get_user_meta($tiers_associe, 'last_name', true);
                    $nom_societe = get_user_meta($tiers_associe, 'billing_company', true);
            
                    // Combine les informations utilisateur !empty($nom_societe) ? $nom_societe :
                    $prenom_nom = trim($last_name . ' ' . $first_name);
                    $entreprise_affichee = $nom_societe ?$nom_societe:($prenom_nom ?:$user->display_name) ;
            
                    // Affiche le résultat
                    echo esc_html($entreprise_affichee);
                } else {
                    echo 'Utilisateur introuvable';
                }
            } else {
                echo '—';
            }
            break;
            
            case 'expire_dans':
                $expiration_date = get_post_meta($post_id, '_generated_event_expiration_date', true);
                $today = date('Y-m-d'); // Récupère la date d'aujourd'hui en format Y-m-d
            
                if ($expiration_date) {
                    if ($expiration_date < $today) {
                        echo 'Expiré le ' . date_i18n('d/m/Y', strtotime($expiration_date));
                    } else {
                        echo date_i18n('d/m/Y', strtotime($expiration_date));
                    }
                } else {
                    echo 'Jamais';
                }
                break;
            

        case 'cree_le':
            // Afficher la date de création
            echo format_date_wp(get_the_date('', $post_id));
            break;

        case 'taille':
            $file_url = get_post_meta($post_id, '_pdf_url', true);
            if ($file_url) {
                 $file_path = str_replace(site_url('/'), ABSPATH, $file_url);
                $upload_dir = wp_upload_dir();
        
                $file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $file_url);
                $file_path = realpath($file_path);

               
                if (file_exists($file_path)) {
                    $file_size = filesize($file_path);
                    echo size_format($file_size);
                } else {
                    echo 'Fichier introuvable';
                }
            } else {
                echo '—';
            }
            break;
    }
}
add_action('manage_crm_docs_gen_posts_custom_column', 'crm_docs_gen_custom_column', 10, 2);
add_action('restrict_manage_posts', function() {
    global $typenow;
    if ($typenow !== 'crm_docs_gen') {
        return;
    }

    global $wpdb;
    $user_ids = $wpdb->get_col("
        SELECT DISTINCT meta_value FROM $wpdb->postmeta
        WHERE meta_key IN ('_generated_event_user_id', '_generated_doc_user_id')
        AND meta_value != ''
    ");

    $user_ids = array_filter(array_unique($user_ids));

    if (!empty($user_ids)) {
        echo '<select name="filtre_tiers_associe">';
        echo '<option value="">— Filtrer par Tiers associé —</option>';

        foreach ($user_ids as $user_id) {
            $user = get_userdata($user_id);
            if ($user) {
                $first_name = get_user_meta($user_id, 'first_name', true);
                $last_name = get_user_meta($user_id, 'last_name', true);
                $nom_societe = get_user_meta($user_id, 'billing_company', true);
                $prenom_nom = trim($last_name . ' ' . $first_name);
                $label = !empty($nom_societe) ? $nom_societe : ($prenom_nom ?: $user->display_name);

                $selected = (isset($_GET['filtre_tiers_associe']) && $_GET['filtre_tiers_associe'] == $user_id) ? 'selected="selected"' : '';
                echo '<option value="' . esc_attr($user_id) . '" ' . $selected . '>' . esc_html($label) . '</option>';
            }
        }

        echo '</select>';
    }
});

// 3️⃣ AJOUT ICI ➡️ MODIFIER la requête pour filtrer
add_action('pre_get_posts', function($query) {
    if (is_admin() && $query->is_main_query() && $query->get('post_type') === 'crm_docs_gen') {
        if (!empty($_GET['filtre_tiers_associe'])) {
            $user_id = intval($_GET['filtre_tiers_associe']);
            $meta_query = [
                'relation' => 'OR',
                [
                    'key'     => '_generated_event_user_id',
                    'value'   => $user_id,
                    'compare' => '='
                ],
                [
                    'key'     => '_generated_doc_user_id',
                    'value'   => $user_id,
                    'compare' => '='
                ]
            ];
            $query->set('meta_query', $meta_query);
        }
    }
});

// Rendre les colonnes triables si nécessaire

add_filter('manage_edit-crm_docs_gen_sortable_columns', function($columns) {
    $columns['tiers_associe'] = 'tiers_associe';
    $columns['expire_dans'] = 'expire_dans';
    $columns['cree_le'] = 'date';
    $columns['taille'] = 'taille';
    return $columns;
});
add_action('pre_get_posts', function($query) {
    if (!is_admin() || !$query->is_main_query()) {
        return;
    }

    if ('expire_dans' === $query->get('orderby')) {
        // Trier par le champ _generated_event_expiration_timestamp
        $query->set('meta_key', '_generated_event_expiration_date_timestamp');
        $query->set('orderby', 'meta_value_num');
    }
});
// Ajouter les metaboxes
function ajouter_metaboxes_crm_events_generes() {
    add_meta_box(
        'metabox_info_document',
        'Information sur la document',
        'afficher_metabox_info_doc',
        'crm_docs_gen',
        'advanced',
        'high'
    );
}
add_action('add_meta_boxes', 'ajouter_metaboxes_crm_events_generes');

function afficher_metabox_info_doc($post) {
    //$users = get_users();
    $args = array(
        //'role__in' => array('prospect', 'customer', 'tiers'),
        'meta_query' => array(
            'relation' => 'OR', 
            array(
                'key' => 'user_status',
                'value' => 'ACTIF',
                'compare' => '='
            ),
            array(
                'key' => 'user_status',
                'value' => 'actif',
                'compare' => '='
            ),
            array(
                'key' => 'user_status',
                'value' => 'active',
                'compare' => '=',
            ),
        ),
        'fields' => array('ID', 'user_login', 'billing_first_name', 'billing_last_name', 'billing_address_1', 'billing_postcode', 'billing_city', 'billing_country', 'billing_phone', 'user_email'),
    );
    $users = get_users($args);
    $post_id = $post->ID;

    // Récupérer les métadonnées 
    $userId = get_post_meta($post_id, '_generated_event_user_id', true);
    $templateId = get_post_meta($post_id, '_used_template_id', true);
    $templateVersion = get_post_meta($post_id, '_used_template_version', true);
    $documentsIds = get_post_meta($post_id, '_documents_associes_list', true);
    //$documentsIds = $documentsIds ? json_decode($documentsIds, true) : [];
            
    $variablesdocument = get_post_meta($post_id, '_generated_event_vars', true);
    $template_associes= $templateId?get_post_meta($templateId, '_associes_list', true):null;

     $template_associes = $template_associes ? json_decode($template_associes, true) : [];
    $templates = get_posts([
        'post_type' => 'crm_events',
        'numberposts' => -1,
        'post_status' => 'publish',
    ]);
    ?>
    <div class="metabox_info_document">
        <div class="user_select_container">
            <label for="user_select">Associé à :</label>
            <select id="user_select" name="user_select" <?php echo $userId ? 'disabled' : ''; ?>>
                <?php foreach ($users as $user): 
                     $nom_societe =get_user_meta($user->ID, 'billing_company', true);
                     $first_name =get_user_meta($user->ID, 'billing_first_name', true);
                     $last_name = get_user_meta($user->ID, 'billing_last_name', true);
                    
                     $prenom_nom=$last_name .' '.$first_name;
                     $entreprise_affichee = !empty($nom_societe) ? $nom_societe :( $user->display_name?$user->display_name:$prenom_nom);
         
         ?>
                    <option value="<?php echo esc_attr($user->ID); ?>" <?php selected($userId, $user->ID); ?>>
                        <?php echo esc_html($entreprise_affichee); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="template_vars_container">
            <div class="template_select_container">
                <label for="template_select">Modèle utilisé :</label>
                <select id="template_select" name="template_select" <?php echo $templateId ? 'disabled' : ''; ?>>
                    <?php foreach ($templates as $template): ?>
                        <option value="<?php echo esc_attr($template->ID); ?>" <?php selected($templateId, $template->ID); ?>>
                            <?php echo esc_html($template->post_title); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div id="templates-list-error"></div>
                    </div>
        <div class="template_version_container"style="<?php echo $templateVersion ? 'display: flex;' : 'display: none;'; ?>">
            <label for="template_version">Version du Modèle :</label>
            <input type="text" id="template_version" name="template_version" value="<?php echo esc_attr($templateVersion); ?>"disabled >
        </div>          
        <?php 
        if (!empty($documentsIds)) : ?>
            <div id="">
            <p>Liste des évènements associés générés :<small> (Evènements générés basés sur le template associé).</small></p>
                <?php
                foreach($documentsIds as $id){
                    $post_title = get_the_title($id);
                    $edit_link = get_edit_post_link($id);
                    echo '<a href="' . esc_url($edit_link) . '">' . esc_html($post_title) . '</a><br>';
                }
                ?>
            </div>
        <?php endif; ?>
</div>

    <?php
}





add_action('before_delete_post', 'delete_attachments_on_post_delete');

function delete_attachments_on_post_delete($post_id) {
    $upload_dir = wp_upload_dir();
    $base_dir = $upload_dir['basedir'];
    $base_url = $upload_dir['baseurl'];

    // Suppression du fichier PDF principal
    $pdf_url = get_post_meta($post_id, '_pdf_url', true);
    if (!empty($pdf_url)) {
        $file_path = str_replace($base_url, $base_dir, $pdf_url);
        if (file_exists($file_path)) {
            unlink($file_path); 
        }
        delete_post_meta($post_id, '_pdf_url'); 
    }

    $generated_event_pieces_joints = get_post_meta($post_id, '_generated_event_pieces_joints', true);
    if (!empty($generated_event_pieces_joints) && is_array($generated_event_pieces_joints)) {
        foreach ($generated_event_pieces_joints as $doc_url) {
            $doc_path = str_replace($base_url, $base_dir, $doc_url);
            if (file_exists($doc_path)) {
                unlink($doc_path); 
            }
        }
        delete_post_meta($post_id, '_generated_event_pieces_joints'); 
    }
}

function make_crm_docs_gen_readonly() {
    global $post;

    if ($post && $post->post_type === 'crm_docs_gen') {
        ?>
        <style>
            #poststuff input[type="text"],
            #poststuff textarea,
            #poststuff select,
            .acf-input input,
            .acf-input textarea,
            .acf-input select {
                pointer-events: none;
                background-color: #f5f5f5; 
            }

            .wp-editor-container textarea {
                pointer-events: none;
                background-color: #f5f5f5;
            }

            #poststuff button,
            #poststuff .button,
            #poststuff .button-primary,
            #poststuff .button-secondary {
                pointer-events: none;
                opacity: 0.5;
            }

            #submitdiv .inside {
                pointer-events: none;
                opacity: 0.5;
            }
            .page-title-action{
                display: none;
            }
        </style>
        <script>
            jQuery(document).ready(function($) {
                if (typeof tinymce !== 'undefined') {
                    tinymce.activeEditor.setMode('readonly');
                }

                $('#publish').prop('disabled', true).css('opacity', 0.5);
            });
        </script>
        <?php
    }
}
add_action('admin_head', 'make_crm_docs_gen_readonly');
