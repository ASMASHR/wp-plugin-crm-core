<?php

function crm_events_tags_config() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_event_tags';
    $tags = $wpdb->get_results("SELECT * FROM $table_name");
    ?>
    <div class="wrap">
        <h1>Gestion des Tags</h1>
        <button id="add-tag-btn" class="add-tag-btn button button-primary"><i class="dashicons dashicons-plus"></i> Ajouter un Tag</button>
        <!-- CodeMirror CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/theme/dracula.min.css">

        <!-- CodeMirror JS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/css/css.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/edit/matchbrackets.min.js"></script>

        <div id="tag-form-container" class="tag-form-container hidden">
            <form id="tag-form" class="tag-form"novalidate>
                <h2 id="tag-form-title">Ajouter un Tag</h2>
                <input type="hidden" id="tag_id" name="id">
                <div class="form-group">
                    <label for="tag_name">Nom du Tag :</label>
                    <input type="text" id="tag_name" name="name" placeholder="Nom du tag" required>
                </div>
                <div class="form-group">
                    <label for="tag_status">État :</label>
                    <select id="tag_status" name="status" class="widefat">
                        <option value="1" selected>Actif</option>
                        <option value="0">Inactif</option>
                    </select>
                </div>
                <div class="form-group">
                <label for="tag_style">Style :</label>
                <div style="width: 71%;">
                    
                <textarea id="tag_style" name="style"></textarea>
                </div>
                </div>
                <div id="tag_form_msg"class="notice"></div>
                <div class="form-actions">
                    <button id="cancel-tag-btn" class="button">Annuler</button>
                    <button type="submit" id="save-tag-btn" class="button button-primary">Enregistrer</button>
                </div>
            </form>
        </div>

        <h2>Liste des Tags</h2>
        <div class="filters">
            <input type="text" id="filter-title" class="widefat" placeholder="Rechercher par titre">
            <select id="filter-status" class="widefat">
                <option value="">Tous</option>
                <option value="1">Actif</option>
                <option value="0">Inactif</option>
            </select>
        </div>
        <div id="tag_table_msg"></div>
        <table class="widefat">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>État</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="tag-list">
                <?php foreach ($tags as $tag) : ?>
                    <tr>
                        <td><span style="<?php echo $tag->tag_style; ?>"><?php echo esc_html($tag->tag_name); ?></span></td>
                        <td><?php echo $tag->status ? 'Actif' : 'Inactif'; ?></td>
                        <td>
                            <button class="button edit-tag" data-id="<?php echo $tag->id; ?>" data-name="<?php echo esc_attr($tag->tag_name); ?>"data-style="<?php echo esc_attr($tag->tag_style); ?>" data-status="<?php echo $tag->status; ?>">
                                <i class="dashicons dashicons-edit"></i>
                            </button>
                            <button class="button delete-tag" data-id="<?php echo $tag->id; ?>">
                                <i class="dashicons dashicons-trash"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script>
        jQuery(document).ready(function($) {
    var editor = CodeMirror.fromTextArea(document.getElementById("tag_style"), {
        mode: "css",
        autocorrect: true
            //theme: "dracula",
            // lineNumbers: true,
            // matchBrackets: true
    });
                const urlParams = new URLSearchParams(window.location.search);
                const tab = urlParams.get('tab');

                if (tab && tab=="configuration-event-tags") {
   
                $('.nav-tab').removeClass('nav-tab-active');
                    $('.nav-tab[href=\"#tab-documents\"]').addClass('nav-tab-active');
                    $('.tab-content').hide();
                    $('#tab-documents').show();
            
                    $('.custom-tab-event').removeClass('active');
                    $('.custom-tab-event-content').hide();
                    $('.custom-tab-event[href=\"#configuration-event-tags\"]').addClass('active');
                    $('#configuration-event-tags').show();
                    const url = new URL(window.location.href);
                    url.searchParams.delete('tab');
                    window.history.replaceState({}, document.title, url.toString());
   
    }
                
                


    $('#add-tag-btn').click(function() {
        $('#tag_id').val('');
        $('#tag_name').val('');
        $('#tag_style').val('');
        $('#tag_status').val('1');
        $('#tag-form-title').text('Ajouter un Tag');
        $('#tag-form-container').slideDown();
        editor.setValue('');
        $('#tag_form_msg').text('');
    });

    $('#cancel-tag-btn').click(function() {
        $('#tag-form-container').slideUp();
    });

    $('#filter-title, #filter-status').on('input change', function() {
        let title = $('#filter-title').val().toLowerCase();
        let status = $('#filter-status').val();

        $('#tag-list tr').each(function() {
            let tagName = $(this).find('td:nth-child(2)').text().toLowerCase();
            let tagStatus = $(this).find('td:nth-child(3)').text().includes('Actif') ? '1' : '0';

            console.log('dd', tagStatus)
            if ((title === '' || tagName.includes(title)) && (status === '' || status === tagStatus)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    $('#tag-form').submit(function(e) {
        e.preventDefault();
        $('#tag_form_msg').text('');
        let tagId = $('#tag_id').val();
        let tagName = $('#tag_name').val();
        let tagStatus = $('#tag_status').val();
        let tagStyle = editor.getValue();

        if (tagName === '' || tagStyle == "") {
            $('#tag_form_msg').text('Le nom du tag et le style sont requis.').addClass("notice-error").removeClass("notice-success").slideDown();
            return;
        }
        if (tagName.includes(',')) {
            $('#tag_form_msg').text('Le nom du tag ne doit pas contenir de virgule. Veuillez choisir un autre nom.').removeClass("notice-success").addClass("notice-error").slideDown();
            return;
        }
        $('#save-tag-btn').prop('disabled', true);

        $.post(ajax_object.ajax_url, { action: "crm_save_tag", id: tagId, name: tagName, status: tagStatus, tagStyle: tagStyle }, function(response) {
            if (response.success) {
                $('#tag_form_msg').text(response.data.message).addClass("notice-success").removeClass("notice-error").slideDown().delay(1500).fadeOut(function() {
                    const url = new URL(window.location.href);
                                url.searchParams.set('tab', 'configuration-event-tags');
                                window.location.href = url.toString();
                                
                });
            } else {
                $('#tag_form_msg').text(response.data.message).addClass("notice-error").slideDown();
                $('#save-tag-btn').prop('disabled', false);
            }
        });
    });

    $(document).on('click', '.edit-tag', function() {
        editor.setValue('');
        let previewtimer = null;
        $('#tag_id').val($(this).data('id'));
        $('#tag_name').val($(this).data('name'));
        $('#tag_status').val($(this).data('status'));
        let tagStyle = $(this).data('style');
        //editor.setValue(tagStyle).trigger('focus');
        clearTimeout(previewtimer);
        previewtimer = setTimeout(function() {
            editor.getDoc().setValue(tagStyle);
        }, 100);
        $('#tag-form-title').text('Modifier le Tag');
        $('#tag-form-container').slideDown();
    });

    $(document).on('click', '.delete-tag', function() {
        if (!confirm('Voulez-vous vraiment supprimer ce tag ?')) return;
        let tagId = $(this).data('id');
        $.post(ajax_object.ajax_url, { action: "crm_delete_tag", id: tagId }, function(response) {
            if (response.success) {
                $('#tag_table_msg').text(response.data.message).addClass("notice-success").fadeIn().delay(1500).fadeOut(function() {
                    
                                const url = new URL(window.location.href);
                                url.searchParams.set('tab', 'configuration-event-tags');
                                window.location.href = url.toString();
                                                    // location.reload()
                          
                            
                });
            } else {
                $('#tag_table_msg').text(response.data.message).addClass("notice-error");
            }
        });
    });
    //gestion des footers

});
    </script>
    <?php
}




function crm_save_tag() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_event_tags';

    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $name = sanitize_text_field($_POST['name']);
    $status = intval($_POST['status']);
    $tagStyle = $_POST['tagStyle'];

    if (!$name) {
        wp_send_json_error(['message' => 'Le nom du tag est requis.']);
    }

    $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE tag_name = %s AND id != %d", $name, $id));
    if ($exists) {
        wp_send_json_error(['message' => 'Ce tag existe déjà.']);
    }

    if ($id) {
        $wpdb->update($table_name, ['tag_name' => $name, 'status' => $status,'tag_style'=>$tagStyle], ['id' => $id]);
        wp_send_json_success(['message' => 'Tag mis à jour.']);
    } else {
        $wpdb->insert($table_name, ['tag_name' => $name, 'status' => $status,'tag_style'=>$tagStyle]);
        wp_send_json_success(['message' => 'Tag ajouté avec succès.']);
    }
}
add_action('wp_ajax_crm_save_tag', 'crm_save_tag');


function crm_delete_tag() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_event_tags';

    $id = intval($_POST['id']);
    
    // Suppression du tag dans la table des tags crm_documents
    $deleted = $wpdb->delete($table_name, ['id' => $id]);

    if ($deleted) {
        // Récupérer tous les posts de type ' crm_docs_gen'
        $args = array(
            'post_type'      => 'crm_docs_gen',
            'posts_per_page' => -1,
            'post_status'    => 'any',
        );
        $query = new WP_Query($args);

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $document_id = get_the_ID();

                $generated_doc_tags = get_post_meta($document_id, '_generated_doc_tags', true);

                if (!empty($generated_doc_tags) && is_array($generated_doc_tags)) {
                    if (($key = array_search($id, $generated_doc_tags)) !== false) {
                        unset($generated_doc_tags[$key]);

                        $generated_doc_tags = array_values($generated_doc_tags);

                        update_post_meta($document_id, '_generated_doc_tags', $generated_doc_tags);
                    }
                }
            }
        }
        //wp_reset_postdata();et mis à jour dans les documents

        wp_send_json_success(['message' => 'Tag supprimé avec succes.']);
    } else {
        wp_send_json_error(['message' => 'Erreur lors de la suppression du tag.']);
    }
}
add_action('wp_ajax_crm_delete_tag', 'crm_delete_tag');
