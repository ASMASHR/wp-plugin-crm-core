<?php


function get_footer_departments() {
    return get_option('_crm_footer_departments', []);
}

add_action('wp_ajax_sauvegarder_footer', function () {
 

    $id = sanitize_text_field($_POST['departement'] ?? '');
    $content = wp_kses_post($_POST['contenu'] ?? '');

    $footers = get_option('_crm_footer_departments', []);
    $footers[$id] = $content;

    update_option('_crm_footer_departments', $footers);

    wp_send_json_success(['message' => "Footer enregistré avec succès."]);
});

add_action('wp_ajax_crm_delete_footer', function () {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => "Non autorisé."]);
    }

    $id = sanitize_text_field($_POST['id'] ?? '');

    $footers = get_option('_crm_footer_departments', []);
    //wp_send_json_error([$footers]);
  
    if (!isset($footers[$id])) {
        wp_send_json_error(['message' => "Le footer pour ce département n'existe pas."]);
    }

    unset($footers[$id]);
    update_option('_crm_footer_departments', $footers);

    wp_send_json_success(['message' => "Footer supprimé avec succès."]);
});
function crm_events_departements_config(){
    $emails_style = get_option('crm_event_emails_style', ''); 
    $synchronisation_active = get_option('vosfactures_sync_enabled', false); 
    $all_departments = []; 
    $current_footers = get_footer_departments(); 
    $used_departments = array_keys($current_footers);
    

    if ($synchronisation_active == 'yes') {
        $departments_vf = get_option('_crm_vosfactures_departments', []);
        $departments_manual = get_option('_crm_departements_manuels', []);
        $all_departments = array_merge($departments_vf, $departments_manual);
    } else {
        $all_departments = get_option('_crm_departements_manuels', []);
    }
    ?>
    <div class="wrap">
        <h2>Gestion des Footer de PDF par Entité d’émission</h2>
        <p class="description">
        Cette section permet d’associer un footer personnalisé à chaque entité d’émission (ou département dans vosfactures). Lors de la génération des PDF liés à des événements basés sur un modèle, le footer du département associé sera utilisé.  <br>
            <strong>Important :</strong> Si un modèle n’est pas rattaché à un département, le système utilisera le footer par défaut. Veuillez donc définir au moins un footer par défaut pour éviter les erreurs.

        </p>
        <p id="dep_footer_table_msg"class="notice"></p>
        <button id="btn-ajouter-footer" class="button button-secondary" style="margin-bottom: 20px;">Ajouter un footer</button>
        <div class="form-footer-container" style="display: none;">
            <form method="post" id="form-footer">
                <h3 id="form-footer-title">Ajouter</h3>
                <div class="form-group">
                    <label for="form_footer_departement">Département :</label>
                    <select name="form_footer_departement" id="form_footer_departement">
                    <?php 
                            if(!in_array('default',$used_departments)){

                            
                            ?>
                        <option value="default">-- Footer par défaut --</option>
                        <?php 
                        }
                        foreach ($all_departments as $dept): ?>
                            <?php 
                            $dept_id = is_array($dept) ? $dept['id'] : $dept;
                            $dept_nom = is_array($dept) ? $dept['nom_usage'] : $dept;
                            if(!in_array($dept['id'],$used_departments)){

                            
                            ?>
                            <option value="<?= esc_attr($dept_id); ?>"><?= esc_html($dept_nom); ?></option>
                        <?php
                        }
                    endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                <label for="footer_content">Contenu du footer :</label>
                <?php
                    wp_editor(
                        '', 
                        'footer_content', 
                        [
                            'textarea_name' => 'footer_content',
                            'media_buttons' => false,
                            'teeny' => true,
                            'textarea_rows' => 6,
                        ]
                    );
                    ?>
                </div>

                
                <div class="form-actions">
                <button type="button" class="button"id="form-footer-discard-btn">Annuler</button>
                <button type="submit" class="button button-primary">Enregistrer</button>
            </div></form>
        </div>
        <h2>Liste des Footers</h2>
        <table class="widefat">
            <thead><tr><th>Département</th><th>Contenu</th><th>Actions</th></tr></thead>
            <tbody id="footer-table-body">
            <?php foreach ($current_footers as $dept => $content): ?>
                <tr>
                    <td>                    
                        <?php
                            $deptNom = '';
                            foreach ($all_departments as $departement) {
                                $id = is_array($departement) ? $departement['id'] : $departement;
                                $nom = is_array($departement) ? $departement['nom_usage'] : $departement;

                                if ($id == $dept) {
                                    $deptNom = $nom;
                                    break;
                                }
                            }
                            echo esc_html($deptNom ?: 'Footer par défaut');
                        ?>
                    </td>
                    <td><?= wp_kses_post($content); ?></td>
                    <td>
                        <button class="button edit-dep-footer" data-id="<?php echo $dept; ?>"data-nom="<?php echo esc_attr($deptNom); ?>" data-content="<?php echo esc_attr($content); ?>" >
                                    <i class="dashicons dashicons-edit"></i>
                                </button>
                                <button class="button delete-dep-footer" data-id="<?php echo $dept; ?>">
                                    <i class="dashicons dashicons-trash"></i>
                                </button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <script>
    
            jQuery(document).ready(function($) {
                
                const $form = $('.form-footer-container');
                const urlParams = new URLSearchParams(window.location.search);
                const tab = urlParams.get('tab');

                if (tab && tab=="configuration-event-departement") {

                $('.nav-tab').removeClass('nav-tab-active');
                    $('.nav-tab[href=\"#tab-documents\"]').addClass('nav-tab-active');
                    $('.tab-content').hide();
                    $('#tab-documents').show();
            
                    $('.custom-tab-event').removeClass('active');
                    $('.custom-tab-event-content').hide();
                    $('.custom-tab-event[href=\"#configuration-event-departement\"]').addClass('active');
                    $('#configuration-event-departement').show();
                    const url = new URL(window.location.href);
                    url.searchParams.delete('tab');
                    window.history.replaceState({}, document.title, url.toString());

                }
                
                $('#btn-ajouter-footer').on('click', function () {
                    $('.form-footer-container').slideDown();
                    $('#form-footer-title').text('Ajouter');
                    $('#form_footer_departement').val('default');
                    if (typeof tinymce !== 'undefined' && tinymce.get('footer_content')) {
                        tinymce.get('footer_content').setContent('');
                    } else {
                        $('#footer_content').val(''); 
                    }
                });

            $('#form-footer-discard-btn').on('click', function () {
                    $('.form-footer-container').slideUp();
                    $('#form-footer-title').text('Ajouter');
                    $('#form_footer_departement').val('default');
                    if (typeof tinymce !== 'undefined' && tinymce.get('footer_content')) {
                        tinymce.get('footer_content').setContent('');
                    } else {
                        $('#footer_content').val(''); 
                    }
                });
                // Édition
                $(document).on('click', '.edit-dep-footer', function() {
                    const depId = $(this).data('id');
                    let nomDept=$(this).data('nom');
                    
                    const content = $(this).data('content');
                    if (typeof tinymce !== 'undefined' && tinymce.get('footer_content')) {
                        tinymce.get('footer_content').setContent(content);
                    } else {
                        $('#footer_content').val(content); 
                    }
                    if(depId=='default'){
                        nomDept="-- Footer par défaut --";
                    }

                    $('#form-footer-title').text('Modifier');
                    //$('#form_footer_departement').val(depId);
                    const $select = $('#form_footer_departement');
                    $select.empty().append(
                        $('<option>', {
                            value: depId,
                            text: nomDept,
                            selected: true
                        })
                );
                    $form.slideDown();
                });

                // Suppression
                $(document).on('click', '.delete-dep-footer', function() {
                    if (!confirm('Voulez-vous vraiment supprimer ce footer ?')) return;

                    const depId = $(this).data('id');
                    $.post(ajaxurl, {
                        action: 'crm_delete_footer',
                        id: depId
                    }, function(response) {
                        if (response.success) {
                            showFooterMessage('success', response.data.message);
                            setTimeout(() => {
                                const url = new URL(window.location.href);
                                url.searchParams.set('tab', 'configuration-event-departement');
                                window.location.href = url.toString();
                                                    // location.reload()
                        
                            }
                            , 1000);
                        } else {

                            showFooterMessage('error', response.data.message);
                            setTimeout(() => {
                                const url = new URL(window.location.href);
                                url.searchParams.set('tab', 'configuration-event-departement');
                                window.location.href = url.toString();
                        // location.reload()
                        
                            }, 1000);
                        }
                    });
                });

                // Sauvegarde
                $('#form-footer').on('submit', function(e) {
                    e.preventDefault();

                    const content =$('#footer_content').val() ;
                    const departement = $('#form_footer_departement').val();
                    const existants = <?php echo json_encode(array_keys($current_footers)); ?>;

                    if (departement === '' && existants.includes("")) {
                        alert("Un seul footer sans département est autorisé.");
                        return;
                    }

                    $.post(ajaxurl, {
                        action: 'sauvegarder_footer',
                        departement: departement,
                        contenu: content
                    }, function(response) {
                        showFooterMessage('success', 'Footer enregistré avec succès !');
                        setTimeout(() => setTimeout(() => {
                                const url = new URL(window.location.href);
                                url.searchParams.set('tab', 'configuration-event-departement');
                                window.location.href = url.toString();
                        
                            }), 1000);
                    }).fail(() => {
                        showFooterMessage('error', "Erreur lors de la sauvegarde.");
                    });
                });
                function showFooterMessage(type, message) {
                const $msgBox = $('#dep_footer_table_msg');
                $msgBox
                    .removeClass('notice-success notice-error')
                    .addClass(type === 'success' ? 'notice notice-success' : 'notice notice-error')
                    .html(`<p>${message}</p>`)
                    .slideDown();

                setTimeout(() => {
                    $msgBox.slideUp();

                }, 4000);
            }

            });
        

        </script>
    </div>
    <?php
}