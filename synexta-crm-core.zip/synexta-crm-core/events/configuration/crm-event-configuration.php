<?php

function crm_events_config_page() {
    ?>
    <div class="crm-custom-wrap ">
        
        <div class="custom-tab-container">
            <a href="#presentation-event" class="custom-tab custom-tab-event active" data-tab="presentation-event"><h2>Présentation</h2></a>
            <a href="#configuration-event-tags" class="custom-tab custom-tab-event" data-tab="configuration-event-tags"><h2>Configuration Tags</h2></a>
            <a href="#configuration-event-departement" class="custom-tab custom-tab-event" data-tab="configuration-event-departement"><h2>Configuration départements</h2></a>
            <a href="#configuration-event-smtp" class="custom-tab custom-tab-event" data-tab="configuration-event-smtp"><h2>Configuration SMTP</h2></a>
        </div>
        
        <div class="crm-custom-wrap-right">    
            <div id="presentation-event" class="custom-tab-content  custom-tab-event-content" style="display:block;">
                    <div style="border-bottom: 1px solid #ddd; margin-bottom: 20px; padding-bottom: 20px;">
                        <h2 style="font-size: 1.5em; margin-bottom: 10px;">Type de post "CRM événements"</h2>
                        <p>Le type de post <strong>CRM événements</strong>  est conçu pour simplifier la création, la gestion et la personnalisation des événements dans votre système de gestion de la relation client (CRM). Ce plugin utilise des templates réutilisables qui permettent de générer des événements personnalisés selon vos besoins.</p>
                        <h1>Plugin CRM Événements</h1>
                        <h2>Fonctionnalités Principales</h2>
                        <ul>
                            <li>Créer des templates structurés pour générer des événements et rapports standardisés.</li>
                            <li>Gérer facilement les événements générés à partir des templates.</li>
                            <li>Personnaliser les événements à l’aide de variables dynamiques et de shortcodes.</li>
                            <li>Offrir la possibilité d'attacher les événements générés à d'autres événements.</li>
                            <li>Ajouter des tags pour classifier les événements générés. Chaque tag a un nom unique et un style. Pour gérer les tags, visitez ce <a href="?post_type=crm_documents&page=crm-documents-tags">lien</a>.</li>
                        </ul>
                        <h2>Méta-Données Principales</h2>
                        <ul>
                            <li>
                                <p><strong>Liste des Variables :</strong> Lors de la création d'un événement, un formulaire affiche les variables nécessaires. Si une variable requise n'existe pas, vous pouvez créer une variable personnalisée. Avec le module <code>crm_don</code>.
                                </p><p>Les variables suivants permettent de récupérer automatiquement certaines informations depuis <strong>VosFactures</strong>, si la synchronisation est activée et que l’utilisateur dispose d’un identifiant VosFactures (stocké dans son profil).</p>

                            <ul style="list-style-type: disc; margin-left: 20px;">
                                <li><strong>'devis'</strong> : Récupère le <em>dernier devis</em> associé à l'utilisateur connecté, via l'API VosFactures.</li>

                                <li><strong>'facture'</strong> : Récupère la <em>dernière facture</em> émise pour cet utilisateur depuis VosFactures.</li>

                                <li><strong>'factures-echues'</strong> : Récupère la liste des <em>factures non payées ou échues</em> (en retard de paiement) pour l'utilisateur connecté.</li>
                            </ul>

                            <p>Ces données peuvent ensuite être affichées dans des templates ou shortcodes pour informer l'utilisateur de sa situation (devis à valider, facture à régler, relance pour impayés, etc.).</p>
                            </li>
                            <li><strong>Configuration de la Template :</strong>
                                <ul>
                                    <li>Autoriser l’ajout de documents joints supplémentaires ? (permet d'attacher des pièces jointes aux événements générés)</li>
                                    <li>Générer le PDF lors de la création du document ? (génère automatiquement un PDF pour chaque événement lié)</li>
                                    <li>Définir comme modèle par défaut (le modèle par défaut est utilisé pour la génération des notes avec le shortcode <code>crm_notes</code>)</li>
                                </ul>
                            </li>
                            <li><strong>Droits d'utilisation :</strong> Définissez les rôles d'utilisateur autorisés à utiliser ce modèle.</li>
                            <li><strong>Association d'Événement :</strong> Associez l'événement généré à un ou plusieurs utilisateurs CRM.</li>
                            <li><strong>Expiration (en jours) :</strong> Définissez une durée après laquelle les événements expirent et reçoivent la classe <code>crm_expired_event</code>.</li>
                        </ul>
                        <h2>Personnalisation de l’apparence du PDF</h2> 
                        <p>Pour modifier le style du PDF généré (typographie, marges, couleurs, mise en page…), vous pouvez ajouter vos règles CSS personnalisées dans le fichier suivant :</p> 
                        <pre><code>wp-content/plugins/synexta-crm-core/assets/css/pdf-css-file.css</code></pre> <p>Ces styles seront appliqués automatiquement lors de la génération du PDF.</p>
                
                        <div style="border: 1px solid #ddd; background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin-top: 20px;">
                            <h3 style="font-size: 1.2em; margin-bottom: 10px;">Shortcodes disponibles</h3>
                            
                            <p>Utilisez les shortcodes suivants pour interagir avec les templates et les événements générés :</p>
                            
                            <!--1ere shortcode

                            <h4 style="font-size: 1.1em; margin-bottom: 5px;">1. [crm_notes]</h4>
                            <p>Ce shortcode permet de générer une note sur le fiche d'un tiers à partir de la template par defaut du module . La note est basé sur les variables définies dans le template. Il accepte les attributs suivants (facultatifs) :</p>
                            <ul style="list-style-type: disc; margin-left: 20px;">
                            <li><strong>ico</strong> : <br>
                                <em>Permet d'ajouter une icône au bouton via une URL. Si une URL est spécifiée, l'image correspondante sera affichée avant le label du bouton. Si `ico=""`, aucune icône ne sera affichée. Par exemple, `ico="https://example.com/icon.png"` affichera l'icône provenant de cette URL.</em>
                            </li>
                            <li><strong>title</strong> : Permet de changer le texte affiché sur le bouton. Par défaut, le bouton portera le texte "Ajouter une note". Si `title=""`, aucun texte ne sera affiché sur le bouton. Ce paramètre est facultatif. <br>
                            
                            </li>

                            
                            <li>Assurer d'utiliser ce shortcode sur la fiche d’un tiers, et de définir le modele par defaut  .</li>
                            </ul>
                            <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                                [crm_notes title="note" ico="https://example.com/icon.png"]
                            </pre>-->

                            
                            <!--2eme shortcode generer=oui liste=oui-->

                            <div style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.6;"> 
                                <h4 style="font-size: 1.1em; margin-bottom: 5px;">1. [crm_gestion_evenements]</h4> 
                                <p>Ce shortcode affiche une liste des événements générés et permet d’en créer de nouveaux. Il propose plusieurs fonctionnalités :</p> 
                                <ul style="list-style-type: disc; margin-left: 20px;"> 
                                    <li>📝 <strong>Créer une note</strong> </li> 
                                    <li>📅 <strong>Créer un événement</strong></li> 
                                    <li>✉️ <strong>Envoyer le contenu des événements par e-mail</strong> à plusieurs utilisateurs</li> 
                                    <li>🔄 <strong>Régénérer et modifier un événement</strong></li> 
                                    <li>📂 <strong>Liste groupée par année</strong> : 
                                    <br>&nbsp;&nbsp;• Affiche les événements des 2 dernières années 
                                    <br>&nbsp;&nbsp;• Les événements plus anciens sont regroupés dans une section "Archives"</li> 
                                    <li>🔍 <strong>Recherche</strong> dans les événements</li> 
                                </ul> 
                                <p>Il accepte les attributs suivants :</p> 
                                <ul style="list-style-type: disc; margin-left: 20px;"> 
                                    <li><strong>nom_template</strong> : Nom du template permettant de filtrer les événements affichés en fonction du template utilisé (facultatif).</li> 
                                    <li><strong>liste</strong> : Accepte <code>oui</code> ou <code>non</code> (par défaut : <code>oui</code>). Affiche la liste des événements générés.</li> 
                                    <li><strong>generer</strong> : Accepte <code>oui</code> ou <code>non</code> (par défaut : <code>oui</code>). Affiche les boutons pour générer un événement et créer des notes.</li> 
                                    <li>⚠️ Si utilisé sur la fiche d’un tiers, il affichera uniquement les événements liés à ce tiers.</li> 
                                </ul> 
                                <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"> [crm_gestion_evenements nom_template="Nom du template" generer="oui" liste="oui"] </pre> 
                                <hr> 
                                <h4 style="font-size: 1.1em; margin-bottom: 5px;">2. [crm_list_evenements]</h4> 
                                <p>Ce shortcode affiche deux listes d’événements :</p> 
                                <ul style="list-style-type: disc; margin-left: 20px;"> <li>👤 <strong>Événements créés par l’utilisateur connecté</strong></li> 
                                    <li>👥 <strong>Événements créés par les autres utilisateurs</strong> <br>🔒 Disponible uniquement si l’utilisateur a le rôle <code>admin</code> ou <code>responsable CRM</code>.
                                    </li> 
                                </ul> 
                                <p>Les événements peuvent être filtrés par tags et créateur. Il accepte l’attribut suivant :</p> 
                                <ul style="list-style-type: disc; margin-left: 20px;"> 
                                    <li><strong>tags</strong> : Liste de tags séparés par des virgules pour filtrer les événements. <br>⚠️ Si aucun tag n’est précisé : tous les événements (toutes dates) sont affichés. <br>📅 Si des tags sont précisés : seuls les événements dont la date est postérieure à aujourd’hui sont affichés.</li> 
                                </ul> 
                                <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"> [crm_list_evenements tags="tag1,tag2"] </pre> 
                                <hr> 
                                <h4 style="font-size: 1.1em; margin-bottom: 5px;">3. [download_event_documents]</h4> 
                                <p>Ce shortcode affiche une liste de documents téléchargeables pour un événement donné (à utiliser sur la page <strong>event-documents</strong>).</p> 
                                <p>URL attendue :</p> 
                                <ul style="list-style-type: disc; margin-left: 20px;"> <li><code>/event-documents/{id_hashé_evenement}/{id_hashé_tracking}</code></li> 
                                </ul> 
                                <p>Fonctionnalités :</p> 
                                <ul style="list-style-type: disc; margin-left: 20px;"> 
                                    <li>📄 Affiche les documents sous forme de tableau avec icônes</li> 
                                    <li>⬇️ Un clic sur un document déclenche : <br>&nbsp;&nbsp;• Le téléchargement immédiat du fichier <br>&nbsp;&nbsp;• L’envoi d’une requête AJAX pour enregistrer le téléchargement dans le log de tracking</li> 
                                </ul> 
                                <p>Il accepte l’attribut suivant :</p> 
                                <ul style="list-style-type: disc; margin-left: 20px;"> 
                                    <li><strong>text</strong> : Texte affiché au-dessus de la liste des documents (par défaut : "Télécharger les pièces jointes").</li> 
                                </ul> 
                                <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"> [download_event_documents text="Cliquez ici pour récupérer les fichiers"] </pre>
                                <hr> 
                                <h4 style="font-size: 1.1em; margin-bottom: 5px;">4. [redirection_vofacture_shortcode]</h4> 
                                <p>Ce shortcode permet de rediriger automatiquement l’utilisateur vers la page <strong>/vosfacture</strong> pour régler une facture spécifique.</p> 
                                <p>URL attendue :</p> 
                                <ul style="list-style-type: disc; margin-left: 20px;"> 
                                    <li><code>/vos-facture-paiment/{id_facture}</code></li> 
                                </ul> 
                                <p>Fonctionnalités :</p> 
                                <ul style="list-style-type: disc; margin-left: 20px;"> 
                                    <li>🔀 Redirection automatique vers la page de paiement de la facture</li> 
                                    <li>📝 Journalisation de l’accès pour le tracking</li> 
                                    <li>❌ Aucun contenu visible n’est affiché sur la page</li> 
                                </ul> 
                                <hr> 
                                <h4 style="font-size: 1.1em; margin-bottom: 5px;">5. [tracking_mails_list]</h4> 
                                <p>Ce shortcode affiche une liste dynamique des suivis d’envoi de documents générés (tracking) dans le CRM.</p> 
                                <p>Fonctionnalités :</p> 
                                <ul style="list-style-type: disc; margin-left: 20px;"> 
                                    <li>🔍 Recherche par nom d’utilisateur</li> 
                                    <li>👤 Filtrage par utilisateur via menu déroulant</li> 
                                    <li>📅 Affiche la date d’envoi et la dernière date de consultation</li> 
                                    <li>🗂️ Interface interactive avec <code>DataTables</code> (tri, pagination, recherche)</li> 
                                </ul> 
                                <p>Il accepte l’attribut suivant :</p> 
                                <ul style="list-style-type: disc; margin-left: 20px;"> 
                                    <li><strong>count</strong> : Nombre d’entrées à afficher par page (par défaut : 10).</li> 
                                </ul> 
                                <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"> [tracking_mails_list count="20"] </pre> 
                        </div>
                    </div> 
            </div>
                            
            </div>
            <div id="configuration-event-tags" class="custom-tab-content custom-tab-event-content" style="display:none;">
                <?php
                crm_events_tags_config();
                ?>
            </div>

            <div id="configuration-event-smtp" class="custom-tab-content custom-tab-event-content" style="display:none;">
                <?php crm_events_smtp_config(); ?>
                


            </div>

            <div id="configuration-event-departement" class="custom-tab-content custom-tab-event-content" style="display:none;">
                <?php
                crm_events_departements_config();
                ?>

            
            </div>
        
        </div>
    </div>
 



    <?php
}

