<?php

function crm_events_smtp_config() {
    if (isset($_POST['save_email_style']) && check_admin_referer('save_email_style_nonce_action')) {
        update_option('crm_event_emails_style', wp_kses_post($_POST['footer_email_style'] ?? ''));
        update_option('crm_event_x_mailer', sanitize_text_field($_POST['x_mailer'] ?? ''));
        update_option('crm_event_return_path', sanitize_email($_POST['return_path'] ?? ''));
        update_option('crm_event_list_unsubscribe', sanitize_email($_POST['list_unsubscribe'] ?? ''));
        update_option('crm_smtp_default_host', sanitize_text_field($_POST['smtp_default_host'] ?? ''));
        update_option('crm_smtp_default_email', sanitize_email($_POST['smtp_default_email'] ?? ''));
        update_option('crm_smtp_default_port', sanitize_text_field($_POST['smtp_default_port'] ?? ''));
        update_option('crm_smtp_default_login', sanitize_text_field($_POST['smtp_default_login'] ?? ''));
        update_option('crm_smtp_default_password', sanitize_text_field($_POST['smtp_default_password'] ?? ''));
        update_option('crm_email_daily_limit', intval($_POST['email_daily_limit'] ?? 0));
        update_option('crm_email_hourly_limit', intval($_POST['email_hourly_limit'] ?? 0));
        update_option('crm_email_favorite_slots', sanitize_textarea_field($_POST['email_favorite_slots'] ?? ''));
        update_option('crm_email_forbidden_slots', sanitize_textarea_field($_POST['email_forbidden_slots'] ?? ''));
        update_option('crm_email_random_variation', intval($_POST['email_random_variation'] ?? 0));
        update_option('crm_event_list_unsubscribe_url', esc_url_raw($_POST['list_unsubscribe_url'] ?? ''));
        

        echo "<script>
        jQuery(document).ready(function($) {
            
            $('.nav-tab').removeClass('nav-tab-active');
            $('.nav-tab[href=\"#tab-documents\"]').addClass('nav-tab-active');
            $('.tab-content').hide();
            $('#tab-documents').show();
    
            $('.custom-tab-event').removeClass('active');
            $('.custom-tab-event-content').hide();
            $('.custom-tab-event[href=\"#configuration-event-smtp\"]').addClass('active');
            $('#configuration-event-smtp').show();
        });
        </script>";
        echo '<div class="updated"><p>Configuration sauvegardé avec succès.</p></div>';
      
    }
               
    ?>
    <?php
    $emails_style  = get_option('crm_event_emails_style', '');
    $x_mailer      = get_option('crm_event_x_mailer', '');
    $return_path   = get_option('crm_event_return_path', '');
    $list_unsub    = get_option('crm_event_list_unsubscribe', '');
    $default_smtp_host     = get_option('crm_smtp_default_host', '');
    $default_smtp_email    = get_option('crm_smtp_default_email', '');
    $default_smtp_port     = get_option('crm_smtp_default_port', '');
    $default_smtp_login    = get_option('crm_smtp_default_login', '');
    $default_smtp_password = get_option('crm_smtp_default_password', '');
    $email_daily_limit        = get_option('crm_email_daily_limit', '');
    $email_hourly_limit       = get_option('crm_email_hourly_limit', '');
    $email_favorite_slots     = get_option('crm_email_favorite_slots', '');
    $email_forbidden_slots    = get_option('crm_email_forbidden_slots', '');
    $email_random_variation   = get_option('crm_email_random_variation', '');
    $listUnsubscribeURL  = get_option('crm_event_list_unsubscribe_url', '');

    ?>

    <div class="wrap">
        <h2>Configuration des emails personnalisés</h2>
        <p class="description">
            Cette configuration permet de personnaliser les emails envoyés depuis le système (notes, événements, etc.).<br>
            Lors de l'ajout ou de l'édition d’une note ou d’un événement, une case à cocher apparaît dans la barre latérale pour permettre
            l’envoi automatique du contenu par email à un ou plusieurs destinataires.
        </p>

        <p class="description">
            Un journal (log) est généré pour chaque événement, indiquant : 
            si le mail a été vu, les fichiers ont été téléchargés, etc.
            <br>Si la case <strong>« envoyer les fichiers via un lien »</strong> est cochée, les pièces jointes seront accessibles via un lien crypté sécurisé.
        </p>

        <form method="post">
            <?php wp_nonce_field('save_email_style_nonce_action'); ?>

            <div class="form-group">
                <label for="footer_email_style"><strong>CSS personnalisé pour les emails</strong></label>
                <p class="description">
                    CSS injecté dans la balise <code>&lt;style&gt;</code> des emails HTML.<br>
                    Permet de modifier couleurs, marges, polices, etc.
                </p>
                <textarea id="footer_email_style" name="footer_email_style" rows="10" style="width: 400px;"><?= esc_textarea($emails_style); ?></textarea>
            </div>

            <hr>

            <div class="form-group">
                <label for="x_mailer"><strong>X-Mailer</strong> (max. 40 caractères)</label>
                <p class="description">Nom du logiciel utilisé pour envoyer l’email (ex : MonCRM 1.0)</p>
                <input type="text" id="x_mailer" name="x_mailer" maxlength="40" style="width: 400px;" value="<?= esc_attr($x_mailer); ?>">
            </div>

            <div class="form-group">
                <label for="return_path"><strong>Return-Path</strong> (obligatoire)</label>
                <p class="description">Adresse utilisée pour le retour des emails non délivrés.</p>
                <input type="email" id="return_path" name="return_path" required style="width: 400px;" value="<?= esc_attr($return_path); ?>">
            </div>

            <div class="form-group">
                <label for="list_unsubscribe"><strong>List-Unsubscribe</strong> (obligatoire)</label>
                <p class="description">Adresse pour se désinscrire des emails (ex : unsubscribe@domaine.com)</p>
                <input type="email" id="list_unsubscribe" name="list_unsubscribe" required style="width: 400px;" value="<?= esc_attr($list_unsub); ?>">
            </div>
            <div class="form-group">
                <label for="list_unsubscribe_url"><strong>URL de désinscription (List-Unsubscribe)</strong></label>
                <p class="description">Ex: https://synexta.fr/unsubscribe</p>
                <input type="url" id="list_unsubscribe_url" name="list_unsubscribe_url" style="width: 400px;" value="<?= esc_attr(get_option('crm_event_list_unsubscribe_url', '')); ?>">
            </div>
            <hr>
            <h3>Configuration SMTP par défaut</h3>
            <p class="description">Ce SMTP sera utilisé si l'utilisateur n'a pas de configuration SMTP personnalisée.</p>


            <div class="form-group">
                <label for="smtp_default_host">Hôte SMTP</label><br>
                <input type="text" id="smtp_default_host" name="smtp_default_host" style="width: 400px;" value="<?= esc_attr($default_smtp_host); ?>">
            </div>

            <div class="form-group">
                <label for="smtp_default_email">Adresse e-mail utilisée (From)</label><br>
                <input type="email" id="smtp_default_email" name="smtp_default_email" style="width: 400px;" value="<?= esc_attr($default_smtp_email); ?>">
            </div>

            <div class="form-group">
                <label for="smtp_default_port">Port SMTP</label><br>
                <input type="number" id="smtp_default_port" name="smtp_default_port" style="width: 400px;" value="<?= esc_attr($default_smtp_port); ?>">
            </div>

            <div class="form-group">
                <label for="smtp_default_login">Identifiant SMTP</label><br>
                <input type="text" id="smtp_default_login" name="smtp_default_login" style="width: 400px;" value="<?= esc_attr($default_smtp_login); ?>">
            </div>

            <div class="form-group">
                <label for="smtp_default_password">Mot de passe SMTP</label><br>
                <input type="password" id="smtp_default_password" name="smtp_default_password" style="width: 400px;" value="<?= esc_attr($default_smtp_password); ?>">
            </div>

            <hr>
            <h3>Fréquence & Créneaux d’envoi des emails</h3>

            <div class="form-group">
                <label for="email_daily_limit">Limitation journalière des emails</label>
                <p class="description">Nombre maximum d’emails autorisés par jour (entier positif).</p>
                <input type="number" id="email_daily_limit" name="email_daily_limit" min="0" style="width: 400px;" value="<?= esc_attr($email_daily_limit); ?>">
            </div>

            <div class="form-group">
                <label for="email_hourly_limit">Limitation par heure des emails</label>
                <p class="description">Nombre d’emails autorisés par heure (doit être inférieur ou égal à la limite journalière).</p>
                <input type="number" id="email_hourly_limit" name="email_hourly_limit" min="0" style="width: 400px;" value="<?= esc_attr($email_hourly_limit); ?>">
            </div>

            <div class="form-group">
                <label><strong>Plages horaires de prédilection</strong></label>
                <p class="description">Plages horaires recommandées (ex. lundi 14h-16h, mardi 9h-12h). Un jour peut avoir plusieurs plages, une par ligne.</p>
                <div id="favorite-slots-container"></div>
                <button type="button" class="button add-slot" data-type="favorite">+ Ajouter une plage</button>
            </div>

            <!-- Plages horaires interdites -->
            <div class="form-group">
                <label><strong>Plages horaires interdites</strong></label>
                <p class="description">Plages horaires interdites (ex. dimanche 00h-23h). Une plage par ligne.</p>
                <div id="forbidden-slots-container"></div>
                <button type="button" class="button add-slot" data-type="forbidden">+ Ajouter une plage</button>
            </div>
            <div id="smtp-config-msg"style="display:none;"></div>

            <!-- Champs cachés qui contiennent les données à sauvegarder -->
            <input type="hidden" name="email_favorite_slots" id="email_favorite_slots_hidden">
            <input type="hidden" name="email_forbidden_slots" id="email_forbidden_slots_hidden">
            <div class="form-group">
                <label for="email_random_variation">Variation aléatoire des envois (en secondes)</label>
                <p class="description">Entier positif entre 0 et 900 (ex. 300 pour varier jusqu’à 5 min l’envoi).</p>
                <input type="number" id="email_random_variation" name="email_random_variation" min="0" max="900" style="width: 400px;" value="<?= esc_attr($email_random_variation); ?>">
            </div>
            <p>
                <button type="submit" class="button button-primary" name="save_email_style">Sauvegarder la configuration</button>
            </p>
        </form>
        <style>
        .container {
            width: 60%;
            margin: 0 auto;
        }
        .slot-container {
            margin: 10px 0;
        }
        .slot-container input {
            width: 100px;
            margin-right: 10px;
        }
        .error {
            color: red;
        }
    </style>
        <script>
jQuery(document).ready(function($) {
    const days = ['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi','Dimanche'];

    function createSlotRow(type, index = '') {
        const name = type + '_slot_' + index;
        return `
        <div class="slot-row" data-type="${type}">
            <select class="day">
                ${days.map(day => `<option value="${day}">${day}</option>`).join('')}
            </select>
            <input type="time" class="start" required>
            <span>à</span>
            <input type="time" class="end" required>
            <button type="button" class="remove-slot button-link-delete">×</button>
        </div>`;
    }

    function refreshHiddenInputs() {
        ['favorite', 'forbidden'].forEach(type => {
            const slots = [];
            $(`#${type}-slots-container .slot-row`).each(function() {
                const day = $(this).find('.day').val();
                const start = $(this).find('.start').val();
                const end = $(this).find('.end').val();

                if (day && start && end && end > start) {
                    const label = `${day} ${start}-${end}`;
                    if (!slots.includes(label)) {
                        slots.push(label);
                    }
                }
            });
            $(`#email_${type}_slots_hidden`).val(slots.join("\n"));
        });
    }

    $(document).on('click', '.add-slot', function() {
        const type = $(this).data('type');
        const container = $(`#${type}-slots-container`);
        container.append(createSlotRow(type, container.children().length));
    });

    $(document).on('click', '.remove-slot', function() {
        $(this).closest('.slot-row').remove();
        refreshHiddenInputs();
    });

    $(document).on('change', '.slot-row select, .slot-row input', function() {
        refreshHiddenInputs();
    });

    $('form').on('submit', function(e) {
        $('#smtp-config-msg').removeClass('notice-success notice-error').html("").slideUp();
                
        let valid = true;
        const allSlots = [];
        const errorMessages = [];
        
        $('.slot-row').each(function() {
            const day = $(this).find('.day').val();
            const start = $(this).find('.start').val();
            const end = $(this).find('.end').val();

            if (day && start && end) {
                const label = `${day} ${start}-${end}`;

                // Vérification des doublons
                if (allSlots.includes(label)) {
                    errorMessages.push(`Cette plage horaire est déjà utilisée : ${label}`);
                } else {
                    allSlots.push(label);
                }

                // Vérification si l'heure de fin est inférieure ou égale à l'heure de début
                if (end <= start) {
                    errorMessages.push(`L'heure de fin doit être supérieure à l'heure de début pour : ${label}`);
                }
            }
        });

        if (errorMessages.length > 0) {
            $('#smtp-config-msg')
                .removeClass('notice-success notice-error')
                .addClass('notice notice-error')
                .html(errorMessages.join("<br>"))
                .slideDown();
            valid = false;
        }


        if (!valid) e.preventDefault() ;
    });

    // initial slots (si besoin à partir des valeurs PHP)
    const initialFavorite = <?= json_encode(explode("\n", $email_favorite_slots)) ?>;
    const initialForbidden = <?= json_encode(explode("\n", $email_forbidden_slots)) ?>;

    function loadInitialSlots(type, initialList) {
        const container = $(`#${type}-slots-container`);
        container.empty();
        initialList.forEach(line => {
            const match = line.match(/(\w+)\s+(\d{2}:\d{2})-(\d{2}:\d{2})/);
            if (match) {
                const [_, day, start, end] = match;
                const row = $(createSlotRow(type, container.children().length));
                row.find('.day').val(day);
                row.find('.start').val(start);
                row.find('.end').val(end);
                container.append(row);
            }
        });
        refreshHiddenInputs();
    }

    loadInitialSlots('favorite', initialFavorite);
    loadInitialSlots('forbidden', initialForbidden);
});
</script>

    </div>
    <?php
}