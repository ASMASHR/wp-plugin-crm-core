<?php

/*
 * Ce fichier PHP gère l'affichage des compte utilisateurs depuis l'API VosFactures dans WordPress.
 *
 * Fonctionnalités principales :
 
 * Shortcode [tiers-actifs] :
 * Affiche la liste des entreprises activées dans l'application VosFactures.
 * Présente les informations sous forme de tableau paginé, avec des détails tels que la date de création et de modification.
 * Attributs :
 * 
 * - count (facultatif) : Détermine le nombre d'utilisateurs affichés par page. Si cet attribut est spécifié, le tableau intègre automatiquement un système de pagination pour
 * naviguer entre les différentes pages de résultats. Par exemple, count="10" affichera 10 utilisateurs par page, avec des liens de navigation pour accéder aux pages suivantes ou
 * précédentes.
 * - role (facultatif) : Si spécifié, le shortcode filtre les utilisateurs selon ce rôle. 
 *   Exemple : [tiers-actifs role="customer"count=15]
 * - Si l'attribut role n'est pas défini, le shortcode récupère tous les utilisateurs ayant l'un des rôles suivants :
 *   'prospect', 'customer', 'tiers', 'non_qualifie', 'hors_cible'.




 * Shortcode [tiers-inactifs] :
 * Affiche la liste des entreprises inactives.
 * Les informations sont également présentées sous forme de tableau paginé.
 * 
 * Attributs :
 *  - count (facultatif) : Détermine le nombre d'utilisateurs affichés par page. Si cet attribut est spécifié, le tableau intègre automatiquement un système de pagination pour
 * naviguer entre les différentes pages de résultats. Par exemple, count="10" affichera 10 utilisateurs par page, avec des liens de navigation pour accéder aux pages suivantes ou
 * précédentes.
 * - role (facultatif) : Si spécifié, le shortcode filtre les utilisateurs selon ce rôle. 
 *   Exemple : [tiers-inactifs role="customer"count=15]
 * - Si l'attribut role n'est pas défini, le shortcode récupère tous les utilisateurs ayant l'un des rôles suivants :
 *   'prospect', 'customer', 'tiers', 'non_qualifie', 'hors_cible'.
 
 * Shortcode [societe_baseinfo] :
 * Présente les informations de base d'une société, incluant :
 * Nom de la société, adresse, code postal, ville, pays, SIREN, contact, email et téléphone.
 * Fournit une interface pour modifier ces informations via un formulaire sécurisé :
 * Les champs sont vérifiés et nettoyés avant de mettre à jour les métadonnées utilisateur.
 * Si les données sont modifiées, un message de succès s'affiche.
 * Possibilité d'éditer ou d'annuler les modifications à l'aide de boutons intégrés.
 
 * Shortcode [societe_adresseslivraison] :
 * Affiche l'adresse de livraison et les informations associées :
 * Société, adresse, code postal, ville, pays, contact et téléphone.
 * Permet l'édition des informations de livraison grâce à un formulaire :
 * Les données saisies sont vérifiées avant mise à jour des métadonnées utilisateur.
 * Confirmation visuelle en cas de succès des modifications.

 * Utilisation :
 * - Cette implémentation garantit que la page crm-customer est créée et contient les shortcodes suivants : [societe_technique], [societe_adresseslivraison], et [societe_baseinfo]. Ces shortcodes permettent d'afficher des informations spécifiques en fonction d'un identifiant (hashedId) transmis via l'URL.
 * - Lorsque l'utilisateur accède à une URL sous la forme site.com/crm-customer/{hashedId}, la page récupère automatiquement l'identifiant et affiche les données correspondantes grâce aux shortcodes intégrés dans la page.
 */


 function ensure_edit_user_page_exists() {
    // Définir le titre et le contenu de la page
    $page_title = 'Gestion des tiers';
    $page_slug = 'crm-customer';
    $page_content = '[societe_baseinfo]'; // Shortcode que vous utiliserez pour afficher le contenu

    // Vérifier si une page avec ce slug existe déjà
    $page = get_page_by_path($page_slug);

    if (!$page) {
        // La page n'existe pas, la créer
        $new_page_id = wp_insert_post([
            'post_title'     => $page_title,
            'post_name'      => $page_slug,
            'post_content'   => $page_content,
            'post_status'    => 'publish',
            'post_type'      => 'page',
        ]);

        
    } 
}

function ensure_Liste_disabled_companies_page_exists() {
    // Définir le titre et le contenu de la page
    $page_title = 'Tiers inactifs';
    $page_slug = 'crm-customer-inactif';
    $page_content = '[tiers-inactifs]'; 
    // Vérifier si une page avec ce slug existe déj
    $page = get_page_by_path($page_slug);

    if (!$page) {
        // La page n'existe pas, la créer
        $new_page_id = wp_insert_post([
            'post_title'     => $page_title,
            'post_name'      => $page_slug,
            'post_content'   => $page_content,
            'post_status'    => 'publish',
            'post_type'      => 'page',
        ]);

        
    } 
}
add_action('after_setup_theme', 'ensure_Liste_disabled_companies_page_exists');

add_action('init', 'remove_page_rewrite_rule', 10, 0);

function remove_page_rewrite_rule() {
    global $wp_rewrite;
    $wp_rewrite->rules = array();
    $wp_rewrite->flush_rules();  // Cela vide les règles existantes
}

function custom_rewrite_rule() {
    add_rewrite_rule(
        '^crm-customer/([a-f0-9]{64})/?$',  
        'index.php?pagename=crm-customer&hashedId=$matches[1]', 
        'top'
    );
    add_rewrite_rule(
        '^page/([0-9]+)/?$',  // Si l'URL est de la forme /page/{numéro}, redirige vers un format compatible.
        'index.php?paged=$matches[1]',  // Redirige vers la page avec le paramètre ?paged={numéro}
        'top'
    );
    
}
add_action('init', 'custom_rewrite_rule',10,0);
/**
 * [tiers-actifs] affiche la liste des entreprises actifs
 * @param mixed $atts
 * @return string
 */

function display_actif_users($atts) {
    $atts = shortcode_atts([
        'role' => '',
        'count' => 10, 
    ], $atts, 'tiers-actifs');

    ob_start();
    
    // Charger les styles
    wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../global.css');
    wp_enqueue_style('p-style', plugin_dir_url(__FILE__) . './gestion-tiers-front.css');

    // Charger jQuery pour le filtre rapide
    wp_enqueue_script('jquery');

    $editIconUrl = plugin_dir_url(__FILE__) . '../assets/icons/edit-icon.svg';
    $searchIconUrl = plugin_dir_url(__FILE__) . '../assets/icons/recherche.svg';

    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        $roles = $current_user->roles;

        if (in_array('administrator', $roles) || in_array('responsable_crm', $roles) || in_array('utilisateur_crm', $roles)) {

            // Pagination : récupérer la page actuelle
            $paged = isset($_GET['page-number']) ? intval($_GET['page-number']) : 1;
            $offset = ($paged - 1) * $atts['count'];
            $count = isset($atts['count']) ? $atts['count'] : 10;
            // Arguments de la requête
            $args = [
                'meta_query' => [
                    [
                        'key' => 'user_status',
                        'value' => ['ACTIF', 'actif', 'active'],
                        'compare' => 'IN',
                    ],
                ],
                'role__in' => !empty($atts['role']) ? [$atts['role']] : ['prospect', 'customer', 'tiers', 'non_qualifie', 'hors_cible'],
                //'number' => isset($atts['count']) ? $atts['count'] : 10, 
               // 'offset' => isset($offset) ? $offset : 0,
               'number' =>-1, 
               
                'orderby' => 'user_registered',
                'order' => 'DESC',
            ];
            if (isset($_GET['user-role']) && !empty($_GET['user-role'])) {
               

                $args['role__in'] = $_GET['user-role'];
            }
            //$total_users = count(get_users(array_merge($args, ['number' => -1, 'offset' => 0])));
            $users = get_users($args);
            if (isset($_GET['q']) && !empty($_GET['q'])) {
                $searchTerm = sanitize_text_field($_GET['q']);
             
                $filtered_users = array_filter($users, function($user) use ($searchTerm) {
                     if (stripos($user->display_name, $searchTerm) !== false || stripos($user->user_email, $searchTerm) !== false) {
                        return true;
                    }
                    
                    // Vérifier les métadonnées
                    $user_meta = get_user_meta($user->ID);
                    foreach ($user_meta as $key => $values) {
                        foreach ($values as $value) {
                            if (stripos($value, $searchTerm) !== false) {
                                return true;
                            }
                        }
                    }
                    
                    return false;
                });
                $users=$filtered_users;
            }
 
            // Filtrage des utilisateurs pour 'utilisateur_crm'
            if (in_array('utilisateur_crm', $roles)) {
                $users = array_filter($users, function($user) use ($current_user) {
                    $associates_users = get_user_meta($user->ID, 'associer_crm', true);
                    return is_array($associates_users) && in_array($current_user->ID, $associates_users);
                });
            }
            $total_users = count($users);
            $users = array_slice($users, $offset, $count);
            $total_pages = ceil($total_users / $count);
			

                $output="<div class='crm-table-container'>
                        <div class='crm-table-header'>
                            <div class='crm-table-header-quick-filter'>
                                    <input type='text' id='quick-filter-input' value='" . (isset($_GET['q']) ? esc_attr($_GET['q']) : '') . "' placeholder='Rechercher...'>
                                    <button id='filter-btn'class='quick-filter-icon'>  
                                        <img src='" . esc_url($searchIconUrl) . "' alt='Rechercher'>
                                    </button>
                            </div>
                           <select class='role-filter' id='user-role-filter'>
                                <option value='all'" . (isset($_GET['user-role']) && $_GET['user-role'] == 'tous' ? " selected" : "") . ">Tous les rôles</option>
                                <option value='tiers'" . (isset($_GET['user-role']) && $_GET['user-role'] == 'tiers' ? " selected" : "") . ">Tiers</option>
                                <option value='customer'" . (isset($_GET['user-role']) && $_GET['user-role'] == 'customer' ? " selected" : "") . ">Client</option>
                                <option value='prospect'" . (isset($_GET['user-role']) && $_GET['user-role'] == 'prospect' ? " selected" : "") . ">Prospect</option>
                                <option value='non_qualifie'" . (isset($_GET['user-role']) && $_GET['user-role'] == 'non_qualifie' ? " selected" : "") . ">Non qualifié</option>
                                <option value='hors_cible'" . (isset($_GET['user-role']) && $_GET['user-role'] == 'hors_cible' ? " selected" : "") . ">Hors cible</option>
                            </select>
                        </div>";
                        $output .= '<table class="crm-table" id="users-table">';
                        $output .= '<thead><tr>
                                    <th>Entreprise</th><th>Nom / Prénom</th><th>Adresse</th><th>CP/ville/Pays</th><th>Tél</th><th>Email</th><th>Actions</th>
                                    </tr></thead><tbody>';
                        if (!empty($users)) {
                           
                            $countries = new WC_Countries();
    
    
                            $countries_list = $countries->get_countries();
                            foreach ($users as $user) {
                                $billing_company = get_user_meta($user->ID, 'billing_company', true);
                                $prenom_nom = get_user_meta($user->ID, 'last_name', true) . ' ' . get_user_meta($user->ID, 'first_name', true);
                                $entreprise_affichee = $billing_company ?: '<i>' . esc_html($prenom_nom) . '</i>';
                                $billing_company = get_user_meta($user->ID, 'billing_company', true);
                                $billing_address_1 = get_user_meta($user->ID, 'billing_address_1', true);
                                $billing_city = get_user_meta($user->ID, 'billing_city', true);
                                $billing_postcode = get_user_meta($user->ID, 'billing_postcode', true);
                                $pays = get_user_meta($user->ID, 'billing_country', true) ;
                                $billing_country =isset($countries_list[$pays]) ?strtoupper($countries_list[$pays]) : $pays;
                                $billing_phone = get_user_meta($user->ID, 'billing_phone', true);
                                //$prenom = get_user_meta($user->ID, 'billing_first_name', true);
                                //$nom = get_user_meta($user->ID, 'billing_last_name', true);
                                $email = $user->user_email;
                                $first_name = get_user_meta($user->ID, 'first_name', true);
                                $last_name = get_user_meta($user->ID, 'last_name', true);
                               
                                $prenom_nom=$last_name .' '.$first_name;
                                
            
                                $entreprise_affichee = $billing_company ?: '<i>' . esc_html($prenom_nom) . '</i>';
            
                                // Construction du champ CP/ville/Pays
                                $cp_ville = '';
                                if ($billing_postcode) {
                                    $cp_ville .= esc_html($billing_postcode);
                                }
                                if ($billing_city) {
                                    $cp_ville .= ($cp_ville ? ', ' : '') . esc_html($billing_city);
                                }
                                if ($billing_country) {
                                    $cp_ville .= ($cp_ville ? ' ' : '') . '(' . esc_html($billing_country) . ')';
                                }
            
                                // Correction de l'ACTIF / INACTIF
                                $user_status = get_user_meta($user->ID, 'user_status', true);
                                $is_actif = ($user_status === 'active');
            
                                $edit_url = site_url('/crm-customer/');
                                $user_id_hash = generate_user_hash($user->ID);
                                $user_role = !empty($user->roles) ? $user->roles[0] : '';

                                $output .= '<tr class="user-row" data-role="' . esc_attr($user_role) . '">';
                                $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . $entreprise_affichee . '</td>';
                                $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($prenom_nom) . '</td>';
                                $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($billing_address_1) . '</td>';
                                $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . $cp_ville . '</td>';
                                $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($billing_phone) . '</td>';
                                $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($email) . '</td>';
                                $output .= '<td><a href="' . esc_url($edit_url) .'/'. esc_attr($user_id_hash) .'"class="btn btn-edit">
                                <img src="' . esc_url($editIconUrl) . '" alt="Modifier" style="width: 24px; height: 24px;"></a></td>';
                                $output .= '</tr>';
                            }
                            }
                        else {
                                $output .= '<tr><td colspan="7"style="text-align: center;">Aucun utilisateur n\'a été trouvé.</td></tr>';
                            }
                        $output .= '</tbody></table>';
                        
             
                        $output .= '<div class="crm-table-footer">';
                        $output .= '<p>Total : ' . $total_users . ' utilisateurs actifs</p>';
                    

                        if ($total_pages > 1) {
                            $output .= '<div class="crm-table-pagination">';
                            for ($i = 1; $i <= $total_pages; $i++) {
                                $active_class = ($i == $paged) ? 'active' : '';
                               
                                
                            $output .= '<span class="pagenum ' . $active_class . '" data-num="' . ($i) . '" >' . $i. '</span> ';
                            //$output .= '<a href="' . get_pagenum_link($i) . '" class="' . $active_class . '">' . $i . '</a> ';
                            }
                            $output .= '</div>';
                        }
                        $output .= '</div></div>';
        } 
        /*else {
            $output = 'Accès non autorisé.';
        }*/
        else {
            $base_url = site_url('/crm-customer/');
            $user_id_hash = generate_user_hash($current_user->ID);
        
            $redirect_url = ($base_url . $user_id_hash);
        
            wp_redirect($redirect_url);
            exit;
        } 
    } else {
        $output = 'Veuillez vous connecter pour voir vos informations.';
    }

    // Script JavaScript pour le filtre rapide
    $output .= '<script>
   
    </script>';

    return $output;
}
add_shortcode('tiers-actifs', 'display_actif_users');


/**
 * [tiers-inactifs] affiche la liste des entreprises inactifs
 * @param mixed $atts
 * @return string
 */

function display_disabled_companies($atts) {
    // Vérifier si l'utilisateur est connecté
    $atts = shortcode_atts([
        'role' => '', 
        'count' => 10, 
    ], $atts, 'tiers-inactifs');
    ob_start();
    wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../global.css');
    wp_enqueue_style('p-style', plugin_dir_url(__FILE__) . './gestion-tiers-front.css');
    $editIconUrl = plugin_dir_url(__FILE__) . '../assets/icons/edit-icon.svg';
    $searchIconUrl = plugin_dir_url(__FILE__) . '../assets/icons/recherche.svg';

     
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        $roles = $current_user->roles;
        
         
           
         
        if (in_array('administrator', $roles) || in_array('responsable_crm', $roles) || in_array('utilisateur_crm', $roles)) {
          $paged = isset($_GET['page-number']) ? intval($_GET['page-number']) : 1;
            $offset = ($paged - 1) * $atts['count'];
            $count = isset($atts['count']) ? $atts['count'] : 10;
            
            $args = [
                'meta_query' => [
                    [
                        'key' => 'user_status',
                        'value' => ['inactive', 'INACTVE', 'NOT EXISTS','inactif'],
                        'compare' => 'IN',
                    ],
                ],
                'role__in' => !empty($atts['role']) ? [$atts['role']] : ['prospect', 'customer', 'tiers', 'non_qualifie', 'hors_cible'],
                //'number' => isset($atts['count']) ? $atts['count'] : 10, 
                //'offset' => isset($offset) ? $offset : 0,
                'number' => -1, 
                'orderby' => 'user_registered',
                'order' => 'DESC',
            ];
          
           
            if (isset($_GET['user-role']) && !empty($_GET['user-role'])) {
               

                $args['role__in'] = $_GET['user-role'];
            }
           
            

            
            //$total_users = count(get_users(array_merge($args, ['number' => -1, 'offset' => 0])));

            //$total_pages = ceil($total_users / $atts['count']);
            
            $users = get_users($args);
            if (isset($_GET['q']) && !empty($_GET['q'])) {
                $searchTerm = sanitize_text_field($_GET['q']);
              
                $filtered_users = array_filter($users, function($user) use ($searchTerm) {
                     if (stripos($user->display_name, $searchTerm) !== false || stripos($user->user_email, $searchTerm) !== false) {
                        return true;
                    }
                    
                    // Vérifier les métadonnées
                    $user_meta = get_user_meta($user->ID);
                    foreach ($user_meta as $key => $values) {
                        foreach ($values as $value) {
                            if (stripos($value, $searchTerm) !== false) {
                                return true;
                            }
                        }
                    }
                    
                    return false;
                });
                $users=$filtered_users;
            }
            $filtredUsers=[];
            if(in_array('utilisateur_crm', $roles))
            {
                foreach ($users as $user) {
                    $associates_users=get_user_meta($user->ID, 'associer_crm', true);
                    if (is_array($associates_users) && in_array($current_user->ID, $associates_users)) {
                        $filtredUsers[] = $user;
                    }
                }
                $users=$filtredUsers;
                
            }
            $total_users = count($users);
            $users = array_slice($users, $offset, $count);

            $total_pages = ceil($total_users / $count);
            
            $countries = new WC_Countries();
    
    
            $countries_list = $countries->get_countries();
            // Crer une table d'utilisateurs à afficher
            $output="<div class='crm-table-container'>
            <div class='crm-table-header'>
                <div class='crm-table-header-quick-filter'>
                        <input type='text' id='quick-filter-input' value='" . (isset($_GET['q']) ? esc_attr($_GET['q']) : '') . "' placeholder='Rechercher...'>
                        <button id='filter-btn'>  
                            <img src='" . esc_url($searchIconUrl) . "' alt='Rechercher'>
                        </button>
                </div>
               <select class='role-filter' id='user-role-filter'>
                    <option value='all'" . (isset($_GET['user-role']) && $_GET['user-role'] == 'tous' ? " selected" : "") . ">Tous les rôles</option>
                    <option value='tiers'" . (isset($_GET['user-role']) && $_GET['user-role'] == 'tiers' ? " selected" : "") . ">Tiers</option>
                    <option value='customer'" . (isset($_GET['user-role']) && $_GET['user-role'] == 'customer' ? " selected" : "") . ">Client</option>
                    <option value='prospect'" . (isset($_GET['user-role']) && $_GET['user-role'] == 'prospect' ? " selected" : "") . ">Prospect</option>
                    <option value='non_qualifie'" . (isset($_GET['user-role']) && $_GET['user-role'] == 'non_qualifie' ? " selected" : "") . ">Non qualifié</option>
                    <option value='hors_cible'" . (isset($_GET['user-role']) && $_GET['user-role'] == 'hors_cible' ? " selected" : "") . ">Hors cible</option>
                </select>
            </div>";
            $output .= '<table class="crm-table" id="users-table">';
            $output .= '<thead><tr>
                        <th>Entreprise</th><th>Nom / Prénom</th><th>Adresse</th><th>CP/ville/Pays</th><th>Tél</th><th>Email</th><th>Actions</th>
                        </tr></thead><tbody>';
            if (!empty($users)) {
                $countries = new WC_Countries();
    
    
                $countries_list = $countries->get_countries();

                foreach ($users as $user) {
                    $billing_company = get_user_meta($user->ID, 'billing_company', true);
                    $prenom_nom = get_user_meta($user->ID, 'last_name', true) . ' ' . get_user_meta($user->ID, 'first_name', true);
                    $entreprise_affichee = $billing_company ?: '<i>' . esc_html($prenom_nom) . '</i>';
                    $billing_company = get_user_meta($user->ID, 'billing_company', true);
                    $billing_address_1 = get_user_meta($user->ID, 'billing_address_1', true);
                    $billing_city = get_user_meta($user->ID, 'billing_city', true);
                    $billing_postcode = get_user_meta($user->ID, 'billing_postcode', true);
                    $pays = get_user_meta($user->ID, 'billing_country', true) ;
                    $billing_country =isset($countries_list[$pays]) ?strtoupper($countries_list[$pays]) : $pays;
                    $billing_phone = get_user_meta($user->ID, 'billing_phone', true);
                    //$prenom = get_user_meta($user->ID, 'billing_first_name', true);
                    //$nom = get_user_meta($user->ID, 'billing_last_name', true);
                    $email = $user->user_email;
                    $first_name = get_user_meta($user->ID, 'first_name', true);
                    $last_name = get_user_meta($user->ID, 'last_name', true);
                   
                    $prenom_nom=$last_name .' '.$first_name;
                    

                    $entreprise_affichee = $billing_company ?: '<i>' . esc_html($prenom_nom) . '</i>';

                    // Construction du champ CP/ville/Pays
                    $cp_ville = '';
                    if ($billing_postcode) {
                        $cp_ville .= esc_html($billing_postcode);
                    }
                    if ($billing_city) {
                        $cp_ville .= ($cp_ville ? ', ' : '') . esc_html($billing_city);
                    }
                    if ($billing_country) {
                        $cp_ville .= ($cp_ville ? ' ' : '') . '(' . esc_html($billing_country) . ')';
                    }

                    // Correction de l'ACTIF / INACTIF
                    $user_status = get_user_meta($user->ID, 'user_status', true);
                    $is_actif = ($user_status === 'active');

                    $edit_url = site_url('/crm-customer/');
                    $user_id_hash = generate_user_hash($user->ID);
                    $user_role = !empty($user->roles) ? $user->roles[0] : '';

                    $output .= '<tr class="user-row" data-role="' . esc_attr($user_role) . '">';
                    $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . $entreprise_affichee . '</td>';
                    $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($prenom_nom) . '</td>';
                    $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($billing_address_1) . '</td>';
                    $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . $cp_ville . '</td>';
                    $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($billing_phone) . '</td>';
                    $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($email) . '</td>';
                    $output .= '<td><a href="' . esc_url($edit_url) .'/'. esc_attr($user_id_hash) .'"class="btn btn-edit">
                    <img src="' . esc_url($editIconUrl) . '" alt="Modifier" style="width: 24px; height: 24px;"></a></td>';
                    $output .= '</tr>';
                }
                }
            else {
                    $output .= '<tr><td colspan="7"style="text-align: center;">Aucun utilisateur n\'a été trouvé.</td></tr>';
                }
            $output .= '</tbody></table>';
            
 
            $output .= '<div class="crm-table-footer">';
            $output .= '<p>Total : ' . $total_users . ' utilisateurs inactifs </p>';
        

            if ($total_pages > 1) {
                $output .= '<div class="crm-table-pagination">';
                for ($i = 1; $i <= $total_pages; $i++) {
                    $active_class = ($i == $paged) ? 'active' : '';
                   
                    
                $output .= '<span class="pagenum ' . $active_class . '" data-num="' . ($i) . '" >' . $i. '</span> ';
                //$output .= '<a href="' . get_pagenum_link($i) . '" class="' . $active_class . '">' . $i . '</a> ';
                }
                $output .= '</div>';
            }
            $output .= '</div></div>';
           
		}
	
        else {
            $base_url = site_url('/crm-customer/');
            $user_id_hash = generate_user_hash($current_user->ID);
        
            $redirect_url = ($base_url . $user_id_hash);
        
            wp_redirect($redirect_url);
            exit;
        }   
    } 

     else {
        // Si l'utilisateur n'est pas connecté
        $output = 'Veuillez vous connecter pour voir vos informations.';
    }

	



    return $output;
}
add_shortcode('tiers-inactifs', 'display_disabled_companies');




function generate_user_hash($user_id) {
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
    return hash_hmac('sha256', $user_id, $secret_key);
}

function get_user_id_from_hash($hash) {
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
    $users = get_users(); 

    foreach ($users as $user) {
        if ($hash === hash_hmac('sha256', $user->ID, $secret_key)) {
            return $user->ID;
        }
    }

    return false; 
}
function get_hashed_id_from_url() {
    // Récuprer l'URL complète de la page
    $current_url = $_SERVER['REQUEST_URI'];
    
    // Vérifier si l'URL contient 'crm-customer'
    if (preg_match('#^/crm-customer/([a-f0-9]{64})#', $current_url, $matches)) {
        // Si l'ID est trouvé, renvoyer le premier match (le hashedId)
        return $matches[1];
    }
    
    // Si aucun hashedId n'est trouvé, retourner null ou une valeur par défaut
    return null;
}
/**
 * [societe_baseinfo] affiche les informations de base d'une entreprise 
 * @param mixed $atts
 * @return string
 */

 function societe_baseinfoold($atts) {
    wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../global.css');
    wp_enqueue_style('p-style', plugin_dir_url(__FILE__) . './gestion-tiers-front.css');
    ob_start();
    $editIcon=plugin_dir_url(__FILE__) . '../assets/icons/edition.svg';
   // session_start();
    if (!is_user_logged_in()) {
        return '<p>Vous devez être connecté pour accéder à cette page.</p>';
    }

    $hashedId = get_hashed_id_from_url();
    $user_id=null;
    if ($hashedId) {
        $user_id = get_user_id_from_hash($hashedId);
    }

    if ($user_id === null || !get_userdata($user_id)) {
        return '<p>ID utilisateur invalide ou expiré.</p>';
    }
    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $current_user = wp_get_current_user();
    $roles = $current_user->roles;
    $user_crm_can_edit=is_array($associates_users) && in_array($current_user->ID, $associates_users);
    if (in_array('responsable_crm', $roles) || in_array('administrator', $roles) || $current_user->ID === $user_id||$user_crm_can_edit) {
       
    

        $countries = new WC_Countries();
    
    
        $countries_list = $countries->get_countries();
    
        $user_role = get_userdata($user_id)->roles[0]; 
        $roles_mapping = [
            'tiers' => 'Tiers',
            'utilisateur_crm' => 'Utilisateur CRM',
            'responsable_crm' => 'Responsable CRM',
            'non_qualifie' => 'Non qualifié',
            'hors_cible' => 'Hors cible',
            'prospect' => 'Prospect',
            'customer' => 'Client',
        ];
        
        // Affichage du rôle formaté
        $role_display = $roles_mapping[$user_role] ?? 'Rôle inconnu';
        $nom_societe = $_POST['billing_company']??get_user_meta($user_id, 'billing_company', true);
        $adresse = $_POST['billing_address_1']??get_user_meta($user_id, 'billing_address_1', true);
        $ville = $_POST['billing_city']??get_user_meta($user_id, 'billing_city', true);
        $code_postal = $_POST['billing_postcode']??get_user_meta($user_id, 'billing_postcode', true);
        $pays = $_POST['billing_country']??get_user_meta($user_id, 'billing_country', true) ;
        $billing_country =isset($countries_list[$pays]) ?strtoupper($countries_list[$pays]) : $pays;
        // Construction du champ CP/ville/Pays
        $cp_ville = '';
        if ($code_postal) {
            $cp_ville .= esc_html($code_postal);
        }
        if ($ville) {
            $cp_ville .= ($cp_ville ? ', ' : '') . esc_html($ville);
        }
        if ($billing_country) {
            $cp_ville .= ($cp_ville ? ' ' : '') . '(' . esc_html($billing_country) . ')';
        }
        $siren = $_POST['tax_no']??get_user_meta($user_id, 'tax_no', true);
        //$prenom_nom = $_POST['billing_first_name'] || $_POST['billing_last_name']?$_POST['billing_first_name'] .' '. $_POST['billing_last_name'] :get_user_meta($user_id, 'billing_first_name', true) . ' ' . get_user_meta($user_id, 'billing_last_name', true);
        //$email = get_user_meta($user_id, 'billing_email', true);
        $user_info = get_userdata($user_id);
        $email = $_POST['email']??$user_info->user_email;
        
        $telephone = $_POST['billing_phone']??get_user_meta($user_id, 'billing_phone', true);
        
        // Charger les pays WooCommerce
        $url = get_user_meta($user_id, 'url', true);
        $first_name = get_user_meta($user_id, 'first_name', true);
        $last_name = get_user_meta($user_id, 'last_name', true);
       
        $prenom_nom=$last_name .' '.$first_name;
        if ($pays === 'FR' && !empty($siren)) {
            $siren_link = '<a href="https://www.pappers.fr/entreprise/' . esc_attr($siren) . '" target="_blank">' . esc_html($siren) . '</a>';
        } else {
            $siren_link = esc_html($siren);
        }
        // Lien pour l'adresse cliquable vers Google Maps
        $adresse_complete = trim("$adresse, $code_postal $ville, $billing_country");
        $adresse_link = 'https://www.google.com/maps/search/?api=1&query=' . urlencode($adresse_complete);

        

        $user_type=$_POST['user_type']??get_user_meta($user_id, 'user_type', true);
        // Gestion de l'affichage du champ "Entreprise"
        $entreprise_affichee = $nom_societe && $user_type === "entreprise" ?$nom_societe: '<i>' . esc_html($prenom_nom) . '</i>';
        
        ?>
        
        
    
        <div class="societe_baseinfo">
            <p id="societe_baseinfo_update_msg"class=""></p>
            <div class="info-view"id="societe_baseinfo_info_view">
                <h3 class="sy-crm-core-title-container <?php echo 'sy_crm_core_role_' . esc_attr($user_role); ?>"> 
                    <span id="nom-entreprise-data"><?php echo ($entreprise_affichee); ?></span>
                    <span class="edit-btn"id='societe_baseinfo_edit_btn' >
                        <img src="<?php echo $editIcon ?>">
                    </span>
                </h3>

                <a id="adress-link-entreprise-data"href="<?php echo esc_url($adresse_link); ?>" target="_blank">
                    <p id="societe_baseinfo_adr"><?php echo esc_html($adresse); ?></p>
                    <p id="societe_baseinfo_cp_ville"><?php  echo $cp_ville;  ?></p>
                </a>            
                <p><strong>Type :</strong> <span id="type-compte-data"><?php  echo esc_html($user_type === "particulier" ? "Particulier" : "Entreprise");  ?></span></p>
                <p style="<?php echo $user_type=='particulier'?'display:none':''?>"><strong>Siren :</strong><span id="siren-data"> <?php echo ($siren_link); ?></span></p>
                <p><strong>Contact :</strong> <span id="nom-data"><?php echo esc_html($prenom_nom); ?></span> </p>
                <p><strong>Rôle :</strong> <span id="role-compte-data"><?php  echo esc_html($role_display); ?></span></p>
                <p><strong>Site web :</strong><a id="url-data" href="<?php echo esc_attr($url); ?>"> <?php echo esc_html($url); ?></a></p>
                <p><strong>Email :</strong> <a id="mail-data" href="mailto:<?php echo esc_attr($email); ?>"> <?php echo esc_html($email); ?></a></p>
                <p><strong>Téléphone :</strong> <a id="tel-data"href="tel:<?php echo esc_attr($telephone); ?>"><?php echo esc_html($telephone); ?></a></p>
                
            </div>

            <div class="edit-form" id="societe_baseinfo_edit_form">
                <form method="post"id="update-societe-baseinfo-form">

                    <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>" >

                    <div class="info-form-group">
                        <label for="user_type" class="label"> Type : *</label>
                        <select name="user_type" id="user_type">
                        <option value="entreprise" <?php echo $user_type === "entreprise" ? "selected" : ""; ?>>Entreprise</option>
                        <option value="particulier" <?php echo $user_type === "particulier" ? "selected" : ""; ?>>Particulier</option>

                        </select>
                    </div>
                    <div class="info-form-group"style="<?php echo $user_type=='particulier'?'display:none':''?>">
                        <label for="billing_company" class="label"> Société : *</label>
                        <input type="text" id="billing_company" name="billing_company" value="<?php echo esc_attr($nom_societe); ?>" >
                    </div>

                    <div class="info-form-group"style="<?php echo $user_type=='particulier'?'display:none':''?>">
                        <label for="tax_no" class="label">Siren : </label>
                        <input type="text" id="tax_no" name="tax_no" value="<?php echo esc_attr($siren); ?>">
                    </div>

                    <div class="info-form-group">
                        <label for="last_name" class="label"> Nom : *</label>
                        <input type="text" id="last_name" name="last_name" value="<?php echo esc_attr($last_name); ?>" >
                    </div>
                    <div class="info-form-group">
                        <label for="first_name" class="label"> Prénom : *</label>
                        <input type="text" id="first_name" name="first_name" value="<?php echo esc_attr($first_name); ?>" >
                    </div>
                    
                    
                    <div class="info-form-group">
                        <label for="billing_address_1" class="label">Adresse : *</label>
                        <input type="text" id="billing_address_1"name="billing_address_1" value="<?php echo esc_attr($adresse); ?>" >
                    </div>
                    <div class="info-form-group">
                        <label for="billing_postcode" class="label">CP : </label>
                        <input type="text" id="billing_postcode"name="billing_postcode" value="<?php echo esc_attr($code_postal); ?>" >
                    </div>
                    <div class="info-form-group">
                        <label for="billing_city" class="label">Ville : *</label>
                        <input type="text" id="billing_city"name="billing_city" value="<?php echo esc_attr($ville); ?>" >
                    </div>
                    <div class="info-form-group">
                        <label for="billing_country" class="label">Pays : *</label>
                        <select  id="billing_country" name="billing_country">
                            <?php foreach (WC()->countries->get_countries() as $key => $value): ?>
                                <option value="<?php echo esc_attr($key); ?>" <?php echo strtoupper($pays) === strtoupper($value) || strtoupper($pays) === strtoupper($key) ? 'selected' : ''; ?>>
                                    <?php echo esc_html($value); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="info-form-group">
                        <label for="role" class="label"> Rôle : *</label>
                        <select name="role" id="role">
                            <option value="prospect" <?php echo $user_role === "prospect" ? "selected" : ""; ?>>Prospect</option>
                            <option value="tiers" <?php echo $user_role === "tiers" ? "selected" : ""; ?>>Tiers</option>
                            <option value="non_qualifie" <?php echo $user_role === "non_qualifie" ? "selected" : ""; ?>>Non qualifié</option>
                            <option value="hors_cible" <?php echo $user_role === "hors_cible" ? "selected" : ""; ?>>Hors cible</option>
                            <option value="customer" <?php echo $user_role === "customer" ? "selected" : ""; ?>>Client</option>

                        </select>
                    </div>
                
                    <div class="info-form-group">
                        <label for="url" class="label">Site web :</label>
                        <input type="url" id="url"name="url" value="<?php echo esc_attr($url); ?>" >
                    </div>
                    <div class="info-form-group">
                        <label for="email" class="label">Email : *</label>
                        <input type="email" id="email"name="email" value="<?php echo esc_attr($email); ?>" <?php echo $user_role === 'customer' ? '' : 'required'; ?>>
                    </div>
                    <div class="info-form-group">
                        <label for="billing_phone" class="label">Téléphone :</label>
                        <input type="text"id="billing_phone" name="billing_phone" value="<?php echo esc_attr($telephone); ?>">
                    </div>
                    <input type="hidden" id="societe_baseinfo_security"name="security" value="<?php echo wp_create_nonce('update_user_nonce'); ?>">
                    
                    <div class="btn-container">
                    
                    <button type="submit" class="submit-btn" name="societe_baseinfo_submit_btn">Enregistrer</button>
                    <button type="button" class="discard-btn"id="societe_baseinfo_discard_edit">Annuler</button></div>
                </form>
            </div>
        </div>
                            

        <script>
            jQuery(document).ready(function($) {
                $('#societe_baseinfo_edit_btn').click(function() {
                    $('#societe_baseinfo_info_view').hide();
                    $('#societe_baseinfo_edit_form').show();
                }); $('#societe_baseinfo_discard_edit').click(function() {
                    $('#societe_baseinfo_info_view').show();
                    $('#societe_baseinfo_edit_form').hide();
                });
                $('#update-societe-baseinfo-form').on('input', 'input, select', function () {
                        $(this).parent().next('.text-error').remove();
                });
                $('#user_type').change(function () {
                    if ($(this).val() == 'entreprise') {
                        $('#billing_company').parent().show();
                        $('#tax_no').parent().show();
                     
                    } else {
                        $('#billing_company').parent().hide();
                        $('#tax_no').parent().hide();   
                        $('#tax_no').val('');
                        $('#billing_company').val('');
                    }
                });

                //

                            // Handle form submission
                $('#update-societe-baseinfo-form').on('submit', function (e) {
                    e.preventDefault();
                    let isValid = true;

                        $('.text-error').remove();

                        $('#update-societe-baseinfo-form input:visible, #update-societe-baseinfo-form select:visible').each(function () {
                            let $input = $(this);
                            const excludedIds = ['url','tax_no', 'billing_phone','billing_postcode']; 

                            if (!excludedIds.includes($input.attr('id')) && $input.val().trim() === '') {
                                isValid = false;

                                // Ajouter un message d'erreur si le champ est vide
                                $input.parent().after('<span class="text-error text-danger">Ce champ est obligatoire.</span>');
                            }
                        });
                   
                    if(isValid)
                    {
                        var formData = $(this).serializeArray();
                        var formValues = {};
                        
                        formData.forEach(function(item) {
                            formValues[item.name] = item.value;
                        });
                        console.log(formValues);
                        $.post(ajax_object.ajax_url, {
                            action: 'update_user_info',
                            
                            security: $('#societe_baseinfo_security').val(),
                            formData: formData,
                            }, 
                            function (response) {
                                console.log('response',response)
                                if (response.success) {
                                    $('#societe_baseinfo_update_msg')
                                    .text(response.data.message)
                                    .addClass('text-success')
                                    .removeClass('text-error').fadeIn()
                                    .delay(3000) 
                                    .fadeOut(function () {
                                      
                                        location.reload(); 
                                            
                                    });
                                } else {
                                    $('#societe_baseinfo_update_msg')
                                    .text(response.data.message || 'Une erreur est survenue.')
                                    .removeClass('text-success')
                                    .addClass('text-error')
                                    .fadeIn()
                                    .delay(3000) 
                                    .fadeOut(function () {
                                    
                                        $('#societe_baseinfo_info_view').show();
                                        $('#societe_baseinfo_edit_form').hide();
                                    });
                                }
                            }).fail(function () {
                                $('#societe_baseinfo_update_msg')
                                    .text('La requête a échoué. Veuillez réessayer.')
                                    .removeClass('text-success')
                                    .addClass('text-error')
                                    .fadeIn()
                                    .delay(3000) 
                                    .fadeOut(function () {
                                    
                                        $('#societe_baseinfo_info_view').show();
                                        $('#societe_baseinfo_edit_form').hide();
                                    });
                            });

                    }

                });

            });
        </script>
        <?php

        return ob_get_clean();
    } else {
        return '<p>Vous n\'avez pas les droits de modification pour cet utilisateur.</p>';
    }
}
function societe_baseinfo($atts) {
    wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../global.css');
    wp_enqueue_style('p-style', plugin_dir_url(__FILE__) . './gestion-tiers-front.css');
    ob_start();
    $editIcon=plugin_dir_url(__FILE__) . '../assets/icons/edition.svg';
    $infoIcon=plugin_dir_url(__FILE__) . '../assets/icons/nfo-icon.svg';
   // session_start();
    if (!is_user_logged_in()) {
        return '<p>Vous devez être connecté pour accéder à cette page.</p>';
    }

    $hashedId = get_hashed_id_from_url();
    $user_id=null;
    if ($hashedId) {
        $user_id = get_user_id_from_hash($hashedId);
    }

    if ($user_id === null || !get_userdata($user_id)) {
        return '<p>ID utilisateur invalide ou expiré.</p>';
    }
    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $current_user = wp_get_current_user();
    $roles = $current_user->roles;
    $user_crm_can_edit=is_array($associates_users) && in_array($current_user->ID, $associates_users);
    if (in_array('responsable_crm', $roles) || in_array('administrator', $roles) || $current_user->ID === $user_id||$user_crm_can_edit) {
       
    

        $countries = new WC_Countries();
    
    
        $countries_list = $countries->get_countries();
    
        $user_role = get_userdata($user_id)->roles[0]; 
        $roles_mapping = [
            'tiers' => 'Tiers',
            'utilisateur_crm' => 'Utilisateur CRM',
            'responsable_crm' => 'Responsable CRM',
            'non_qualifie' => 'Non qualifié',
            'hors_cible' => 'Hors cible',
            'prospect' => 'Prospect',
            'customer' => 'Client',
        ];
        
        // Affichage du rôle formaté
        $role_display = $roles_mapping[$user_role] ?? 'Rôle inconnu';
        $nom_societe = $_POST['billing_company']??get_user_meta($user_id, 'billing_company', true);
        $adresse = $_POST['billing_address_1']??get_user_meta($user_id, 'billing_address_1', true);
        $ville = $_POST['billing_city']??get_user_meta($user_id, 'billing_city', true);
        $code_postal = $_POST['billing_postcode']??get_user_meta($user_id, 'billing_postcode', true);
        $pays = $_POST['billing_country']??get_user_meta($user_id, 'billing_country', true) ;
        $billing_country =isset($countries_list[$pays]) ?strtoupper($countries_list[$pays]) : $pays;
        // Construction du champ CP/ville/Pays
        $cp_ville = '';
        if ($code_postal) {
            $cp_ville .= esc_html($code_postal);
        }
        if ($ville) {
            $cp_ville .= ($cp_ville ? ', ' : '') . esc_html($ville);
        }
        if ($billing_country) {
            $cp_ville .= ($cp_ville ? ' ' : '') . '(' . esc_html($billing_country) . ')';
        }
        $siren = $_POST['tax_no']??get_user_meta($user_id, 'tax_no', true);
        //$prenom_nom = $_POST['billing_first_name'] || $_POST['billing_last_name']?$_POST['billing_first_name'] .' '. $_POST['billing_last_name'] :get_user_meta($user_id, 'billing_first_name', true) . ' ' . get_user_meta($user_id, 'billing_last_name', true);
        //$email = get_user_meta($user_id, 'billing_email', true);
        $user_info = get_userdata($user_id);
        $email = $_POST['email']??$user_info->user_email;
        
        $telephone = $_POST['billing_phone']??get_user_meta($user_id, 'billing_phone', true);
        
        // Charger les pays WooCommerce
        $url = get_user_meta($user_id, 'url', true);
        $first_name = get_user_meta($user_id, 'first_name', true);
        $last_name = get_user_meta($user_id, 'last_name', true);
       
        $prenom_nom=$last_name .' '.$first_name;
        if ($pays === 'FR' && !empty($siren)) {
            $siren_link = '<a href="https://www.pappers.fr/entreprise/' . esc_attr($siren) . '" target="_blank">' . esc_html($siren) . '</a>';
        } else {
            $siren_link = esc_html($siren);
        }
        // Lien pour l'adresse cliquable vers Google Maps
        $adresse_complete = trim("$adresse, $code_postal $ville, $billing_country");
        $adresse_link = 'https://www.google.com/maps/search/?api=1&query=' . urlencode($adresse_complete);

        

        $user_type=$_POST['user_type']??get_user_meta($user_id, 'user_type', true);
        // Gestion de l'affichage du champ "Entreprise"
        $entreprise_affichee = $nom_societe && $user_type === "entreprise" ?$nom_societe: '<i>' . esc_html($prenom_nom) . '</i>';
        //shipping infoo
        $nom_societe_shipping =  get_user_meta($user_id, 'shipping_company', true) ;

        $adresse_shipping = get_user_meta($user_id, 'shipping_address_1', true) ;

        $ville_shipping =  get_user_meta($user_id, 'shipping_city', true) ;
                

        $code_postal_shipping =get_user_meta($user_id, 'shipping_postcode', true) ;

        $pays_shipping = get_user_meta($user_id, 'shipping_country', true) ;

    

        $telephone_shipping =get_user_meta($user_id, 'shipping_phone', true) ;
        $first_name_shipping =get_user_meta($user_id, 'shipping_first_name', true) ;

        $last_name_shipping =get_user_meta($user_id, 'shipping_last_name', true);

    


        //fin
        // info tecknique
        $associates_users = get_user_meta($user_id, 'associer_crm', true);
        $current_user = wp_get_current_user();
        $current_user_roles = $current_user->roles;
        $user_crm_can_edit =in_array('utilisateur_crm', $current_user_roles)&& is_array($associates_users) && in_array($current_user->ID, $associates_users);
      
            $id_facture = $_POST['vosfactures_id']??get_user_meta($user_id, 'vosfactures_id', true);
            $date_creation = get_user_meta($user_id, 'account_creation_date', true);
            $date_creation = $date_creation ? date("d-m-Y H:i:s", strtotime($date_creation)) : '';
        
            $date_update = get_user_meta($user_id, 'account_last_modified_date', true);
            $date_update = $date_update ? date("d-m-Y H:i:s", strtotime($date_update)) : '';
        
            //get_user_meta($user_id, 'last_login', true);
            $publipostage=$_POST['user_mailing']??get_user_meta($user_id, 'user_mailing', true);
            $status=$_POST['user_status']??get_user_meta($user_id, 'user_status', true);
        
            $email = $user_info->user_email;
            $roles = array(); 
            $user_roles = $user_info->roles;
           if(in_array('tiers', $user_roles) ||in_array('non_qualifie', $user_roles) ||in_array('hors_cible', $user_roles) || in_array('prospect', $user_roles) || in_array('customer', $user_roles)) {
                $roles=['utilisateur_crm'];
            }
        $args = array(
            'role__in' => $roles, 
            'exclude' => array($user_id), 
            'fields' => array('ID', 'display_name','email'),
        );
        
        
        $associer_crm = get_user_meta($user_id, 'associer_crm', true);
        
        $users_list = get_users($args);    
       
        //fin
        ?>
        
        
    
        <div class="societe_baseinfo">
            
            <div class="info-view"id="societe_baseinfo_info_view">
                <h3 class="sy-crm-core-title-container <?php echo 'sy_crm_core_role_' . esc_attr($user_role); ?>"> 
                    <span id="nom-entreprise-data"><?php echo ($entreprise_affichee); ?></span>
                    <span class="edit-btn"id='societe_baseinfo_edit_btn' >
                        <img src="<?php echo $editIcon ?>">
                    </span>
                </h3>

                <a id="adress-link-entreprise-data"href="<?php echo esc_url($adresse_link); ?>" target="_blank">
                    <p id="societe_baseinfo_adr"><?php echo esc_html($adresse); ?></p>
                    <p id="societe_baseinfo_cp_ville"><?php  echo $cp_ville;  ?></p>
                </a>            
                <p><strong>Type :</strong> <span id="type-compte-data"><?php  echo esc_html($user_type === "particulier" ? "Particulier" : "Entreprise");  ?></span></p>
                <p style="<?php echo $user_type=='particulier'?'display:none':''?>"><strong>Siren :</strong><span id="siren-data"> <?php echo ($siren_link); ?></span></p>
                <p><strong>Contact :</strong> <span id="nom-data"><?php echo esc_html($prenom_nom); ?></span> </p>
                <p><strong>Rôle :</strong> <span id="role-compte-data"><?php  echo esc_html($role_display); ?></span></p>
                <p><strong>Site web :</strong><a id="url-data" href="<?php echo esc_attr($url); ?>"> <?php echo esc_html($url); ?></a></p>
                <p><strong>Email :</strong> <a id="mail-data" href="mailto:<?php echo esc_attr($email); ?>"> <?php echo esc_html($email); ?></a></p>
                <p><strong>Téléphone :</strong> <a id="tel-data"href="tel:<?php echo esc_attr($telephone); ?>"><?php echo esc_html($telephone); ?></a></p>
                
            </div>

            <div class="sy-crm-core-edit-info-sidebar"id="edit-info-sidebar"style="display:none;">
                <div class="sidebar-header">
                        <h5 class="">Modifier les données personnel</h5>
                        <button class="sy-crm-core-edit-info-sidebar-discard">X</button>
                </div>
                <form method="post" id="update-societe-baseinfo-form">
                    <div class="sy-crm-core-edit-info-sidebar-content">
                        <div class="sidebar-msg-container" id="societe_baseinfo_update_msg"></div>

                        <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">

                        <!-- Section Informations Générales -->
                        <div class="form-section">
                            <h3>Informations Générales</h3>
                            <div class="form-row">
                                <div class="info-form-group">
                                    <label for="user_type" class="label">Type : *</label>
                                    <select name="user_type" id="user_type">
                                        <option value="entreprise" <?php echo $user_type === "entreprise" ? "selected" : ""; ?>>Entreprise</option>
                                        <option value="particulier" <?php echo $user_type === "particulier" ? "selected" : ""; ?>>Particulier</option>
                                    </select>
                                </div>

                                <!-- Section pour Particulier uniquement  echo $user_type == 'particulier' ? 'display:none' : '';  -->
                                <div class="info-form-group" style="">
                                    <label for="billing_company" class="label">Société : *</label>
                                    <input type="text" id="billing_company" name="billing_company" value="<?php echo esc_attr($nom_societe); ?>"<?php echo $user_type == 'particulier' ? 'readOnly disabled' : ''; ?>>
                                </div>

                                <div class="info-form-group" style="">
                                    <label for="tax_no" class="label">Siren : </label>
                                    <input type="text" id="tax_no" name="tax_no" value="<?php echo esc_attr($siren); ?>" <?php echo $user_type == 'particulier' ? 'readOnly disabled' : ''; ?>>
                                </div>


                            </div>
                            
                            <div class="form-row">
                                <div class="info-form-group">
                                    <label for="last_name" class="label">Nom : *</label>
                                    <input type="text" id="last_name" name="last_name" value="<?php echo esc_attr($last_name); ?>">
                                </div>

                                <div class="info-form-group">
                                    <label for="first_name" class="label">Prénom : *</label>
                                    <input type="text" id="first_name" name="first_name" value="<?php echo esc_attr($first_name); ?>">
                                </div>
                            </div>
                            
                        </div>


                        <!-- Section Contact -->
                        <div class="form-section">
                            <h3>Contact</h3>
                            <div class="form-row">
                                <div class="info-form-group">
                                    <label for="role" class="label">Rôle : *</label>
                                    <select name="role" id="role">
                                        <option value="prospect" <?php echo $user_role === "prospect" ? "selected" : ""; ?>>Prospect</option>
                                        <option value="tiers" <?php echo $user_role === "tiers" ? "selected" : ""; ?>>Tiers</option>
                                        <option value="non_qualifie" <?php echo $user_role === "non_qualifie" ? "selected" : ""; ?>>Non qualifié</option>
                                        <option value="hors_cible" <?php echo $user_role === "hors_cible" ? "selected" : ""; ?>>Hors cible</option>
                                        <option value="customer" <?php echo $user_role === "customer" ? "selected" : ""; ?>>Client</option>
                                    </select>
                                </div>

                                <div class="info-form-group">
                                    <label for="email" class="label">Email : *</label>
                                    <input type="email" id="email" name="email" value="<?php echo esc_attr($email); ?>" <?php echo $user_role === 'customer' ? '' : 'required'; ?>>
                                </div>

                                <div class="info-form-group">
                                    <label for="billing_phone" class="label">Téléphone : </label>
                                    <input type="text" id="billing_phone" name="billing_phone" value="<?php echo esc_attr($telephone); ?>">
                                </div>
                            </div>
                        </div>
                        <!-- Section Adresse -->
                        <div class="form-section">
                            <h3>Adresse de facturation </h3>
                            <div class="info-form-group">
                                <label for="billing_address_1" class="label">Adresse : *</label>
                                <input type="text" id="billing_address_1" name="billing_address_1" value="<?php echo esc_attr($adresse); ?>">
                            </div>
                            <div class="form-row">


                                <div class="info-form-group">
                                    <label for="billing_postcode" class="label">CP : </label>
                                    <input type="text" id="billing_postcode" name="billing_postcode" value="<?php echo esc_attr($code_postal); ?>">
                                </div>

                                <div class="info-form-group">
                                    <label for="billing_city" class="label">Ville : *</label>
                                    <input type="text" id="billing_city" name="billing_city" value="<?php echo esc_attr($ville); ?>">
                                </div>

                                <div class="info-form-group">
                                    <label for="billing_country" class="label">Pays : *</label>
                                    <select id="billing_country" name="billing_country">
                                        <?php foreach (WC()->countries->get_countries() as $key => $value): ?>
                                            <option value="<?php echo esc_attr($key); ?>" <?php echo strtoupper($pays) === strtoupper($value) || strtoupper($pays) === strtoupper($key) ? 'selected' : ''; ?>>
                                                <?php echo esc_html($value); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Section Adresse Livraison -->
                        <div class="form-section">
                            <h3>Adresse de Livraison</h3>
                            <div class="info-form-group">
                                <label for="shipping_company" class="label">Société : </label>
                                <input type="text" id="shipping_company" name="shipping_company" value="<?php echo esc_attr($nom_societe_shipping); ?>">
                            </div>
                            

                            <div class="info-form-group">
                                <label for="shipping_address_1" class="label">Adresse : </label>
                                <input type="text" id="shipping_address_1" name="shipping_address_1" value="<?php echo esc_attr($adresse_shipping); ?>">
                            </div>
                            <div class="form-row">
                                <div class="info-form-group">
                                    <label for="shipping_last_name" class="label">Nom : </label>
                                    <input type="text" id="shipping_last_name" name="shipping_last_name" value="<?php echo esc_attr($first_name_shipping); ?>">
                                </div>

                                <div class="info-form-group">
                                    <label for="shipping_first_name" class="label">Prénom : </label>
                                    <input type="text" id="shipping_first_name" name="shipping_first_name" value="<?php echo esc_attr($last_name_shipping); ?>">
                                </div>

                                <div class="info-form-group">
                                    <label for="shipping_phone" class="label">Téléphone : </label>
                                    <input type="text" id="shipping_phone" name="shipping_phone" value="<?php echo esc_attr($telephone_shipping); ?>">
                                </div>
                            </div>   
                            <div class="form-row">
                                <div class="info-form-group">
                                    <label for="shipping_postcode" class="label">CP : </label>
                                    <input type="text" id="shipping_postcode" name="shipping_postcode" value="<?php echo esc_attr($code_postal_shipping); ?>">
                                </div>

                                <div class="info-form-group">
                                    <label for="shipping_city" class="label">Ville : </label>
                                    <input type="text" id="shipping_city" name="shipping_city" value="<?php echo esc_attr($ville_shipping); ?>">
                                </div>

                                <div class="info-form-group">
                                    <label for="shipping_country" class="label">Pays : </label>
                                    <select id="shipping_country" name="shipping_country">
                                        <?php foreach (WC()->countries->get_countries() as $key => $value): ?>
                                            <option value="<?php echo esc_attr($key); ?>" <?php echo strtoupper($pays_shipping) === strtoupper($value) || strtoupper($pays_shipping) === strtoupper($key) ? 'selected' : ''; ?>>
                                                <?php echo esc_html($value); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>


                            </div>

                            
                            
                        </div>

                        <!-- Section Compte -->
                        <div class="form-section">
                            <h3>Administration tiers </h3>
                            <div class="form-row">
                                <?php if (!in_array('utilisateur_crm', $current_user_roles)): ?>
                                <div class="info-form-group">
                                    <label for="vosfactures_id" class="label">vosfactures :</label>
                                    <input type="text" id="vosfactures_id" name="vosfactures_id" value="<?php echo esc_attr($id_facture); ?>" required readOnly disabled>
                                </div>
                                <?php endif; ?>

                                <div class="info-form-group">
                                    <label for="user_mailing" class="label">Publipostage :</label>
                                    <select name="user_mailing" id="user_mailing">
                                        <option value="yes" <?php echo $publipostage === "yes" ? "selected" : ""; ?>>Oui</option>
                                        <option value="no" <?php echo $publipostage === "no" ? "selected" : ""; ?>>Non</option>
                                    </select>
                                </div>

                                <div class="info-form-group">
                                    <label for="user_status" class="label">Statut :</label>
                                    <select name="user_status" id="user_status">
                                        <option value="active" <?php echo $status === "active" ? "selected" : ""; ?>>Actif</option>
                                        <option value="inactive" <?php echo $status === "inactive" ? "selected" : ""; ?>>Inactif</option>
                                    </select>
                                </div>
                            </div>

                            <div class="info-form-group">
                                <div class="sy-crm-core-associer-crm-info">
                                    <label for="associer_crm" class="label">Associé à :</label>
                                    <span class="sy-crm-core-info-container">
                                        <img src="<?php echo $infoIcon ?>">
                                        <span class="sy-crm-core-tooltip-custom">Tous les utilisateurs (tiers, prospects, clients) sont automatiquement associés à tous les gestionnaires de CRM.</span>
                                    </span>
                                </div>
                                <div class="users_list  <?php echo (in_array('utilisateur_crm', $current_user_roles)? 'disabled':'') ?>"data-edit="<?php echo (in_array('utilisateur_crm', $current_user_roles)? '0':'1') ?>">
                                    
                                    <?php foreach ($users_list as $user):
                                         $isSelected = is_array($associer_crm) && in_array($user->ID, $associer_crm); 
       
                                        ?>
                                        <div class="form-group">
                                            <span class="user-tag <?php echo $isSelected ? 'selected' : ''; ?>" data-id="<?php echo esc_attr($user->ID); ?>">
                                                <?php echo esc_html($user->display_name); ?>
                                            </span>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="users_select_list <?php echo (in_array('utilisateur_crm', $current_user_roles)? 'disabled':'') ?>"data-edit="<?php echo (in_array('utilisateur_crm', $current_user_roles)? '0':'1') ?>">
                                    <?php foreach ($users_list as $user):
                                         if (is_array($associer_crm) && in_array($user->ID, $associer_crm)):?>
                                            <span class="selected-user-tag" id="selected-user-tag-<?php echo esc_attr($user->ID); ?>" data-id="<?php echo esc_attr($user->ID) ?>">
                                                    <?php echo esc_html($user->display_name); ?>
                                                <span class="remove-tag" style="margin-left: 5px; cursor: pointer;">&times;</span>
                                            </span>
                                            
                                        <?php 
                                        endif;
                                         endforeach; ?>
                                    ?>
                                </div>
                            </div>
                        </div>

                        <input type="hidden" id="societe_baseinfo_security" name="security" value="<?php echo wp_create_nonce('update_user_nonce'); ?>">

                    </div>

                    <div class="sy-crm-core-edit-info-sidebar-footer">
                        <button type="button" class="sy-crm-core-edit-info-sidebar-discard" >Annuler</button>
                        <button type="submit" class="sy-crm-core-edit-info-sidebar-submit">Modifer</button>


                    </div>
                </form>
            </div>

        </div>
        
        <?php

        return ob_get_clean();
    } else {
        return '<p>Vous n\'avez pas les droits de modification pour cet utilisateur.</p>';
    }
}
add_shortcode('societe_baseinfo', 'societe_baseinfo');

// Fonction AJAX pour mise à jour
function ajax_update_user_info() {
    // Vérification de la sécurité via nonce
    check_ajax_referer('update_user_nonce', 'security');

    // Vérifie si l'utilisateur est connecté
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Vous devez être connecté pour effectuer cette action.']);
    }
   
    $form_data_raw = $_POST['formData'];
    $form_data = [];

    foreach ($form_data_raw as $item) {
        if ($item['name'] === 'associer_crm') {
            $form_data[$item['name']] = $item['value']; 
           
        }
        else{

        $form_data[$item['name']] = sanitize_text_field($item['value']);
        }
    }
    $user_id = intval($form_data['user_id']);
    $current_user_id = get_current_user_id();
    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $current_user = wp_get_current_user();
   
    $roles = $current_user->roles;
    $user_crm_can_edit=is_array($associates_users) && in_array($current_user->ID, $associates_users);
    $canEdit=in_array('responsable_crm', $roles) || in_array('administrator', $roles) || $current_user->ID === $user_id||$user_crm_can_edit;
   
    if (!$canEdit) {
        wp_send_json_error(['message' => 'Vous n\'avez pas la permission de modifier ces informations.']);
    }

    $allowed_fields = [
        'last_name',
        'first_name',
        'billing_company',
        'billing_address_1',
        'billing_city',
        'billing_postcode',
        'billing_country',
        'tax_no',
        'billing_phone',
        'url',
        'user_type',
        'shipping_company',
        'shipping_address_1',
        'shipping_city',
        'shipping_postcode',
        'shipping_country',
        'shipping_phone',
        'shipping_last_name', 
        'shipping_first_name'
    ];

    $data_modified = false;
    $associer_crm =  $form_data['associer_crm'];
    //wp_send_json_error([$form_data['associer_crm']]);
            
    $current_value = get_user_meta($user_id, 'associer_crm', true);
    if ($associer_crm !== $current_value) {
        $data_modified = true; 
        update_user_meta($user_id, 'associer_crm', $associer_crm);

    }   
    if (isset($form_data['user_status'])) {
    $new_value = sanitize_text_field($form_data['user_status']);
    $current_value =get_user_meta($user_id, 'user_status', true);
    if ($new_value != $current_value) {
        $data_modified = true; 
        update_user_meta($user_id,'user_status',$form_data['user_status']);

    } 
    
}
if (isset($_POST['user_mailing'])) {
    $new_value = sanitize_text_field($form_data['user_mailing']);
    $current_value =get_user_meta($user_id, 'user_mailing', true);
    if ($new_value != $current_value) {
        $data_modified = true; 
        update_user_meta($user_id,'user_mailing',$form_data['user_mailing']);

    } 
    
}

    //wp_send_json_error($form_data);
    // Validation et mise à jour de l'email
    if (!empty($form_data['email'])) {
        $new_email = sanitize_email($form_data['email']);
        $current_email = get_userdata($user_id)->user_email;

        if ($new_email && $new_email !== $current_email) {
            if (!is_email($new_email)) {
                wp_send_json_error(['message' => 'L\'adresse email fournie n\'est pas valide.']);
            }
            $update_result = wp_update_user([
                'ID' => $user_id,
                'user_email' => $new_email
            ]);

            if (is_wp_error($update_result)) {
                wp_send_json_error(['message' => 'Erreur lors de la mise à jour de l\'email.']);
            }
            $data_modified = true;
        }
    }

    // Mise à jour des métadonnées utilisateur
    foreach ($allowed_fields as $field) {
        if (isset($form_data[$field])) {
            $new_value = sanitize_text_field($form_data[$field]);
            $current_value = get_user_meta($user_id, $field, true);

            if ($new_value !== $current_value) {
                update_user_meta($user_id, $field, $new_value);
                $data_modified = true;
            }
        }
    }
    $user_data = get_userdata($user_id);
   
    $tax_no = get_user_meta($user_id, 'tax_no', true);

    $vosfactures_id = get_user_meta($user_id, 'vosfactures_id', true);
    $data = [
        'user_id'=>$user_id,
        'email' => get_userdata($user_id)->user_email,
        'first_name' => $user_data->first_name,
        'last_name' => $user_data->last_name,
        'billing_company'=>get_user_meta($user_id, 'billing_company', true),
        'billing_address_1'=>get_user_meta($user_id, 'billing_address_1', true),
        'billing_city'=>get_user_meta($user_id, 'billing_city', true),
        'billing_postcode'=>get_user_meta($user_id, 'billing_postcode', true),
        'billing_country'=>get_user_meta($user_id, 'billing_country', true),
        'tax_no'=>$tax_no,
        
        'billing_phone'=>get_user_meta($user_id, 'billing_phone', true),
        'url'=>get_user_meta($user_id, 'url', true),
        'user_type'=>get_user_meta($user_id, 'user_type', true)
    ];
    if (isset($form_data['role'])) {
        $new_role = $form_data['role'];
 
       
        $user = get_userdata($user_id);
        $user_role = $user->roles[0];
        if($user_role!=$new_role)
        {
        $user->set_role($new_role);
        $data_modified = true;
        }
    }
    if ($data_modified) {
        update_user_meta($user_id, 'account_last_modified_date', current_time('mysql'));
        $response = sync_with_vosfacture($vosfactures_id, $data);

        if ($response['success']) {
            if ($response['action'] === 'updated') {
                wp_send_json_success(['message' => 'Données modifiées et synchronisées avec l\'utilisateur VosFacture.']);
            } 
            elseif ($response['action'] === 'created') {
                wp_send_json_success(['message' => 'Données modifiées et utilisateur créé sous VosFacture avec l\'ID : ' . $response['new_id']]);
            }
        } else {
            wp_send_json_error(['message' => 'Erreur lors de la synchronisation avec VosFacture.', 'body' => $response['body']]);
        }
    } else {
        wp_send_json_success(['message' => 'Aucune modification détectée.']);
    }

    wp_send_json_error(['message' => 'Erreur lors de la mise à jour des informations.']);
}

add_action('wp_ajax_update_user_info', 'ajax_update_user_info');


/**
 * Synchronise les données de l'utilisateur avec VosFacture.
 *
 * Si l'ID VosFacture existe, les données de l'utilisateur sont mises à jour.
 * Si l'ID VosFacture n'est pas trouvé ou que l'utilisateur correspondant n'existe pas,
 * un nouvel utilisateur est créé avec les données fournies.
 *
 * @param mixed $vosfactures_id L'ID VosFacture de l'utilisateur, s'il existe.
 * @param mixed $form_data Les données du formulaire utilisateur à synchroniser.
 * @return void
 */
function sync_with_vosfacture($vosfactures_id, $form_data) {
    
    $api_key = get_option('vosfactures_api_key');
    $api_url = rtrim(get_option('vosfactures_api_url'), '/');

    if (empty($api_key) || empty($api_url)) {
        wp_send_json_error( array('success' => false, 'message' => 'La clé API ou l\'URL VosFactures n\'est pas configurée.'));
    }

     $contact_data = array(
        'client' => array(
            'name' => trim($form_data['first_name'] . ' ' . $form_data['last_name']),
            'first_name' => $form_data['first_name'],
            'last_name' => $form_data['last_name'],
            'email' => $form_data['email'],
            'street' => $form_data['billing_address_1'],
            'post_code' => $form_data['billing_postcode'],
            'city' => $form_data['billing_city'],
            'country' => $form_data['billing_country'],
            'phone' => $form_data['billing_phone'],
            'tax_no' => $form_data['tax_no'],
            'company'=>$form_data['user_type']=="entreprise"?true: false,
        )
    );
   

    // Envoyer les données à VosFactures
    $endpoint = $vosfactures_id ? "/clients/{$vosfactures_id}.json" : "/clients.json";
    $method = $vosfactures_id ? 'PUT' : 'POST';
    $action =  $vosfactures_id ? 'updated' : "created";

    $response = wp_remote_request($api_url . $endpoint, array(
        'method'      => $method,
        'headers'     => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
        ),
        'body'        => json_encode($contact_data),
        'data_format' => 'body'
    ));

    if (is_wp_error($response)) {
        wp_send_json_error(array('success' => false, 'message' => 'Erreur lors de la connexion à VosFacture.'));
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    if($method=="PUT"&&isset($body['error'])&&$body['error']=="Not Found"){
        $endpoint="/clients.json";
        $responseNew = wp_remote_request($api_url . $endpoint, array(
            'method'      => 'POST',
            'headers'     => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ),
            'body'        => json_encode($contact_data),
            'data_format' => 'body'
        ));

    $body = json_decode(wp_remote_retrieve_body($responseNew), true);
    
    $action =   "created";
    }
    $reponse=[];
        
    if (isset($body['id'])) {
        update_user_meta($form_data['user_id'], 'vosfactures_id', $body['id']);
        
        $reponse=['success' => true, 'message' => 'Utilisateur synchronisé avec succès.','new_id' => $body['id'] ?? null,'action'=>$action];
    } 
    else {
         $reponse=['success' => false, 'message' => 'Erreur lors de la mise à jour de VosFacture.','body'=>$body];
        
    }

    return $reponse;


}


/**
 * [societe_adresseslivraison] affiche les informations de livraison d'une entreprise 
 * @param mixed $atts
 * @return string
 */

function societe_adresseslivraison($atts) {

    wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../global.css');
    wp_enqueue_style('p-style', plugin_dir_url(__FILE__) . './gestion-tiers-front.css');
    ob_start();
    $editIcon=plugin_dir_url(__FILE__) . '../assets/icons/edition.svg';
   // session_start();
    if (!is_user_logged_in()) {
        return '<p>Vous devez être connecté pour accéder à cette page.</p>';
    }

    $hashedId = get_hashed_id_from_url();
    $user_id=null;
    if ($hashedId) {
        $user_id = get_user_id_from_hash($hashedId);
    }

    if ($user_id === null || !get_userdata($user_id)) {
        return '<p>ID utilisateur invalide ou expiré.</p>';
    }

    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $current_user = wp_get_current_user();
    $roles = $current_user->roles;
    $user_crm_can_edit =in_array('utilisateur_crm', $roles)&& is_array($associates_users) && in_array($current_user->ID, $associates_users);
    if (in_array('responsable_crm', $roles) || in_array('administrator', $roles) || $current_user->ID === $user_id||$user_crm_can_edit) {
    $countries = new WC_Countries();
   
   
    $countries_list = $countries->get_countries();
   
    $nom_societe =  get_user_meta($user_id, 'shipping_company', true) ;

    $adresse = get_user_meta($user_id, 'shipping_address_1', true) ;

    $ville =  get_user_meta($user_id, 'shipping_city', true) ;
            

    $code_postal =get_user_meta($user_id, 'shipping_postcode', true) ;

    $pays = get_user_meta($user_id, 'shipping_country', true) ;

    $billing_country = isset($countries_list[$pays]) 
        ? strtoupper($countries_list[$pays]) 
        : $pays;

    $telephone =get_user_meta($user_id, 'shipping_phone', true) ;
    $first_name =get_user_meta($user_id, 'shipping_first_name', true) ;

    $last_name =get_user_meta($user_id, 'shipping_last_name', true);

       
        $prenom_nom = $first_name .' '.$last_name;
        // Charger les pays WooCommerce  
       
    // Construction du champ CP/ville/Pays
    $cp_ville = '';
    if ($code_postal) {
        $cp_ville .= esc_html($code_postal);
    }
    if ($ville) {
        $cp_ville .= ($cp_ville ? ', ' : '') . esc_html($ville);
    }
    if ($billing_country) {
        $cp_ville .= ($cp_ville ? ' ' : '') . '(' . esc_html($billing_country) . ')';
    }
    $telephone = $_POST['shipping_phone']??get_user_meta($user_id, 'shipping_phone', true);
    
    $adresse_complete = trim("$adresse, $code_postal $ville, $billing_country");
    $adresse_link = 'https://www.google.com/maps/search/?api=1&query=' . urlencode($adresse_complete);

    
    $entreprise_affichee = $nom_societe ?: '<i>' . esc_html($prenom_nom) . '</i>';
    
    $user_role = get_userdata($user_id)->roles[0]; 
    

    ?>
    
    <script>
        /*   jQuery(document).ready(function($) {
                $('#livraison_info_edit_btn').click(function() {
                    $('#livraison_info_view').hide();
                    $('#livraison_info_form').show();
                });

                $('#livraison_info_discard_edit').click(function() {
                    $('#livraison_info_view').show();
                    $('#livraison_info_form').hide();
                });

                $('#edit_livraison_info_form').on('submit', function(e) {
                    e.preventDefault();
                    let isValid = true;

                   

                    if (isValid) {
                        var formData = $(this).serializeArray();
                        var formValues = {};

                        formData.forEach(function(item) {
                            formValues[item.name] = item.value;
                        });

                        $.post(ajax_object.ajax_url, {
                            action: 'update_societe_adresseslivraison',
                            security: $('#societe_adress_livraison_security').val(),
                            formData: formData,
                        }, function(response) {
                            console.log('response', response);
                            if (response.success) {
                                $('#livraison_info_update_msg')
                                    .text(response.data.message)
                                    .addClass('text-success')
                                    .removeClass('text-error').fadeIn()
                                    .delay(3000)
                                    .fadeOut(function() {
                                        location.reload();
                                    });
                            } else {
                                $('#livraison_info_update_msg')
                                    .text(response.data.message || 'Une erreur est survenue.')
                                    .removeClass('text-success')
                                    .addClass('text-error')
                                    .fadeIn()
                                    .delay(3000)
                                    .fadeOut(function() {
                                        $('#livraison_info_view').show();
                                        $('#livraison_info_form').hide();
                                    });
                            }
                        }).fail(function() {
                            $('#livraison_info_update_msg')
                                .text('La requête a échoué. Veuillez réessayer.')
                                .removeClass('text-success')
                                .addClass('text-error')
                                .fadeIn()
                                .delay(3000)
                                .fadeOut(function() {
                                    $('#livraison_info_view').show();
                                    $('#livraison_info_form').hide();
                                });
                        });
                    }
                });
            });

    */
    </script>
 
    <div class="livraison_info">
        <p id="livraison_info_update_msg"></p>
        
       <div class="info-view"id="livraison_info_view">
            <p class="sy-crm-core-title-container  <?php echo 'sy_crm_core_role_' . esc_attr($user_role); ?>"> <?php echo ($entreprise_affichee); ?><span class="edit-btn"id='livraison_info_edit_btn' style="display:none;">
            <img src="<?php echo $editIcon ?>"></span></p>
            <a href="<?php echo esc_url($adresse_link); ?>"id="link-adress-livraison" target="_blank">
                <p id="adress-livraison"><?php echo esc_html($adresse); ?></p>
            <p  id="cp-ville-livraison"><?php echo $cp_ville; ?></p>            
            
            </a><p><strong>Contact :</strong> <span id="nom-livraison"><?php echo esc_html($prenom_nom); ?></span></p>
            <p><strong>Téléphone :</strong> <span id="tel-livraison"><a href="tel:<?php echo esc_attr($telephone); ?>"><?php echo esc_html($telephone); ?></a></span></p>
        </div>

        <div class="edit-form" id="livraison_info_form">
            <form method="post"id="edit_livraison_info_form">
                <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>" >
                <div class="info-form-group">
                    <label for="shipping_company" class="label"> Société :</label>
                    <input type="text" id="shipping_company" name="shipping_company" value="<?php echo esc_attr($nom_societe); ?>" >
                </div>
                <div class="info-form-group">
                    <label for="shipping_address_1" class="label">Adresse :</label>
                    <input type="text" id="shipping_address_1"name="shipping_address_1" value="<?php echo esc_attr($adresse); ?>" >
                </div>
                <div class="info-form-group">
                    <label for="shipping_postcode" class="label">CP :</label>
                    <input type="text" id="shipping_postcode"name="shipping_postcode" value="<?php echo esc_attr($code_postal); ?>" >
                </div>
                <div class="info-form-group">
                    <label for="shipping_city" class="label">Ville :</label>
                    <input type="text" id="shipping_city"name="shipping_city" value="<?php echo esc_attr($ville); ?>" >
                </div>
                <div class="info-form-group">
                    <label for="shipping_country" class="label">Pays :</label>
                    <select  id="shipping_country" name="shipping_country">
                        <?php foreach (WC()->countries->get_countries() as $key => $value): ?>
                            <option value="<?php echo esc_attr($key); ?>" <?php echo strtoupper($pays) === strtoupper($value) || strtoupper($pays) === strtoupper($key) ? 'selected' : ''; ?>>
                                <?php echo esc_html($value); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="info-form-group"> 
                    <label for="shipping_last_name" class="label">Nom :</label>
                    <input type="text"id="shipping_last_name" name="shipping_last_name" value="<?php echo esc_attr($first_name); ?>" >
                </div>
                <div class="info-form-group">
                    <label for="shipping_first_name" class="label">Prénom :</label>
                     <input type="text" id="shipping_first_name"name="shipping_first_name" value="<?php echo esc_attr($last_name); ?>" >
                </div>
               <div class="info-form-group">
                    <label for="shipping_phone" class="label">Téléphone :</label>
                     <input type="text" id="shipping_phone"name="shipping_phone" value="<?php echo esc_attr($telephone); ?>" >
                </div>
                <input type="hidden" id="societe_adress_livraison_security"name="security" value="<?php echo wp_create_nonce('update_societe_adresses_livraison_nonce'); ?>">
               
                <div class="btn-container">
                
                <button type="submit" class="submit-btn" name="livraison_info_submit_btn">Enregistrer</button>
                <button type="button" class="discard-btn"id="livraison_info_discard_edit">Annuler</button></div>
            </form>
        </div>
    </div>
   
    <?php
    
    
    
        return ob_get_clean();
    } else {
        return '<p>Vous n\'avez pas les droits de modification pour cet utilisateur.</p>';
    }
  
}
add_shortcode('societe_adresseslivraison', 'societe_adresseslivraison');

function ajax_update_societe_adresseslivraison() {
    // Vérification de la sécurité via nonce
    check_ajax_referer('update_societe_adresses_livraison_nonce', 'security');

    // Vérifie si l'utilisateur est connecté
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Vous devez être connecté pour effectuer cette action.']);
    }
   
    $form_data_raw = $_POST['formData'];
    $form_data = [];

    foreach ($form_data_raw as $item) {
        $form_data[$item['name']] = sanitize_text_field($item['value']);
    }
    $user_id = intval($form_data['user_id']);
    $current_user_id = get_current_user_id();

    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $current_user = wp_get_current_user();
   
    $roles = $current_user->roles;
    $user_crm_can_edit=is_array($associates_users) && in_array($current_user->ID, $associates_users);
    $canEdit=in_array('responsable_crm', $roles) || in_array('administrator', $roles) || $current_user->ID === $user_id||$user_crm_can_edit;
   
    if (!$canEdit)  {
        wp_send_json_error(['message' => 'Vous n\'avez pas la permission de modifier ces informations.']);
    }

    $allowed_fields = [
        'shipping_company',
        'shipping_address_1',
        'shipping_city',
        'shipping_postcode',
        'shipping_country',
        'shipping_phone',
        'shipping_last_name', 
        'shipping_first_name'
    ];

    $data_modified = false;

    // Mise à jour des métadonnées utilisateur
    foreach ($allowed_fields as $field) {
        if (isset($form_data[$field])) {
            $new_value = sanitize_text_field($form_data[$field]);
            $current_value = get_user_meta($user_id, $field, true);

            if ($new_value !== $current_value) {
                update_user_meta($user_id, $field, $new_value);
                $data_modified = true;
            }
        }
    }

    // Enregistrement de la date de modification si des données ont changé
    if ($data_modified) {
        update_user_meta($user_id, 'account_last_modified_date', current_time('mysql'));
        wp_send_json_success(['message' => 'Les informations ont été mises à jour avec succès.']);
    } else {
        wp_send_json_success(['message' => 'Aucune modification détectée.']);
    }

    wp_send_json_error(['message' => 'Erreur lors de la mise à jour des informations.']);
}

add_action('wp_ajax_update_societe_adresseslivraison', 'ajax_update_societe_adresseslivraison');

/**
 * [societe_factinfo] affiche les informations de livraison d'une entreprise 
 * @param mixed $atts
 * @return string
 */

 function societe_factinfo($atts) {

    wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../global.css');
    wp_enqueue_style('p-style', plugin_dir_url(__FILE__) . './gestion-tiers-front.css');
    ob_start();
    $editIcon=plugin_dir_url(__FILE__) . '../assets/icons/edition.svg';
   // session_start();
    if (!is_user_logged_in()) {
        return '<p>Vous devez être connecté pour accéder à cette page.</p>';
    }

    $hashedId = get_hashed_id_from_url();
    $user_id=null;
    if ($hashedId) {
        $user_id = get_user_id_from_hash($hashedId);
    }

    if ($user_id === null || !get_userdata($user_id)) {
        return '<p>ID utilisateur invalide ou expiré.</p>';
    }

    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $current_user = wp_get_current_user();
    $roles = $current_user->roles;
    $user_crm_can_edit =in_array('utilisateur_crm', $roles)&& is_array($associates_users) && in_array($current_user->ID, $associates_users);
    if (in_array('responsable_crm', $roles) || in_array('administrator', $roles) || $current_user->ID === $user_id||$user_crm_can_edit) {
    $countries = new WC_Countries();
   
   
    $countries_list = $countries->get_countries();
   
    $nom_societe =  get_user_meta($user_id, 'billing_company', true);

    $adresse =  get_user_meta($user_id, 'billing_address_1', true);

    $ville = get_user_meta($user_id, 'billing_city', true);

    $code_postal = get_user_meta($user_id, 'billing_postcode', true);

    $pays =get_user_meta($user_id, 'billing_country', true);

    $billing_country = isset($countries_list[$pays]) 
        ? strtoupper($countries_list[$pays]) 
        : $pays;

    $telephone = get_user_meta($user_id, 'billing_phone', true);
    $first_name = get_user_meta($user_id, 'billing_first_name', true);

    $last_name = get_user_meta($user_id, 'billing_last_name', true);
    $billing_email = get_user_meta($user_id, 'billing_email', true);

       
        $prenom_nom = $first_name .' '.$last_name;
        // Charger les pays WooCommerce  
       
    // Construction du champ CP/ville/Pays
    $cp_ville = '';
    if ($code_postal) {
        $cp_ville .= esc_html($code_postal);
    }
    if ($ville) {
        $cp_ville .= ($cp_ville ? ', ' : '') . esc_html($ville);
    }
    if ($billing_country) {
        $cp_ville .= ($cp_ville ? ' ' : '') . '(' . esc_html($billing_country) . ')';
    }
    $telephone =get_user_meta($user_id, 'billing_phone', true);
    
    $adresse_complete = trim("$adresse, $code_postal $ville, $billing_country");
    $adresse_link = 'https://www.google.com/maps/search/?api=1&query=' . urlencode($adresse_complete);

    
    $entreprise_affichee = $nom_societe ?: '<i>' . esc_html($prenom_nom) . '</i>';
    
    $user_role = get_userdata($user_id)->roles[0]; 
    

    ?>
    
    <script>
        /*   jQuery(document).ready(function($) {
                $('#facturation_info_edit_btn').click(function() {
                    $('#facturation_info_view').hide();
                    $('#facturation_info_form').show();
                });

                $('#facturation_info_discard_edit').click(function() {
                    $('#facturation_info_view').show();
                    $('#facturation_info_form').hide();
                });

                $('#edit_facturation_info_form').on('submit', function(e) {
                    e.preventDefault();
                    let isValid = true;

                  

                    if (isValid) {
                        var formData = $(this).serializeArray();
                        var formValues = {};

                        formData.forEach(function(item) {
                            formValues[item.name] = item.value;
                        });

                        $.post(ajax_object.ajax_url, {
                            action: 'update_societe_factinfo',
                            security: $('#societe_adress_facturation_security').val(),
                            formData: formData,
                        }, function(response) {
                            console.log('response', response);
                            if (response.success) {
                                $('#facturation_info_update_msg')
                                    .text(response.data.message)
                                    .addClass('text-success')
                                    .removeClass('text-error').fadeIn()
                                    .delay(3000)
                                    .fadeOut(function() {
                                        location.reload();
                                    });
                            } else {
                                $('#facturation_info_update_msg')
                                    .text(response.data.message || 'Une erreur est survenue.')
                                    .removeClass('text-success')
                                    .addClass('text-error')
                                    .fadeIn()
                                    .delay(3000)
                                    .fadeOut(function() {
                                        $('#facturation_info_view').show();
                                        $('#facturation_info_form').hide();
                                    });
                            }
                        }).fail(function() {
                            $('#facturation_info_update_msg')
                                .text('La requête a échoué. Veuillez réessayer.')
                                .removeClass('text-success')
                                .addClass('text-error')
                                .fadeIn()
                                .delay(3000)
                                .fadeOut(function() {
                                    $('#facturation_info_view').show();
                                    $('#facturation_info_form').hide();
                                });
                        });
                    }
                });
            });
        */

    </script>
 
    <div class="facturation_info">
        <p id="facturation_info_update_msg"></p>
        
       <div class="info-view"id="facturation_info_view">
            <p class="sy-crm-core-title-container  <?php echo 'sy_crm_core_role_' . esc_attr($user_role); ?>"> <?php echo ($entreprise_affichee); ?><span class="edit-btn"id='facturation_info_edit_btn'  style="display:none;">
            <img src="<?php echo $editIcon ?>"></span></p>
            <a href="<?php echo esc_url($adresse_link); ?>"id="link-adress-facturation" target="_blank">
                <p id="adress-facturation"><?php echo esc_html($adresse); ?></p>
            <p  id="cp-ville-facturation"><?php echo $cp_ville; ?></p>            
            
            </a><p><strong>Contact :</strong> <span id="nom-facturation"><?php echo esc_html($prenom_nom); ?></span></p>
            <p><strong>Téléphone :</strong> <span id="tel-facturation"><a href="tel:<?php echo esc_attr($telephone); ?>"><?php echo esc_html($telephone); ?></a></span></p>
            <p><strong>Email :</strong> <span id="tel-facturation"><a href="mailto:<?php echo esc_attr($billing_email); ?>"><?php echo esc_html($billing_email); ?></a></span></p>
        </div>

        <div class="edit-form" id="facturation_info_form">
            <form method="post"id="edit_facturation_info_form">
                <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>" >
                <div class="info-form-group">
                    <label for="billing_company" class="label"> Société :</label>
                    <input type="text" id="billing_company" name="billing_company" value="<?php echo esc_attr($nom_societe); ?>" >
                </div>
                <div class="info-form-group">
                    <label for="billing_address_1" class="label">Adresse :</label>
                    <input type="text" id="billing_address_1"name="billing_address_1" value="<?php echo esc_attr($adresse); ?>" >
                </div>
                <div class="info-form-group">
                    <label for="billing_postcode" class="label">CP :</label>
                    <input type="text" id="billing_postcode"name="billing_postcode" value="<?php echo esc_attr($code_postal); ?>" >
                </div>
                <div class="info-form-group">
                    <label for="billing_city" class="label">Ville :</label>
                    <input type="text" id="billing_city"name="billing_city" value="<?php echo esc_attr($ville); ?>" >
                </div>
                <div class="info-form-group">
                    <label for="billing_country" class="label">Pays :</label>
                    <select  id="billing_country" name="billing_country">
                        <?php foreach (WC()->countries->get_countries() as $key => $value): ?>
                            <option value="<?php echo esc_attr($key); ?>" <?php echo strtoupper($pays) === strtoupper($value) || strtoupper($pays) === strtoupper($key) ? 'selected' : ''; ?>>
                                <?php echo esc_html($value); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="info-form-group"> 
                    <label for="billing_last_name" class="label">Nom :</label>
                    <input type="text"id="billing_last_name" name="billing_last_name" value="<?php echo esc_attr($first_name); ?>" >
                </div>
                <div class="info-form-group">
                    <label for="billing_first_name" class="label">Prénom :</label>
                     <input type="text" id="billing_first_name"name="billing_first_name" value="<?php echo esc_attr($last_name); ?>" >
                </div>
               <div class="info-form-group">
                    <label for="billing_phone" class="label">Téléphone :</label>
                     <input type="text" id="billing_phone"name="billing_phone" value="<?php echo esc_attr($telephone); ?>" >
                </div>
               <div class="info-form-group">
                    <label for="billing_email" class="label">Email :</label>
                     <input type="text" id="billing_email"name="billing_email" value="<?php echo esc_attr($billing_email); ?>" >
                </div>
                <input type="hidden" id="societe_adress_facturation_security"name="security" value="<?php echo wp_create_nonce('update_societe_adresses_facturation_nonce'); ?>">
               
                <div class="btn-container">
                
                <button type="submit" class="submit-btn" name="facturation_info_submit_btn">Enregistrer</button>
                <button type="button" class="discard-btn"id="facturation_info_discard_edit">Annuler</button></div>
            </form>
        </div>
    </div>
   
    <?php
    
    
    
        return ob_get_clean();
    } else {
        return '<p>Vous n\'avez pas les droits de modification pour cet utilisateur.</p>';
    }
  
}
add_shortcode('societe_factinfo', 'societe_factinfo');


function ajax_update_societe_factinfo() {
    // Vérification de la sécurité via nonce
    check_ajax_referer('update_societe_adresses_facturation_nonce', 'security');

    // Vérifie si l'utilisateur est connecté
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Vous devez être connecté pour effectuer cette action.']);
    }
   
    $form_data_raw = $_POST['formData'];
    $form_data = [];

    foreach ($form_data_raw as $item) {
        $form_data[$item['name']] = sanitize_text_field($item['value']);
    }
    $user_id = intval($form_data['user_id']);
    $current_user_id = get_current_user_id();

    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $current_user = wp_get_current_user();
   
    $roles = $current_user->roles;
    $user_crm_can_edit=is_array($associates_users) && in_array($current_user->ID, $associates_users);
    $canEdit=in_array('responsable_crm', $roles) || in_array('administrator', $roles) || $current_user->ID === $user_id||$user_crm_can_edit;
   
    if (!$canEdit) {
             wp_send_json_error(['message' => 'Vous n\'avez pas la permission de modifier ces informations.']);
    }

    $allowed_fields = [
        'billing_company',
        'billing_address_1',
        'billing_city',
        'billing_postcode',
        'billing_country',
        'billing_phone',
        'billing_last_name', 
        'billing_first_name',
        'billing_email', 
    ];

    $data_modified = false;

    // Mise à jour des métadonnées utilisateur
    foreach ($allowed_fields as $field) {
        if (isset($form_data[$field])) {
            $new_value = sanitize_text_field($form_data[$field]);
            $current_value = get_user_meta($user_id, $field, true);

            if ($new_value !== $current_value) {
                update_user_meta($user_id, $field, $new_value);
                $data_modified = true;
            }
        }
    }

    // Enregistrement de la date de modification si des données ont changé
    if ($data_modified) {
        update_user_meta($user_id, 'account_last_modified_date', current_time('mysql'));
        wp_send_json_success(['message' => 'Les informations ont été mises à jour avec succès.']);
    } else {
        wp_send_json_success(['message' => 'Aucune modification détectée.']);
    }

    wp_send_json_error(['message' => 'Erreur lors de la mise à jour des informations.']);
}

add_action('wp_ajax_update_societe_factinfo', 'ajax_update_societe_factinfo');




/**
 * [societe_technique] affiche les informations thecniques d'une entreprise 
 * @param mixed $atts
 * @return string
 */   

    function societe_technique($atts) {

        wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../global.css');
        wp_enqueue_style('p-style', plugin_dir_url(__FILE__) . './gestion-tiers-front.css');
        ob_start();
        $editIcon=plugin_dir_url(__FILE__) . '../assets/icons/edition.svg';
        // session_start();
        if (!is_user_logged_in()) {
            return '<p>Vous devez être connecté pour accéder à cette page.</p>';
        }
    
        $hashedId = get_hashed_id_from_url();
        $user_id=null;
        if ($hashedId) {
            $user_id = get_user_id_from_hash($hashedId);
        }
    
        if ($user_id === null || !get_userdata($user_id)) {
            return '<p>ID utilisateur invalide ou expiré.</p>';
        }
    
        $associates_users = get_user_meta($user_id, 'associer_crm', true);
        $current_user = wp_get_current_user();
        $roles = $current_user->roles;
        $user_crm_can_edit =in_array('utilisateur_crm', $roles)&& is_array($associates_users) && in_array($current_user->ID, $associates_users);
        if (in_array('responsable_crm', $roles) || in_array('administrator', $roles) || $current_user->ID === $user_id||$user_crm_can_edit) {

            $id_facture = $_POST['vosfactures_id']??get_user_meta($user_id, 'vosfactures_id', true);
            $date_creation = get_user_meta($user_id, 'account_creation_date', true);
            $date_creation = $date_creation ? date("d-m-Y H:i:s", strtotime($date_creation)) : '';
        
            $date_update = get_user_meta($user_id, 'account_last_modified_date', true);
            $date_update = $date_update ? date("d-m-Y H:i:s", strtotime($date_update)) : '';
        
            //get_user_meta($user_id, 'last_login', true);
            $publipostage=$_POST['user_mailing']??get_user_meta($user_id, 'user_mailing', true);
            $status=$_POST['user_status']??get_user_meta($user_id, 'user_status', true);
                //$email = get_user_meta($user_id, 'billing_email', true);
            $user_info = get_userdata($user_id);
            $email = $user_info->user_email;
            $roles = array(); 
            $user_roles = $user_info->roles;
            if (in_array('responsable_crm', $user_roles)) {
                $roles=['utilisateur_crm'];
            } elseif (in_array('utilisateur_crm', $user_roles)) {
                $roles=['responsable_crm'];
            } elseif (in_array('tiers', $user_roles) || in_array('prospect', $user_roles) || in_array('customer', $user_roles)) {
                $roles=['utilisateur_crm', 'responsable_crm'];
            }
        $args = array(
            'role__in' => $roles, 
            'exclude' => array($user_id), 
            'fields' => array('ID', 'display_name','email'),
        );
        
        
        $associer_crm = get_user_meta($user_id, 'associer_crm', true);
        
        $users_list = get_users($args);    
            ?>
        
            
        <div class="technical_info">
                
                <p id="techincal_info_update_msg"></p>
                <div class="info-view"id="technical_info_view">
                    <p class="title-vosfactures"><strong>Id vosfactures : </strong> <?php echo esc_html($id_facture); ?><span class="edit-btn"id='technical_info_edit_btn'  style="display:none;">
                    <img src="<?php echo $editIcon ?>"></span></p>
                                
                    <p><strong>Date de création  : </strong> <?php echo esc_html($date_creation); ?></p>
                    <p><strong>Date de mise à jour  : </strong> <?php echo esc_html($date_update ); ?></p>            
                    <p><strong>Publipostage  :</strong> <?php echo esc_html($publipostage === "yes" ? "Oui" : "Non"); ?></p>            
                    <p><strong>Statut du compte client  : </strong> <?php echo esc_html($status === "active" ? "Actif" : "Inactif"); ?></p>            
                    
        
                    <p>  <strong>Tier associé à : </strong></p>  
                    <ul>
                        <?php 
                        if (!empty($associer_crm)) {
                            $associated_users = get_users(array(
                                'include' => $associer_crm,
                                'fields' => array('display_name'),
                            ));
                        
                            echo '<ul>';
                            foreach ($associer_crm as $user) {
                                $user_info = get_userdata($user);
                                $email = $user_info->user_email;
                                
                                echo '<li>' . esc_html($email) . '</li>';
                            }
                            echo '</ul>';
                        }
                            ?>
                            
                            
                        
                    </ul>
                </div>
        
                <div class="edit-form" id="technical_info_form">
                    <form method="post"id="edit_techincal_info_form">
                        <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>" required>
                        <?php if(!in_array('utilisateur_crm', $roles)) :?>
                        <div class="info-form-group">

                            <label for="vosfactures_id" class="label"> vosfactures :</label>
                            <input type="text" id="vosfactures_id" name="vosfactures_id" value="<?php echo esc_attr($id_facture); ?>" required readOnly disabled>
                        </div>
                        <?php endif;?>
                        <div class="info-form-group">
                            <label for="user_mailing" class="label"> Publipostage :</label>
                            <select name="user_mailing" id="user_mailing">
                            <option value="yes" <?php echo $publipostage === "yes" ? "selected" : ""; ?>>Oui</option>
                            <option value="no" <?php echo $publipostage === "no" ? "selected" : ""; ?>>Non</option>
        
                            </select>
                        </div>
                        <div class="info-form-group">
                            <label for="user_status" class="label"> Statut :</label>
                            <select name="user_status" id="user_status">
                            <option value="active" <?php echo $status === "active" ? "selected" : ""; ?>>Actif</option>
                            <option value="inactive" <?php echo $status === "inactive" ? "selected" : ""; ?>>Inactif</option>
        
                            </select>
                        </div>
                        <div class="info-form-group">
                            <label for="associer_crm" class="label">Associé à :</label>
                            <div class="users_list">
                                <?php foreach ($users_list as $user): ?>
                                    <div class="form-group">
                                        <input type="checkbox" 
                                            id="user_<?php echo esc_attr($user->ID); ?>" 
                                            name="associer_crm[]" 
                                            value="<?php echo esc_attr($user->ID); ?>" 
                                            <?php echo (!empty($associer_crm) && in_array($user->ID, $associer_crm)) ? 'checked' : ''; ?>
                                            <?php echo (in_array('utilisateur_crm', $roles)? 'disabled readonly':'') ?>
               
            >
                                        <label for="user_<?php echo esc_attr($user->ID); ?>">
                                            <?php echo esc_html($user->display_name); ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <input type="hidden" id="technical_information_security"name="security" value="<?php echo wp_create_nonce('update_user_technical_information_nonce'); ?>">
                
                        <div class="btn-container">
                        
                        <button type="submit" class="submit-btn" name="technical_info_submit_btn">Enregistrer</button>
                        <button type="button" class="discard-btn"id="technical_info_discard_edit">Annuler</button></div>
                    </form>
                </div>

            <script>
            /*jQuery(document).ready(function($) {
                    $('#technical_info_edit_btn').click(function() {
                        $('#technical_info_view').hide();
                        $('#technical_info_form').show();
                    });

                    $('#technical_info_discard_edit').click(function() {
                        $('#technical_info_view').show();
                        $('#technical_info_form').hide();
                    });

                    $('#edit_techincal_info_form').on('submit', function(e) {
                        e.preventDefault();
                        let isValid = true;

                        $('.text-error').remove();
                        $('#edit_techincal_info_form input:visible, #edit_techincal_info_form select:visible').each(function () {
                            let $input = $(this);
                            if ($input.val().trim() === '') {
                                isValid = false;
                                $input.parent().after('<span class="text-error text-danger">Ce champ est obligatoire.</span>');
                            }
                        });

                        if (isValid) {
                            var formData = $(this).serializeArray();
                            var formValues = {};

                        
                            $.post(ajax_object.ajax_url, {
                                action: 'update_technical_informations',
                                security: $('#technical_information_security').val(),
                                formData: formData,
                            }, function(response) {
                                console.log('response', response);
                                if (response.success) {
                                    $('#techincal_info_update_msg')
                                        .text(response.data.message)
                                        .addClass('text-success')
                                        .removeClass('text-error').fadeIn()
                                        .delay(3000)
                                        .fadeOut(function() {

                                            location.reload();
                                        });
                                } else {
                                    $('#techincal_info_update_msg')
                                        .text(response.data.message || 'Une erreur est survenue.')
                                        .removeClass('text-success')
                                        .addClass('text-error')
                                        .fadeIn()
                                        .delay(3000)
                                        .fadeOut(function() {
                                            $('#technical_info_view').show();
                                            $('#technical_info_form').hide();
                                        });
                                }
                            }).fail(function() {
                                $('#techincal_info_update_msg')
                                    .text('La requête a échoué. Veuillez réessayer.')
                                    .removeClass('text-success')
                                    .addClass('text-error')
                                    .fadeIn()
                                    .delay(3000)
                                    .fadeOut(function() {
                                        $('#technical_info_view').show();
                                        $('#technical_info_form').hide();
                                    });
                            });
                        }
                    });
                });*/

        </script>
    
        </div>
            
            <?php
        
        
        
        return ob_get_clean();
    } 
    else {
        return '<p>Vous n\'avez pas les droits de modification pour cet utilisateur.</p>';
    }
        
        }
add_shortcode('societe_technique', 'societe_technique');

function ajax_update_technical_informations() {
    // Vérification de la sécurité via nonce
    check_ajax_referer('update_user_technical_information_nonce', 'security');

    // Vérifie si l'utilisateur est connecté
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Vous devez être connecté pour effectuer cette action.']);
    }
   
    $form_data_raw = $_POST['formData'];
    $form_data = [];

    foreach ($form_data_raw as $item) {
        if($item['name']=='associer_crm[]'){
            $form_data[$item['name']][] = sanitize_text_field($item['value']);    
        }
        else{

        $form_data[$item['name']] = sanitize_text_field($item['value']);
        }
    }
    $user_id = intval($form_data['user_id']);
    $current_user_id = get_current_user_id();
    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $current_user = wp_get_current_user();
   
    $roles = $current_user->roles;
    $user_crm_can_edit=is_array($associates_users) && in_array($current_user->ID, $associates_users);
    $canEdit=in_array('responsable_crm', $roles) || in_array('administrator', $roles) || $current_user->ID === $user_id||$user_crm_can_edit;
   
    if (!$canEdit) {
        wp_send_json_error(['message' => 'Vous n\'avez pas la permission de modifier ces informations.']);
    }
     $data_modified = false;
    $associer_crm =  $form_data['associer_crm[]'];
                
                    $current_value = get_user_meta($user_id, 'associer_crm', true);
                    if ($associer_crm !== $current_value) {
                        $data_modified = true; 
                        update_user_meta($user_id, 'associer_crm', $associer_crm);
            
                    }   
                
                /*if (isset($_POST['vosfactures_id'])) {
                    $new_value = sanitize_text_field($_POST['vosfactures_id']);
                    $current_value =get_user_meta($user_id, 'vosfactures_id', true);
                    if ($new_value != $current_value) {
                        $data_modified = true; 
                        update_user_meta($user_id,'vosfactures_id',$_POST['vosfactures_id']);
            
                    } 
                    
                }*/
            if (isset($form_data['user_status'])) {
                    $new_value = sanitize_text_field($form_data['user_status']);
                    $current_value =get_user_meta($user_id, 'user_status', true);
                    if ($new_value != $current_value) {
                        $data_modified = true; 
                        update_user_meta($user_id,'user_status',$form_data['user_status']);
            
                    } 
                    
                }
                if (isset($_POST['user_mailing'])) {
                    $new_value = sanitize_text_field($form_data['user_mailing']);
                    $current_value =get_user_meta($user_id, 'user_mailing', true);
                    if ($new_value != $current_value) {
                        $data_modified = true; 
                        update_user_meta($user_id,'user_mailing',$form_data['user_mailing']);
            
                    } 
                    
                }
            



    // Enregistrement de la date de modification si des données ont changé
    if ($data_modified) {
        update_user_meta($user_id, 'account_last_modified_date', current_time('mysql'));
        wp_send_json_success(['message' => 'Les informations ont été mises à jour avec succès.']);
    } else {
        wp_send_json_success(['message' => 'Aucune modification détectée.']);
    }

    wp_send_json_error(['message' => 'Erreur lors de la mise à jour des informations.']);
}

add_action('wp_ajax_update_technical_informations', 'ajax_update_technical_informations');

function gestion_tiers_enqueue_scripts() {
    
    wp_enqueue_script(
        'gestion-tiers-shortcode',
        plugin_dir_url(__FILE__) . 'gestion-tiers-front.js',
        array('jquery'),
        null,
        true
    );
    wp_localize_script(
        'gestion-tiers-shortcode',
        'ajax_object',
        array('ajax_url' => admin_url('admin-ajax.php'))
    );

}
add_action('wp_enqueue_scripts', 'gestion_tiers_enqueue_scripts');
function restrict_crm_tiers_page_access() {
  
    $url=$_SERVER['REQUEST_URI'];
    if (is_page('crm-customer')&&strpos($url, 'vcv-editable') === false) {
        // Vérifier si l'utilisateur est connecté
          if (!is_user_logged_in()) {
            wp_safe_redirect(home_url('/404-not-found'));
            exit;
        }

        
        $hashedId = get_hashed_id_from_url();
        $user_id = $hashedId ? get_user_id_from_hash($hashedId) : null;

        // Vérification si l'utilisateur est valide
        if ($user_id === null || !get_userdata($user_id)) {
            wp_safe_redirect(home_url('/404-not-found'));
            exit;
        }

        // Vérification des droits d'accès
        $associates_users = get_user_meta($user_id, 'associer_crm', true);
        $current_user = wp_get_current_user();
        $roles = $current_user->roles;

        $user_crm_can_edit =in_array('utilisateur_crm', $roles)&& is_array($associates_users) && in_array($current_user->ID, $associates_users);
        if (!in_array('responsable_crm', $roles) && 
            !in_array('administrator', $roles) && 
            $current_user->ID !== $user_id && 
            !$user_crm_can_edit) {

            wp_safe_redirect(home_url('/404-not-found'));
            exit;
        }
    }
    if (is_page('crm-login')&&strpos($url, 'vcv-editable') === false && is_user_logged_in()) {

        wp_safe_redirect(home_url());
        exit;
    }
}

//add_action('template_redirect', 'restrict_crm_tiers_page_access');

?>