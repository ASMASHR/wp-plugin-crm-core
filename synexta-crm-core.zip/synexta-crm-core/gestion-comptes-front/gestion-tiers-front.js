jQuery(document).ready(function($) {
    $('.clickable-row').on('click', function() {
        const userId = $(this).data('id');
        const href = '/crm-customer/' + userId;

        window.location.href = href;
    });
    $('.pagenum').on('click', function(e) {
        e.preventDefault();
        var pageNum = $(this).data('num')
        var params = new URLSearchParams(window.location.search);

        if (pageNum) {
            params.set('page-number', pageNum);
        } else {
            params.delete('page-number');
        }

        var newUrl = window.location.origin + window.location.pathname + '?' + params.toString();
        window.location.href = newUrl;
    });
    // Gestion de la recherche avec le bouton "Filtrer"
    $('#filter-btn').on('click', function(e) {
        e.preventDefault();
        handleFilter();

    });
    $('#quick-filter-input').on('keypress', function(e) {

        if (e.which === 13) {
            handleFilter();
        }
    });

    function handleFilter() {
        var searchTerm = $('#quick-filter-input').val();
        var params = new URLSearchParams(window.location.search);
        params.delete('page-number');

        if (searchTerm) {
            params.set('q', searchTerm);
        } else {
            params.delete('q');
        }

        var newUrl = window.location.origin + window.location.pathname + '?' + params.toString();
        window.location.href = newUrl;
    }

    $('#user-role-filter').on('change', function() {
        var userRole = $(this).val();
        var params = new URLSearchParams(window.location.search);
        params.delete('page-number');
        if (userRole && userRole !== 'all') {
            params.set('user-role', userRole);
        } else {
            params.delete('user-role');
        }

        var newUrl = window.location.origin + window.location.pathname + '?' + params.toString();
        window.location.href = newUrl;
    });

    $('#update-societe-baseinfo-form').on('input', 'input, select', function() {
        $(this).next('.text-error').remove();
    });
    $('#user_type').change(function() {
        if ($(this).val() == 'entreprise') {
            $('#billing_company').attr('readOnly', false).attr('disabled', false);
            $('#tax_no').attr('readOnly', false).attr('disabled', false);

        } else {
            $('#billing_company').attr('readOnly', true).attr('disabled', true);
            $('#tax_no').attr('readOnly', true).attr('disabled', true);
            // $('#tax_no').val('');
            // $('#billing_company').val('');
        }
    });
    $(document).on('click', '.user-tag', function() {
        let userId = $(this).data('id');
        let userName = $(this).text();
        if ($('.users_list').data('edit') == 1) {
            if ($(this).hasClass('selected')) {
                $(this).removeClass('selected');

                $(`#selected-user-tag-${userId}`).remove();
            } else {
                $(this).addClass('selected');

                $('.users_select_list').append(`
                <span class="selected-user-tag" id="selected-user-tag-${userId}" data-id="${userId}">
                    ${userName}
                    <span class="remove-tag" style="margin-left: 5px; cursor: pointer;">&times;</span>
                </span>
            `);
            }
        }

    });

    $(document).on('click', '.remove-tag', function() {
        let userId = $(this).closest('.selected-user-tag').data('id');
        if ($('.users_list').data('edit') == 1) {
            $(this).closest('.selected-user-tag').remove();
            $(`.user-tag[data-id="${userId}"]`).removeClass('selected');
        }

    });

    $(document).on("click", function(e) {
        const isOutsideSidebar = !$(e.target).closest("#edit-info-sidebar").length;
        const isDiscardBtn = $(e.target).is(".sy-crm-core-edit-info-sidebar-discard");
        const isEditBtn = $(e.target).is("#societe_baseinfo_edit_btn");

        setTimeout(function() {
            if ((isOutsideSidebar && !isEditBtn) || isDiscardBtn) {
                $("#edit-info-sidebar").removeClass("open").hide();
            }
        }, 200);
    });

    $('#societe_baseinfo_edit_btn').click(function(e) {
        e.stopPropagation();
        $('#edit-info-sidebar').show().addClass('open');
    });
    $('#update-societe-baseinfo-form').on('submit', function(e) {
        e.preventDefault();
        let isValid = true;

        $('.text-error').remove();

        $('#update-societe-baseinfo-form input:visible:not(:disabled), #update-societe-baseinfo-form select:visible:not(:disabled)').each(function() {
            let $input = $(this);
            const excludedIds = ['url', 'tax_no', 'billing_phone', 'shipping_postcode', 'shipping_last_name', 'shipping_first_name', 'billing_postcode', 'shipping_phone', ];

            if (!excludedIds.includes($input.attr('id')) && $input.val().trim() === '') {
                isValid = false;

                // Ajouter un message d'erreur si le champ est vide
                $input.after('<span class="text-error text-danger">Ce champ est obligatoire.</span>');
            }
        });

        if (isValid) {
            var formData = $(this).serializeArray();
            var formValues = {};
            $('.sy-crm-core-edit-info-sidebar-submit').attr('disabled', true);
            formData.forEach(function(item) {
                formValues[item.name] = item.value;
            });
            let selectedTags = [];
            $('.users_select_list .selected-user-tag').each(function() {
                selectedTags.push($(this).data('id'));

                //formData.push('associer_crm[]', $(this).data('id'));
            });

            // Ajouter les IDs des tags dans les données envoyées
            formData.push({ name: 'associer_crm', value: selectedTags });
            //  console.log(formValues);
            $.post(ajax_object.ajax_url, {
                    action: 'update_user_info',

                    security: $('#societe_baseinfo_security').val(),
                    formData: formData,
                },
                function(response) {
                    if (response.success) {

                        $("#edit-info-sidebar").animate({ scrollTop: 0 }, 500, function() {

                            $('#societe_baseinfo_update_msg')
                                .text(response.data.message)
                                .addClass('text-success')
                                .removeClass('text-error')
                                .fadeIn()
                                .delay(3000)
                                .fadeOut(500, function() {
                                    $("#edit-info-sidebar").removeClass("open").hide();
                                    location.reload();

                                });

                        });
                    } else {
                        $("#edit-info-sidebar").animate({ scrollTop: 0 }, 500, function() {

                            $('#societe_baseinfo_update_msg')
                                .text(response.data.message || 'Une erreur est survenue.')
                                .removeClass('text-success')
                                .addClass('text-error')
                                .fadeIn()
                                .delay(3000)
                                .fadeOut(500, function() {

                                    $("#edit-info-sidebar").removeClass("open").hide();
                                });
                        });
                    }
                }).fail(function() {
                $("#edit-info-sidebar").animate({ scrollTop: 0 }, 500, function() {
                    $('#societe_baseinfo_update_msg')
                        .text('La requête a échoué. Veuillez réessayer.')
                        .removeClass('text-success')
                        .addClass('text-error')
                        .fadeIn()
                        .delay(3000)
                        .fadeOut(500, function() {

                            $("#edit-info-sidebar").removeClass("open").hide();
                        });
                });
            });

        }

    });
    $(".sy-crm-core-info-container").hover(
        function() {
            $(this).find(".sy-crm-core-tooltip-custom").fadeIn(200);
        },
        function() {
            $(this).find(".sy-crm-core-tooltip-custom").fadeOut(200);
        }
    );


});