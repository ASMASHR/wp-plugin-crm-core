<?php
require_once('../../../wp-load.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    wp_die('Méthode non autorisée');
}

if (!is_user_logged_in()) {
    wp_die('Vous devez être connecté pour effectuer cette action.');
}

$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : null;

if (!$user_id || !get_userdata($user_id)) {
    wp_die('ID utilisateur invalide.');
}

/*if (!current_user_can('edit_user', $user_id) && $user_id !== get_current_user_id()) {
    wp_die('Vous n\'avez pas la permission de modifier cet utilisateur.');
}*/
$form_name = isset($_POST['form_name']) ? sanitize_text_field($_POST['form_type']) : null;
if (!$form_name) {
    wp_die('Formulaire non reconnu.');
}
$redirect_url = wp_get_referer();
$status = 'error';
switch ($form_type) {
    case 'societe_baseinfo_edit_form':
        
        
        break;

    case 'form2':
       
        break;

    default:
        wp_die('Type de formulaire inconnu.');
}

// Redirection après la soumission
$redirect_url = add_query_arg('status', 'success', wp_get_referer());
wp_safe_redirect($redirect_url);
exit;
