<?php
// Fichier : regles-utilisateurs.php

add_action('show_user_profile', 'custom_user_profile_fields');
add_action('edit_user_profile', 'custom_user_profile_fields');
add_action('personal_options_update', 'save_custom_user_profile_fields');
add_action('edit_user_profile_update', 'save_custom_user_profile_fields');

function custom_user_profile_fields($user) {
    $current_user = wp_get_current_user();
    $user_roles = $user->roles;

    // Vérifier si le compte utilisateur affiché est l'un des types gérés
    if (in_array('responsable_crm', $user_roles)) {
        show_utilisateur_crm_checklist($user);
    } elseif (in_array('utilisateur_crm', $user_roles)) {
        show_responsable_crm_checklist($user);
    } elseif (in_array('tiers', $user_roles) || in_array('prospect', $user_roles) || in_array('customer', $user_roles)) {
        show_crm_checklist($user, $current_user);
    }
}

function show_utilisateur_crm_checklist($user) {
    // Récupérer tous les utilisateurs de type 'utilisateur_crm'
    $utilisateurs_crm = get_users(array('role' => 'utilisateur_crm'));
    $associer_crm = get_user_meta($user->ID, 'associer_crm', true);
   
   /* echo '<h3>Utilisateurs CRM</h3>';
    echo '<table class="form-table">';
    foreach ($utilisateurs_crm as $crm_user) {
        $checked = get_user_meta($user->ID, 'responsable_crm_for_' . $crm_user->ID, true) ? 'checked' : '';
        $label = esc_html($crm_user->first_name . ' ' . $crm_user->last_name) . ' (' . esc_html($crm_user->user_email) . ')';
        echo '<tr>';
        echo '<th><label>' . $label . '</label></th>';
        echo '<td><input type="checkbox" name="utilisateur_crm[]" value="' . esc_attr($crm_user->ID) . '" ' . $checked . '></td>';
        echo '</tr>';
    }*/
    //associer_crm
    echo '<h3>Utilisateurs CRM</h3>';
    echo '<table class="form-table">';
    foreach ($utilisateurs_crm as $crm_user) {
        $checked = (!empty($associer_crm) && in_array($crm_user->ID, $associer_crm)) ? 'checked' : ''; 
       $label = esc_html($crm_user->first_name . ' ' . $crm_user->last_name) . ' (' . esc_html($crm_user->user_email) . ')';
        echo '<tr>';
        echo '<th><label>' . $label . '</label></th>';
        echo '<td><input type="checkbox" name="associer_crm[]" value="' . esc_attr($crm_user->ID) . '" ' . $checked . '></td>';
        echo '</tr>';
    }
    echo '</table>';
}

function show_responsable_crm_checklist($user) {
    // Récupérer tous les utilisateurs de type 'responsable_crm'
    $responsables_crm = get_users(array('role' => 'responsable_crm'));
    $associer_crm = get_user_meta($user->ID, 'associer_crm', true);
   
    echo '<h3>Responsables CRM</h3>';
    echo '<table class="form-table">';

    $first = true;
    foreach ($responsables_crm as $resp_user) {
        $checked = (!empty($associer_crm) && in_array($resp_user->ID, $associer_crm)) ? 'checked' : ''; 
       $label = esc_html($resp_user->first_name . ' ' . $resp_user->last_name) . ' (' . esc_html($resp_user->user_email) . ')';
        echo '<tr>';
        echo '<th><label>' . $label . '</label></th>';
        echo '<td><input type="checkbox" name="associer_crm[]" value="' . esc_attr($resp_user->ID) . '" ' . $checked . '></td>';
        echo '</tr>';
    
    }
    echo '</table>';
}

function show_crm_checklist($user, $current_user) {
    // Récupérer tous les utilisateurs de type 'utilisateur_crm' et 'responsable_crm'
    $utilisateurs_crm = get_users(array('role' => 'utilisateur_crm'));
    $responsables_crm = get_users(array('role' => 'responsable_crm'));
    $associer_crm = get_user_meta($user->ID, 'associer_crm', true);
    echo '<h3>CRM Associations</h3>';
    echo '<table class="form-table">';

    // Liste des utilisateurs CRM
    foreach ($utilisateurs_crm as $crm_user) {

        $checked = (!empty($associer_crm) && in_array($crm_user->ID, $associer_crm)) ? 'checked' : ''; 
        $label = esc_html($crm_user->first_name . ' ' . $crm_user->last_name) . ' (' . esc_html($crm_user->user_email) . ')';
        echo '<tr>';
        echo '<th><label>' . $label . '</label></th>';
        echo '<td><input type="checkbox" name="associer_crm[]" value="' . esc_attr($crm_user->ID) . '" ' . $checked . '></td>';
        echo '</tr>';
    }

    // Liste des responsables CRM, coché par défaut et non modifiable
    foreach ($responsables_crm as $resp_user) {
       
        $checked = (!empty($associer_crm) && in_array($resp_user->ID, $associer_crm)) ? 'checked' : ''; 
        $label = esc_html($resp_user->first_name . ' ' . $resp_user->last_name) . ' (' . esc_html($resp_user->user_email) . ')';
        echo '<tr>';
        echo '<th><label>' . $label . '</label></th>';
        echo '<td><input type="checkbox" name="associer_crm[]" value="' . esc_attr($resp_user->ID) . '" ' . $checked . '></td>';
        echo '</tr>';
    }
    echo '</table>';
}

function save_custom_user_profile_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    // Supprimer les anciennes associations
    $utilisateurs_crm = get_users(array('role' => 'utilisateur_crm'));
    /*foreach ($utilisateurs_crm as $crm_user) {
        delete_user_meta($user_id, 'responsable_crm_for_' . $crm_user->ID);
    }*/

    // Sauvegarder les nouvelles associations pour les utilisateurs CRM
    /*if (isset($_POST['utilisateur_crm'])) {
        foreach ($_POST['utilisateur_crm'] as $crm_user_id) {
            update_user_meta($user_id, 'responsable_crm_for_' . $crm_user_id, true);
        }
    }*/

    // Sauvegarder les associations pour les responsables CRM
    /*if (isset($_POST['responsable_crm'])) {
        foreach ($_POST['responsable_crm'] as $resp_user_id) {
            update_user_meta($user_id, 'responsable_crm_for_' . $resp_user_id, true);
        }
    }*/
    if (isset($_POST['associer_crm'])) {
        $associer_crm = array_map('intval', $_POST['associer_crm']); 
                
        update_user_meta($user_id, 'associer_crm', $associer_crm);
        }
}
?>
