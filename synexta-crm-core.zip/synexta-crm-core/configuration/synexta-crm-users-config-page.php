<?php 
function crm_core_users_settings(){
?>
<div class="crm-custom-wrap ">
    <div class="custom-tab-container" >
        <a href="#configuration-tags" class="custom-tab custom-tab-users active" data-tab="configuration-tags"><h2>Tag Utilisateurs</h2></a>
        <a href="#configuration-users" class="custom-tab custom-tab-users" data-tab="configuration-users"><h2>Autorisations d’accès</h2></a>

    </div>
    <div class="crm-custom-wrap-right">
        <div id="configuration-tags" class="custom-tab-content  custom-tab-users-content" style="display:block;">
        <?php
        crm_users_tags_page_callback();
        ?>
        </div>
        <div id="configuration-users" class="custom-tab-content  custom-tab-users-content" style="display:none;">
        <?php
        synexta_authorization_settings_page();
        ?>
        </div>


    </div>
</div>
<?php
};


function crm_users_tags_page_callback() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_users_tags';
    $tags = $wpdb->get_results("SELECT * FROM $table_name");
    
    ?>
    <div class="wrap">
        <h1>Gestion des Tags</h1>
        <button id="add-tag-btn" class="add-tag-btn button button-primary"><i class="dashicons dashicons-plus"></i> Ajouter un Tag</button>
        <!-- CodeMirror CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/theme/dracula.min.css">

        <!-- CodeMirror JS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/css/css.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/edit/matchbrackets.min.js"></script>

        <div id="tag-user-form-container" class="tag-form-container hidden">
            <form id="tag-user-form" class="tag-form"novalidate>
                <h2 id="tag-user-form-title">Ajouter un Tag</h2>
                <input type="hidden" id="tag_id" name="id">
                <div class="form-group">
                    <label for="tag_name">Nom du Tag :</label>
                    <input type="text" id="tag_name" name="name" placeholder="Nom du tag" required>
                </div>
                <div class="form-group">
                    <label for="tag_status">État :</label>
                    <select id="tag_status" name="status" class="widefat">
                        <option value="1" selected>Actif</option>
                        <option value="0">Inactif</option>
                    </select>
                </div>
                <div class="form-group">
                <label for="tag_name">Style :</label>
                <div style="width: 71%;">
                    
                <textarea id="tag_user_style" name="style"></textarea>
                </div>
                </div>
                <div id="tag_users_form_msg"></div>
                <div class="form-actions">
                    <button type="submit" id="save-users-tag-btn" class="button button-primary">Enregistrer</button>
                    <button id="cancel-users-tag-btn" class="button">Annuler</button>
                </div>
            </form>
        </div>

        <h2>Liste des Tags</h2>
        <div class="filters">
            <input type="text" id="filter-title" class="widefat" placeholder="Rechercher par titre">
            <select id="filter-status" class="widefat">
                <option value="">Tous</option>
                <option value="1">Actif</option>
                <option value="0">Inactif</option>
            </select>
        </div>
        <div id="tag_table_msg"></div>
        <table class="widefat">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>État</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="tag-list">
                <?php foreach ($tags as $tag) : ?>
                    <tr>
                        <td><span style="<?php echo $tag->tag_style; ?>"><?php echo esc_html($tag->tag_name); ?></span></td>
                        <td><?php echo $tag->status ? 'Actif' : 'Inactif'; ?></td>
                        <td>
                            <button class="button edit-user-tag-btn" data-id="<?php echo $tag->id; ?>" data-name="<?php echo esc_attr($tag->tag_name); ?>"data-style="<?php echo esc_attr($tag->tag_style); ?>" data-status="<?php echo $tag->status; ?>">
                                <i class="dashicons dashicons-edit"></i>
                            </button>
                            <button class="button delete-user-tag-btn" data-id="<?php echo $tag->id; ?>">
                                <i class="dashicons dashicons-trash"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script>
        jQuery(document).ready(function($) {
            var editor = CodeMirror.fromTextArea(document.getElementById("tag_user_style"), {
                mode: "css",
                autocorrect: true
                    //theme: "dracula",
                    // lineNumbers: true,
                    // matchBrackets: true
            });

            const urlParams = new URLSearchParams(window.location.search);
            const tab = urlParams.get('tab');

            if (tab && tab=="configuration-users-tags") {

                $('.nav-tab').removeClass('nav-tab-active');
                        $('.nav-tab[href=\"#tab-users\"]').addClass('nav-tab-active');
                        $('.tab-content').hide();
                        $('#tab-users').show();
                
                        $('.custom-tab-users').removeClass('active');
                        $('.custom-tab-users-content').hide();
                        $('.custom-tab-users[href=\"#configuration-tags\"]').addClass('active');
                        $('#configuration-tags').show();
                        const url = new URL(window.location.href);
                    url.searchParams.delete('tab');
                    window.history.replaceState({}, document.title, url.toString());

            }
            $('#add-tag-btn').click(function() {
                $('#tag_id').val('');
                $('#tag_name').val('');
                $('#tag_user_style').val('');
                $('#tag_status').val('1');
                $('#tag-user-form-title').text('Ajouter un Tag');
                $('#tag-user-form-container').slideDown();
                editor.setValue('');
                $('#tag_users_form_msg').text('');
            });

            $('#cancel-users-tag-btn').click(function() {
                $('#tag-user-form-container').slideUp();
            });

            $('#filter-title, #filter-status').on('input change', function() {
                let title = $('#filter-title').val().toLowerCase();
                let status = $('#filter-status').val();

                $('#tag-list tr').each(function() {
                    let tagName = $(this).find('td:nth-child(2)').text().toLowerCase();
                    let tagStatus = $(this).find('td:nth-child(3)').text().includes('Actif') ? '1' : '0';

                    console.log('dd', tagStatus)
                    if ((title === '' || tagName.includes(title)) && (status === '' || status === tagStatus)) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            });

            $('#tag-user-form').submit(function(e) {
                e.preventDefault();
                $('#tag_users_form_msg').text('');
                let tagId = $('#tag_id').val();
                let tagName = $('#tag_name').val();
                let tagStatus = $('#tag_status').val();
                let tagStyle = editor.getValue();

                if (tagName === '' || tagStyle == "") {
                    $('#tag_users_form_msg').text('Le nom du tag et le style sont requis.').addClass("error-message").removeClass("text-success");
                    return;
                }
                if (tagName.includes(',')) {
                    $('#tag_users_form_msg').text('Le nom du tag ne doit pas contenir de virgule. Veuillez choisir un autre nom.').removeClass("text-success").addClass("error-message");
                    return;
                }
                $('#save-users-tag-btn').prop('disabled', true);

                $.post(ajax_object.ajax_url, { action: "crm_save_users_tag", id: tagId, name: tagName, status: tagStatus, tagStyle: tagStyle }, function(response) {
                    if (response.success) {
                        $('#tag_users_form_msg').text(response.data.message).addClass("text-success").removeClass("error-message").fadeIn().delay(1500).fadeOut(function() {
                            setTimeout(function () {
                                        const url = new URL(window.location.href);
                                        url.searchParams.set('tab', 'configuration-users-tags');
                                        window.location.href = url.toString();
                            })
                        });
                    } else {
                        $('#tag_users_form_msg').text(response.data.message).addClass("error-message");
                        $('#save-users-tag-btn').prop('disabled', false);
                    }
                });
            });

            $(document).on('click', '.edit-user-tag-btn', function() {
                editor.setValue('');
                let previewtimer = null;
                $('#tag_id').val($(this).data('id'));
                $('#tag_name').val($(this).data('name'));
                $('#tag_status').val($(this).data('status'));
                let tagStyle = $(this).data('style');
                //editor.setValue(tagStyle).trigger('focus');
                clearTimeout(previewtimer);
                previewtimer = setTimeout(function() {
                    editor.getDoc().setValue(tagStyle);
                }, 100);
                $('#tag-user-form-title').text('Modifier le Tag');
                $('#tag-user-form-container').slideDown();
            });

            $(document).on('click', '.delete-user-tag-btn', function() {
                if (!confirm('Voulez-vous vraiment supprimer ce tag ?')) return;
                let tagId = $(this).data('id');
                $.post(ajax_object.ajax_url, { action: "crm_delete_users_tag", id: tagId }, function(response) {
                    if (response.success) {
                        $('#tag_table_msg').text(response.data.message).addClass("text-success").fadeIn().delay(1500).fadeOut(function() {
                            const url = new URL(window.location.href);
                                        url.searchParams.set('tab', 'configuration-users-tags');
                                        window.location.href = url.toString();
                            
                        });
                    } else {
                        $('#tag_table_msg').text(response.data.message).addClass("error-message");
                    }
                });
            });
        });
    </script>
    <style>

        .add-tag-btn {
            display: flex !important;
            align-items: center;
            gap: 7px;
            margin: 13px 0px !important;
        }

        .tag-form-container {
            background: #f9f9f9;
            border-radius: 8px;
        }

        .tag-form {
            padding: 15px;
            width: 70%
        }

        .tag-form-container .form-group {
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 7px;
        }

        .tag-form-container .form-group input,
        .tag-form-container .form-group select {
            width: 70% !important;
            max-width: unset !important;
        }

        .tag-form-container .form-group label {
            width: 30% !important;
        }

        .form-actions {
            margin-top: 10px;
        }

        .filters {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }

        .error-message {
            color: red;
        }

        .text-success {
            color: green;
        }
    </style>
    <?php
}



function crm_save_users_tag() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_users_tags';

    if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        crm_users_create_table(); 
        if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            wp_send_json_error(['message' => 'Table creation failed.']);
        }
    }

    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $name = sanitize_text_field($_POST['name']);
    $status = intval($_POST['status']);
    $tagStyle = $_POST['tagStyle'];

    if (!$name) {
        wp_send_json_error(['message' => 'Le nom du tag est requis.']);
    }

    $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE tag_name = %s AND id != %d", $name, $id));
    if ($exists) {
        wp_send_json_error(['message' => 'Ce tag existe déjà.']);
    }

    if ($id) {
        $updated = $wpdb->update($table_name, ['tag_name' => $name, 'status' => $status, 'tag_style' => $tagStyle], ['id' => $id]);
        if ($updated === false) {
            wp_send_json_error(['message' => 'Erreur lors de la mise à jour du tag.']);
        }
        wp_send_json_success(['message' => 'Tag mis à jour.', 'id' => $id]);
    } else {
        $inserted = $wpdb->insert($table_name, ['tag_name' => $name, 'status' => $status, 'tag_style' => $tagStyle]);
        if ($inserted === false) {
            wp_send_json_error(['message' => 'Erreur lors de l\'ajout du tag.']);
        }
        $new_id = $wpdb->insert_id;
        wp_send_json_success(['message' => 'Tag ajouté avec succès.', 'id' => $new_id]);
    }
}
add_action('wp_ajax_crm_save_users_tag', 'crm_save_users_tag');

function crm_delete_users_tag() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_users_tags';

    $id = intval($_POST['id']);
    
    // Suppression du tag dans la table des tags crm_documents
    $deleted = $wpdb->delete($table_name, ['id' => $id]);

    if ($deleted) {
        
        wp_send_json_success(['message' => 'Tag supprimé avec succes.']);
    } else {
        wp_send_json_error(['message' => 'Erreur lors de la suppression du tag.']);
    }
}
add_action('wp_ajax_crm_delete_users_tag', 'crm_delete_users_tag');
