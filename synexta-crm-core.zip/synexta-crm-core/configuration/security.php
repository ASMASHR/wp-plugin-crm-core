<?php
/*
 * security.php
 * 
 * Ce fichier a pour but de renforcer la sécurité de votre site WordPress en implémentant des mesures
 * adaptées à un environnement intranet. Les fonctionnalités ici sont choisies pour garantir que seules
 * les personnes autorisées puissent accéder au site, tout en limitant l'exposition des informations.
 * Ces mesures incluent la désactivation des fonctionnalités inutiles, la sécurisation des connexions,
 * et l'ajout de protections contre les accès non autorisés.
 */

/*
 * Masquer la version de WordPress
 */
add_filter('the_generator', '__return_empty_string');
add_filter('style_loader_src', 'remove_wp_version_from_assets');
add_filter('script_loader_src', 'remove_wp_version_from_assets');

function remove_wp_version_from_assets($src) {
    if (strpos($src, 'ver=' . get_bloginfo('version')))
        $src = remove_query_arg('ver', $src);
    return $src;
}

/*
 * Bloquer l'accès à xmlrpc.php
 */
add_filter('xmlrpc_enabled', '__return_false');
add_action('wp_head', 'remove_xmlrpc_rsd_link');

function remove_xmlrpc_rsd_link() {
    remove_action('wp_head', 'rsd_link');
}

/*
 * Forcer HTTPS
 */
add_action('init', 'force_https');

function force_https() {
    if (!is_ssl()) {
        wp_redirect('https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], 301);
        exit();
    }
}

/*
 * Désactiver la page de réparation
 */
define('WP_ALLOW_REPAIR', false);

/*
 * Filtrer les téléversements
 */
define('ALLOW_UNFILTERED_UPLOADS', false);

/*
 * Connexion sécurisée à l'administration
 */
// define('FORCE_SSL_ADMIN', true);


/*
 * Désactiver et interdire tous les commentaires
 */
add_action('admin_menu', function() {
    remove_menu_page('edit-comments.php');
});
add_action('init', function() {
    remove_post_type_support('post', 'comments');
    remove_post_type_support('page', 'comments');
});
add_filter('comments_open', '__return_false', 20, 2);
add_filter('pings_open', '__return_false', 20, 2);
add_filter('comments_array', '__return_empty_array', 10, 2);

/*
 * Ajouter un Header "No Index"
 */
add_action('send_headers', function() {
    header('X-Robots-Tag: noindex, nofollow', true);
});

/*
 * Limiter l'accès par adresse IP (exemple)
 * 
 * Pour activer cette fonctionnalité, décommentez l'action 'init' ci-dessous.
 * Remplacez les adresses IP dans le tableau $allowed_ips par celles que vous souhaitez autoriser.
 * Par exemple, pour autoriser cinq IP distinctes, vous pouvez utiliser :
 * $allowed_ips = ['192.168.1.1', '192.168.1.2', '192.168.1.3', '192.168.1.4', '192.168.1.5'];
 */
// add_action('init', function() {
//     $allowed_ips = ['192.168.1.1', '192.168.1.2']; // Exemple d'adresses IP autorisées
//     if (!in_array($_SERVER['REMOTE_ADDR'], $allowed_ips)) {
//         wp_die('Access denied');
//     }
// });

/*
 * Désactiver l'API REST pour les utilisateurs non authentifiés
 */
add_filter('rest_authentication_errors', function($result) {
    if (!is_user_logged_in()) {
        return new WP_Error('rest_cannot_access', __('REST API restricted to authenticated users.', 'text-domain'), array('status' => rest_authorization_required_code()));
    }
    return $result;
});

