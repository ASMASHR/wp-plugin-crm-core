<?php
//synexta-crm-logs-page.php
// Fonction pour enregistrer un log
function crm_core_update_logs_option($function_name, $error_message,$responsable_id, $data) {
 
    $logs = get_option('crm_core_logs', []);

    $logs[] = [
        'function' => $function_name,
        'error' => $error_message,
        'responsable_id'=>$responsable_id,
        'data' => maybe_serialize($data), 
        'date' => current_time('mysql'),  
    ];

    update_option('crm_core_logs', $logs);
}

// Fonction pour afficher la page de log (dans le back-office)
function crm_core_logs_page() {
    // On récupère les logs
    $logs = get_option('crm_core_logs', []);
    if (isset($_POST['purge_old_logs'])) {
        crm_core_purge_old_logs();  
        echo '<div class="updated notice"><p>Les anciens logs (plus de 7 jours) ont été supprimés.</p></div>';
      
        $logs = get_option('crm_core_logs', []);
    }

    echo '<div class="wrap"><h1>Logs du plugin CRM Core</h1>';
    echo '<form method="post">';
    echo '<button type="submit" name="purge_old_logs" class="button button-danger" onclick="return confirm(\'Supprimer les logs de plus de 7 jours ?\')">Purger les logs de plus de 7 jours</button>';
    echo '</form>';

    if (empty($logs)) {
        echo '<p>Aucun log enregistré.</p>';
    } else {
        echo '<table class="widefat fixed striped">';
        echo '<thead><tr><th>Déclencheur</th><th>Fonction</th><th>Erreur</th><th>Données</th><th>Date</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            echo '<tr>';
            if (!empty($log['responsable_id'])) {
                $user_info = get_userdata($log['responsable_id']);
                $formatted_Respnsable_nom='';
                if ($user_info) {
                    $responsable_nom = esc_html($user_info->last_name);
                    $responsable_prenom = esc_html($user_info->first_name);
                    $responsable_roles = implode(', ', array_map('esc_html', $user_info->roles));
        
                    $formatted_Respnsable_nom .= $responsable_prenom . ' ' . $responsable_nom . ' (' . $responsable_roles . ')</p>';
                } else {
                    $formatted_Respnsable_nom .= '--';
                }
                echo '<td>' . esc_html($formatted_Respnsable_nom) . '</td>';
           
            }
            else{
                echo '<td>--</td>';
           
            }
            echo '<td>' . esc_html($log['function']) . '</td>';
            echo '<td>' . esc_html($log['error']) . '</td>';
            $data = maybe_unserialize($log['data']);
            $formatted_data = '';
        
            if (is_array($data) && !empty($data)) {
                $formatted_data .= '<ul>';
                foreach ($data as $key => $value) {
                    $formatted_data .= '<li><strong>' . esc_html($key) . '</strong> => ' . esc_html($value) . '</li>';
                }
                $formatted_data .= '</ul>';
            } elseif (!empty($data)) {
                $formatted_data = esc_html($data);
            } else {
                $formatted_data = '<em>--</em>';
            }
        
            echo '<td>' . $formatted_data . '</td>';
             echo '<td>' . esc_html($log['date']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    echo '</div>';
}

// Fonction pour purger les logs de plus de 7 jours
function crm_core_purge_old_logs() {
    $logs = get_option('crm_core_logs', []);
    $filtered_logs = [];

    $seven_days_ago = strtotime('-7 days');

    foreach ($logs as $log) {
        $log_timestamp = strtotime($log['date']);
        if ($log_timestamp >= $seven_days_ago) {
            $filtered_logs[] = $log;
        }
    }

    update_option('crm_core_logs', $filtered_logs);
}
