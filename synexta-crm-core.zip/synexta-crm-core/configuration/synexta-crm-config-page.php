<?php
add_action('admin_menu', 'ajouter_menu_crm');

function ajouter_menu_crm() {
    add_menu_page(
        'CRM', 
        'CRM', 
        'manage_options', 
        'crm-dashboard', 
        '', 
        'dashicons-businessperson', 
        30 
    );
 
    add_submenu_page(
        'crm-dashboard', 
        'Configuration CRM',
        'Configuration', 
        'manage_options', 
        'crm-settings', 
        'page_configuration_crm' 
    );
}
function page_configuration_crm() {
    ?>
  <div class="wrap">
        <h1>CRM Configuration</h1>
        <div class="updated"id="updated-msg"style="display:none"></div>
        <h2 class="nav-tab-wrapper">
        <a href="#tab-crm" class="nav-tab nav-tab-active" style="margin-left: 0px;">Module CRM</a>
        <a href="#tab-users" class="nav-tab">Utilisateurs</a>
            
            <a href="#tab-documents" class="nav-tab">Événements et mails</a>
            
            <a href="#tab-depenses" class="nav-tab">Dépenses</a>
            <a href="#tab-factures" class="nav-tab">Factures</a>
            <?php if (post_type_exists('crm-don')) : ?>
        
                <a href="#tab-dons" class="nav-tab">Dons</a>
                <a href="#tab-logs" class="nav-tab">Logs</a>

        <?php endif; ?>
          </h2>
        <div id="tab-crm" class="tab-content" style="display: block;">
            <?php
            gestioncrm_settings_page();
            ?>
        </div>
        <div id="tab-users" class="tab-content" style="display: none;">
            <?php 
            crm_core_users_settings();
            ?>
            
        </div>
       
        
        <div id="tab-documents" class="tab-content" style="display: none;">
        
        <?php
            crm_events_config_page();
            ?>
        </div>

        <div id="tab-depenses" class="tab-content" style="display: none;">
        
        <?php
            crm_depense_settings_page();
            ?>
        </div>
        <div id="tab-factures" class="tab-content" style="display: none;">
        
        <?php
            crm_factures_settings_page();
            
            ?>
        </div>
        <?php if (post_type_exists('crm-don')) : ?>
        

        <div id="tab-dons" class="tab-content" style="display: none;">
        <?php
            crm_don_settings_page();
            ?>
        </div>
        <?php endif; ?>

        <div id="tab-logs" class="tab-content" style="display: none;">
        <?php
            crm_core_logs_page();
            ?>
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        $('.nav-tab').on('click', function(e) {
            e.preventDefault();

            $('.nav-tab').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');

            var target = $(this).attr('href');
            $('.tab-content').hide();
            $(target).show();
        });
        $('.custom-tab-event').on('click', function(e) {

        e.preventDefault();
        $('.custom-tab-event').removeClass('active');
        var target = $(this).data('tab');

        $('.custom-tab-event-content').hide();
        var $targetContent = $('#' + target);

        $targetContent.show();
        $(this).addClass('active');
    
    });
    $('.custom-tab-crm').on('click', function(e) {

        e.preventDefault();
        $('.custom-tab-crm').removeClass('active');
        var target = $(this).data('tab');

        $('.custom-tab-crm-content').hide();
        var $targetContent = $('#' + target);

        $targetContent.show();
        $(this).addClass('active');

    });
    $('.custom-tab-users').on('click', function(e) {

        e.preventDefault();
        $('.custom-tab-users').removeClass('active');
        var target = $(this).data('tab');

        $('.custom-tab-users-content').hide();
        var $targetContent = $('#' + target);

        $targetContent.show();
        $(this).addClass('active');
    });
    $('.custom-tab-don').on('click', function(e) {

        e.preventDefault();
        $('.custom-tab-don').removeClass('active');
        var target = $(this).data('tab');

        $('.custom-tab-don-content').hide();
        var $targetContent = $('#' + target);

        $targetContent.show();
        $(this).addClass('active');

    });
    $('.custom-tab-factures').on('click', function(e) {
        //
        e.preventDefault();
        $('.custom-tab-factures').removeClass('active');
        var target = $(this).data('tab');

        $('.custom-tab-factures-content').hide();
        var $targetContent = $('#' + target);

        $targetContent.show();
        $(this).addClass('active');

    });
    });
    </script>

    <style>
    
    .tab-content {
        border: 1px solid #ccd0d4;
        padding: 20px 0px 20px 20px;
        background: #fff;
        margin-top: -1px;
    }
    .crm-custom-wrap{
        display: flex;
        
    }
    .crm-custom-wrap-right{
        padding: 15px;
        background-color:#f1f1f1 ;
        width: -webkit-fill-available;
    }
    .custom-tab-container {
    display: flex;
    flex-direction: column;
    max-width: 300px;
    width: 100%;
    }

    .custom-tab {
        display: inline-block;
        padding: 10px 15px;
        background-color: #f1f1f1;
        color: #333;
        text-decoration: none;
        transition: background-color 0.3s;
        
    }
    a.custom-tab:focus {
        box-shadow: unset !important; 
        outline: unset !important; 
    }

    .custom-tab:hover {
        background-color: #e2e2e2;
    }

    .custom-tab.active {
    background-color: #0073aa;
    color: #fff;
   }
   .custom-tab.active  h2{
     color: #fff;
   }

    </style>

    <?php
}


function gestioncrm_settings_page() {
        $memory_limit = ini_get('memory_limit');
        $execution_time = ini_get('max_execution_time');
        $php_version = phpversion();

        $memory_status = intval($memory_limit) < 512 ? '<span style="color:red;">' . $memory_limit . ' (insuffisant, 512Mo recommandé)</span>' : $memory_limit . ' (parfait)';
        $execution_status = intval($execution_time) < 300 ? '<span style="color:red;">' . $execution_time . ' (insuffisant, 300 minimum recommandé)</span>' : $execution_time . ' (parfait)';
        $user_fields=array(
        'user_type' => 'Type',
        'billing_company' => 'Société',
        'tax_no' => 'Identifiant commercial',
        //'last_name' => 'Nom',
        //'first_name' => 'Prénom',
        'role' => 'Rôle',
    // 'email' => 'Email',
        'billing_phone' => 'Téléphone',
        'url' => 'Site web',
        'billing_address_1' => 'Adresse',
        'billing_postcode' => 'CP',
        'billing_city' => 'Ville',
        'billing_country' => 'Pays',
        'shipping_company' => 'Société (livraison)',
        'shipping_address_1' => 'Adresse (livraison)',
        'shipping_last_name' => 'Nom (livraison)',
        'shipping_first_name' => 'Prénom (livraison)',
        'shipping_phone' => 'Télphone (livraison)',
        'shipping_postcode' => 'CP (livraison)',
        'shipping_city' => 'Ville (livraison)',
        'shipping_country' => 'Pays (livraison)',
        'vosfactures_id' => 'Vos factures',
        'user_mailing' => 'Publipostage',
        'user_status' => 'Statut',
        'associer_crm' => 'Associé à CRM',
        );
        $fields_visibility = get_option('crm_user_management_fields_visibility')!=""?get_option('crm_user_management_fields_visibility'):[];
        /*if (isset($_POST['sync_status'])) {
            update_option('vosfactures_sync_enabled', sanitize_text_field($_POST['sync_status']));
            wp_send_json_success();
        } else {
            wp_send_json_error();
    }*/
    ?>
    <style>
        .form-table {
            margin: 20px 0;
            display: flex;
            justify-content: space-between;
        }
        .form-table th {
            text-align: left;
        }
        .button {
            margin: 10px 0;
        }
    </style>
    <div class="crm-custom-wrap ">
    <div class="custom-tab-container">
        <a href="#presentation-crm" class="custom-tab custom-tab-crm active" data-tab="presentation-crm"><h2>Présentation</h2></a>
        <a href="#configuration-crm" class="custom-tab custom-tab-crm" data-tab="configuration-crm"><h2>Configuration</h2></a>
    </div>
    <div class="crm-custom-wrap-right">    
        <div id="presentation-crm" class="custom-tab-content  custom-tab-crm-content" style="display:block;">
        <h1>Présentation du Plugin CRM – Gestion de la Relation Client</h1>

            <p>
                Ce plugin CRM pour WordPress permet de gérer efficacement les relations avec vos clients, prospects, fournisseurs et partenaires. 
                Il propose des fonctionnalités puissantes comme la synchronisation avec <strong>VosFactures</strong>, la gestion des rôles utilisateurs personnalisés, l’affichage dynamique via des shortcodes, et bien plus.
            </p>

            <h2>🚀 Fonctionnalités principales</h2>
            <ul>
                <li><strong>Création et gestion d’utilisateurs CRM</strong> avec rôles personnalisés : <code>utilisateur_crm</code>, <code>responsable_crm</code>, <code>fournisseur</code>, <code>client</code>, <code>tiers</code>, <code>prospect</code></li>
                <li><strong>Ajout de métadonnées utilisateurs</strong> : bio (description), société, statut actif/inactif, etc.</li>
                <li><strong>Synchronisation avec VosFactures</strong> : liaison des utilisateurs avec leur compte, affichage d’informations de facturation, livraison et identifiants externes.</li>
                <li><strong>Affichage dynamique grâce aux shortcodes</strong> : fiches utilisateurs, listes filtrées, formulaires de création, recherches, etc.</li>
            </ul>  

            <h2>🧩 Liste des Shortcodes Disponibles</h2>
            <table class="widefat fixed striped">
                <thead>
                    <tr>
                        <th>Shortcode</th>
                        <th>Description</th>
                        <th>Attributs</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>[connected_user]</code></td>
                        <td>Affiche le nom de l'utilisateur connecté (client actuel).</td>
                        <td>—</td>
                    </tr>
                    <tr>
                        <td><code>[info]</code></td>
                        <td>Affiche les informations de version et auteur du plugin.</td>
                        <td>—</td>
                    </tr>
                    <tr>
                        <td><code>[current-user]</code></td>
                        <td>Avatar + nom de l'utilisateur connecté, avec options de sync si admin/CRM responsable.</td>
                        <td>—</td>
                    </tr>
                    <tr>
                        <td><code>[current]</code></td>
                        <td>Affiche la société ou le nom/prénom du client actuel.</td>
                        <td>—</td>
                    </tr>
                    <tr>
                        <td><code>[compte-id]</code></td>
                        <td>Affiche l’ID du compte VosFactures lié à l’utilisateur.</td>
                        <td>—</td>
                    </tr>
                    <tr>
                        <td><code>[user-bio]</code></td>
                        <td>Affiche la description du client actuel avec la possibilité de la modifier.</td>
                        <td>—</td>
                    </tr>
                
                    <tr>
                        <td><code>[searchbox]</code></td>
                        <td>Champ de recherche pour trouver un utilisateur.</td>
                        <td>—</td>
                    </tr>
                    <tr>
                        <td><code>[user-create]</code></td>
                        <td>Formulaire de création des administrateurs avec rôles personnalisés (responsable_crm, utilisateur_crm).</td>
                        <td>—</td>
                    </tr>
                    <tr>
                        <td><code>[users-list]</code></td>
                        <td>Affiche la liste des administrateurs CRM (responsable_crm, utilisateur_crm).</td>
                        <td>
                            <code>role=""</code> (ex: <code>responsable_crm</code>)<br>
                            <code>count=10</code> (nombre d’utilisateurs à afficher)
                        </td>
                    </tr>
                    <tr>
                        <td><code>[tiers-actifs]</code></td>
                        <td>Affiche la liste des entreprises actives.</td>
                        <td>
                            <code>role=""</code><br>
                            <code>count=10</code>
                        </td>
                    </tr>
                    <tr>
                        <td><code>[tiers-inactifs]</code></td>
                        <td>Affiche la liste des entreprises inactives.</td>
                        <td>
                            <code>role=""</code><br>
                            <code>count=10</code>
                        </td>
                    </tr>
                    <tr>
                        <td><code>[societe_technique]</code></td>
                        <td>Données techniques d’une entreprise : création, mise à jour, publipostage, ID VosFactures…</td>
                        <td>—</td>
                    </tr>
                    <tr>
                        <td><code>[societe_factinfo]</code></td>
                        <td>Affiche les informations de facturation de l’entreprise.</td>
                        <td>—</td>
                    </tr>
                    <tr>
                        <td><code>[societe_adresseslivraison]</code></td>
                        <td>Affiche les adresses de livraison de l’entreprise.</td>
                        <td>—</td>
                    </tr>
                    <tr>
                        <td><code>[societe_baseinfo]</code></td>
                        <td>Affiche les informations de base de l’entreprise avec sidebar de modification.</td>
                        <td>—</td>
                    </tr>
                </tbody>
            </table>


            <h2>📌 Utilisation</h2>
            <p>Ajoutez simplement le shortcode dans une page, un article ou un widget WordPress. Exemple :</p>
            <code>[users-list]</code>

            <h2>🔐 Remarques</h2>
            <ul>
                <li>Les rôles personnalisés s’intègrent au système de rôles WordPress pour contrôler l’accès.</li>
                <li>Les fiches utilisateurs et les actions de modification sont sécurisées selon le rôle connecté.</li>
                <li>Le plugin est pensé pour être extensible et compatible multisite.</li>
            </ul>
        </div>
        <div id="configuration-crm" class="custom-tab-content  custom-tab-crm-content" style="display:none;">

            <h1>Configuration CRM</h1>
            <div class="php-info">
                <p><strong>Memoire Max PHP :</strong> <?php echo $memory_status; ?></p>
                <p><strong>Temps d'exécution Max :</strong> <?php echo $execution_status; ?></p>
                <p><strong>Version PHP :</strong> <?php echo $php_version; ?></p>
            </div>
            <p>Pour obtenir vos informations API et URL de VosFactures, connectez-vous à votre compte VosFactures et accdez à la section API dans les paramètres. Utilisez votre clé API et l'URL de votre compte pour configurer l'accs.</p>
            <form method="post">
                <input type="hidden" name="test_connexion" value="1" />
                <button type="submit" class="button">Test Connexion</button>
            </form>
            <?php
                
                if (isset($_POST['save_vosfacture_info']) && check_admin_referer('save_vosfacture_info_nonce_action')) {
                    update_option('vosfactures_api_key', sanitize_text_field($_POST['vosfactures_api_key']));
                    update_option('vosfactures_api_url', esc_url_raw($_POST['vosfactures_api_url']));
                    update_option('vosfactures_sync_enabled', in_array($_POST['vosfactures_sync_enabled'], ['yes', 'no']) ? $_POST['vosfactures_sync_enabled'] : 'no');

                    echo "<script>
                    jQuery(document).ready(function($) {
                        
                        $('.nav-tab').removeClass('nav-tab-active');
                        $('.nav-tab[href=\"#tab-crm\"]').addClass('nav-tab-active');
                        $('.tab-content').hide();
                        $('#tab-crm').show();
                
                        $('.custom-tab-crm').removeClass('active');
                        $('.custom-tab-crm-content').hide();
                        $('.custom-tab-crm[href=\"#configuration-crm\"]').addClass('active');
                        $('#configuration-crm').show();
                    });
                    </script>";
              
                    echo '<div class="updated"><p>Configuration sauvegardé avec succès.</p></div>';
                  
                }
                //

                           

                ?>
            <form method="post">
                <?php
                settings_fields('gestioncrm-settings-group');
                do_settings_sections('gestioncrm-settings-group');
                ?>
            <?php wp_nonce_field('save_vosfacture_info_nonce_action'); ?>

                <table class="form-table">
                    <tr>
                        <th>API Key</th>
                        <td>
                            <input type="text" name="vosfactures_api_key" value="<?php echo esc_attr(get_option('vosfactures_api_key')); ?>" />
                        </td>
                    </tr>
                    <tr>
                        <th>URL de connexion</th>
                        <td>
                            <input type="text" name="vosfactures_api_url" value="<?php echo esc_attr(get_option('vosfactures_api_url')); ?>" placeholder="https://nomentreprise.vosfactures.fr" />
                        </td>

                    </tr>
                
                    <tr>
                        <th>Synchronisation automatique VosFactures</th>
                        <td>
                            <select name="vosfactures_sync_enabled"style="    width: -webkit-fill-available;">
                                <option value="yes" <?php selected(get_option('vosfactures_sync_enabled'), 'yes'); ?>>Activé</option>
                                <option value="no" <?php selected(get_option('vosfactures_sync_enabled'), 'no'); ?>>Désactivé</option>
                            </select>
                            
                            
                        </td>
                    </tr>    
                    <tr>
                        <td colspan="2">  
                            <p class="sync-disabled">⚠️ Lorsque la synchronisation est désactivée :<br>
                                    - Les tiers créés dans le CRM ne seront pas ajoutés dans VosFactures.<br>
                                    - Les mises à jour des tiers ne seront pas synchronisées.<br>
                                    - La synchronisation des factures entre VosFactures et le CRM sera désactivée.
                                </p></td>
                    </tr>
                </table>
                <button type="submit" class="button-primary"name="save_vosfacture_info">Enregistrer les modifications</button>
            </form>

            <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['test_connexion'])) {
                $api_key = get_option('vosfactures_api_key');
                $api_url = get_option('vosfactures_api_url');
                
                $response = wp_remote_get($api_url, array(
                    'headers' => array(
                        'Authorization' => 'Basic ' . base64_encode($api_key . ':')
                    )
                ));
                
                if (is_wp_error($response)) {
                    echo "<script>
                    jQuery(document).ready(function($) {
                        
                        $('.nav-tab').removeClass('nav-tab-active');
                        $('.nav-tab[href=\"#tab-crm\"]').addClass('nav-tab-active');
                        $('.tab-content').hide();
                        $('#tab-crm').show();
                
                        $('.custom-tab-crm').removeClass('active');
                        $('.custom-tab-crm-content').hide();
                        $('.custom-tab-crm[href=\"#configuration-crm\"]').addClass('active');
                        $('#configuration-crm').show();
                    });
                    </script>";
              
                    echo '<div class="updated"><p>Erreur de connexion : ' . $response->get_error_message() . '</p></div>';
                } else {
                    echo "<script>
                    jQuery(document).ready(function($) {
                        
                        $('.nav-tab').removeClass('nav-tab-active');
                        $('.nav-tab[href=\"#tab-crm\"]').addClass('nav-tab-active');
                        $('.tab-content').hide();
                        $('#tab-crm').show();
                
                        $('.custom-tab-crm').removeClass('active');
                        $('.custom-tab-crm-content').hide();
                        $('.custom-tab-crm[href=\"#configuration-crm\"]').addClass('active');
                        $('#configuration-crm').show();
                    });
                    </script>";
                    echo '<div class="notice notice-success">Connexion russie !</div>';

                    echo '<div class="updated"><p>Connexion russie !</p></div>';
                }
            }
            ?>

            <div class="wrap">
               
                <?php if (get_option('vosfactures_sync_enabled') == 'yes'): ?>
                    <div class="php-info">
                        <button type="button" id="syncho_departements" class="button-primary">Synchroniser les départements</button>
                    </div>
                    <div id="sy-crm-core-config-result"></div>

                    <div id="departements_list">
                        <?php 
                        $departments = get_option('_crm_vosfactures_departments', []);
                        if (!empty($departments)) {
                            echo '<h2>Liste des départements synchronisés :</h2>
                                <table class="widefat"><thead><tr><th>ID</th><th>Nom</th></tr></thead><tbody>';
                            foreach ($departments as $dept) {
                                echo '<tr><td>' . esc_html($dept['id']) . '</td><td>' . esc_html($dept['nom']) . ' (' . esc_html($dept['nom_usage']) . ')</td></tr>';
                            }
                            echo '</tbody></table>';
                        } else {
                            echo '<p>Aucun département synchronisé pour le moment.</p>';
                        }
                        ?>
                    </div>

                    

            <?php else: ?>
                <div id="departements_list">
                    <?php 
                    $departments = get_option('_crm_departements_manuels', []);
                    if (!empty($departments)) {
                        echo '<h2>Liste des départements manuellement ajoutés :</h2>
                        <div style="margin-top: 20px;">
                    <button type="button" id="show_add_form" class="button-primary">Ajouter un département</button>
                </div>

                <div id="form_departement" style="display:none; margin-top: 15px;">
                    <input type="hidden" id="departement_id" />
                    <input type="text" id="departement_nom" placeholder="Nom du département" />
                    <button type="button" id="submit_departement" class="button-secondary">Ajouter</button>
                    <div id="form_resultat" style="margin-top:10px;"></div>
                </div>';
                        echo'
                            <table class="widefat">
                                <thead>
                                    <tr><th>ID</th><th>Nom</th><th>Actions</th></tr>
                                </thead><tbody>';

                        foreach ($departments as $dept) {
                            echo '<tr data-id="' . esc_attr($dept['id']) . '" data-nom="' . esc_attr($dept['nom_usage']) . '">
                                    <td>' . esc_html($dept['id']) . '</td>
                                    <td class="nom-dept">' . esc_html($dept['nom_usage']) . '</td>
                                    <td>
                                        <button class="button edit-dept">Modifier</button>
                                        <button class="button delete-dept">Supprimer</button>
                                    </td>
                                </tr>';
                        }
                        echo '</tbody></table>';
                    } else {
                        echo '<p>Aucun département ajouté pour le moment.</p>';
                    }
                    ?>
                </div>

            <?php endif; ?>



            </div>

            <div class="wrap">
                <h1>Configuration de la visibilité des champs dans la gestion des utilisateur</h1>
                <p>Permet de gérer la visibilité des champs dans le formulaire de gestion des informations utilisateur.</p>
    <?php
    if (isset($_POST['update_crm_user_management_fields_visibility']) ) {
        $cleaned_fields_visibility = array_map('sanitize_text_field', $_POST['crm_user_management_fields_visibility']);
        update_option('crm_user_management_fields_visibility', $cleaned_fields_visibility);

        echo "<script>
        jQuery(document).ready(function($) {
            
            $('.nav-tab').removeClass('nav-tab-active');
            $('.nav-tab[href=\"#tab-crm\"]').addClass('nav-tab-active');
            $('.tab-content').hide();
            $('#tab-crm').show();

            $('.custom-tab-crm').removeClass('active');
            $('.custom-tab-crm-content').hide();
            $('.custom-tab-crm[href=\"#configuration-crm\"]').addClass('active');
            $('#configuration-crm').show();
        });
        </script>";

        echo '<div class="updated"><p>Configuration sauvegardé avec succès.</p></div>';
    
    }?>
                <form method="post">
                    <?php
                    settings_fields('gestioncrm-settings-user-visibility');
                    do_settings_sections('gestioncrm-settings-user-visibility');
                ?>

                    <?php wp_nonce_field('update_crm_user_management_fields_visibility_nonce_action'); ?>
                    <table class="form-table">
                        <tr>
                            <th>Nom du champ</th>
                            <th>Afficher/Masquer</th>
                        </tr>
                        
                        <?php foreach ($user_fields as $field_name => $field_label): ?>
    <tr>
        <td><?php echo esc_html($field_label); ?></td>
        <td>
            <select name="crm_user_management_fields_visibility[<?php echo esc_attr($field_name); ?>]">
                <option value="1" <?php selected($fields_visibility[$field_name] ?? '', 1); ?>>Afficher</option>
                <option value="0" <?php selected($fields_visibility[$field_name] ?? '', 0); ?>>Masquer</option>
            </select>
        </td>
    </tr>
    <?php endforeach; ?>
                        </table>

                        <p class="submit">
                            <button type="submit" class="button-primary" name="update_crm_user_management_fields_visibility">Sauvegarder les modifications</button>
                        </p>
                    </form>
                </div>
            </div>
            <script>
                jQuery(document).ready(function($) {
                    // Lors de la soumission du formulaire
                    ////
                    const urlParams = new URLSearchParams(window.location.search);
                    const tab = urlParams.get('tab');

                    if (tab && tab=="configuration-crm-global") {

                    $('.nav-tab').removeClass('nav-tab-active');
                            $('.nav-tab[href=\"#tab-crm\"]').addClass('nav-tab-active');
                            $('.tab-content').hide();
                            $('#tab-crm').show();
                    
                            $('.custom-tab-crm').removeClass('active');
                            $('.custom-tab-crm-content').hide();
                            $('.custom-tab-crm[href=\"#configuration-crm\"]').addClass('active');
                            $('#configuration-crm').show();
                            const url = new URL(window.location.href);
                        url.searchParams.delete('tab');
                        window.history.replaceState({}, document.title, url.toString());

                    }
                    ////
                    $('#update_crm_user_management_fields_visibility').on('submit', function(e) {
                        e.preventDefault();  // Empêche l'envoi traditionnel du formulaire
                        var fieldsVisibility = {
                            "user_type": $("select[name='user_type']").val(),
                            "billing_company": $("select[name='billing_company']").val(),
                            "tax_no": $("select[name='tax_no']").val(),
                            "last_name": $("select[name='last_name']").val(),
                            "first_name": $("select[name='first_name']").val(),
                            "role": $("select[name='role']").val(),
                            "email": $("select[name='email']").val(),
                            "billing_phone": $("select[name='billing_phone']").val(),
                            "url": $("select[name='url']").val(),
                            "billing_address_1": $("select[name='billing_address_1']").val(),
                            "billing_postcode": $("select[name='billing_postcode']").val(),
                            "billing_city": $("select[name='billing_city']").val(),
                            "billing_country": $("select[name='billing_country']").val(),
                            "shipping_company": $("select[name='shipping_company']").val(),
                            "shipping_address_1": $("select[name='shipping_address_1']").val(),
                            "shipping_last_name": $("select[name='shipping_last_name']").val(),
                            "shipping_first_name": $("select[name='shipping_first_name']").val(),
                            "shipping_phone": $("select[name='shipping_phone']").val(),
                            "shipping_postcode": $("select[name='shipping_postcode']").val(),
                            "shipping_city": $("select[name='shipping_city']").val(),
                            "shipping_country": $("select[name='shipping_country']").val(),
                            "vosfactures_id": $("select[name='vosfactures_id']").val(),
                            "user_mailing": $("select[name='user_mailing']").val(),
                            "user_status": $("select[name='user_status']").val(),
                            "associer_crm": $("select[name='associer_crm']").val()
                        }; var nonce = 'save_crm_user_management_fields_visibility_nonce';
                        var formData = {
                                    action: 'save_crm_user_management_fields_visibility',
                                    data: JSON.stringify({ crm_user_management_fields_visibility: fieldsVisibility }), // Sérialisation en JSON
                                    _wpnonce: '<?php echo wp_create_nonce('save_crm_user_management_fields_visibility_nonce'); ?>'
                                };
                                // Effectuer l'appel AJAX
                        $.ajax({
                            url: ajaxurl,  // L'URL de WordPress pour les requêtes AJAX
                            type: 'POST',
                            data: formData,
                            success: function(response) {
                                // Afficher un message de succès ou d'erreur
                                if (response.success) {
                                    $('#updated-msg').html('<p>Configuration sauvegardé avec succès.</p>').show();
                            $('.nav-tab').removeClass('nav-tab-active');
                        $('.nav-tab[href="#tab-crm"]').addClass('nav-tab-active');
                        $('.tab-content').hide();
                        $('#tab-crm').show();
                
                        $('.custom-tab-crm').removeClass('active');
                        $('.custom-tab-crm-content').hide();
                        $('.custom-tab-crm:last-child').addClass('active');
                        $('#configuration-crm').show();
                    
                                } else {
                                    alert('Une erreur s\'est produite lors de l\'enregistrement.');
                                }
                            },
                            error: function(xhr, status, error) {
                                alert('Erreur AJAX : ' + error);
                            }
                        });
                    });
                

        
                    $('#syncho_departements').on('click', function() {
                            $.ajax({
                                url: ajaxurl,
                                type: 'POST',
                                data: {
                                    action: 'synchro_departements',
                                    api_token: '<?php echo get_option("vosfactures_api_key"); ?>',
                                    api_url: '<?php echo get_option("vosfactures_api_url"); ?>'
                                },
                                success: function(response) {
                                    if (response.success) {
                                        $('#sy-crm-core-config-result').html('<p style="color: green;">Départements synchronisés et sauvegardés.</p>');
                                        setTimeout(function () {
                                            const url = new URL(window.location.href);
                                    url.searchParams.set('tab', 'configuration-crm-global');
                                    window.location.href = url.toString();
                                
                                        }, 500);
                                    } else {
                                        alert('Erreur lors de la synchronisation des départements');
                                    }
                                }
                            });
                        });
                    
                function resetForm() {
                    $('#departement_id').val('');
                    $('#departement_nom').val('');
                    $('#submit_departement').text('Ajouter');
                    $('#form_resultat').html('');
                }

                // Afficher le formulaire d'ajout vide
                    $('#show_add_form').on('click', function() {
                        resetForm();
                        $('#form_departement').slideDown();
                    });

                    // Soumettre le formulaire
                    $('#submit_departement').on('click', function() {
                        const id = $('#departement_id').val();
                        const nom = $('#departement_nom').val().trim();

                        if (!nom) {
                            $('#form_resultat').html('<p style="color:red;">Veuillez entrer un nom.</p>');
                            return;
                        }

                        const action = id ? 'modifier_departement_manuel' : 'ajouter_departement_manuel';
                        const data = { action: action, nom_usage: nom };
                        if (id) data.id = id;

                        $.post(ajaxurl, data, function(response) {
                            if (response.success) {
                                $('#form_resultat').html('<p style="color:green;">' + response.data.message + '</p>');
                                setTimeout(function () {
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('tab', 'configuration-crm-global');
                                    window.location.href = url.toString();
                                            
                    
                                            }, 500); 
                            } else {
                                $('#form_resultat').html('<p style="color:red;">Erreur : ' + response.data.message + '</p>');
                            }
                        });
                    });

                    // Modifier un département
                    $(document).on('click', '.edit-dept', function() {
                        const row = $(this).closest('tr');
                        const id = row.data('id');
                        const nom = row.data('nom');

                        $('#departement_id').val(id);
                        $('#departement_nom').val(nom);
                        $('#submit_departement').text('Modifier');
                        $('#form_resultat').html('');
                        $('#form_departement').slideDown();
                    });

                    // Supprimer un département
                    $(document).on('click', '.delete-dept', function() {
                    const row = $(this).closest('tr');
                    const id = row.data('id');

                    if (confirm("Supprimer ce département ?")) {
                        $.post(ajaxurl, {
                            action: 'supprimer_departement_manuel',
                            id: id
                        }, function(response) {
                            if (response.success) {
                                $('#form_resultat').html('<p style="color:green;">Département supprimé avec succès.</p>');
                            setTimeout(function () {
                                const url = new URL(window.location.href);
                                    url.searchParams.set('tab', 'configuration-crm-global');
                                    window.location.href = url.toString();
                                
                                        }, 500); 
                            } else {
                                alert("Erreur lors de la suppression.");
                            }
                        });
                    }
                });
                });
            </script>
        </div>
    </div>


    <?php
}


add_action('admin_init', 'gestioncrm_register_settings');

function gestioncrm_register_settings() {
    register_setting('gestioncrm-settings-group', 'vosfactures_api_key', 'sanitize_text_field');
    register_setting('gestioncrm-settings-group', 'vosfactures_api_url');
    register_setting('gestioncrm-settings-group', 'vosfactures_sync_enabled');
    register_setting('gestioncrm-settings-user-visibility', 'crm_user_management_fields_visibility');
}

add_action('wp_ajax_synchro_departements', 'synchro_departements_callback');

function synchro_departements_callback() {
    if (isset($_POST['api_token']) && isset($_POST['api_url'])) {
        $api_key = sanitize_text_field($_POST['api_token']);
        $departments_url = rtrim(sanitize_text_field($_POST['api_url']), '/') . "/departments.json?api_token=$api_key"; 
        
        $response = wp_remote_get($departments_url);

        if (!is_wp_error($response)) {
            $departments_data = json_decode(wp_remote_retrieve_body($response), true);
            $departments = [];

            if (!empty($departments_data)) {
                foreach ($departments_data as $dept) {
                    $departments[] = [
                        'id' => $dept['id'],
                        'nom' => $dept['name'],
                        'nom_usage' => $dept['shortcut']
                    ];
                }
                update_option('_crm_vosfactures_departments', $departments);

                
                wp_send_json_success(['departments_html' => 'synchronisation ']);
            } else {
                wp_send_json_error();
            }
        } else {
            wp_send_json_error();
        }
    }
    wp_die();
}
add_action('wp_ajax_ajouter_departement_manuel', 'ajouter_departement_manuel_callback');

function ajouter_departement_manuel_callback() {
    $nom = sanitize_text_field($_POST['nom_usage'] ?? '');
    if (!$nom) {
        wp_send_json_error(['message' => 'Nom invalide.']);
    }

    $departements = get_option('_crm_departements_manuels', []);

    // Vérifier si le nom existe déjà (insensible à la casse)
    foreach ($departements as $dept) {
        if (strtolower($dept['nom_usage']) === strtolower($nom)) {
            wp_send_json_error(['message' => 'Ce département existe déjà.']);
        }
    }

    // Générer un ID unique (auto-incrément basé sur le max ID existant)
    $max_id = 0;
    foreach ($departements as $dept) {
        if ($dept['id'] > $max_id) {
            $max_id = $dept['id'];
        }
    }

    $new_dept = [
        'id' => $max_id + 1,
        'nom_usage' => $nom
    ];

    $departements[] = $new_dept;
    update_option('_crm_departements_manuels', $departements);

    wp_send_json_success(['message' => 'Département ajouté avec succès.', 'departement' => $new_dept]);
}

function supprimer_departement_manuel_callback() {
    $id = intval($_POST['id']);
    $departements = get_option('_crm_departements_manuels', []);
    $departements = array_filter($departements, fn($d) => $d['id'] != $id);
    update_option('_crm_departements_manuels', array_values($departements));
    wp_send_json_success();
}
add_action('wp_ajax_supprimer_departement_manuel', 'supprimer_departement_manuel_callback');

function modifier_departement_manuel_callback() {
    $id = intval($_POST['id']);
    $nom = sanitize_text_field($_POST['nom_usage']);
    $departements = get_option('_crm_departements_manuels', []);
    foreach ($departements as &$d) {
        if ($d['id'] == $id) {
            $d['nom_usage'] = $nom;
            break;
        }
    }
    update_option('_crm_departements_manuels', $departements);
 

    wp_send_json_success(['message' => 'Département modifié avec succès.']);
}
add_action('wp_ajax_modifier_departement_manuel', 'modifier_departement_manuel_callback');
