<?php

// Section 1 : Ajouter une page de menu distincte pour les autorisations d'accès
//add_action('admin_menu', 'synexta_add_authorization_menu');

function synexta_add_authorization_menu() {
    add_menu_page(
        'Autorisations d\'accès', // Titre de la page
        'Autorisations d\'accès', // Titre du menu
        'manage_options', // Capacité requise
        'authorization-settings', // Slug du menu
        'synexta_authorization_settings_page', // Fonction de callback
        'dashicons-lock', // Icône du menu
        81 // Position du menu
    );
}

// Section 2 : Afficher la page de configuration des autorisations
function synexta_authorization_settings_page() {
    $pages = get_pages(); // Récuprer toutes les pages du site
    $not_logged_in_redirect = get_option('synexta_not_logged_in_redirect', home_url('/wp-login.php')); // Option de redirection si pas connecté
    $always_available_pages = get_option('synexta_always_available_pages', []); // Pages toujours disponibles
    $role_redirects = get_option('synexta_role_redirects', []); // Redirections par rôle
    $custom_url = get_option('synexta_custom_url', ''); // URL personnalise

    // Assurer que always_available_pages est un tableau
    if (!is_array($always_available_pages)) {
        $always_available_pages = [];
    }

    if (isset($_POST['update_auth_config']) && check_admin_referer('update_auth_config_nonce_action')) {
        // Sauvegarder les sélections
        $not_logged_in_redirect = sanitize_text_field($_POST['not_logged_in_redirect']);
        $always_available_pages = isset($_POST['always_available_pages']) ? array_map('sanitize_text_field', $_POST['always_available_pages']) : [];
        $role_redirects = [];
        $custom_url = '';

        foreach ($_POST['role_redirects'] as $role => $page_id) {
            $role_redirects[$role] = sanitize_text_field($page_id);
        }

        if ($not_logged_in_redirect === 'other') {
            $custom_url = esc_url_raw($_POST['custom_url']);
            if (filter_var($custom_url, FILTER_VALIDATE_URL) && strpos($custom_url, home_url()) !== false) {
                $not_logged_in_redirect = $custom_url;
            } else {
                $not_logged_in_redirect = sanitize_text_field($_POST['not_logged_in_redirect_page']);
            }
        }

        // Assurer que la page "not_logged_in_redirect" est dans always_available_pages
        if (!in_array($not_logged_in_redirect, $always_available_pages)) {
            $always_available_pages[] = $not_logged_in_redirect;
        }

        update_option('synexta_not_logged_in_redirect', $not_logged_in_redirect);
        update_option('synexta_always_available_pages', $always_available_pages);
        update_option('synexta_role_redirects', $role_redirects);
        update_option('synexta_custom_url', $custom_url);

        echo "<script>
        jQuery(document).ready(function($) {
            
            $('.nav-tab').removeClass('nav-tab-active');
            $('.nav-tab[href=\"#tab-users\"]').addClass('nav-tab-active');
            $('.tab-content').hide();
            $('#tab-users').show();
    
            $('.custom-tab-users').removeClass('active');
            $('.custom-tab-users-content').hide();
            $('.custom-tab-users[href=\"#configuration-users\"]').addClass('active');
            $('#configuration-users').show();
        });
        </script>";
        echo '<div class="updated"><p>Configuration sauvegardé avec succès.</p></div>';
    }

    ?>
    <div class="wrap">
        <h1>Autorisations d'accès</h1>
        <form method="post">

        <?php wp_nonce_field('update_auth_config_nonce_action'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Destination si pas connecté :</th>
                    <td>
                        <select name="not_logged_in_redirect" id="not_logged_in_redirect" onchange="toggleCustomURL()">
                            <option value="other" <?php selected($not_logged_in_redirect, 'other'); ?>>Autre</option>
                            <?php foreach ($pages as $page): ?>
                                <option value="<?php echo esc_attr($page->ID); ?>" <?php selected($not_logged_in_redirect, $page->ID); ?>>
                                    <?php echo esc_html($page->post_title); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <input type="text" name="custom_url" id="custom_url" value="<?php echo esc_attr($custom_url); ?>" style="display:inline;" />
                        <input type="hidden" name="not_logged_in_redirect_page" id="not_logged_in_redirect_page" value="<?php echo esc_attr($not_logged_in_redirect); ?>" />
                        <?php if ($not_logged_in_redirect === 'other' && !empty($custom_url)): ?>
                            <p>URL configurée : <?php echo esc_html($custom_url); ?></p>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Pages toujours disponibles :</th>
                    <td>
                        <?php foreach ($pages as $page): ?>
                            <label>
                                <input type="checkbox" name="always_available_pages[]" value="<?php echo esc_attr($page->ID); ?>"
                                    <?php checked(in_array($page->ID, $always_available_pages)); ?>>
                                <?php echo esc_html($page->post_title); ?>
                            </label><br>
                        <?php endforeach; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Redirection par rôle :</th>
                    <td>
                        <table>
                            <tr>
                                <th>Rôle</th>
                                <th>Redirection</th>
                            </tr>
                            <?php
                            $roles = wp_roles()->get_names();
                            foreach ($roles as $role => $name) {
                                $selected_page = isset($role_redirects[$role]) ? $role_redirects[$role] : '';
                                ?>
                                <tr>
                                    <td><?php echo esc_html($name); ?></td>
                                    <td>
                                        <select name="role_redirects[<?php echo esc_attr($role); ?>]">
                                            <?php if ($role !== 'administrator'): ?>
                                                <option value="no_login" <?php selected($selected_page, 'no_login'); ?>>Ne peut pas se connecter</option>
                                            <?php endif; ?>
                                            <?php foreach ($pages as $page): ?>
                                                <option value="<?php echo esc_attr($page->ID); ?>" <?php selected($selected_page, $page->ID); ?>>
                                                    <?php echo esc_html($page->post_title); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <button type="submit" class="button-primary" name="update_auth_config">Sauvegarder les modifications</button>
            </p>
        </form>
    </div>
    <script type="text/javascript">
        function toggleCustomURL() {
            var select = document.getElementById('not_logged_in_redirect');
            var customURL = document.getElementById('custom_url');
            if (select.value === 'other') {
                customURL.style.display = 'inline';
            } else {
                customURL.style.display = 'none';
            }
        }
    </script>
    <?php
}


// Section 3 : Redirection pour les utilisateurs non connectés
add_action('template_redirect', 'synexta_redirect_non_logged_in_users');

function synexta_redirect_non_logged_in_users() {
    if (!is_user_logged_in()) {
        $not_logged_in_redirect = get_option('synexta_not_logged_in_redirect', '');
        $always_available_pages = get_option('synexta_always_available_pages', []);

        if (!in_array(get_the_ID(), $always_available_pages)) {
            if (!strpos($_SERVER['REQUEST_URI'], 'wp-login.php') && !strpos($_SERVER['REQUEST_URI'], 'wp-admin')) {
                wp_redirect($not_logged_in_redirect);
                exit;
            }
        }
    }
}

// Section 4 : Redirection après connexion
add_action('wp_login', 'synexta_redirect_after_login', 10, 2);

function synexta_redirect_after_login($user_login, $user) {
    $role_redirects = get_option('synexta_role_redirects', []);
    $user_roles = $user->roles;

    foreach ($user_roles as $role) {
        if (isset($role_redirects[$role]) && $role_redirects[$role] === 'no_login') {
            $not_logged_in_redirect = get_option('synexta_not_logged_in_redirect', '');
            wp_redirect($not_logged_in_redirect);
            wp_logout();
            exit;
        } elseif (isset($role_redirects[$role]) && $role_redirects[$role] !== 'no_login') {
            $redirect_page = $role_redirects[$role];
            wp_redirect(get_permalink($redirect_page));
            exit;
        } else {
            // Si le rle n'est pas configuré, rediriger vers la page de destination si pas connecté
            $not_logged_in_redirect = get_option('synexta_not_logged_in_redirect', '');
            wp_redirect($not_logged_in_redirect);
            exit;
        }
    }
}

// Section 5 : Interdire l'accès aux pages wp-admin et wp-login pour les admins connectés
add_action('template_redirect', 'synexta_restrict_admin_access');

function synexta_restrict_admin_access() {
    if (is_user_logged_in() && current_user_can('administrator')) {
        if (strpos($_SERVER['REQUEST_URI'], 'wp-admin') !== false || strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false) {
            wp_redirect(home_url());
            exit;
        }
    }
}

// Section 6 : Interdire la connexion pour les rôles configurés comme "ne peut pas se connecter"
add_action('wp_authenticate', 'synexta_prevent_login', 10, 2);

function synexta_prevent_login($username, $password) {
    $user = get_user_by('login', $username);
    if ($user) {
        $role_redirects = get_option('synexta_role_redirects', []);
        $user_roles = $user->roles;

        foreach ($user_roles as $role) {
            if (isset($role_redirects[$role]) && $role_redirects[$role] === 'no_login') {
                $not_logged_in_redirect = get_option('synexta_not_logged_in_redirect', '');
                wp_redirect($not_logged_in_redirect);
                exit;
            }
        }
    }
}

// Section 7 : Rediriger les utilisateurs non administrateurs vers leur page de redirection après connexion si ils tentent d'accder au dashboard
add_action('template_redirect', 'synexta_restrict_dashboard_access');

function synexta_restrict_dashboard_access() {
    if (is_user_logged_in() && !current_user_can('administrator') && (strpos($_SERVER['REQUEST_URI'], 'wp-admin') !== false || strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false)) {
        $role_redirects = get_option('synexta_role_redirects', []);
        $user_roles = wp_get_current_user()->roles;

        foreach ($user_roles as $role) {
            if (isset($role_redirects[$role]) && $role_redirects[$role] !== 'no_login') {
                $redirect_page = $role_redirects[$role];
                wp_redirect(get_permalink($redirect_page));
                exit;
            } else {
                // Si le rôle n'est pas configuré, rediriger vers la page de destination si pas connecté
                $not_logged_in_redirect = get_option('synexta_not_logged_in_redirect', '');
                wp_redirect($not_logged_in_redirect);
                exit;
            }
        }
    }
}

// Section 8 : Masquer la barre d'administration pour les utilisateurs non administrateurs
add_action('after_setup_theme', 'synexta_hide_admin_bar');

function synexta_hide_admin_bar() {
    if (!current_user_can('administrator') && is_user_logged_in()) {
        show_admin_bar(false);
    }
}

// Section 9 : Rediriger les utilisateurs vers la page définie en "Destination si pas connect" après déconnexion
add_action('wp_logout', 'synexta_redirect_after_logout');

function synexta_redirect_after_logout() {
    $not_logged_in_redirect = get_option('synexta_not_logged_in_redirect', '');
    wp_redirect($not_logged_in_redirect);
    exit;
}

// Section 10 : Déconnecter immédiatement les utilisateurs avec le rôle "ne peut pas se connecter"
add_action('wp_login', 'synexta_disconnect_no_login_role', 10, 2);

function synexta_disconnect_no_login_role($user_login, $user) {
    $role_redirects = get_option('synexta_role_redirects', []);
    $user_roles = $user->roles;

    foreach ($user_roles as $role) {
        if (isset($role_redirects[$role]) && $role_redirects[$role] === 'no_login') {
            wp_logout();
            $not_logged_in_redirect = get_option('synexta_not_logged_in_redirect', '');
            wp_redirect($not_logged_in_redirect);
            exit;
        }
    }
}

// Section 11 : Forcer la déconnexion si l'utilisateur a le rôle "ne peut pas se connecter" lorsqu'il arrive sur la page "pas connecté"
add_action('template_redirect', 'synexta_force_logout_if_no_login_role');

function synexta_force_logout_if_no_login_role() {
    $not_logged_in_redirect = get_option('synexta_not_logged_in_redirect', '');
    $current_page_id = get_the_ID();

    if ($current_page_id == $not_logged_in_redirect && is_user_logged_in()) {
        $role_redirects = get_option('synexta_role_redirects', []);
        $user_roles = wp_get_current_user()->roles;

        foreach ($user_roles as $role) {
            if (isset($role_redirects[$role]) && $role_redirects[$role] === 'no_login') {
                wp_logout();
                exit;
            }
        }
    }
}

// Section 12 : Interdire l'accès à wp-login.php pour les utilisateurs déjà connectés sauf pour la déconnexion
add_action('init', 'block_login_page_except_for_logout');

function block_login_page_except_for_logout() {
    // Vérifie si l'utilisateur est connect et tente d'accéder à wp-login.php sans vouloir se déconnecter
    if (is_user_logged_in() && strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false && !isset($_GET['action']) && $_GET['action'] !== 'logout') {
        wp_redirect(home_url());
        exit;
    }
}
