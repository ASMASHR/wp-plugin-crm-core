jQuery(document).ready(function($) {




    //ajout


    //pieces jointes
    $('#sy-crm-core-depense-generate-btn').click(function() {
        $('#sy-crm-core-depense-sidebar').show().addClass('open')
    })
    $(document).on('change input', 'select:visible, input:visible', function() {
        $(this).next('.text-error').remove();
    });

    $("#file-input").change(function(e) {
        let files = e.target.files;
        let fileListContainer = $("#file-list");

        fileListContainer.empty();
        Array.from(files).forEach(file => {
            let fileReader = new FileReader();
            fileReader.onload = function(e) {
                let fileUrl = e.target.result;
                let fileType = file.type.split('/')[0];

                let fileHtml;
                if (fileType === 'image') {
                    fileHtml = `<div class="file-item"><img src="${fileUrl}" class="file-preview"></div>`;
                } else {
                    fileHtml = `<div class="file-item"><i class="fas fa-file-alt file-icon"></i> ${file.name}</div>`;
                }

                fileListContainer.append(fileHtml);
            };

            fileReader.readAsDataURL(file);
        });
    });
    // Ajouter un produit
    //add-new user 
    $('#search_tiers_btn').click(function() {


    });
    $('#create_new_tiers').click(function() {
        if ($('#new_tier').val() == 0) {
            $('#sy_crm_core_depense_tiers_search,#sy_crm_core_depense_tiers_search_pays').slideUp();

            $('#new_tier_block').slideDown();
            $('#new_tier').val('1');
            $('#tiers_pays').val('FR');
            $('#sy_crm_depense_create_new_tiers_text').text('Recherche')

        } else {
            $('#new_tier_block').slideUp();
            $('#new_tier_block select,#new_tier_block input,#new_tier_block select textarea').val('');

            $('#sy_crm_core_depense_tiers_search,#sy_crm_core_depense_tiers_search_pays').slideDown();

            $('#new_tier').val('0');
            $('#sy_crm_depense_create_new_tiers_text').text('Créer tiers')

        }



    });
    //#sy_crm_core_depense_ajout_produit_btn
    const currency = $('#woo_config').data('currency');
    const currencyPos = $('#woo_config').data('currency-pos');
    const decimalSep = $('#woo_config').data('decimal-sep') || ",";
    const thousandSep = $('#woo_config').data('thousand-sep') || " ";
    const numDecimals = parseInt($('#woo_config').data('num-decimals')) || 2;
    $('#sy_crm_core_depense_ajout_produit_btn').click(function() {
        var clone = $('.sy_crm_core_depense_produit:first').clone();
        clone.append('<button type="button" class="sy-crm-core-depense-button sy-crm-core-remove-produit">Supprimer le produit</button>');
        clone.find('input').val('');
        clone.find('.text-error').remove();

        //clone.find('.produit-select').show();
        // clone.find('.sy-crm-core-depense-product-name').show();
        //clone.find('.nouveau-produit').hide();
        clone.find('textarea').val('');

        clone.find('.nouveau-produit-flag').val('0');
        clone.find('.sy-crm-core-depense-product-id').val('')
        $('#sy_crm_core_depense_produits_list').append(clone);
    });

    function calculateTotal() {
        var totalDepenseHT = 0;
        var totalDepenseTTC = 0;
        $('#sy-crm-core-depense-new-product-table tr').each(function() {
            var totalHT = parseFormattedNumber($(this).find('.total-ht').val()) || 0;
            var totalTTC = parseFormattedNumber($(this).find('.total-TTC').val()) || 0;
            totalDepenseHT += totalHT;
            totalDepenseTTC += totalTTC;
        });
        $('#total_depense_ht').val(formatPrice(totalDepenseHT.toFixed(2)));
        $('#total_depense_ttc').val(formatPrice(totalDepenseTTC.toFixed(2)));
    }

    function formatPrice(value) {
        let originalValue = value;

        value = value.replace(/,/g, '.');
        let number = parseFloat(value);
        if (isNaN(number)) return "";


        return number.toLocaleString('fr-FR', {
                minimumFractionDigits: numDecimals,
                maximumFractionDigits: numDecimals,
                useGrouping: true
            }).replace(/\s/g, thousandSep)
            .replace('.', decimalSep);

    }
    $(document).on('click', '.sy-crm-core-depense-new-produit-btn', function() {
        //sy_crm_core_depense_produit
        var container = $(this).closest('tr');
        $(this).text() === 'Créer?' ? $(this).text('Chercher?') : $(this).text('Créer?');

        //container.find('.nouveau-produit').toggle();
        container.find('.sy-crm-core-depense-product-name').val('');
        container.next().find('.produit-description').val('');

        //container.find('.sy-crm-core-depense-product-name').toggle();
        container.find('.nouveau-produit-flag').val() == '1' ? container.find('.nouveau-produit-flag').val('0') : container.find('.nouveau-produit-flag').val('1');


        container.find('.tva-depense,.quantite,.prix-unitaire,.total-ht,.prix-unitaire-TTC,.total-TTC').val('');
        container.find('.quantite').val(1);
        var tva = container.find('.nouveau-produit-flag').val() == '1' ? container.find('.tva-depense').data('default-val') : '';
        container.find('.tva-depense').val(formatPrice(tva));
    });
    // Supprimer un produit tiers_name
    /*$(document).on('click', '.sy-crm-core-remove-produit', function() {
        if ($('.sy_crm_core_depense_produit').length > 1) {
            $(this).closest('.sy_crm_core_depense_produit').remove();
            calculateTotal();
        }
    });
    $(document).on('click', '.sy_crm-core-depense-new-produit-btn', function() {
        //sy_crm_core_depense_produit
        var container = $(this).closest('tr');

        container.find('.nouveau-produit').toggle();
        container.find('.produit-select').toggle();
        container.find('.nouveau-produit-flag').val() == '1' ? container.find('.nouveau-produit-flag').val('0') : container.find('.nouveau-produit-flag').val('1');


        container.find('.tva-depense,.quantite,.prix-unitaire,.total-ht,.prix-unitaire-TTC,.total-TTC').val('');
    });
   */
    $(document).on('input', '#sy-crm-core-depense-new-tier-entreprise', function() {
        var query = $(this).val();
        var today = new Date();
        var depenseDate = today.getFullYear() + '-' +
            String(today.getMonth() + 1).padStart(2, '0') + '-' +
            String(today.getDate()).padStart(2, '0');


        if (query.length > 3) {
            var docTitle = query + ' - Dépense - ' + depenseDate;
            $('#titre_depense').val(docTitle);
        }
    });
    $('#sy_crm_core_depense_ajout_produit_btn').on('click', function() {
        var $container = $('#produit-container');

        // Cloner la première ligne du produit et de la description
        var $firstProductRow = $container.find('.product-row:first').clone();
        var $firstDescriptionRow = $container.find('.product-description-row:first').clone();

        // Réinitialiser les champs du clone
        $firstProductRow.find('input, select').each(function() {
            if ($(this).attr('type') === "number") {
                $(this).val(1);
            } else {
                $(this).val("");
            }
        });

        $firstDescriptionRow.find("textarea").val("");

        $firstProductRow.find('.sy-crm-core-depense-new-remove-product').show()


        $container.append($firstProductRow);
        $container.append($firstDescriptionRow);
    });

    // Supprimer un produit lorsqu'on clique sur le bouton "-"
    $(document).on('click', '.sy-crm-core-depense-new-remove-product', function() {
        event.stopPropagation();
        var row = $(this).closest('tr');
        var rowIndex = row.index();

        if (rowIndex !== 1) {
            row.next().remove();
            row.remove();
            calculateTotal();
        } else {
            event.preventDefault()
        }
    });


    $(document).on('input', '#tiers_name', function() {
        var query = $(this).val();

        if (query.length > 3) {
            $.ajax({

                url: ajax_object.ajax_url,

                method: 'GET',
                data: {
                    action: 'search_users_data',
                    query: query
                },
                success: function(response) {
                    if (response.success) {
                        var results = response.data;
                        var suggestionsList = $('#sy_crm_core_depense_tiers_suggestions');
                        suggestionsList.empty();

                        if (results.length > 0) {
                            suggestionsList.show();

                            // Ajouter chaque utilisateur à la liste var depenseTitle = $(this).data('');

                            results.forEach(function(user) {
                                suggestionsList.append('<li class="suggestion-item" data-depense-title="' + user.depenseTitle + '"data-id="' + user.tierId + '" data-pays="' + user.tierPays + '">' + user.tierName + '</li>');
                            });
                        } else {
                            suggestionsList.hide(); // Cacher si aucune suggestion
                        }
                    }
                },
                error: function() {
                    console.log('Erreur lors de la récupération des utilisateurs.');
                }
            });
        } else {
            $('#sy_crm_core_depense_tiers_suggestions').hide();
        }
    });
    $(document).click(function(event) {
        if ($('#sy_crm_core_depense_tiers_suggestions').is(':visible')) {
            $('#sy_crm_core_depense_tiers_suggestions').hide();
        }
        if (!$(event.target).closest('#sy-crm-core-depense-generate-btn').length &&
            !$(event.target).closest('#sy-crm-core-depense-sidebar').length &&
            $('#sy-crm-core-depense-sidebar').hasClass('open')) {
            $('#sy-crm-core-depense-sidebar').hide().removeClass('open');
            $('#sy-crm-core-depense-form').find('input,select,textarea').val('');
            $('#sy_crm_core_depense_produits_list').find('.sy_crm_core_depense_produit:not(:first)').remove();

        }

    });

    $(document).on('click', '.discard-add-depense-sidebar', function() {
        $('#sy-crm-core-depense-sidebar').hide().removeClass('open');
        $('#sy-crm-core-depense-form').find('input,select,textarea').val('');
        $('#sy_crm_core_depense_produits_list').find('.sy_crm_core_depense_produit:not(:first)').remove();

    })
    $(document).on('click', '.suggestion-item', function() {
        var tierName = $(this).text();
        var tierId = $(this).data('id');
        var tierPays = $(this).data('pays');
        var depenseTitle = $(this).data('depense-title');

        // Remplir les champs
        $('#tiers_name').val(tierName);
        $('#tiers').val(tierId);
        $('#tiers_pays').val(tierPays);
        $('#titre_depense').val(depenseTitle);


        // Cacher la liste des suggestions après sélection
        $('#sy_crm_core_depense_tiers_suggestions').hide();
    });
    var currentIndex = -1;

    function updateSelectedItem() {
        var suggestionsList = $('#sy_crm_core_depense_tiers_suggestions');
        var suggestionItems = suggestionsList.find('.suggestion-item');

        // Désélectionner tous les éléments
        suggestionItems.removeClass('selected');

        // Sélectionner l'élément actuel
        $(suggestionItems[currentIndex]).addClass('selected');

    }
    $(document).on('keydown', '#tiers_name', function(e) {
        var suggestionsList = $('#sy_crm_core_depense_tiers_suggestions');
        var suggestionItems = suggestionsList.find('.suggestion-item');

        if (suggestionItems.length > 0) {
            if (e.key === 'ArrowDown') {

                currentIndex = Math.min(currentIndex + 1, suggestionItems.length - 1);
                updateSelectedItem();
            } else if (e.key === 'ArrowUp') {

                currentIndex = Math.max(currentIndex - 1, 0);
                updateSelectedItem();
            } else if (e.key === 'Enter') {
                e.preventDefault();
                if (currentIndex >= 0 && currentIndex < suggestionItems.length) {
                    $(suggestionItems[currentIndex]).click();
                }
            }
        }
    });

    //
    $(document).on('input', '.sy-crm-core-depense-product-name', function() {
        var query = $(this).val();
        var container = $(this).closest('tr');
        var $this = $(this);
        var newProductFlag = (container.find('.nouveau-produit-flag')).val()

        if (query.length >= 3 && newProductFlag == 0) {
            $.ajax({
                url: ajax_object.ajax_url,
                method: 'GET',
                data: {
                    action: 'search_product_data',
                    query: query
                },
                success: function(response) {
                    if (response.success) {
                        var results = response.data;
                        var suggestionsList = $this.next('.sy_crm_core_depense_products_suggestions');
                        suggestionsList.empty();

                        if (results.length > 0) {
                            suggestionsList.show();

                            results.forEach(function(product) {
                                // Ajoutez les données nécessaires en tant qu'attributs data-*
                                suggestionsList.append(
                                    '<li class="suggestion-product" ' +
                                    'data-product-id="' + product.product_id + '" ' +
                                    'data-price="' + product.price + '" ' +
                                    'data-description="' + product.description + '" ' +
                                    'data-tva="' + product.tax_rate + '">' +
                                    product.nom +
                                    '</li>'
                                );
                            });
                        } else {
                            suggestionsList.hide();
                        }
                    }
                },
                error: function() {
                    console.log('Erreur lors de la récupération des produits.');
                }
            });
        } else {
            $this.next('.sy_crm_core_depense_products_suggestions').hide();
        }
    });

    $(document).on('click', '.suggestion-product', function() {
        var productId = $(this).data('product-id');
        var price = parseFloat($(this).data('price'));
        var tva = parseFloat($(this).data('tva'));
        var description = $(this).data('description');
        var container = $(this).closest('tr');
        var quantite = container.find('.quantite').val() || 1;

        container.find('.prix-unitaire').val(formatPrice(price.toFixed(2)));
        container.find('.tva-depense').val(formatPrice(tva.toFixed(2)));
        container.find('.sy-crm-core-depense-product-name').val($(this).text());

        var totalHT = price * quantite;
        var totalTTC = totalHT * (1 + tva / 100);

        container.find('.sy-crm-core-depense-product-id').val(productId);
        container.find('.total-ht').val(formatPrice(totalHT.toFixed(2)));
        container.find('.prix-unitaire-TTC').val(formatPrice((price * (1 + tva / 100)).toFixed(2)));
        container.find('.total-TTC').val(formatPrice(totalTTC.toFixed(2)));
        container.next().find('.produit-description').val(description);

        $(this).parent().hide();

        updateTotalPerProduct(container);
    });

    $(document).on('input', '.sy-crm-core-depense-num-val', function() {
            this.value = parseFormattedNumber(this.value.replace(/[^0-9]/g, ''));
        })
        /*$(document).on('change', '.produit-select', function() {
            var selectedOption = $(this).find(':selected');
            var container = $(this).closest('tr');
            //.sy_crm_core_depense_produit
            var price = parseFloat(selectedOption.data('price'));
            var description = selectedOption.data('description') || '';
            var tva = parseFloat(selectedOption.data('tva'));

            container.find('.prix-unitaire').val(formatPrice(price.toFixed(2)));
            container.find('.quantite').val(1);
            container.find('.total-ht').val(formatPrice(price.toFixed(2)));
            //container.find('.product-description').val(description);
            //container.find('.tva-depense').val(tva.toFixed(2));
            container.next().find('.produit-description').val(description);
            container.find('.tva-depense').val(formatPrice(tva.toFixed(2)));


            updateTotalPerProduct(container);
        });*/

    $(document).on('input', '.quantite,.tva-depense', function() {
        var container = $(this).closest('tr');
        updateTotalPerProduct(container);

    });
    $(document).on('input', '.prix-unitaire', function() {
        var container = $(this).closest('tr');
        container.find('.prix-unitaire-TTC,.total-TTC,.total-ht').val('')
        updateTotalPerProduct(container);

    });
    $(document).on('input', '.total-ht', function() {
        var container = $(this).closest('tr');
        container.find('.prix-unitaire-TTC,.total-TTC,.prix-unitaire').val('')
        updateTotalPerProduct(container);

    });
    $(document).on('input', '.prix-unitaire-TTC', function() {
        var container = $(this).closest('tr');
        container.find('.prix-unitaire,.total-ht,.total-TTC').val('')
        updateTotalPerProduct(container);

    });
    $(document).on('input', '.total-TTC', function() {
        var container = $(this).closest('tr');
        container.find('.prix-unitaire,.total-ht,.prix-unitaire-TTC').val('')
        updateTotalPerProduct(container);

    });

    function updateTotalPerProduct(container) {
        var price = parseFormattedNumber(container.find('.prix-unitaire').val()) || 0;
        var quantity = parseFormattedNumber(container.find('.quantite').val()) || 0;
        var tva = parseFormattedNumber(container.find('.tva-depense').val()) || null;
        var totalHT = parseFormattedNumber(container.find('.total-ht').val()) || 0;
        var priceTTC = parseFormattedNumber(container.find('.prix-unitaire-TTC').val()) || 0;

        var totalTTC = parseFormattedNumber(container.find('.total-TTC').val()) || 0;

        if (price && quantity && tva != "") {
            var calculatedTotalHT = price * quantity;
            var calculatedTotalTVA = (calculatedTotalHT * tva) / 100;
            var calculatedTotalTTC = calculatedTotalHT + calculatedTotalTVA;
            var calculatedPriceUnitaireTTC = price * (1 + tva / 100);

            container.find('.total-ht').val(formatPrice(calculatedTotalHT.toFixed(2)));
            container.find('.total-TTC').val(formatPrice(calculatedTotalTTC.toFixed(2)));
            container.find('.prix-unitaire-TTC').val(formatPrice(calculatedPriceUnitaireTTC.toFixed(2)));
        } else if (totalHT && tva && quantity) {
            var calculatedPriceHT = totalHT / quantity;
            container.find('.prix-unitaire').val(formatPrice(calculatedPriceHT.toFixed(2)));

            var calculatedTotalTVA = (totalHT * tva) / 100;
            var calculatedTotalTTC = totalHT + calculatedTotalTVA;
            var calculatedPriceUnitaireTTC = calculatedPriceHT * (1 + tva / 100); // Calcul du prix unitaire TTC

            container.find('.prix-unitaire-TTC').val(formatPrice(calculatedPriceUnitaireTTC.toFixed(2)));
            container.find('.total-TTC').val(formatPrice(calculatedTotalTTC.toFixed(2)));
        } else if (totalTTC && tva && quantity) {
            var calculatedTotalHTFromTTC = totalTTC / (1 + tva / 100);
            var calculatedPriceHTFromTTC = calculatedTotalHTFromTTC / quantity;

            container.find('.prix-unitaire').val(formatPrice(calculatedPriceHTFromTTC.toFixed(2)));
            container.find('.total-ht').val(formatPrice(calculatedTotalHTFromTTC.toFixed(2)));

            var calculatedPriceUnitaireTTC = calculatedPriceHTFromTTC * (1 + tva / 100);
            container.find('.prix-unitaire-TTC').val(formatPrice(calculatedPriceUnitaireTTC.toFixed(2)));
        } else if (priceTTC && quantity && tva) {
            var priceHT = priceTTC / (1 + tva / 100);
            var calculatedTotalHT = priceHT * quantity;
            var calculatedTotalTVA = (calculatedTotalHT * tva) / 100;
            var calculatedTotalTTC = calculatedTotalHT + calculatedTotalTVA;

            container.find('.prix-unitaire').val(formatPrice(priceHT.toFixed(2)));
            container.find('.total-ht').val(formatPrice(calculatedTotalHT.toFixed(2)));
            container.find('.total-TTC').val(formatPrice(calculatedTotalTTC.toFixed(2)));
        } else {}
        calculateTotal();
    }

    function parseFormattedNumber(value) {
        if (!value) return 0;
        value = value.toString();
        value = value.replace(/\s/g, '').replace(',', '.');
        return parseFloat(value) || 0;
    }
    $(document).on('change input', '#sy-crm-core-depense-new-tier-prenom,#sy-crm-core-depense-new-tier-nom,#sy-crm-core-depense-new-tier-entreprise', function() {
        $('#sy-crm-core-depense-tiers-error').empty();
    });



    // Vérifier les champs requis
    $('#sy-crm-core-depense-form').submit(function(e) {
        var isValid = true;
        e.preventDefault();
        $(this).find('.text-error').remove();

        // Validation des champs requis
        $(this).find('select:visible, input:visible').not('#file-input,#sy-crm-core-depense-new-tier-mail,#sy-crm-core-depense-new-tier-civilite,#sy-crm-core-depense-new-tier-phone,#sy-crm-core-depense-new-tier-nom,#sy-crm-core-depense-new-tier-prenom,#sy-crm-core-depense-new-tier-entreprise,#sy-crm-core-depense-new-tier-ville,#sy-crm-core-depense-new-tier-cp,#sy-crm-core-depense-new-tier-adresse,#departement_vendeur').each(function() {
            if (!$(this).val()) {
                isValid = false;
                $(this).after('<span class="text-error">Ce champ est requis.</span>');
            }
        });
        var prenom = $('#sy-crm-core-depense-new-tier-prenom').val();
        var nom = $('#sy-crm-core-depense-new-tier-nom').val();
        var entreprise = $('#sy-crm-core-depense-new-tier-entreprise').val();

        if (($('#new_tier').val() == 1) && (!((prenom && nom) || entreprise))) {
            isValid = false;
            if (!prenom || !nom) {
                $('#sy-crm-core-depense-tiers-error').html('<span class="text-error">Prénom, et nom requis si l\'entreprise n\'est pas fournie.</span>');
            }
            if (!entreprise) {
                $('#sy-crm-core-depense-tiers-error').html('<span class="text-error">Nom de l\'entreprise requis si prénom, et nom ne sont pas fournis.</span>');
            }
        }
        if ($('#departement_vendeur').is('select') && $('#departement_vendeur').val() === '') {
            isValid = false;
            $('#departement_vendeur').after('<span class="text-error">Ce champ est requis.</span>');

        }

        if (!isValid) {
            e.preventDefault();
            return;
        }

        e.preventDefault();

        // Formater les données des produits
        /*var produitsFinal = [];
        $('tr').each(function() {
            var produit = $(this).find('.produit-select').val();
            var nouveauProduitFlag = $(this).find('.nouveau-produit-flag').val();
            var nouveauProduitNom = $(this).find('.nouveau-produit').val();
            var quantite = $(this).find('.quantite').val();
            var prixUnitaire = $(this).find('.prix-unitaire').val();
            var prixUnitaireTTC = $(this).find('.prix-unitaire-TTC').val();
            var tva = $(this).find('.tva-depense').val();
            var totalTTC = $(this).find('.total-TTC').val();
            var totalHt = $(this).find('.total-ht').val();
            var description = $(this).find('.product-description').val();

            produitsFinal.push({
                id: produit,
                nouveau: nouveauProduitFlag,
                nom: nouveauProduitNom,
                prixUnitaire: prixUnitaire,
                prixUnitaireTTC: prixUnitaireTTC,
                quantite: quantite,
                tva: tva,
                totalTTC: totalTTC,
                totalHt: totalHt,
                description: description,
            });
        });*/
        var produitsFinal = [];
        $('#sy-crm-core-depense-new-product-table tbody tr').each(function(index) {
            if (index % 2 == 0) {
                //var produit = $(this).find('.produit-select').val();
                var produit = $(this).find('.sy-crm-core-depense-product-id').val();
                var nouveauProduitFlag = $(this).find('.nouveau-produit-flag').val();
                var nouveauProduitNom = $(this).find('.sy-crm-core-depense-product-name').val();
                var quantite = $(this).find('.quantite').val();
                var prixUnitaire = $(this).find('.prix-unitaire').val();
                var prixUnitaireTTC = $(this).find('.prix-unitaire-TTC').val();
                var tva = $(this).find('.tva-depense').val();
                var totalTTC = $(this).find('.total-TTC').val();
                var totalHt = $(this).find('.total-ht').val();
                //var description = $(this).find('.product-description').val();
                var description = $(this).next().find('.produit-description').val();

                produitsFinal.push({
                    id: produit,
                    nouveau: nouveauProduitFlag,
                    nom: nouveauProduitNom,
                    prixUnitaire: prixUnitaire,
                    prixUnitaireTTC: prixUnitaireTTC,
                    quantite: quantite,
                    tva: tva,
                    totalTTC: totalTTC,
                    totalHt: totalHt,
                    description: description,
                });

            }

        });


        let formData = new FormData();
        formData.append('action', 'crm_sauvegarder_depense');

        formData.append('date_depense', $('#date_depense').val());
        formData.append('tiers', $('#tiers').val());
        formData.append('sy-crm-core-depense-tier-pays', $('#tiers_pays').val());
        formData.append('moyen_reglement', $('#sy-crm-core-depense-new-moyen-reglement').val());
        formData.append('commentaire', $('#sy-crm-core-depense-new-commentaire').val());
        formData.append('total_depense_ht', $('#total_depense_ht').val());
        formData.append('total_depense_ttc', $('#total_depense_ttc').val());
        formData.append('new_tier', $('#new_tier').val());
        if ($('#new_tier').val() == 1) {
            formData.append('sy-crm-core-depense-new-tier-nom', $('#sy-crm-core-depense-new-tier-nom').val());
            formData.append('sy-crm-core-depense-new-tier-civilite', $('#sy-crm-core-depense-new-tier-civilite').val());
            formData.append('sy-crm-core-depense-new-tier-prenom', $('#sy-crm-core-depense-new-tier-prenom').val());
            formData.append('sy-crm-core-depense-new-tier-mail', $('#sy-crm-core-depense-new-tier-mail').val());
            formData.append('sy-crm-core-depense-new-tier-entreprise', $('#sy-crm-core-depense-new-tier-entreprise').val());
            formData.append('sy-crm-core-depense-new-tier-cp', $('#sy-crm-core-depense-new-tier-cp').val());
            formData.append('sy-crm-core-depense-new-tier-ville', $('#sy-crm-core-depense-new-tier-ville').val());
            formData.append('sy-crm-core-depense-new-tier-pays', $('#sy-crm-core-depense-new-tier-pays').val());
            formData.append('sy-crm-core-depense-new-tier-adr', $('#sy-crm-core-depense-new-tier-adresse').val());
            formData.append('sy-crm-core-depense-new-tier-phone', $('#sy-crm-core-depense-new-tier-phone').val());

        }
        formData.append('titre_depense', $('#titre_depense').val());

        formData.append('vendeur', $(this).find('#departement_vendeur').val());

        formData.append('produits', JSON.stringify(produitsFinal));

        let files = $('#file-input')[0].files;
        for (let i = 0; i < files.length; i++) {
            formData.append('pieces_jointes[]', files[i]);
        }

        $.ajax({

            url: ajax_object.ajax_url,
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                if (response.success) {
                    //  alert('Dépense enregistrée avec succès !');
                    // $("#sy-crm-core-depense-form").animate({ scrollTop: 0 }, 500, function() {

                    $('#sy-crm-core-depense-creation-result').html('<p style="color: green;">Dépense créé avec succès.</p>');
                    setTimeout(function() {
                        location.reload();
                    }, 500);

                    // })
                } else {
                    $('#sy-crm-core-depense-creation-result').html('<p style="color: red;">' + response.data.message + '</p>');
                }
            }
        });
    });




});