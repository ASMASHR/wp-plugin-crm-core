<?php

/**
 * Le shortcode [crm_creation_depense] permet de gérer la création de dépenses dans votre CRM intégré à WooCommerce.
 * Si ce shortcode est ajouté sur une fiche tiers, il affiche une sidebar dédiée permettant d'ajouter une dépense pour ce tiers spécifique.
 * Si le shortcode est utilisé en dehors d'une fiche tiers, il propose un formulaire permettant de créer une nouvelle dépense en choisissant un tiers existant.
 * Si le tiers n'existe pas, il permet d'en créer un nouveau de type fournisseur et de lui associer directement la dépense.
 * Si la synchronisation avec VosFactures est activée, le shortcode permet également de créer l'utilisateur sur VosFactures.
 * Si le produit n'existe pas, il offre la possibilité d'ajouter le produit directement via le formulaire de dépense.
 * Ce shortcode est particulièrement utile pour faciliter la gestion des dépenses, optimiser la saisie et assurer une meilleure synchronisation des données avec VosFactures.
 
 **/




// Shortcode [crm_creation_depense]

function crm_creation_depense_shortcode() {

    wp_enqueue_script('depenses-js', plugin_dir_url(__FILE__) . 'depenses.js', array(), '1.0', true);
   // wp_enqueue_style('depenses-css', plugin_dir_url(__FILE__) . '../global.css', array(), '1.0', 'all');

    ob_start();
    $users=[];
    $current_user = wp_get_current_user();
    $roles = $current_user->roles;
//
    $depenseIconUrl=plugin_dir_url(__FILE__) . '../assets/icons/depense.png';

    $addIcon=plugin_dir_url(__FILE__) . '../assets/icons/user.svg';
    $tax_based_on = get_option('woocommerce_tax_based_on'); 
    $countryTva = get_option('woocommerce_default_country'); 
    $tax_rates = WC_Tax::get_rates_for_tax_class( $tax_based_on );
    $tax_rate_found = null;
    foreach ($tax_rates as $rate) {
       if ($rate->tax_rate_country == $countryTva) {
            $tax_rate_found = $rate;
            break;
        }

    } 
    $tax_rate=$tax_rate_found->tax_rate;
    $config = array(
        'currency'        => get_option('woocommerce_currency'), 
        'currency_pos'    => get_option('woocommerce_currency_pos'), 
        'decimal_sep'     => get_option('woocommerce_price_decimal_sep'), 
        'thousand_sep'    => get_option('woocommerce_price_thousand_sep'), 
        'num_decimals'    => get_option('woocommerce_price_num_decimals'), 
    );
    $base_country = WC()->countries->get_base_country()??'FR';  
    if (in_array('administrator', $roles) || in_array('responsable_crm', $roles) || in_array('utilisateur_crm', $roles)) {

        $args = [
            'meta_query' => [
                [
                    'key' => 'user_status',
                    'value' => ['ACTIF', 'actif', 'active'],
                    'compare' => 'IN',
                ],
            ],
            'role__in' =>  ['prospect', 'customer', 'tiers', 'non_qualifie', 'hors_cible'],
           
           'number' =>-1, 
           
            'orderby' => 'user_registered',
            'order' => 'DESC',
        ];
         $users = get_users($args);

        if (in_array('utilisateur_crm', $roles)) {
            $users = array_filter($users, function($user) use ($current_user) {
                $associates_users = get_user_meta($user->ID, 'associer_crm', true);
                return is_array($associates_users) && in_array($current_user->ID, $associates_users);
            });
        }

    } 
    else {
        return '';
    }
    $current_url = $_SERVER['REQUEST_URI'];
    $user_id = null;
    $tiersId=null;
    
    $title="";
    if (strpos($current_url, 'crm-customer/') !== false) {
        $hashedId = get_hashed_id_from_url();
        $user_id = $hashedId ? get_user_id_from_hash($hashedId) : null;
		$tiersId=$user_id;

        $prenom_nom = get_user_meta($user_id, 'last_name', true) . ' ' . get_user_meta($user_id, 'first_name', true);
        $title= $prenom_nom;
        if (!$user_id || !get_userdata($user_id)) {
            return '';
        }
    }

    ?>
    
    
     <?php
        if($tiersId){
           ?>
           <button id="sy-crm-core-depense-generate-btn" class="sy-crm-core-depense-button sy-crm-core-depense-generate-btn" >
                     <img src="<?php echo $depenseIconUrl; ?>" alt="Ajout">
                     <span> Dépense</span>
                </button>
           <div class="sy-crm-core-depense-sidebar"id="sy-crm-core-depense-sidebar" style="display:none;">
            <div class="sy-crm-core-depense-sidebar-header">
             <h5 class="">Ajouter une dépense</h5>
            <button class="sy-crm-core-depense-sidebar-header-btn discard-add-depense-sidebar">X</button>

             </div>
             <?php
        }
             ?>
<form id="sy-crm-core-depense-form" novalidate>
        <div class="sy-crm-core-depense-tiers-section-title">
            <h2>Détails de la Dépense  </h2><?php
            if(!$tiersId){?>
                <button type="button" id="create_new_tiers"class="sy-crm-core-depense-button sy-crm-core-depense-add-tiers">
                    <img src="<?php echo $addIcon; ?>"class="menuicon"><span id="sy_crm_depense_create_new_tiers_text">Créer tiers</span>
                </button>
            <?php }?>
        </div>
        <?php
        if(!$tiersId){
            ?>

    <div class="sy-crm-core-depense-new-tier-block-row" style="display:none;" id="new_tier_block">
        <div class="sy-crm-core-depense-row" >
   
            <input type="hidden" id="new_tier" name="new_tier" value="0">
            <div class="form-group">
                    <label>Civilité : </label>
                    <select name="sy-crm-core-depense-new-tier-civilite" id="sy-crm-core-depense-new-tier-civilite"   >
                            <option value="">--Choisir--</option>
                            <option value="Monsieur">Monsieur</option>
                            <option value="Madame">Madame</option>
                            <option value="Monsieur ou Madame">Monsieur ou Madame</option>
                            <option value="Non binaire">Non binaire</option>
                    </select>
                
                </div>
            <div class="form-group">
                <label>Nom interlocuteur :</label>
                <input type="text" id="sy-crm-core-depense-new-tier-nom" name="sy-crm-core-depense-new-tier-nom" placeholder="" />
            </div>
            <div class="form-group">
                <label>Prénom interlocuteur :</label>
                <input type="text" id="sy-crm-core-depense-new-tier-prenom" name="sy-crm-core-depense-new-tier-prenom" placeholder="" />
            </div>

            <div class="form-group">
                <label>Nom de la société : </label>
                <input type="text" id="sy-crm-core-depense-new-tier-entreprise" name="sy-crm-core-depense-new-tier-entreprise" placeholder="" />
            </div>
            <div class="form-group">
                <label>Email interlocuteur :</label>
                <input type="email" id="sy-crm-core-depense-new-tier-mail" name="sy-crm-core-depense-new-tier-mail" placeholder="" />
            </div>

            <div class="form-group">
                <label>Téléphone interlocuteur :</label>
                <input type="text" id="sy-crm-core-depense-new-tier-phone" name="sy-crm-core-depense-new-tier-phone" placeholder="" />
            </div>
        </div>

        <div id="sy-crm-core-depense-tiers-error"class="sy-crm-core-depense-row"></div>
        
        
        <div class="sy-crm-core-depense-row" >

            <div class="form-group">
                <label>Code postal :</label>
                <input type="text" id="sy-crm-core-depense-new-tier-cp" name="sy-crm-core-depense-new-tier-cp" placeholder="" />
            </div>
            <div class="form-group">
                <label>Ville :</label>
                <input type="text" id="sy-crm-core-depense-new-tier-ville" name="sy-crm-core-depense-new-tier-ville" placeholder="" />
            </div>
            <div class="form-group">
                <label>Pays :</label>
                <select name="sy-crm-core-depense-new-tier-pays" id="sy-crm-core-depense-new-tier-pays" required>
                    <?php
                    $countries = WC()->countries->get_countries();
                    foreach ($countries as $code => $country) {
                        $selected = ($code === $base_country) ? 'selected' : '';
                        echo '<option value="' . esc_attr($code) . '" ' . $selected . '>' . esc_html($country) . '</option>';
                    }
                    ?>
                </select>
            </div>
        </div>
        <div class="sy-crm-don-row">
            <div class="form-group form-group-comments">
                <label>Adresse :</label>
                <textarea id="sy-crm-core-depense-new-tier-adresse" ></textarea>
            </div>
        </div>
    </div>
    <?php 
        }
    ?>

        <div class="sy-crm-core-depense-row">
            <?php
            if($tiersId){
                $tiersPays=  get_user_meta($tiersId, 'billing_country',true);
                ?>

                <input type="hidden" id="tiers" name="tiers" value="<?php echo $tiersId ;?>">
                <input type="hidden" name="pays" id="tiers_pays" value="<?php echo $tiersPays ;?>"required>
                <?php
            }
            else{

            

            ?>
            <div class="form-group" id="sy_crm_core_depense_tiers_search">
                <label>Tiers :</label>
                <div class="sy_crm_core_depense_tiers_search_container">
                    <input type="text" id="tiers_name" name="tiers_name" placeholder="Tiers" />
                    <ul id="sy_crm_core_depense_tiers_suggestions" class="sy_crm_core_depense_tiers_search_container_result"></ul>
                </div>
                <input type="hidden" id="tiers" name="tiers">
            </div>
            <div class="form-group" id="sy_crm_core_depense_tiers_search_pays">
                <label>Pays :</label>
                <select name="pays" id="tiers_pays" required>
                    <option value="">Sélectionner</option>
                    <?php
                    $countries = WC()->countries->get_countries();
                    foreach ($countries as $code => $country) {
                        $selected = ($code === $base_country) ? 'selected' : '';
                        echo '<option value="' . esc_attr($code) . '" ' . $selected . '>' . esc_html($country) . '</option>';
                    }
                    ?>
                </select>
            </div>

            <?php
            }

            
            ?>
            <div class="form-group">
                <label>Date de dépense :</label>
                <input type="date" name="date_depense" id="date_depense" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group sy_crm_core_depense_group_price">
                <label>Moyen de règlement :</label>
                <select name="moyen_reglement"id="sy-crm-core-depense-new-moyen-reglement">
                    <option value="Espèce">Espèce</option>
                    <option value="Chèque">Chèque</option>
                    <option value="Virement">Virement</option>
                    <option value="Prélèvement">Prélèvement</option>
                    <option value="Internet">Internet</option>
                    <option value="Carte bancaire">Carte bancaire</option>
                </select>
            </div>
            
        
<?php
$selected_vendeur = '';

// Récupération du dernier vendeur sélectionné
$args = [
    'post_type'      => 'crm-depenses',
    'posts_per_page' => 1,
    'orderby'        => 'date',
    'order'          => 'DESC'
];
$latest_post = new WP_Query($args);
if ($latest_post->have_posts()) {
    $latest_post->the_post();
    $selected_vendeur = get_post_meta(get_the_ID(), '_depense_vendeur', true);
}
wp_reset_postdata();

// VosFactures activé
if (get_option('vosfactures_sync_enabled') == 'yes') {
    $departments_vf = get_option('_crm_vosfactures_departments', []);
    $departments_manual = get_option('_crm_departements_manuels', []);

    echo '<div class="form-group">';
    echo '<label for="departement_vendeur">Département :</label>';
    echo '<select name="departement_vendeur" id="departement_vendeur">';
    echo '<option value="">-- Sélectionnez --</option>';

    // Départements VosFactures
    if (!empty($departments_vf)) {
        echo '<optgroup label="Depuis VosFactures">';
        foreach ($departments_vf as $dept) {
            $selected = ($dept['id'] == $selected_vendeur) ? 'selected' : '';
            echo '<option value="' . esc_attr($dept['id']) . '" ' . $selected . '>' . esc_html($dept['nom_usage']) . '</option>';
        }
        echo '</optgroup>';
    }

    // Départements ajoutés manuellement
    if (!empty($departments_manual)) {
        echo '<optgroup label="Ajout manuel">';
        foreach ($departments_manual as $dept) {
            $selected = ($dept['id'] == $selected_vendeur) ? 'selected' : '';
            echo '<option value="' . esc_attr($dept['id']) . '" ' . $selected . '>' . esc_html($dept['nom_usage']) . '</option>';
        }
        echo '</optgroup>';
    }

    echo '</select>';
    echo '</div>';
} else {
    // VosFactures désactivé → seulement les départements CRM manuels
    $departments_manual = get_option('_crm_departements_manuels', []);
    echo '<div class="form-group">';
    echo '<label for="departement_vendeur">Département :</label>';
    echo '<select name="departement_vendeur" id="departement_vendeur">';
    echo '<option value="">-- Sélectionnez --</option>';
    if (!empty($departments_manual)) {
        foreach ($departments_manual as $dept) {
            $selected = ($dept['id'] == $selected_vendeur) ? 'selected' : '';
            echo '<option value="' . esc_attr($dept['id']) . '" ' . $selected . '>' . esc_html($dept['nom_usage']) . '</option>';
        }
    }
    echo '</select>';
    echo '</div>';
}
?>

         

            
        </div>
    
        <div class="sy-crm-core-depense-row">
            <div  class="form-group form-group-title">
                <label>Libellé :</label>
                <input type="text" name="titre_depense" id="titre_depense" value="<?php echo $title ?>" required>
            </div>
            
        <div class="form-group form-group-comments">
            <label>Commentaire :</label><textarea id="sy-crm-core-depense-new-commentaire" rows="1" style="resize: none; overflow: hidden; white-space: nowrap;"></textarea>

        </div>
    </div>
    <input type="hidden" id="woo_config" data-currency="<?php echo $config['currency']; ?>" data-currency-pos="<?php echo $config['currency_pos']; ?>" data-decimal-sep="<?php echo $config['decimal_sep']; ?>" data-thousand-sep="<?php echo $config['thousand_sep']; ?>" data-num-decimals="<?php echo $config['num_decimals']; ?>">
    <div id="sy_crm_core_depense_produits_list">
    <h2>Produits</h2>
    <table class="sy-crm-core-depense-new-product-table " id="sy-crm-core-depense-new-product-table">
        <thead>
            <tr>
                <th></th>
                <th>Nom</th>
                <th>Qté</th>
                <th>PU HT</th>
                <th>Total HT</th>
                <th>TVA %</th>
                <th>PU TTC</th>
                <th>Total TTC</th>
            </tr>
            </thead>
        <tbody id="produit-container">
            <!-- Produit par défaut -->
            <tr class="product-row">
            <td data-label=""><button class="sy-crm-core-depense-new-remove-product" style="display: none;">-</button></td>
                <td  data-label="Nom du produit">
                    <div class="sy-crm-core-depense-product-col">
                   
                    <div class="sy_crm_core_depense_tiers_search_container">
                        <input type="text"  class="sy-crm-core-depense-product-name" placeholder="Nom du produit" />
                        
                       
                        <ul class="sy_crm_core_depense_products_suggestions"></ul>
                

                    </div>
          
                    <input type="hidden" name="" class="sy-crm-core-depense-product-id" value="0">
                    <input type="hidden" name="" class="nouveau-produit-flag" value="0">
                    <!--<input type="text" class="nouveau-produit" name="nouveau_produit[]" style="display:none;" placeholder="Nom du produit">-->
                <button type="button" class="sy-crm-core-depense-button sy-crm-core-depense-new-produit-btn">Créer?</button>
                </div>
                 </td>
                <td  data-label="Quantité"><input type="number"style="max-width: 100px;"  name="quantite[]" value="1" class="quantite sy-crm-core-depense-num-val "></td>
                <td data-label="Prix unitaire HT"><input type="text" name="prix_unitaire[]"style="max-width: 110px;" class="prix-unitaire sy-crm-core-depense-num-val"></td>
                <td data-label="Total HT"><input type="text" name="total_ht[]" style="max-width: 110px;"class="total-ht sy-crm-core-depense-num-val"></td>
                <td data-label="TVA sur produit"><input type="text" name="tva_depense[]"style="max-width: 110px;" class="tva-depense sy-crm-core-depense-num-val"data-default-val=<?php echo $tax_rate; ?>></td>
                <td data-label="Prix unitaire TTC"><input type="text" name="prix_unitaire_TTC[]"style="max-width: 110px;" class="prix-unitaire-TTC sy-crm-core-depense-num-val"></td>
                <td data-label="Total TTC"><input type="text" name="total_TTC[]" style="max-width: 110px;"class="total-TTC sy-crm-core-depense-num-val" ></td>
                
            </tr>
            <tr class="product-description-row">
                <td  data-label="Description" colspan="8">
                    <textarea name="description_products[]" class="produit-description" placeholder="Description du produit"></textarea>
                </td>
            </tr>
        </tbody>
    </table>
  
</div>
<button type="button" id="sy_crm_core_depense_ajout_produit_btn" class="sy-crm-core-depense-button sy-crm-core-add-produit">+ Produit</button>
<div class="sy-crm-core-depense-bottom-row">

    <div class="sy-crm-core-depense-attachement-row">

            <p>Pièces jointes :</p>
            <input type="file" id="file-input" multiple>
       
    </div>
    <div  class=" sy-crm-core-depense-row-prices" >
            <div class="form-group sy_crm_core_depense_group_price">
                <label>Total HT (<?php echo $config['currency']; ?>) :</label>
                <input type="text" name="total_depense_ht" id="total_depense_ht" value="" readOnly>
            </div>
            <div class="form-group sy_crm_core_depense_group_price">
                <label>Total TTC (<?php echo $config['currency']; ?>) :</label>
                <input type="text" name="total_depense_ttc" id="total_depense_ttc" value="" readOnly>
            </div>
    </div>
</div>
    <div id="file-list" class="file-list"></div>
   
       
    <div id="sy-crm-core-depense-creation-result"></div>
     
    <?php
        if($tiersId){
           ?>
             <div class="sy-crm-core-depense-sidebar-footer">
            <button type="button"class="sy-crm-core-depense-button discard-add-depense-sidebar">Fermer</button>
            <?php 
        }
    ?> 
     <div class="sy-crm-core-depense-creation-btn">
    <button type="submit"class="sy-crm-core-depense-button sy-crm-core-depense-submit">Enregistrer</button></div>
    <?php if($tiersId){
           ?>
           </div>
          
        <?php 
        }
    ?>  
       
</form>
<?php if($tiersId){
           ?>
           </div>
        <?php 
        }
    ?>  


    <?php
    return ob_get_clean();
}
add_shortcode('crm_creation_depense', 'crm_creation_depense_shortcode');


// Fonction AJAX pour sauvegarder la dépense
/**
 * Fonction crm_sauvegarder_depense
 * Cette fonction gère la sauvegarde des dépenses dans un système CRM sous WordPress. Elle effectue les opérations suivantes :
 *  Récupération et traitement des données :
 * Décode les données JSON envoyées via $_POST['produits'].
 * Vérifie si un nouveau tiers (fournisseur) doit être créé.
 * Création d'un nouveau tiers si nécessaire :
 * Vérifie si l'utilisateur a fourni une adresse e-mail. Si non, génère une adresse factice unique.
 * Crée un utilisateur WordPress avec le rôle "fournisseur".
 * Remplit les métadonnées de facturation et de livraison.
 * Synchronisation avec le service externe "VosFactures" (si activée) :
 * Envoie les informations du nouveau fournisseur via une API REST.
 * Récupère l'ID du fournisseur depuis "VosFactures" et l'associe à l'utilisateur WordPress.
 * Génère un user_login basé sur l'ID récupéré.
 * Gestion des produits liés à la dépense :
 * Si un produit est nouveau, il est ajouté à WooCommerce.
 * Récupère ou crée l'ID du produit et compile une liste des produits associés à la dépense.
 * Création du post "crm-depenses" :
 * Insère un nouveau post personnalisé (crm-depenses) avec les informations de la dépense.
 * Ajoute les métadonnées associées (fournisseur, mode de paiement, total HT/TTC, etc.).
 * Gestion des pièces jointes :
 * Vérifie et stocke les fichiers envoyés en les enregistrant dans un dossier spécifique (wp-content/uploads/crm-core/depense).
 * Sauvegarde les liens des fichiers en tant que métadonnées du post.
 * Réponse JSON : Retourne une réponse JSON avec l'ID du post créé en cas de succès.

 * @return void
 */
function crm_sauvegarder_depense() {
   // $produits = $_POST['produits'];
    $produits_final = [];
    $produits = json_decode(stripslashes($_POST['produits']), true); // Décoder les données JSON
    $new_tier=$_POST['new_tier'];
    $new_tier_email=$_POST['sy-crm-core-depense-new-tier-mail'];
    $post_pays=$_POST['sy-crm-core-depense-tier-pays'];
    if ($new_tier == '1') {
        $post_pays=$_POST['sy-crm-core-depense-new-tier-pays'];

  
            if($new_tier_email!="")
            {
                $new_email = generate_unique_email($new_tier_email);
                $userMailing='yes';
            }
            else{
                $counter = 1;
                    do {
                        $new_email = 'aucun-email-fournis-' . $counter . '@void.com';
                        $counter++;
                    } while (email_exists($new_email));
            
                    $userMailing='no';
                
            }
            //$user_id = wp_create_user($new_email, wp_generate_password(), $new_email);
    
            $tier_nom = custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-nom']);
            $tier_prenom = custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-prenom']);

            /*if (!empty($tier_nom) && !empty($tier_prenom)) {
                $display_name = sanitize_user_login($tier_nom . '_' . $tier_prenom);
            } else {
                // Extraire la partie avant le @ de l'email
                $display_name = explode('@', $new_email)[0];
            }*/

            $timestamp = date('Ymd-His');
            $display_name = $timestamp; 
            $user_id = wp_create_user($display_name, wp_generate_password(), $new_email);
            if (!is_wp_error($user_id)) {
                $user = new WP_User($user_id);
                $user->set_role('fournisseur');
                wp_update_user([
                    'ID'         => $user_id,
                    'first_name' => $_POST['sy-crm-core-depense-new-tier-prenom'],
                    'last_name'  => $_POST['sy-crm-core-depense-new-tier-nom'],
                    'display_name' => $_POST['sy-crm-core-depense-new-tier-nom'] . ' ' . $_POST['sy-crm-core-depense-new-tier-prenom'],
                         
                   
                ]);
                $tier_adr=$_POST['sy-crm-core-depense-new-tier-adr']!=""?custom_normalize_and_uppercase(str_replace('<br>', '-', $_POST['sy-crm-core-depense-new-tier-adr'])) : '';
           
                // Mettre à jour les métadonnées de facturation et de livraison
                update_user_meta($user_id, 'billing_company',  custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-entreprise']));                
                update_user_meta($user_id, 'billing_company',  custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-entreprise']));
                update_user_meta($user_id, 'billing_first_name',  custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-prenom']));
                update_user_meta($user_id, 'billing_last_name',  custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-nom']));
                update_user_meta($user_id, 'billing_postcode', $_POST['sy-crm-core-depense-new-tier-cp']);
                update_user_meta($user_id, 'billing_city',  custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-ville']));
                update_user_meta($user_id, 'billing_country', $post_pays);
    
                update_user_meta($user_id, 'billing_country', $post_pays);
                update_user_meta($user_id, 'shipping_first_name',  custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-prenom']));
                update_user_meta($user_id, 'shipping_last_name',  custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-nom']));
                update_user_meta($user_id, 'shipping_postcode', $_POST['sy-crm-core-depense-new-tier-cp']);
                update_user_meta($user_id, 'shipping_city',  custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-ville']));
                update_user_meta($user_id, 'shipping_country', $post_pays);
                update_user_meta($user_id, 'user_mailing',$userMailing );

                update_user_meta($user_id, 'billing_address_1', $tier_adr);
                update_user_meta($user_id, 'shipping_address_1', $tier_adr);
                update_user_meta($user_id, 'user_civilite', custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-civilite']));
                update_user_meta($user_id, 'user_status', 'active');
                update_user_meta($user_id, 'shipping_phone', $_POST['sy-crm-core-depense-new-tier-phone']);
                update_user_meta($user_id, 'billing_phone', $_POST['sy-crm-core-depense-new-tier-phone']);
                update_user_meta($user_id, 'account_creation_date', current_time('mysql'));
                update_user_meta($user_id, 'account_last_modified_date', current_time('mysql'));
                if (!empty($_POST['sy-crm-core-depense-new-tier-entreprise'])) {
                    $user_type = 'entreprise';
                } else {
                    $user_type = 'particulier';
                }
                update_user_meta($user_id, 'user_type', $user_type);

                if(get_option('vosfactures_sync_enabled') === 'yes'){
                    $api_key = get_option('vosfactures_api_key');
                    $api_url = rtrim(get_option('vosfactures_api_url'), '/');
                
                    if (empty($api_key) || empty($api_url)) {
                        wp_send_json_error(array('success' => false, 'message' => 'La cl API ou l\'URL VosFactures n\'est pas configurée.'));
                    }
                    $civilite = $_POST['sy-crm-core-depense-new-tier-civilite'];

                    switch ($civilite) {
                        case 'Monsieur':
                            $civilite_vosfacture = 'mr'; 
                            break;
                        case 'Madame':
                            $civilite_vosfacture = 'mrs'; 
                            break;
                        case 'Monsieur ou Madame':
                            $civilite_vosfacture = 'mr_mrs'; 
                            break;
                        case 'Non binaire':
                            $civilite_vosfacture = 'more'; 
                            break;
                        default:
                            $civilite_vosfacture = ''; 
                            break;
                    }
                   

                    $contact_data = array(
                        'client' => array(
                            'name' => $_POST['sy-crm-core-depense-new-tier-entreprise']?custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-entreprise']): trim(custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-prenom']) . ' ' . custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-nom'])),
                            
                            'first_name' =>  custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-prenom']),
                            'last_name' =>  custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-nom']),
                            'email' => $new_email,
                            'post_code' =>  $_POST['sy-crm-core-depense-new-tier-cp'],
                            'city' =>  custom_normalize_and_uppercase($_POST['sy-crm-core-depense-new-tier-ville']),
                            'country' => $post_pays,
                            'title' =>  $civilite_vosfacture ,
                            'company' =>  !empty($_POST['sy-crm-core-depense-new-tier-entreprise']) ? true : false ,
                            'street' => $tier_adr,
                            'phone' =>$_POST[' sy-crm-core-depense-new-tier-phone'],
                           
                            
                        )
                    );
                    $response = wp_remote_post($api_url . '/clients.json', array(
                        'method' => 'POST',
                        'headers' => array(
                            'Authorization' => 'Bearer ' . $api_key,
                            'Content-Type' => 'application/json',
                        ),
                        'body' => json_encode($contact_data),
                        'timeout' => 30,
                    ));
            
                    if (is_wp_error($response)) {
                        crm_core_update_logs_option(
                            'Shortcode Ajout depense',  
                            'Erreur lors de la synchronisation avec VosFacture.', 
                            get_current_user_id(), 
                            $_POST  
                        );
                        wp_send_json_error(array('success' => false, 'message' => 'Erreur lors de la synchronisation avec VosFactures.'));
                    }
                    $body = wp_remote_retrieve_body($response);
                    $data = json_decode($body, true);
            
                    if (!isset($data['id'])) {
                        crm_core_update_logs_option(
                            'Shortcode Ajout depense',  
                            'Erreur lors de la création du client sur VosFactures.', 
                            get_current_user_id(), 
                            $_POST  
                        );
                        wp_send_json_error(array('success' => false, 'message' => 'Erreur lors de la création du client sur VosFactures.'));
                    }
            
                    $vosfacture_id = $data['id'];
            
                    update_user_meta($user_id, 'vosfactures_id', $vosfacture_id);
                    // Générer un user_login unique basé sur l'ID VOSFACTURE
                    $user_login = generate_user_login_from_vosfacture_id($vosfacture_id);
                    wp_update_user([
                        'ID'         => $user_id,
                        'user_login' => $user_login,
                            
                       
                    ]);
                }
                   
    
            } else {
                crm_core_update_logs_option(
                    'Shortcode Ajout depense',  
                    'Erreur lors de la création du tiers', 
                    get_current_user_id(), 
                    $_POST  
                );
                wp_send_json_error(['message' => 'Erreur lors de la création du tiers']);
                return;
            }
    
       
    } else {
        $user_id = $_POST['tiers']; 
    }
    foreach ($produits as $produit) {
        $produit_id = $produit['id'];


        if ($produit['nouveau'] == '1' && !empty($produit['nom'])) {
            $display_prices_including_tax = get_option( 'woocommerce_tax_display_shop' );

            if ($display_prices_including_tax === 'incl') {
                $price=$produit['prixUnitaireTTC'] ;
            } else {
                $price=$produit['prixUnitaire'] ;
            }
            $new_product = [
                'post_title'   => sanitize_text_field($produit['nom']),
                'post_status'  => 'publish',
                'post_type'    => 'product',
                'meta_input'   => [
                    '_price' => floatval($price),
                    '_regular_price' => floatval($price),
                    '_tax_class' => '',
                    '_stock_status' => 'instock',
                ],
                'post_excerpt' => sanitize_textarea_field($produit['description']),
                'post_content' => sanitize_textarea_field($produit['description']), 
    
            
            ];
            $produit_id = wp_insert_post($new_product);
            wp_publish_post($produit_id);
            wc_get_product($produit_id)->save();
        }

        $produits_final[] = [
            'idProduit'    => intval(value: $produit_id),
            'nomProduit'   => get_the_title($produit_id),
            'quantite'     => intval($produit['quantite']),
            'prixUnitaire_ht'  => ($produit['prixUnitaire']),
            'prixUnitaire_ttc'  => ($produit['prixUnitaireTTC']),
            'tva'    => sanitize_text_field($produit['tva']),
            'total_ht'    => sanitize_text_field($produit['totalHt']),
            'total_ttc'    => sanitize_text_field($produit['totalTTC']),
            'description'    => sanitize_text_field($produit['description']),
        ];
    }
    $date_depense = $_POST['date_depense'];
      $date_format = get_option('date_format'); 
   
    if (!empty($date_depense)) {
        $timestamp = strtotime($date_depense); 
        $formatted_date = date($date_format, $timestamp); 
    } else {
        $formatted_date = "";
    }
   
    $post_id = wp_insert_post([
        'post_type'    => 'crm-depenses',
        'post_status'  => 'publish',
        'post_title'   =>sanitize_text_field($_POST['titre_depense']) ,
        'meta_input'   => [
            '_depense_date'     => $_POST['date_depense'],
            '_depense_tiers'            => $user_id,
            '_depense_pays'             => $post_pays,
            '_depense_moyen_reglement'  => sanitize_text_field($_POST['moyen_reglement']),
            '_depense_commentaire'      => sanitize_textarea_field($_POST['commentaire']),
            '_depense_products'=> $produits_final ,
            '_depense_total_prix_ht'=>$_POST['total_depense_ht'],
            '_depense_total_prix_ttc'=>$_POST['total_depense_ttc'],
            '_depense_vendeur'=>$_POST['vendeur']
            
        ]
    ]);
 if (!empty($_FILES['pieces_jointes'])) {
        $upload_dir = wp_upload_dir();
        $base_dir = $upload_dir['basedir'] . '/crm-core/depense/' . $user_id . '/' . $post_id;
    $file_links=[];
        if (!file_exists($base_dir)) {
            wp_mkdir_p($base_dir);
        }
    
        foreach ($_FILES['pieces_jointes']['name'] as $key => $file_name) {
            $file_tmp = $_FILES['pieces_jointes']['tmp_name'][$key];
            $file_dest = $base_dir . '/' . sanitize_file_name($file_name);
    
            if (move_uploaded_file($file_tmp, $file_dest)) {
                $file_links[] = $upload_dir['baseurl'] . '/crm-core/depense/' . $user_id . '/' . $post_id . '/' . sanitize_file_name($file_name);
    
            }
        }
                update_post_meta($post_id, '_depense_pieces_jointes', $file_links);
    }
    wp_send_json_success(['post_id' => $post_id]);
}


add_action('wp_ajax_crm_sauvegarder_depense', 'crm_sauvegarder_depense');
add_action('wp_ajax_nopriv_crm_sauvegarder_depense', 'crm_sauvegarder_depense');

/**
 * Recherche des utilisateurs actifs correspondant à une requête.
 *
 * Cette fonction effectue une recherche parmi les utilisateurs ayant un statut actif et appartenant à certains rôles spécifiques.
 * Elle filtre les résultats en fonction du nom d'affichage, du pseudo, de l'email ou des métadonnées utilisateur.
 * 
 * Processus :
 * 1. Récupère la requête de recherche depuis $_GET et la nettoie.
 * 2. Vérifie que la requête contient au moins 3 caractères.
 * 3. Effectue une requête pour récupérer les utilisateurs ayant un statut "ACTIF".
 * 4. Filtre les utilisateurs dont les informations correspondent à la requête.
 * 5. Sélectionne un maximum de 10 résultats et construit une réponse JSON.
 * 6. Retourne les utilisateurs sous forme de JSON avec leur ID, nom affiché et pays de facturation.
 *
 * @return void Envoie une réponse JSON contenant les résultats filtrés.
 */

function search_users_data() {
    $query = isset($_GET['query']) ? sanitize_text_field($_GET['query']) : '';

    if (strlen($query) < 3) {
        wp_send_json([]);
    }


    $args = [
        'number' => -1,
        'meta_query' => [
            [
                'key' => 'user_status',
                'value' => ['ACTIF', 'actif', 'active'],
                'compare' => 'IN',
            ],
        ],
        'role__in' => ['tiers', 'customer', 'prospect', 'non_qualifie', 'hors_cible','fournisseur']
    ];
    $user_query = new WP_User_Query($args);
    $users = $user_query->get_results();
	
    $filtered_users = array_filter($users, function($user) use ($query) {
		if (stripos($user->display_name, $query) !== false ||stripos($user->user_nicename, $query) !== false || stripos($user->user_email, $query) !== false) {
			return true;
		}
		$user_meta = get_user_meta($user->ID);
		foreach ($user_meta as $key => $values) {
			foreach ($values as $value) {
				if (stripos($value, $query) !== false) {
					return true;
				}
			}
		}

		return false;
	});
$filtered_users = array_slice($filtered_users, 0, 10);
 //wp_send_json_error(['count'=>count($users),'aaa'=>count($filtered_users),'filtered_users'=>$filtered_users]);
    $results = [];
    foreach ($filtered_users as $user) {
     


        $billing_company = get_user_meta($user->ID, 'billing_company', true);
        $prenom_nom = get_user_meta($user->ID, 'last_name', true) . ' ' . get_user_meta($user->ID, 'first_name', true);
        $entreprise_affichee = $billing_company ?$billing_company  .' '. get_user_meta($user->ID, 'billing_postcode', true): esc_html($prenom_nom).' '. get_user_meta($user->ID, 'billing_postcode', true);
        $billing_country = get_user_meta($user->ID, 'billing_country', true)??'FR'; 

            $results[] = [
                'tierId'=>$user->ID,
                'tierName'=> $entreprise_affichee,
                'tierPays'=>$billing_country,
                'depenseTitle'=> $billing_company ?$billing_company :$prenom_nom ,//.' - Dépense - '.date('Y-m-d')
       
            ];
                
        }
    

        wp_send_json_success($results);
}
add_action('wp_ajax_search_users_data', 'search_users_data');
add_action('wp_ajax_nopriv_search_users_data', 'search_users_data');

function search_product_data() {
     if ( ! isset( $_GET['query'] ) ) {
        wp_send_json_error();
    }

    $query = sanitize_text_field( $_GET['query'] );
    $tax_based_on = get_option('woocommerce_tax_based_on'); 
    $countryTva = get_option('woocommerce_default_country');
    $tax_rates = WC_Tax::get_rates_for_tax_class( $tax_based_on );
    $tax_rate_found = null;
    foreach ($tax_rates as $rate) {
       if ($rate->tax_rate_country == $countryTva) {
            $tax_rate_found = $rate;
            break;
        }

    } 
    $tax_rate=$tax_rate_found->tax_rate;
    
    $products = wc_get_products(array('status' => 'publish', 'limit' => -1, 'orderby' => 'date', 'order' => 'DESC'));
    $search_query = sanitize_text_field( $_GET['query'] );

    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => -1, 
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
        's'              => $search_query, 
    );

    $query = new WP_Query( $args );
    $results = array();           
    
    $results = array();

    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            $product_tax_class=get_post_meta(get_the_ID(),'_tax_class',true);

            $product = wc_get_product( get_the_ID() );
            $description = !empty($product->get_description()) ? esc_attr($product->get_description()) : esc_attr($product->get_short_description());
            $display_prices_including_tax = get_option('woocommerce_tax_display_shop');
            $price = ($display_prices_including_tax === 'incl') ? $product->get_price_including_tax() : $product->get_price_excluding_tax();
          
            $results[] = array(
                'product_id'  => $product->get_id(),
                'nom'         => $product->get_name(),
                'price'       => $price,
                'description' => $description,
                'tax_rate'    => $tax_rate,
                'product_tax_class'=>$product_tax_class 
            );
        }
        wp_reset_postdata();
    }

    wp_send_json_success( $results );
}

// Ajoutez l'action AJAX pour les utilisateurs connectés et non connectés
add_action( 'wp_ajax_search_product_data', 'search_product_data' );
add_action( 'wp_ajax_nopriv_search_product_data', 'search_product_data' );


/**
 * Fonction get_depense_details
 * 
 * Cette fonction récupère les détails d'une dépense spécifique en fonction de son ID.
 * Elle effectue plusieurs vérifications avant d'envoyer les données :
 * - Vérifie si l'ID de la dépense est valide.
 * - Récupère la dépense et ses métadonnées associées.
 * - Détermine les droits d'édition et de suppression en fonction du rôle de l'utilisateur et de l'ancienneté de la dépense.
 * - Convertit le code pays en son nom complet si applicable.
 * 
 * Fonctionnalités :
 * - Vérification et validation de l'ID de la dépense.
 * - Récupération des informations de la dépense (nom, date, montant HT/TTC, vendeur, produits associés, etc.).
 * - Définition des permissions d'édition et de suppression en fonction des rôles utilisateur.
 * - Renvoi des informations sous forme de JSON.
 * 
 * Paramètres :
 * - Reçoit en POST l'ID de la dépense à récupérer.
 * 
 * Retour :
 * - Un objet JSON contenant les détails de la dépense ou un message d'erreur en cas d'échec.
 */
function get_depense_details() {
    $depense_id = intval($_POST['depense_id']);
    if (!$depense_id) {
        crm_core_update_logs_option(
            'Shortcode list des depenses',  
            'ID de dépense invalide.', 
            get_current_user_id(), 
            ['depense_id'=>$depense_id]  
        );
        wp_send_json_error('ID de dépense invalide.');
    }

    $depense = get_post($depense_id);
    if (!$depense) {
        crm_core_update_logs_option(
            'Shortcode list des depenses',  
            'Dépense non trouvée.', 
            get_current_user_id(), 
            ['depense_id'=>$depense_id]  
        );
        wp_send_json_error('Dépense non trouvée.');
    }
    $pays = get_post_meta($depense_id, '_depense_pays', true);
    $current_user = wp_get_current_user();
    $user_roles = $current_user->roles;
    $can_edit=false;
    $can_delete=false;
 
    $dateCreation = strtotime(get_post_field('post_date', $depense_id));
    $user_id=get_post_meta($depense_id, '_depense_tiers', true);
    $author_id = get_post_field('post_author', $depense_id);  
   
    // Calculer la différence en jours entre aujourd'hui et la date de création
$differenceInDays = (time() - $dateCreation) / (60 * 60 * 24); // Conversion en jours

    if(in_array('administrator', $user_roles)|| in_array('responsable_crm', $user_roles)){
        $can_edit=true;
        $can_delete=true;
        
    }
    elseif(in_array('utilisateur_crm', $user_roles)){
        $associer_crm = get_user_meta($user_id, 'associer_crm', true);
        $can_edit=(($current_user->ID==$user_id&&$differenceInDays<7)||
        ($associer_crm && in_array($current_user->ID,  $associer_crm)&&$differenceInDays<7&&$author_id==$current_user->ID));
        $can_delete=(($current_user->ID==$user_id&&$differenceInDays<7)||
        ($associer_crm && in_array($current_user->ID,  $associer_crm)&&$differenceInDays<7&&$author_id==$current_user->ID));
        
    }
    else{
        
        $can_edit=($current_user->ID==$user_id&&$differenceInDays<7);
        $can_delete=($current_user->ID==$user_id&&$differenceInDays<7);

    }
    $tiersId=get_post_meta($depense_id, '_depense_tiers', true);
    $billing_company = get_user_meta($tiersId, 'billing_company', true);
    $prenom_nom = get_user_meta($tiersId, 'last_name', true) . ' ' . get_user_meta($tiersId, 'first_name', true);
    $entreprise_affichee = $billing_company ?: esc_html($prenom_nom);
    if (!$entreprise_affichee) {
        $user_email = get_userdata($tiersId)->user_email;
        $entreprise_affichee = $user_email;  
    }
    $tax_based_on = get_option('woocommerce_tax_based_on'); 
    $countryTva = get_option('woocommerce_default_country');
    $tax_rates = WC_Tax::get_rates_for_tax_class( $tax_based_on );
    $tax_rate_found = null;
    foreach ($tax_rates as $rate) {
       if ($rate->tax_rate_country == $countryTva) {
            $tax_rate_found = $rate;
            break;
        }

    } 
    $tax_rate=$tax_rate_found->tax_rate;
    

$pays = WC()->countries->countries[$pays] ?? $pays; 
    $data = [
        'id' => $depense->ID,
        'nom' => $depense->post_title,
        'date' => get_post_meta($depense_id, '_depense_date', true),
        'total_ht' => get_post_meta($depense_id, '_depense_total_prix_ht', true),
        'total_ttc' => get_post_meta($depense_id, '_depense_total_prix_ttc', true),
        'vendeur' => get_post_meta($depense_id, '_depense_vendeur', true),
        'products' => get_post_meta($depense_id, '_depense_products', true),
        'commentaire' => get_post_meta($depense_id, '_depense_commentaire', true),
        'pieces_jointes' => get_post_meta($depense_id, '_depense_pieces_jointes', true)!=""?get_post_meta($depense_id, '_depense_pieces_jointes', true):[],
        'depense_pays'  =>$pays ,
        'moyen_reglement'  => get_post_meta($depense_id, '_depense_moyen_reglement', true) ,
        'plugin_base_url'=>plugin_dir_url(__FILE__) . '../assets/icons',
        'acceptAttachement'=>'on',
        'canEdit'=>$can_edit,
        'canDelete'=>$can_delete,
        'tiers_id'=>get_post_meta($depense_id, '_depense_tiers', true),
        'depense_entreprise'=>$entreprise_affichee ,
        'default_tva'=>$tax_rate
       
    ];

    wp_send_json_success($data);
}

add_action('wp_ajax_get_depense_details', 'get_depense_details');
add_action('wp_ajax_nopriv_get_depense_details', 'get_depense_details');

/**
 * crm_modifier_depense
 * Permet de modifier une dépense existante dans le système CRM.
 * Elle effectue plusieurs actions :
 * 1. Récupère et traite les informations des produits associés à la dépense depuis une requête POST.
 * 2. Si un produit est marqué comme nouveau, il est ajouté au système WooCommerce avec ses détails (prix, description, etc.).
 * 3. Les informations des produits sont ensuite ajoutées à la dépense (ID, nom, quantité, prix, etc.).
 * 4. Met à jour la dépense avec de nouvelles informations : titre, date, moyen de paiement, commentaire, produits associés, etc.
 * 5. Si des fichiers (pièces jointes) sont envoyés avec la dépense, ils sont téléchargés et associés à la dépense dans un dossier spécifique.
 * 6. La fonction renvoie une réponse JSON indiquant si la mise à jour de la dépense a réussi ou échoué.
 *
 * @return void
 */
function crm_modifier_depense() {
    $produits_final = [];
    $produits = json_decode(stripslashes($_POST['produits']), true);
    $post_id = intval($_POST['depense_id']);
    $new_tier = $_POST['new_tier'];
    $post_pays = $_POST['pays'];
    $user_id = $_POST['tiers'];

    foreach ($produits as $produit) {
        $produit_id = $produit['id'];

        if ($produit['nouveau'] == '1' && !empty($produit['nom'])) {
            $display_prices_including_tax = get_option('woocommerce_tax_display_shop');
            $price = ($display_prices_including_tax === 'incl') ? $produit['prixUnitaireTTC'] : $produit['prixUnitaire'];

            $new_product = [
                'post_title'   => sanitize_text_field($produit['nom']),
                'post_status'  => 'publish',
                'post_type'    => 'product',
                'meta_input'   => [
                    '_price' => floatval($price),
                    '_regular_price' => floatval($price),
                    '_tax_class' => '',
                    '_stock_status' => 'instock',
                ],
                'post_excerpt' => sanitize_textarea_field($produit['description']),

                'post_content' => sanitize_textarea_field($produit['description']), 
            ];
            $produit_id = wp_insert_post($new_product);
            wp_publish_post($produit_id);
            wc_get_product($produit_id)->save();
        }

        $produits_final[] = [
            'idProduit'    => intval($produit_id),
            'nomProduit'   => $produit['nom'],
            'quantite'     => intval($produit['quantite']),
            'prixUnitaire_ht'  => floatval($produit['prixUnitaire']),
            'prixUnitaire_ttc'  => floatval($produit['prixUnitaireTTC']),
            'tva'    => sanitize_text_field($produit['tva']),
            'total_ht'    => sanitize_text_field($produit['totalHt']),
            'total_ttc'    => sanitize_text_field($produit['totalTtc']),
            'description'    => sanitize_text_field($produit['description']),
        ];
    }

    $update_result = wp_update_post([
        'ID'           => $post_id,
        'post_title'   => sanitize_text_field($_POST['titre_depense']),
        'meta_input'   => [
            '_depense_date'     => sanitize_text_field($_POST['date_depense']),
            '_depense_tiers'    => $user_id,
            '_depense_pays'     => $post_pays,
            '_depense_moyen_reglement'  => sanitize_text_field($_POST['moyen_reglement']),
            '_depense_commentaire'      => sanitize_textarea_field($_POST['commentaire']),
            '_depense_products' => $produits_final,
            '_depense_total_prix_ht' => $_POST['total_depense_ht'],
            '_depense_total_prix_ttc' => $_POST['total_depense_ttc'],
            '_depense_vendeur' => $_POST['vendeur'],
        ],
    ]);

    if ($update_result !== 0) {
        if (!empty($_FILES['pieces_jointes'])) {
            $upload_dir = wp_upload_dir();
            $base_dir = $upload_dir['basedir'] . '/crm-core/depense/' . $user_id . '/' . $post_id;
            $file_links = get_post_meta($post_id, '_depense_pieces_jointes',true)!=""?get_post_meta($post_id, '_depense_pieces_jointes',true):[];
            if (!file_exists($base_dir)) {
                wp_mkdir_p($base_dir);
            }

            foreach ($_FILES['pieces_jointes']['name'] as $key => $file_name) {
                $file_tmp = $_FILES['pieces_jointes']['tmp_name'][$key];
                $file_dest = $base_dir . '/' . sanitize_file_name($file_name);

                if (move_uploaded_file($file_tmp, $file_dest)) {
                    $file_links[] = $upload_dir['baseurl'] . '/crm-core/depense/' . $user_id . '/' . $post_id . '/' . sanitize_file_name($file_name);
                }
            }
            update_post_meta($post_id, '_depense_pieces_jointes', $file_links);
        }
        wp_send_json_success(['post_id' => $post_id]);
    } else {
        crm_core_update_logs_option(
            'Shortcode list des depenses',  
            'Échec de la mise à jour de la dépense.', 
            get_current_user_id(), 
            $_POST
        );
        wp_send_json_error(['message' => 'Échec de la mise à jour de la dépense.']);
    }
}

add_action('wp_ajax_crm_modifier_depense', 'crm_modifier_depense');
add_action('wp_ajax_nopriv_crm_modifier_depense', 'crm_modifier_depense');

//
/**
 * Gère la suppression d'une atachement via une requête AJAX sécurisée.
 *
 * Cette fonction est utilisée pour supprimer un piece jointe  lié à une dépense partir de son ID. Elle 
 * effectue les étapes suivantes :
 * 
 * - Vérifie que l'ID du dépense est fourni et est un entier valide.
 * - Récupère l'URL du piece jointe associé au dépense.
 * - Traduit l'URL du fichier en chemin absolu sur le serveur et supprime le fichier physique.
 * - Mettre à jour la list des attachement de cette dépense.
 * - Renvoie une réponse JSON en cas de succès ou d'erreur.
 *
 * @return void
 */
function crm_depense_delete_attachement() {
      if (isset($_POST['depense_id']) && is_numeric($_POST['depense_id']) && isset($_POST['attachement_url'])) {
         $depense_id = intval($_POST['depense_id']);
         $attachment_url = sanitize_text_field($_POST['attachement_url']);
 
         // Récupère les pièces jointes existantes
         $depense_pieces_joints = get_post_meta($depense_id, '_depense_pieces_jointes', true);
 
         if (is_array($depense_pieces_joints)) {
             // Supprime l'URL du tableau
             $depense_pieces_joints = array_filter($depense_pieces_joints, function ($url) use ($attachment_url) {
                 return $url !== $attachment_url;
             });
 
             // Supprime le fichier du serveur
             $upload_dir = wp_upload_dir();
             $file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $attachment_url);
             if (file_exists($file_path)) {
                 unlink($file_path);
             }
 
             // Met à jour les pièces jointes
             update_post_meta($depense_id, '_depense_pieces_jointes', $depense_pieces_joints);
 
             wp_send_json_success(['message' => 'pièce jointe supprimé avec succès.']);
         } else {
            crm_core_update_logs_option(
                'Shortcode list des depenses (suppression des attachements)',  
                'Aucune pièce jointe trouvée pour cet dépense.', 
                get_current_user_id(), 
                ['depense_id'=>$depense_id,'attachment_url' =>$attachment_url]
            );
 
                
             wp_send_json_error(['message' => 'Aucune pièce jointe trouvée pour cet dépense.']);
         }
     } else {
        crm_core_update_logs_option(
            'Shortcode list des depenses ( suppression des attachements)',  
            'Requête invalide.', 
            get_current_user_id(), 
            ['depense_id'=>$_POST['depense_id'],'attachment_url' =>$_POST['attachement_url']]
        );

         wp_send_json_error(['message' => 'Requête invalide.']);
     }
 
     exit;
 }
 add_action('wp_ajax_crm_depense_delete_attachement', 'crm_depense_delete_attachement');
 
 /**
 * Gère la suppression d'une dépense via une requête AJAX .
 *
 * Cette fonction est utilisée pour supprimer une dépense à partir de son ID. Elle 
 * effectue les étapes suivantes :
 * 
 * - Vérifie que l'ID du dépense est fourni et est un entier valide.
 * - Traduit l'URL des pieces jointes en chemin absolu sur le serveur et supprime le fichier physique.
 * - Supprime le post WordPress associé au dépense de manière définitive.
 * - Renvoie une réponse JSON en cas de succès ou d'erreur.
 *
 * Réponses possibles :
 * - Succès : `{ success: true, data: { message: "Dépense supprimée avec succès." } }`
 * - Erreur : `{ success: false, data: { message: "Dépense non trouvé." } }`
 *
 * @return void
 */
function crm_delete_depense() {
 
     if (isset($_POST['depense_id']) && is_numeric($_POST['depense_id'])) {
         $depense_id = intval($_POST['depense_id']);
         $attachements =get_post_meta($depense_id, '_depense_pieces_jointes', true);
         $upload_dir = wp_upload_dir();
         $base_dir = $upload_dir['basedir'] . '/crm-core/depense/' . get_post_meta($depense_id, '_depense_tiers', true) . '/' . $post_id;
     
     
         
       
         if(is_array($attachements)&&count($attachements)>0){
             foreach($attachements as $url){
                  $pdf_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $url);
             if (file_exists($pdf_path)) {
                 unlink($pdf_path);
             }
             }
         }
         if (is_dir($base_dir)) {
            rmdir($base_dir);
        }
    
         wp_delete_post($depense_id, true);
         wp_send_json_success(['message' => 'Dépense supprimé avec succès.']);
     } else {
        crm_core_update_logs_option(
            'Shortcode list des depenses (suppression des depenses)',  
            'Dépense non trouvé.', 
            get_current_user_id(), 
            ['depense_id'=>$_POST['depense_id']]
        );
         wp_send_json_error(['message' => 'Dépense non trouvé.']);
     }
 
     exit;
 }
 add_action('wp_ajax_crm_delete_depense', 'crm_delete_depense');
 
 


?>
