jQuery(document).ready(function($) {

    $(document).on('click', '.sy-crm-core-user-depenses-table tr:not(:last-child)', function() {
        var depenseId = $(this).find('td:first').text();

        if (depenseId) {
            $.ajax({
                url: ajax_object.ajax_url,
                type: 'POST',
                data: {
                    action: 'get_depense_details',
                    depense_id: depenseId
                },
                success: function(response) {
                    if (response.success) {
                        var productsHtml = "";
                        var data = response.data;
                        $('#sy-crm-core-depense-delete-btn').data('id', depenseId);
                        $('#sy-crm-core-depense-edit-id').val(depenseId).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-titre-depense').val(data.nom).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-titre-pays').val(data.depense_pays).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-tiers').val(data.tiers_id).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-tiers-pays').val(data.depense_pays).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-tiers-entreprise').val(data.depense_entreprise).attr('readonly', true);
                        //formData.append('tiers', $('').val());

                        $('#sy-crm-core-depense-edit-moyen-reglement').val(data.moyen_reglement).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-moyen-reglement option').each(function() {
                            if ($(this).val() !== data.moyen_reglement) {
                                $(this).hide();
                            }
                        }).prop('readonly', true);
                        var $field = $('#sy-crm-core-depense-edit-departement-vendeur');

                        if ($field.is('select')) {
                            var optionExists = false;

                            $field.find('option').each(function() {
                                if ($(this).val() === data.vendeur) {
                                    optionExists = true;
                                } else {
                                    $(this).hide();
                                }
                            });

                            // Si l'option n'existe pas, on l'ajoute et on la sélectionne
                            if (!optionExists) {
                                $field.append(new Option(data.vendeur, data.vendeur, true, true));
                            }

                            $field.val(data.vendeur);
                        } else if ($field.is('input')) {
                            // Si c'est un <input>, on assigne simplement la valeur
                            $field.val(data.vendeur);
                        }

                        // Rendre le champ en lecture seule
                        $field.prop('readonly', true);

                        if (data.canEdit) {
                            $('.sy-crm-core-depense-edit-btn').show();

                        } else {
                            $('.sy-crm-core-depense-edit-btn').hide();

                        }

                        if (data.canDelete) {
                            $('.sy-crm-core-depense-delete').show();

                        } else {
                            $('.sy-crm-core-depense-delete').hide();

                        }

                        /*$('#sy-crm-core-depense-edit-departement-vendeur').val(data.vendeur_id).attr('readonly', true);*/
                        $('#sy-crm-core-depense-edit-date-depense').val(data.date).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-total-ht').val(data.total_ht).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-total-ttc').val(data.total_ttc).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-commentaire').val(data.commentaire).attr('readonly', true);
                        productsHtml += '<p class="sy-crm-core-depense-section-title">Produits :</p><table class="edit-product-table" id="edit-product-table">';
                        productsHtml += '<thead><tr><th>Nom</th><th>Qté</th><th>PU HT</th><th>Total HT</th> <th>TVA %</th><th>PU TTC</th><th>Total TTC</th><th style="display:none"></th></tr></thead><tbody>';
                        //<th>Réf</th>
                        data.products.forEach(function(produit) {
                            productsHtml += '<tr class="product-row">';
                            // productsHtml += '<td><input value="' + produit.idProduit + '"class="sy-crm-core-depense-edit-nouveau-produit-id"readonly style="max-width: 93px;"></input></td>';
                            productsHtml += '<td> <div class="sy-crm-core-depense-product-col"><div class="sy_crm_core_depense_tiers_search_container"><input type="text" value="' + produit.nomProduit + '" class="sy-crm-core-depense-edit-nouveau-produit-name"  readOnly/><ul class="sy_crm_core_depense_products_suggestions"></ul></div><input type = "hidden"name = ""class = "sy-crm-core-depense-edit-nouveau-produit-id"value = "' + produit.idProduit + '" ><input type = "hidden"name = ""class = "sy-crm-core-depense-edit-nouveau-produit-flag"value = "0" ></div></td > ';
                            productsHtml += '<td><input type="number" value="' + produit.quantite.toString() + '" class="product_quantite" readonly style="max-width: 100px;"></td>';
                            productsHtml += '<td><input type="text"value="' + produit.prixUnitaire_ht + '"class="product_pu_ht"readonly style="max-width: 110px;"></input></td>';
                            productsHtml += '<td><input type="text"value="' + produit.total_ht + '"class="product_total_ht"readonly style="max-width: 110px;"></input></td>';
                            productsHtml += '<td><input type="text"value="' + produit.tva + '"class="product_tva"readonly style="max-width: 110px;"></input></td>';
                            productsHtml += '<td><input type="text"value="' + produit.prixUnitaire_ttc + '"class="product_pu_ttc"readonly style="max-width: 110px;"></input></td>';

                            productsHtml += '<td><input type="text" value="' + produit.total_ttc + '"class="product_total_ttc"readonly style="max-width: 110px;"></input></td>';
                            productsHtml += '<td style="display:none"><button class="sy-crm-core-depense-remove-product">-</button></td>';
                            productsHtml += '</tr>';
                            productsHtml += '<tr class="product-description-row"><td colspan="9"><textarea value="' + produit.description + '"class="product_description"readonly placeholder="description">' + produit.description + '</textarea></td></tr>';
                        });



                        productsHtml += '</tbody></table>';
                        $('#sy-crm-core-depense-edit-products-list').html(productsHtml);
                        if (data.pieces_jointes.length > 0) {
                            var attachmentsArray = data.pieces_jointes;

                            let attachmentsHtml = "<p>Pièces joints</p><table><thead><tr></tr></thead><tbody>";

                            attachmentsArray.forEach((docUrl) => {


                                const fileName = docUrl.split("/").pop();
                                const fileExtension = fileName.split('.').pop().toLowerCase();
                                const iconUrl = data.plugin_base_url + '/' + depenseGetFileIcon(fileExtension);
                                const deleteIcon = data.plugin_base_url + '/trash-icon.svg';
                                attachmentsHtml += `
                                <tr>
                                    <td class="crm_depense_attachement_type"><img class="icon-attachment" src="${iconUrl}" alt="File Icon"></td>
                
                                    <td class="crm_depense_attachement_name"><a href="${docUrl}" target="_blank">${fileName}</a></td>
                                    <td class="crm_depense_attachement_action"style='display:none'> `;

                                if (data.canDelete == true) {
                                    attachmentsHtml += `<img  class="delete-attachment" data-depense-id="${depenseId}" data-url="${docUrl}" src="${deleteIcon}" alt="delete Icon">
                                `;
                                } else {
                                    attachmentsHtml += `--`;
                                }
                                attachmentsHtml += `
                                    </td>
                                    </tr>
                            `;
                            });


                            if (data.canEdit == true) {
                                const iconAdd = data.plugin_base_url + "add-icon.svg";
                                attachmentsHtml += ` <tr id="sy-crm-core-depense-add-new-attachement-tr"style="display:none;">
                            <td colspan="3">
                            <input type="file" id="sy-crm-core-depense-edit-file-input" multiple>
      
                        
                            
                            </td>
                        </tr>`;
                            }
                            attachmentsHtml += "</tbody></table>";

                            $('#sy-crm-core-depense-edit-file-list').html(attachmentsHtml).hide();




                        } else {

                            let attachmentsHtml = "<p>Pièces joints</p><table><thead><tr></tr></thead><tbody>";

                            if (data.canEdit == true) {

                                const iconAdd = data.plugin_base_url + "add-icon.svg";
                                attachmentsHtml += ` <tr id="sy-crm-core-depense-add-new-attachement-tr"style="display:none;">
                            <td colspan="3">
                            <input type="file" id="sy-crm-core-depense-edit-file-input" multiple>
      
                        
                            
                            </td>
                        </tr>`;
                            }
                            attachmentsHtml += "</tbody></table>";

                            $('#sy-crm-core-depense-edit-file-list').html(attachmentsHtml);

                        }

                        $('#sy-crm-core-depense-edit-sidebar').show().addClass('open');


                    } else {
                        alert('Erreur: ' + response.data);
                    }
                }
            });
        }
    });

    $('.sy-crm-core-depense-edit-sidebar-header-btn,.discard-edit-depense-sidebar').on('click', function() {

        closeEditDepenseSidebar();



    });

    function depenseGetFileIcon(fileExtension) {
        switch (fileExtension) {
            case 'pdf':
                return 'pdf-icon.svg';
            case 'doc':
            case 'docx':
                return 'word-icon.svg';
            case 'xls':
            case 'xlsx':
                return 'excel-icon.svg';
            case 'jpg':
            case 'jpeg':
            case 'png':
                return 'image-icon.svg';
            case 'zip':
            case 'rar':
                return 'zip-icon.svg';
            default:
                return 'default-icon.svg';
        }
    }

    $(document).on("click", ".delete-attachment", function() {
        const button = $(this);
        const depenseId = button.data("depense-id");
        const docUrl = button.data("url");

        if (confirm("Êtes-vous sûr de vouloir supprimer cette pièce jointe?")) {

            $.ajax({
                url: ajax_object.ajax_url,
                method: "POST",
                data: {
                    action: "crm_depense_delete_attachement",
                    depense_id: depenseId,
                    attachement_url: docUrl,
                },
                success: function(response) {
                    if (response.success) {
                        //alert(response.data.message);
                        // location.reload();
                        $("#sy-crm-core-depense-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {

                            $(`#sy-crm-core-depense-edit-result`)
                                .text("Attachement supprimé avec succès")
                                .addClass("text-success").removeClass("text-error")
                                .fadeIn()
                                .delay(500)
                                .fadeOut(function() {
                                    location.reload();
                                });
                        })
                    } else {
                        $("#sy-crm-core-depense-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {


                            $('#sy-crm-core-depense-edit-result')
                                .text(response.data.message)
                                .removeClass("text-success").addClass("text-error")
                                .fadeIn()
                                .delay(500)
                                .fadeOut(

                                );
                        })
                    }

                },
                error: function() {
                    alert("Une erreur s\'est produite lors de la suppression du event.");
                },
            });
        }


    });
    $(document).on("click", "#sy-crm-core-depense-delete-btn", function(e) {
        e.preventDefault();
        const depenseId = $(this).data("id");

        if (confirm("Êtes-vous sûr de vouloir supprimer cet dépense? ?")) {
            $.ajax({
                url: ajax_object.ajax_url,
                type: "POST",
                data: {
                    action: "crm_delete_depense",
                    depense_id: depenseId,
                },
                success: function(response) {
                    if (response.success) {
                        $("#sy-crm-core-depense-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {

                            $(`#sy-crm-core-depense-edit-result`)
                                .text(response.data.message)
                                .addClass("text-success").removeClass("text-error")
                                .fadeIn()
                                .delay(500)
                                .fadeOut(function() {

                                    location.reload();
                                });
                        })
                    } else {
                        $("#sy-crm-core-depense-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {

                            $(`#sy-crm-core-depense-edit-result`)
                                .text(response.data.message)
                                .removeClass("text-success").addClass("text-error")
                                .fadeIn()
                                .delay(500)
                                .fadeOut(function() {
                                    location.reload();
                                });
                        });
                    }
                },
                error: function() {
                    $(`#${containerNotif}`)
                        .text("Erreur lors de la suppression du event.")
                        .removeClass("text-success").addClass("text-error")
                        .fadeIn()
                        .delay(1500)
                        .fadeOut();
                }
            });
        }
    });

    function closeEditDepenseSidebar() {
        $('#sy-crm-core-depense-edit-sidebar').hide();
        $('#sy-crm-core-depense-edit-file-list').html('').hide();

        $('#sy-crm-core-depense-edit-products-list').html('');
        $('#sy-crm-core-depense-edit-form input, #sy-crm-core-depense-edit-form textarea').attr('readonly', true);
        $('.sy-crm-core-depense-edit-submit').hide();
        $('.sy-crm-core-depense-edit-btn').show();
        $('#sy-crm-core-depense-edit-moyen-reglement option, #sy-crm-core-depense-edit-departement-vendeur option').show();
        $('#edit-product-table th:last, #edit-product-table td:last, #sy-crm-core-depense-edit-ajout-produit-btn, #sy-crm-core-depense-add-new-attachement-tr').hide();
        $('#sy-crm-core-depense-delete-btn').data('id', '');

    }

    // Événement de clic sur les boutons pour fermer le sidebar
    $('.sy-crm-core-depense-edit-sidebar-header-btn, .discard-edit-depense-sidebar').on('click', function() {
        closeEditDepenseSidebar();
    });
    $(document).on('click', function(event) {
        if (!$(event.target).closest('#sy-crm-core-depense-edit-sidebar').length) {
            closeEditDepenseSidebar();
        }
    });
    $(document).on('click', '.sy-crm-core-depense-edit-btn', function(event) {
        $(this).hide();
        $('.sy-crm-core-depense-edit-submit').show();
        $('#sy-crm-core-depense-edit-form input, #sy-crm-core-depense-edit-form textarea').attr('readonly', false);
        $('#sy-crm-core-depense-edit-moyen-reglement option, #sy-crm-core-depense-edit-departement-vendeur option').show();
        $('#edit-product-table th,#edit-product-table td,#sy-crm-core-depense-edit-ajout-produit-btn,#sy-crm-core-depense-add-new-attachement-tr').show()
            // $('#edit-product-table tr').find('.product_quantite').attr('type', 'number');
        $('#edit-product-table').find('.sy-crm-core-depense-remove-product:first').hide();
        $('#sy-crm-core-depense-edit-tiers-pays,#sy-crm-core-depense-edit-tiers-entreprise').attr('readonly', true);

        $('#sy-crm-core-depense-edit-file-list').show();



    });
    $(document).on('click', '#sy-crm-core-depense-edit-ajout-produit-btn', function(event) {
        // Cloner les deux premiers <tr> et vider leurs champs
        var row1 = $('#edit-product-table tr:eq(1)').clone();
        var row2 = $('#edit-product-table tr:eq(2)').clone();

        var nomnewProductContainer = $('#sy-crm-core-depense-edit-new-product').html();
        row1.find('input').val('');
        row2.find('textarea').val('');
        row1.find('td:eq(0)').html(nomnewProductContainer);
        row1.find('.sy-crm-core-depense-remove-product').show();
        var newPContainer = $("<div class='sy-crm-core-depense-product-col'></div>");
        newPContainer.append(nomnewProductContainer);
        row1.find('td:eq(0)').html(newPContainer);
        $('#edit-product-table').append(row1).append(row2);
    });

    $(document).on('click', '.sy-crm-core-depense-edit-new-produit-btn', function() {
        var container = $(this).closest('tr');

        $(this).text() === 'Créer?' ? $(this).text('Chercher?') : $(this).text('Créer?');

        container.find('.sy-crm-core-depense-edit-nouveau-produit-name').val('');
        container.next().find('.product_description').val('');

        container.find('.sy-crm-core-depense-edit-nouveau-produit-flag').val() == '1' ? container.find('.sy-crm-core-depense-edit-nouveau-produit-flag').val('0') : container.find('sy-crm-core-depense-edit-nouveau-produit-flag').val('1');


        container.find('.product_pu_ht,.product_quantite,.product_total_ht,.product_tva,.product_pu_ttc,.product_total_ttc').val('');

    });

    $(document).on('click', '.sy-crm-core-depense-remove-product', function(event) {
        event.stopPropagation();
        var row = $(this).closest('tr');
        var rowIndex = row.index();

        if (rowIndex !== 1) {
            row.next().remove();
            row.remove();
            calculateTotalEdit();
        } else {
            event.preventDefault()
        }

    });
    $('#sy-crm-core-depense-edit-form').submit(function(e) {
        e.preventDefault();
        var isValid = true;
        $(this).find('.text-error').remove();

        // Validation des champs requis
        $(this).find('select:visible, input:visible').not('#sy-crm-core-depense-edit-file-input').each(function() {
            if (!$(this).val()) {
                isValid = false;
                $(this).after('<span class="text-error">Ce champ est requis.</span>');
            }
        });

        if (!isValid) {
            return;
        }

        // Formater les données des produits
        var produitsFinal = [];
        $('#edit-product-table tr').each(function(index) {
            if (index > 0 && index % 2 !== 0) {
                var idProduit = $(this).find('.sy-crm-core-depense-edit-nouveau-produit-id').val();
                var nomProduit = $(this).find('.sy-crm-core-depense-edit-nouveau-produit-name').val();
                var quantite = $(this).find('.product_quantite').val();
                var prixUnitaireHT = $(this).find('.product_pu_ht').val();
                var prixUnitaireTTC = $(this).find('.product_pu_ttc').val();
                var tva = $(this).find('.product_tva').val();
                var totalHT = $(this).find('.product_total_ht').val();
                var totalTTC = $(this).find('.product_total_ttc').val();
                let nouveauP = $(this).find('.sy-crm-core-depense-edit-nouveau-produit-flag').val();
                /* if (nouveauP == 0) {
                     nomProduit = $(this).find('.sy-crm-core-depense-edit-produit-select').val()

                 }*/
                // La description est dans la ligne suivante
                var description = $(this).next().find('.product_description').val();

                produitsFinal.push({
                    id: idProduit,
                    nom: nomProduit,
                    quantite: quantite,
                    prixUnitaire: prixUnitaireHT,
                    prixUnitaireTTC: prixUnitaireTTC,
                    tva: tva,
                    totalHt: totalHT,
                    totalTtc: totalTTC,
                    description: description,
                    nouveau: nouveauP,
                });
            }

        });
        console.log('sqq', produitsFinal);

        let formData = new FormData();
        formData.append('action', 'crm_modifier_depense');
        formData.append('depense_id', $('#sy-crm-core-depense-edit-id').val());

        // Ajout des autres données du formulaire
        formData.append('date_depense', $('#sy-crm-core-depense-edit-date-depense').val());
        formData.append('tiers', $('#sy-crm-core-depense-edit-tiers').val());
        formData.append('pays', $('#sy-crm-core-depense-edit-titre-pays').val());
        formData.append('moyen_reglement', $('#sy-crm-core-depense-edit-moyen-reglement').val());
        formData.append('commentaire', $('#sy-crm-core-depense-edit-commentaire').val());
        formData.append('total_depense_ht', $('#sy-crm-core-depense-edit-total-ht').val());
        formData.append('total_depense_ttc', $('#sy-crm-core-depense-edit-total-ttc').val());
        formData.append('titre_depense', $('#sy-crm-core-depense-edit-titre-depense').val());
        formData.append('vendeur', $('#sy-crm-core-depense-edit-departement-vendeur').val());

        // Ajouter les produits formatés
        formData.append('produits', JSON.stringify(produitsFinal));
        let files = $('#sy-crm-core-depense-edit-file-input')[0].files;
        for (let i = 0; i < files.length; i++) {
            formData.append('pieces_jointes[]', files[i]);
        }

        // Envoi des données avec AJAX
        $.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                if (response.success) {
                    $("#sy-crm-core-depense-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {



                        $('#sy-crm-core-depense-edit-result').html('<p style="color: green;">Dépense modifiée avec succès.</p>');
                        setTimeout(function() {
                            location.reload();
                        }, 500);
                    })
                } else {
                    $("#sy-crm-core-depense-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {



                        $('#sy-crm-core-depense-edit-result').html('<p style="color: red;">' + response.data.message + '</p>');
                    })
                }
            }
        });
    });

    $(document).on('change', '.sy-crm-core-depense-edit-produit-select', function() {
        var selectedOption = $(this).find(':selected');

        var container = $(this).closest('tr');
        container.find('.sy-crm-core-depense-edit-nouveau-produit-id').val(selectedOption.val());
        var price = (selectedOption.data('price')) || 0;
        var description = selectedOption.data('description') || '';
        var tva = selectedOption.data('tva') != "" ? (selectedOption.data('tva')) : 0;

        container.find('.sy-crm-core-depense-edit-nouveau-produit-name').val((selectedOption.text()));
        container.find('.product_pu_ht').val((price));
        container.find('.product_quantite').val(1);
        container.find('.product_total_ht').val((price));
        container.next('tr').find('.product_description').val(description);
        container.find('.product_tva').val((tva));

        updateTotalPerProductEdit(container);
    });
    // Gestion des modifications sur les champs
    $(document).on('input', '.product_quantite, .product_tva, .product_pu_ht, .product_total_ht, .product_pu_ttc, .product_total_ttc', function() {
        var container = $(this).closest('tr');
        updateTotalPerProductEdit(container);
    });





    function updateTotalPerProductEdit(container) {
        function sanitizeNumber(value) {
            return parseFloat(value.replace(',', '.')) || 0; // Remplace les virgules et convertit en float
        }

        var priceHT = sanitizeNumber(container.find('.product_pu_ht').val());
        var quantity = sanitizeNumber(container.find('.product_quantite').val());
        var tva = sanitizeNumber(container.find('.product_tva').val());
        var totalHT = sanitizeNumber(container.find('.product_total_ht').val());
        var priceTTC = sanitizeNumber(container.find('.product_pu_ttc').val());
        var totalTTC = sanitizeNumber(container.find('.product_total_ttc').val());

        console.log('aaaa', totalTTC, priceTTC, totalHT, tva, priceHT);

        if (priceHT > 0 && quantity > 0 && tva >= 0) {
            totalHT = priceHT * quantity;
            var totalTVA = (totalHT * tva) / 100;
            totalTTC = totalHT + totalTVA;
            priceTTC = priceHT * (1 + tva / 100);

            container.find('.product_total_ht').val(totalHT.toFixed(2));
            container.find('.product_total_ttc').val(totalTTC.toFixed(2));
            container.find('.product_pu_ttc').val(priceTTC.toFixed(2));
        } else if (totalHT > 0 && quantity > 0 && tva >= 0) {
            priceHT = totalHT / quantity;
            priceTTC = priceHT * (1 + tva / 100);
            totalTTC = totalHT + (totalHT * tva / 100);

            container.find('.product_pu_ht').val(priceHT.toFixed(2));
            container.find('.product_pu_ttc').val(priceTTC.toFixed(2));
            container.find('.product_total_ttc').val(totalTTC.toFixed(2));
        } else if (totalTTC > 0 && quantity > 0 && tva >= 0) {
            totalHT = totalTTC / (1 + tva / 100);
            priceHT = totalHT / quantity;
            priceTTC = priceHT * (1 + tva / 100);

            container.find('.product_pu_ht').val(priceHT.toFixed(2));
            container.find('.product_total_ht').val(totalHT.toFixed(2));
            container.find('.product_pu_ttc').val(priceTTC.toFixed(2));
        } else if (priceTTC > 0 && quantity > 0 && tva >= 0) {
            priceHT = priceTTC / (1 + tva / 100);
            totalHT = priceHT * quantity;
            totalTTC = totalHT + (totalHT * tva / 100);

            container.find('.product_pu_ht').val(priceHT.toFixed(2));
            container.find('.product_total_ht').val(totalHT.toFixed(2));
            container.find('.product_total_ttc').val(totalTTC.toFixed(2));
        }

        // Mettre à jour le total général de la dépense
        calculateTotalEdit();
    }

    function calculateTotalEdit() {
        var totalDepenseHT = 0;
        var totalDepenseTTC = 0;

        $('#edit-product-table tbody tr').each(function() {
            console.log($(this))
                //var totalHT = parseFloat($(this).find('.').val().replace(',', '.')) || 0;
                //var totalTTC = parseFloat($(this).find('.').val().replace(',', '.')) || 0;
            var totalHT = parseFormattedNumber($(this).find('.product_total_ht').val()) || 0;
            var totalTTC = parseFormattedNumber($(this).find('.product_total_ttc').val()) || 0;

            totalDepenseHT += totalHT;
            totalDepenseTTC += totalTTC;
        });

        $('#sy-crm-core-depense-edit-total-ht').val(totalDepenseHT.toFixed(2));
        $('#sy-crm-core-depense-edit-total-ttc').val(totalDepenseTTC.toFixed(2));
    }

    function parseFormattedNumber(value) {
        if (!value) return 0;
        value = value.toString();
        value = value.replace(/\s/g, '').replace(',', '.');
        return parseFloat(value) || 0;
    }
})