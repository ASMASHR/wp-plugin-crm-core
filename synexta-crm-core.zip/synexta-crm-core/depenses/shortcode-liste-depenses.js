jQuery(document).ready(function($) {

    //list depense
    var depenseTable = $('#sy-crm-core-depense-table').DataTable({
        "paging": true,
        "pageLength": $('#sy-crm-core-depense-table').data('count'),
        "searching": true,
        "ordering": true,
        "search": {
            "smart": false,
            "caseInsensitive": true
        },
        "searchDelay": 100,
        "columnDefs": [{
                "orderable": true,
                "targets": 0,
                "type": 'html'
            },
            { "orderable": false, "targets": 8 },
            { "responsivePriority": 1, "targets": [0, 1, 8] },
            { "responsivePriority": 2, "targets": '_all' }
        ],
        "order": [
            [0, 'asc']
        ],
        "lengthChange": false,
        "info": true,
        "responsive": true,
        "language": {
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            "info": " _START_ - _END_ / _TOTAL_",
            "infoEmpty": "Aucune dépense disponible",
            "zeroRecords": "Aucune dépense correspondant trouvé",
            "emptyTable": "Aucune dépense trouvé",
            "infoFiltered": "(filtré à partir de _MAX_ entrées )"
        },
        "drawCallback": function() {
            //$('.dataTables_paginate').appendTo('.sy-sy-crm-core-depense-table-info');
            // $('#sy-sy-crm-core-depense-table-custom-info').html($('.dataTables_info').html());
        }
    });

    if ($('#sy-crm-core-depense-table_filter').length > 0) {
        $('#sy-crm-core-depense-table_filter').hide()
    }



    $('#sy-crm-core-depense-table-search').on('keyup', function() {
        let value = $(this).val();
        depenseTable.search(value).draw();

    });



    // Appliquer le filtrage lors du changement de statut
    $('#sy-crm-core-depense-table-reglement-search').on('change', function() {
        let value = $(this).val();
        depenseTable.search(value).draw();
    });
    $('#sy-crm-core-depense-table-departement-search').on('change', function() {
        let value = $(this).val();
        depenseTable.search(value).draw();
    });


    $(document).on('click', '.sy-crm-core-depense-table-menu-detail-btn', function() {
        var depenseId = $(this).data('id');
        if (depenseId) {
            $.ajax({
                url: ajax_object.ajax_url,
                type: 'POST',
                data: {
                    action: 'get_depense_details',
                    depense_id: depenseId
                },
                success: function(response) {
                    if (response.success) {
                        var productsHtml = "";
                        var data = response.data;
                        $('#sy-crm-core-depense-delete-btn').data('id', depenseId);
                        $('#sy-crm-core-depense-edit-id').val(depenseId).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-titre-depense').val(data.nom).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-titre-pays').val(data.depense_pays).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-tiers').val(data.tiers_id).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-tiers-pays').val(data.depense_pays).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-tiers-entreprise').val(data.depense_entreprise).attr('readonly', true);
                        //formData.append('tiers', $('').val());

                        $('#sy-crm-core-depense-edit-moyen-reglement').val(data.moyen_reglement).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-moyen-reglement option').each(function() {
                            if ($(this).val() !== data.moyen_reglement) {
                                $(this).hide();
                            }
                        }).prop('readonly', true);
                        var $field = $('#sy-crm-core-depense-edit-departement-vendeur');

                        if ($field.is('select')) {
                            var optionExists = false;

                            $field.find('option').each(function() {
                                if ($(this).val() === data.vendeur) {
                                    optionExists = true;
                                } else {
                                    $(this).hide();
                                }
                            });

                            // Si l'option n'existe pas, on l'ajoute et on la sélectionne
                            if (!optionExists) {
                                $field.append(new Option(data.vendeur, data.vendeur, true, true));
                            }

                            $field.val(data.vendeur);
                        } else if ($field.is('input')) {
                            // Si c'est un <input>, on assigne simplement la valeur
                            $field.val(data.vendeur);
                        }

                        // Rendre le champ en lecture seule
                        $field.prop('readonly', true);

                        if (data.canEdit) {
                            $('.sy-crm-core-depense-edit-btn').show();

                        } else {
                            $('.sy-crm-core-depense-edit-btn').hide();

                        }

                        if (data.canDelete) {
                            $('.sy-crm-core-depense-delete').show();

                        } else {
                            $('.sy-crm-core-depense-delete').hide();

                        }
                        /*$('#sy-crm-core-depense-edit-departement-vendeur').val(data.vendeur_id).attr('readonly', true);*/
                        $('#sy-crm-core-depense-edit-date-depense').val(data.date).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-total-ht').val(data.total_ht).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-total-ttc').val(data.total_ttc).attr('readonly', true);
                        $('#sy-crm-core-depense-edit-commentaire').val(data.commentaire).attr('readonly', true);
                        productsHtml += '<p class="sy-crm-core-depense-section-title">Produits :</p><table class="sy-crm-core-depense-edit-product-table" id="edit-product-table">';
                        productsHtml += '<thead><tr><th style="display:none"></th><th>Nom</th><th>Qté</th><th>PU HT</th><th>Total HT</th> <th>TVA %</th><th>PU TTC</th><th>Total TTC</th></tr></thead><tbody>';
                        //<th>Réf</th>
                        data.products.forEach(function(produit) {
                            productsHtml += '<tr class="product-row">';
                            // productsHtml += '<td><input value="' + produit.idProduit + '"class="sy-crm-core-depense-edit-nouveau-produit-id"readonly style="max-width: 93px;"></input></td>';
                            productsHtml += '<td style="display:none"><button class="sy-crm-core-depense-remove-product">-</button></td>';
                            productsHtml += '<td  data-label="Nom du produit"> <div class="sy-crm-core-depense-product-col"><div class="sy_crm_core_depense_tiers_search_container"><input type="text" value="' + produit.nomProduit + '" class="sy-crm-core-depense-edit-nouveau-produit-name"  readOnly/><ul class="sy_crm_core_depense_products_suggestions"></ul></div><input type = "hidden"name = ""class = "sy-crm-core-depense-edit-nouveau-produit-id"value = "' + produit.idProduit + '" ><input type = "hidden"name = ""class = "sy-crm-core-depense-edit-nouveau-produit-flag"value = "0" ></div></td > ';
                            productsHtml += '<td data-label="Quantité"><input type="number" value="' + produit.quantite.toString() + '" class="product_quantite" readonly style="max-width: 100px;"></td>';
                            productsHtml += '<td data-label="Prix unitaire HT"><input type="text"value="' + produit.prixUnitaire_ht + '"class="product_pu_ht"readonly style="max-width: 110px;"></input></td>';
                            productsHtml += '<td data-label="Total HT"><input type="text"value="' + produit.total_ht + '"class="product_total_ht"readonly style="max-width: 110px;"></input></td>';
                            productsHtml += '<td data-label="TVA sur produit"><input type="text"value="' + produit.tva + '"class="product_tva"readonly style="max-width: 110px;"data-default-val="' + data.default_tva + '"></input></td>';
                            productsHtml += '<td data-label="Prix unitaire TTC"><input type="text"value="' + produit.prixUnitaire_ttc + '"class="product_pu_ttc"readonly style="max-width: 110px;"></input></td>';

                            productsHtml += '<td data-label="Total TTC"><input type="text" value="' + produit.total_ttc + '"class="product_total_ttc"readonly style="max-width: 110px;"></input></td>';
                            productsHtml += '</tr>';
                            productsHtml += '<tr class="product-description-row"><td  data-label="Description" colspan="9"><textarea value="' + produit.description + '"class="product_description"readonly placeholder="description">' + produit.description + '</textarea></td></tr>';
                        });


                        productsHtml += '</tbody></table>';
                        $('#sy-crm-core-depense-edit-products-list').html(productsHtml);
                        if (data.pieces_jointes.length > 0) {
                            var attachmentsArray = data.pieces_jointes;

                            let attachmentsHtml = "<p>Pièces joints</p><table><thead><tr></tr></thead><tbody>";

                            attachmentsArray.forEach((docUrl) => {


                                const fileName = docUrl.split("/").pop();
                                const fileExtension = fileName.split('.').pop().toLowerCase();
                                const iconUrl = data.plugin_base_url + '/' + depenseGetFileIcon(fileExtension);
                                const deleteIcon = data.plugin_base_url + '/trash-icon.svg';
                                attachmentsHtml += `
                                    <tr>
                                        <td class="crm_depense_attachement_type"><img class="icon-attachment" src="${iconUrl}" alt="File Icon"></td>
                    
                                        <td class="crm_depense_attachement_name"><a href="${docUrl}" target="_blank">${fileName}</a></td>
                                        <td class="crm_depense_attachement_action"style='display:none'> `;

                                if (data.canDelete == true) {
                                    attachmentsHtml += `<img  class="delete-attachment" data-depense-id="${depenseId}" data-url="${docUrl}" src="${deleteIcon}" alt="delete Icon">
                                    `;
                                } else {
                                    attachmentsHtml += `--`;
                                }
                                attachmentsHtml += `
                                        </td>
                                        </tr>
                                `;
                            });


                            if (data.canEdit == true) {
                                const iconAdd = data.plugin_base_url + "add-icon.svg";
                                attachmentsHtml += ` <tr id="sy-crm-core-depense-add-new-attachement-tr"style="display:none;">
                                <td colspan="3">
                                <input type="file" id="sy-crm-core-depense-edit-file-input" multiple>
          
                            
                                
                                </td>
                            </tr>`;
                            }
                            attachmentsHtml += "</tbody></table>";


                            $('#sy-crm-core-depense-edit-file-list').html(attachmentsHtml).show();


                        } else {
                            let attachmentsHtml = "<p class='sy-crm-core-depense-section-title'>Pièces joints</p><table><thead><tr></tr></thead><tbody>";


                            if (data.canEdit == true) {
                                const iconAdd = data.plugin_base_url + "add-icon.svg";
                                attachmentsHtml += ` <tr id="sy-crm-core-depense-add-new-attachement-tr"style="display:none;">
                                <td colspan="3">
                                <input type="file" id="sy-crm-core-depense-edit-file-input" multiple>
          
                            
                                
                                </td>
                            </tr>`;
                            }
                            attachmentsHtml += "</tbody></table>";

                            $('#sy-crm-core-depense-edit-file-list').html(attachmentsHtml).hide();
                        }


                        $('#sy-crm-core-depense-edit-sidebar').show().addClass('open');


                    } else {
                        alert('Erreur: ' + response.data);
                    }
                }
            });
        }
    });
    $('.sy-crm-core-depense-edit-sidebar-header-btn,.discard-edit-depense-sidebar').on('click', function() {

        closeEditDepenseSidebar();



    });

    function depenseGetFileIcon(fileExtension) {
        switch (fileExtension) {
            case 'pdf':
                return 'pdf-icon.svg';
            case 'doc':
            case 'docx':
                return 'word-icon.svg';
            case 'xls':
            case 'xlsx':
                return 'excel-icon.svg';
            case 'jpg':
            case 'jpeg':
            case 'png':
                return 'image-icon.svg';
            case 'zip':
            case 'rar':
                return 'zip-icon.svg';
            default:
                return 'default-icon.svg';
        }
    }

    $(document).on("click", ".delete-attachment", function() {
        const button = $(this);
        const depenseId = button.data("depense-id");
        const docUrl = button.data("url");

        if (confirm("Êtes-vous sûr de vouloir supprimer cette pièce jointe?")) {

            $.ajax({
                url: ajax_object.ajax_url,
                method: "POST",
                data: {
                    action: "crm_depense_delete_attachement",
                    depense_id: depenseId,
                    attachement_url: docUrl,
                },
                success: function(response) {
                    if (response.success) {
                        //alert(response.data.message);
                        // location.reload();
                        $("#sy-crm-core-depense-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {

                            $(`#sy-crm-core-depense-edit-result`)
                                .text("Attachement supprimé avec succès")
                                .addClass("text-success").removeClass("text-error")
                                .fadeIn()
                                .delay(500)
                                .fadeOut(function() {
                                    location.reload();
                                });
                        })
                    } else {
                        $("#sy-crm-core-depense-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {


                            $('#sy-crm-core-depense-edit-result')
                                .text(response.data.message)
                                .removeClass("text-success").addClass("text-error")
                                .fadeIn()
                                .delay(500)
                                .fadeOut(

                                );
                        })
                    }

                },
                error: function() {
                    alert("Une erreur s\'est produite lors de la suppression du event.");
                },
            });
        }


    });
    $(document).on("click", "#sy-crm-core-depense-delete-btn", function(e) {
        e.preventDefault();
        const depenseId = $(this).data("id");

        if (confirm("Êtes-vous sûr de vouloir supprimer cet dépense? ?")) {
            $.ajax({
                url: ajax_object.ajax_url,
                type: "POST",
                data: {
                    action: "crm_delete_depense",
                    depense_id: depenseId,
                },
                success: function(response) {
                    if (response.success) {
                        $("#sy-crm-core-depense-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {

                            $(`#sy-crm-core-depense-edit-result`)
                                .text(response.data.message)
                                .addClass("text-success").removeClass("text-error")
                                .fadeIn()
                                .delay(500)
                                .fadeOut(function() {

                                    location.reload();
                                });
                        })
                    } else {
                        $("#sy-crm-core-depense-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {

                            $(`#sy-crm-core-depense-edit-result`)
                                .text(response.data.message)
                                .removeClass("text-success").addClass("text-error")
                                .fadeIn()
                                .delay(500)
                                .fadeOut(function() {
                                    location.reload();
                                });
                        });
                    }
                },
                error: function() {
                    $(`#${containerNotif}`)
                        .text("Erreur lors de la suppression du event.")
                        .removeClass("text-success").addClass("text-error")
                        .fadeIn()
                        .delay(1500)
                        .fadeOut();
                }
            });
        }
    });

    function closeEditDepenseSidebar() {
        $('#sy-crm-core-depense-edit-sidebar').hide();
        $('#sy-crm-core-depense-edit-file-list').html('').hide();

        $('#sy-crm-core-depense-edit-products-list').html('');
        $('#sy-crm-core-depense-edit-form input, #sy-crm-core-depense-edit-form textarea').attr('readonly', true);
        $('.sy-crm-core-depense-edit-submit').hide();
        $('.sy-crm-core-depense-edit-btn').show();
        $('#sy-crm-core-depense-edit-moyen-reglement option, #sy-crm-core-depense-edit-departement-vendeur option').show();
        $('#edit-product-table th:first, #edit-product-table td:first, #sy-crm-core-depense-edit-ajout-produit-btn, #sy-crm-core-depense-add-new-attachement-tr').hide();
        $('#sy-crm-core-depense-delete-btn').data('id', '');

    }

    // Événement de clic sur les boutons pour fermer le sidebar
    $('.sy-crm-core-depense-edit-sidebar-header-btn, .discard-edit-depense-sidebar').on('click', function() {
        closeEditDepenseSidebar();
    });
    $(document).on('click', function(event) {
        if (!$(event.target).closest('#sy-crm-core-depense-edit-sidebar').length) {
            closeEditDepenseSidebar();
        }
    });
    $(document).on('click', '.sy-crm-core-depense-edit-btn', function(event) {
        $(this).hide();
        $('.sy-crm-core-depense-edit-submit').show();
        $('#sy-crm-core-depense-edit-form input, #sy-crm-core-depense-edit-form textarea').attr('readonly', false);
        $('#sy-crm-core-depense-edit-moyen-reglement option, #sy-crm-core-depense-edit-departement-vendeur option').show();
        $('#edit-product-table th,#edit-product-table td,#sy-crm-core-depense-edit-ajout-produit-btn,#sy-crm-core-depense-add-new-attachement-tr').show()
            // $('#edit-product-table tr').find('.product_quantite').attr('type', 'number');
        $('#edit-product-table').find('.sy-crm-core-depense-remove-product:first').hide();
        $('#sy-crm-core-depense-edit-tiers-pays,#sy-crm-core-depense-edit-tiers-entreprise').attr('readonly', true);

        $('#sy-crm-core-depense-edit-file-list').show();
        $('.crm_depense_attachement_action').show();



    });
    $(document).on('click', '#sy-crm-core-depense-edit-ajout-produit-btn', function(event) {
        // Cloner les deux premiers <tr> et vider leurs champs
        var row1 = $('#edit-product-table tr:eq(1)').clone();
        var row2 = $('#edit-product-table tr:eq(2)').clone();

        var nomnewProductContainer = $('#sy-crm-core-depense-edit-new-product').html();
        row1.find('input').val('');
        row1.find('.sy-crm-core-depense-remove-product').show()
        row2.find('textarea').val('');
        row1.find('td:eq(1)').html(nomnewProductContainer);
        $('#edit-product-table').append(row1).append(row2);
    });

    $(document).on('click', '.sy-crm-core-depense-edit-new-produit-btn', function() {
        var container = $(this).closest('tr');

        $(this).text() === 'Créer?' ? $(this).text('Chercher?') : $(this).text('Créer?');

        container.find('.sy-crm-core-depense-edit-nouveau-produit-name').val('');
        container.next().find('.product_description').val('');

        container.find('.sy-crm-core-depense-edit-nouveau-produit-flag').val() == '1' ? container.find('.sy-crm-core-depense-edit-nouveau-produit-flag').val('0') : container.find('.sy-crm-core-depense-edit-nouveau-produit-flag').val('1');


        container.find('.product_pu_ht,.product_total_ht,.product_tva,.product_pu_ttc,.product_total_ttc').val('');
        container.find('.product_quantite').val(1);

        var tva = container.find('.sy-crm-core-depense-edit-nouveau-produit-flag').val() == '1' ? container.find('.product_tva').data('default-val') : '';
        container.find('.product_tva').val(formatPrice(tva));

    });

    $(document).on('click', '.sy-crm-core-depense-remove-product', function(event) {
        event.stopPropagation();
        var row = $(this).closest('tr');
        var rowIndex = row.index();

        if (rowIndex !== 1) {
            row.next().remove();
            row.remove();
            calculateTotalEdit();
        } else {
            event.preventDefault()
        }

    });
    $('#sy-crm-core-depense-edit-form').submit(function(e) {
        e.preventDefault();
        var isValid = true;
        $(this).find('.text-error').remove();

        // Validation des champs requis
        $(this).find('select:visible, input:visible').not('#sy-crm-core-depense-edit-file-input').each(function() {
            if (!$(this).val()) {
                isValid = false;
                $(this).after('<span class="text-error">Ce champ est requis.</span>');
            }
        });

        if (!isValid) {
            return;
        }

        // Formater les données des produits
        var produitsFinal = [];
        $('#edit-product-table tr').each(function(index) {
            if (index > 0 && index % 2 !== 0) {
                var idProduit = $(this).find('.sy-crm-core-depense-edit-nouveau-produit-id').val();
                var nomProduit = $(this).find('.sy-crm-core-depense-edit-nouveau-produit-name').val();
                var quantite = $(this).find('.product_quantite').val();
                var prixUnitaireHT = $(this).find('.product_pu_ht').val();
                var prixUnitaireTTC = $(this).find('.product_pu_ttc').val();
                var tva = $(this).find('.product_tva').val();
                var totalHT = $(this).find('.product_total_ht').val();
                var totalTTC = $(this).find('.product_total_ttc').val();
                let nouveauP = $(this).find('.sy-crm-core-depense-edit-nouveau-produit-flag').val();
                /* if (nouveauP == 0) {
                     nomProduit = $(this).find('.sy-crm-core-depense-edit-produit-select').val()

                 }*/
                // La description est dans la ligne suivante
                var description = $(this).next().find('.product_description').val();

                produitsFinal.push({
                    id: idProduit,
                    nom: nomProduit,
                    quantite: quantite,
                    prixUnitaire: prixUnitaireHT,
                    prixUnitaireTTC: prixUnitaireTTC,
                    tva: tva,
                    totalHt: totalHT,
                    totalTtc: totalTTC,
                    description: description,
                    nouveau: nouveauP,
                });
            }

        });

        let formData = new FormData();
        formData.append('action', 'crm_modifier_depense');
        formData.append('depense_id', $('#sy-crm-core-depense-edit-id').val());

        // Ajout des autres données du formulaire
        formData.append('date_depense', $('#sy-crm-core-depense-edit-date-depense').val());
        formData.append('tiers', $('#sy-crm-core-depense-edit-tiers').val());
        formData.append('pays', $('#sy-crm-core-depense-edit-titre-pays').val());
        formData.append('moyen_reglement', $('#sy-crm-core-depense-edit-moyen-reglement').val());
        formData.append('commentaire', $('#sy-crm-core-depense-edit-commentaire').val());
        formData.append('total_depense_ht', $('#sy-crm-core-depense-edit-total-ht').val());
        formData.append('total_depense_ttc', $('#sy-crm-core-depense-edit-total-ttc').val());
        formData.append('titre_depense', $('#sy-crm-core-depense-edit-titre-depense').val());
        formData.append('vendeur', $('#sy-crm-core-depense-edit-departement-vendeur').val());

        // Ajouter les produits formatés
        formData.append('produits', JSON.stringify(produitsFinal));
        let files = $('#sy-crm-core-depense-edit-file-input')[0].files;
        for (let i = 0; i < files.length; i++) {
            formData.append('pieces_jointes[]', files[i]);
        }

        // Envoi des données avec AJAX
        $.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                if (response.success) {
                    $("#sy-crm-core-depense-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {



                        $('#sy-crm-core-depense-edit-result').html('<p style="color: green;">Dépense modifiée avec succès.</p>');
                        setTimeout(function() {
                            location.reload();
                        }, 500);
                    })
                } else {
                    $("#sy-crm-core-depense-edit-sidebar").animate({ scrollTop: 0 }, 500, function() {



                        $('#sy-crm-core-depense-edit-result').html('<p style="color: red;">' + response.data.message + '</p>');
                    })
                }
            }
        });
    });

    /* $(document).on('change', '.sy-crm-core-depense-edit-produit-select', function() {
         var selectedOption = $(this).find(':selected');

         var container = $(this).closest('tr');
         container.find('.sy-crm-core-depense-edit-nouveau-produit-id').val(selectedOption.val());
         var price = (selectedOption.data('price')) || 0;
         var description = selectedOption.data('description') || '';
         var tva = selectedOption.data('tva') != "" ? (selectedOption.data('tva')) : 0;

        
     });*/
    // Gestion des modifications sur les champs
    $(document).on('input', '.product_quantite, .product_tva, .product_pu_ht, .product_total_ht, .product_pu_ttc, .product_total_ttc', function() {
        var container = $(this).closest('tr');
        updateTotalPerProductEdit(container);
    });

    $(document).on('input', '.sy-crm-core-depense-edit-nouveau-produit-name', function() {
        var query = $(this).val();
        var container = $(this).closest('tr');
        var $this = $(this);
        var newProductFlag = (container.find('.sy-crm-core-depense-edit-nouveau-produit-flag')).val()

        if (query.length >= 3 && newProductFlag == 0) {
            $.ajax({
                url: ajax_object.ajax_url,
                method: 'GET',
                data: {
                    action: 'search_product_data',
                    query: query
                },
                success: function(response) {
                    if (response.success) {
                        var results = response.data;
                        var suggestionsList = $this.next('.sy_crm_core_depense_products_suggestions');
                        suggestionsList.empty();

                        if (results.length > 0) {
                            suggestionsList.show();

                            results.forEach(function(product) {
                                // Ajoutez les données nécessaires en tant qu'attributs data-*
                                suggestionsList.append(
                                    '<li class="suggestion-product" ' +
                                    'data-product-id="' + product.product_id + '" ' +
                                    'data-price="' + product.price + '" ' +
                                    'data-description="' + product.description + '" ' +
                                    'data-tva="' + product.tax_rate + '">' +
                                    product.nom +
                                    '</li>'
                                );
                            });
                        } else {
                            suggestionsList.hide();
                        }
                    }
                },
                error: function() {
                    console.log('Erreur lors de la récupération des produits.');
                }
            });
        } else {
            $this.next('.sy_crm_core_depense_products_suggestions').hide();
        }
    });

    $(document).on('click', '.suggestion-product', function() {
        var productId = $(this).data('product-id');
        var price = parseFloat($(this).data('price'));
        var tva = parseFloat($(this).data('tva'));
        var description = $(this).data('description');
        var container = $(this).closest('tr');
        var quantite = container.find('.quantite').val() || 1;
        container.find('.tva-depense').val(formatPrice(tva.toFixed(2)));

        var totalHT = price * quantite;
        var totalTTC = totalHT * (1 + tva / 100);

        container.find('.sy-crm-core-depense-edit-nouveau-produit-id').val(productId);
        //

        container.find('.sy-crm-core-depense-edit-nouveau-produit-name').val($(this).text());
        container.find('.product_pu_ht').val(formatPrice(price.toFixed(2)));
        container.find('.product_quantite').val(1);
        container.find('.product_total_ht').val((totalHT));
        container.next('tr').find('.product_description').val(description);
        container.find('.product_tva').val((tva));

        updateTotalPerProductEdit(container);
        //

        $(this).parent().hide();

        updateTotalPerProductEdit(container);
    });



    function updateTotalPerProductEdit(container) {
        function sanitizeNumber(value) {
            return parseFloat(value.replace(',', '.')) || 0; // Remplace les virgules et convertit en float
        }

        var priceHT = sanitizeNumber(container.find('.product_pu_ht').val());
        var quantity = sanitizeNumber(container.find('.product_quantite').val());
        var tva = sanitizeNumber(container.find('.product_tva').val());
        var totalHT = sanitizeNumber(container.find('.product_total_ht').val());
        var priceTTC = sanitizeNumber(container.find('.product_pu_ttc').val());
        var totalTTC = sanitizeNumber(container.find('.product_total_ttc').val());

        console.log('aaaa', totalTTC, priceTTC, totalHT, tva, priceHT);

        if (priceHT > 0 && quantity > 0 && tva >= 0) {
            totalHT = priceHT * quantity;
            var totalTVA = (totalHT * tva) / 100;
            totalTTC = totalHT + totalTVA;
            priceTTC = priceHT * (1 + tva / 100);

            container.find('.product_total_ht').val(totalHT.toFixed(2));
            container.find('.product_total_ttc').val(totalTTC.toFixed(2));
            container.find('.product_pu_ttc').val(priceTTC.toFixed(2));
        } else if (totalHT > 0 && quantity > 0 && tva >= 0) {
            priceHT = totalHT / quantity;
            priceTTC = priceHT * (1 + tva / 100);
            totalTTC = totalHT + (totalHT * tva / 100);

            container.find('.product_pu_ht').val(priceHT.toFixed(2));
            container.find('.product_pu_ttc').val(priceTTC.toFixed(2));
            container.find('.product_total_ttc').val(totalTTC.toFixed(2));
        } else if (totalTTC > 0 && quantity > 0 && tva >= 0) {
            totalHT = totalTTC / (1 + tva / 100);
            priceHT = totalHT / quantity;
            priceTTC = priceHT * (1 + tva / 100);

            container.find('.product_pu_ht').val(priceHT.toFixed(2));
            container.find('.product_total_ht').val(totalHT.toFixed(2));
            container.find('.product_pu_ttc').val(priceTTC.toFixed(2));
        } else if (priceTTC > 0 && quantity > 0 && tva >= 0) {
            priceHT = priceTTC / (1 + tva / 100);
            totalHT = priceHT * quantity;
            totalTTC = totalHT + (totalHT * tva / 100);

            container.find('.product_pu_ht').val(priceHT.toFixed(2));
            container.find('.product_total_ht').val(totalHT.toFixed(2));
            container.find('.product_total_ttc').val(totalTTC.toFixed(2));
        }

        // Mettre à jour le total général de la dépense
        calculateTotalEdit();
    }

    function calculateTotalEdit() {
        var totalDepenseHT = 0;
        var totalDepenseTTC = 0;

        $('#edit-product-table tbody tr').each(function() {
            console.log($(this))
                //var totalHT = parseFloat($(this).find('.').val().replace(',', '.')) || 0;
                //var totalTTC = parseFloat($(this).find('.').val().replace(',', '.')) || 0;
            var totalHT = parseFormattedNumber($(this).find('.product_total_ht').val()) || 0;
            var totalTTC = parseFormattedNumber($(this).find('.product_total_ttc').val()) || 0;

            totalDepenseHT += totalHT;
            totalDepenseTTC += totalTTC;
        });

        $('#sy-crm-core-depense-edit-total-ht').val(totalDepenseHT.toFixed(2));
        $('#sy-crm-core-depense-edit-total-ttc').val(totalDepenseTTC.toFixed(2));
    }

    function parseFormattedNumber(value) {
        if (!value) return 0;
        value = value.toString();
        value = value.replace(/\s/g, '').replace(',', '.');
        return parseFloat(value) || 0;
    }

    const currency = $('#woo_config').data('currency');
    const currencyPos = $('#woo_config').data('currency-pos');
    const decimalSep = $('#woo_config').data('decimal-sep') || ",";
    const thousandSep = $('#woo_config').data('thousand-sep') || " ";
    const numDecimals = parseInt($('#woo_config').data('num-decimals')) || 2;

    function formatPrice(value) {
        let originalValue = value;

        value = value.replace(/,/g, '.');
        let number = parseFloat(value);
        if (isNaN(number)) return "";


        return number.toLocaleString('fr-FR', {
                minimumFractionDigits: numDecimals,
                maximumFractionDigits: numDecimals,
                useGrouping: true
            }).replace(/\s/g, thousandSep)
            .replace('.', decimalSep);

    }



    $(document).on('change', '#sy-crm-core-depense-download-sidebar-options-select', function(event) {
            var action = "";
            $('#sy-crm-core-depense-download-sidebar-msg').html('');
            $('#sy-crm-core-depense-download-sidebar-link').attr('href', '');
            if ($('#sy-crm-core-depense-download-sidebar-options-select').val() == "uniquement listing XLS") {
                action = "dons";
            } else if ($('#sy-crm-core-depense-download-sidebar-options-select').val() == "PDF de tous les dons") {
                action = "all_pdf_dons";
            } else if ($('#sy-crm-core-depense-download-sidebar-options-select').val() == "PDF des dons non envoyés") {
                action = "not_send_pdf_dons";

            }


            $('#action_link').val(action);


        })
        // Button click handlers 
    $('#crm-don-download-list-btn').on('click', function() {
        $('#sy-crm-core-depense-download-sidebar').show().addClass('open');

    });


    //
    $('.sy-crm-core-depense-download-header-discard-btn,.sy-crm-core-depense-download-footer-discard-btn').on('click', function() {
        $('#sy-crm-core-depense-download-sidebar').hide().removeClass('open');
        $('#sy-crm-core-depense-download-sidebar-date-debut').val('');
        $('#sy-crm-core-depense-download-sidebar-date-fin').val('');
        $('#sy-crm-core-depense-download-sidebar-departement-vendeur').val('');
        $('#sy-crm-core-depense-download-sidebar-msg').html('');
        $('#sy-crm-core-depense-download-sidebar-options-checkbox').prop('checked', false);

    });

    $(document).on('click', function(event) {
        if (!$(event.target).closest('#sy-crm-core-depense-download-sidebar, #crm-don-download-list-btn').length) {
            $('#sy-crm-core-depense-download-sidebar').hide().removeClass('open');
            $('#sy-crm-core-depense-download-sidebar-date-debut').val('');
            $('#sy-crm-core-depense-download-sidebar-date-fin').val('');
            $('#sy-crm-core-depense-download-sidebar-departement-vendeur').val('');
            $('#sy-crm-core-depense-download-sidebar-options-checkbox').prop('checked', false);

            $('#sy-crm-core-depense-download-sidebar-msg').html('');
        }
    });
    $('#sy-crm-core-depense-download-sidebar-date-debut').on('change', function() {

        var startDate = $(this).val();
        if (!startDate) return;
        var parts = startDate.split('-');
        var year = parseInt(parts[0], 10);
        var month = parseInt(parts[1], 10);
        var endOfMonthDate = new Date(year, month, 1);
        var endOfMonthStr = endOfMonthDate.toISOString().split('T')[0];

        $('#sy-crm-core-depense-download-sidebar-date-fin')
            .attr('min', startDate)
            .val(endOfMonthStr);
    });

    $('#sy-crm-core-depense-download-sidebar-date-debut,#sy-crm-core-depense-download-sidebar-date-fin,#sy-crm-core-depense-download-sidebar-departement-vendeur').on('change', function() {
        $('#sy-crm-core-depense-download-sidebar-msg').html('');
    });
    // Handle validation and download
    $('#sy-crm-core-depense-button-validate-download').on('click', function(e) {
        e.preventDefault();
        $('#sy-crm-core-depense-download-sidebar-msg').html('');

        $('#sy-crm-core-depense-download-sidebar-link').attr('href', '');
        var dateDebut = $('#sy-crm-core-depense-download-sidebar-date-debut').val();
        var dateFin = $('#sy-crm-core-depense-download-sidebar-date-fin').val();
        var includePdfs = $('#sy-crm-core-depense-download-sidebar-options-checkbox').is(':checked') ? 1 : 0;
        var departement = $('#sy-crm-core-depense-download-sidebar-departement-vendeur').val()
        var ajax_action = 'export_depenses';

        /* $('#sy-crm-core-depense-download-sidebar-msg').html('<span style="color:red;">En cours de dévelopement.</span>');
         return;*/
        var erreurs = [];

        if (!dateDebut) {
            erreurs.push("la date de début");
        }
        if (!dateFin) {
            erreurs.push("la date de fin");
        }
        if (!departement) {
            erreurs.push("le département");
        }

        if (erreurs.length > 0) {
            $('#sy-crm-core-depense-download-sidebar-msg').html(
                '<span style="color:red;">Veuillez renseigner ' + erreurs.join(', ') + '.</span>'
            );
            return;
        }

        var startDate = new Date(dateDebut);
        var endDate = new Date(dateFin);
        var timeDiff = Math.abs(endDate.getTime() - startDate.getTime());
        var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

        if (diffDays > 30) {
            $('#sy-crm-core-depense-download-sidebar-msg').html('<span style="color:red;">La période ne doit pas dépasser 30 jours.</span>');
            return;
        }


        $('#sy-crm-core-depense-download-loading-screen').show();


        // Requête AJAX pour télécharger le fichier  
        $.post(ajax_object.ajax_url, {
            action: ajax_action,
            date_debut: dateDebut,
            date_fin: dateFin,
            include_pdfs: includePdfs,
            departement: departement
        }, function(response) {
            setTimeout(function() {
                $('#sy-crm-core-depense-download-loading-screen').hide();

                if (response.success) {
                    //Téléchargez le ZIP <a href="' + response.data.zip_url + '" download>ici</a>
                    $('#sy-crm-core-depense-download-sidebar-msg').html(
                        '<span style="color:green;">Documents créés avec succès. Téléchargez le fichier xls <a href="' + response.data.xls_url + '" download>ici</a>.</span>'
                    );
                    if (response.data.zip_url != "") {
                        $('#sy-crm-core-depense-download-sidebar-msg').append(
                            '<p style="color:green;">Téléchargez le dossier des attachements <a href="' + response.data.zip_url + '" download>ici</a>.</p>'
                        );
                    }
                } else {
                    $('#sy-crm-core-depense-download-sidebar-msg').html('<span style="color:red;">' + response.data.message + '</span>');
                }
            }, 1000);
        });
    });

    $('#sy-crm-core-depense-button-validate-downloadold').on('click', function(e) {
        e.preventDefault()

        $('#sy-crm-core-depense-download-sidebar-link').attr('href', '');
        var dateDebut = $('#sy-crm-core-depense-download-sidebar-date-debut').val();
        var dateFin = $('#sy-crm-core-depense-download-sidebar-date-fin').val();
        var ajax_action = 'export_depenses';
        if (!dateDebut || !dateFin) {
            $('#sy-crm-core-depense-download-sidebar-msg').html('<span style="color:red;">Veuillez sélectionner les deux dates.</span>');

            return;
        }
        var startDate = new Date(dateDebut);
        var endDate = new Date(dateFin);
        var timeDiff = Math.abs(endDate.getTime() - startDate.getTime());
        var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

        if (diffDays > 30) {
            $('#sy-crm-core-depense-download-sidebar-msg').html('<span style="color:red;">La période ne doit pas dépasser 30 jours.</span>');
            return;
        }
        $('#sy-crm-core-depense-download-loading-screen').show();
        // AJAX request to download the file  
        $.post(ajax_object.ajax_url, {
            action: ajax_action,
            date_debut: dateDebut,
            date_fin: dateFin
        }, function(response) {

            if (response.success) {
                setTimeout(function() {
                    $('#sy-crm-core-depense-download-loading-screen').hide();
                    $('#sy-crm-core-depense-download-sidebar-link').attr({
                        href: response.data.file_url,
                        download: '',
                        style: 'display: none;'
                    })[0].click();
                    $('#sy-crm-core-depense-download-sidebar-msg').html(
                        '<span style="color:green;">Document créé avec succés. Si le fichier n\'a pas été téléchargé, <a href="' + response.data.file_url + '" download>téléchargez-le via ce lien</a>.</span>'
                    );
                }, 1000);

                // Provide a link if the automatic download doesn't work

            } else {
                setTimeout(function() {
                    $('#sy-crm-core-depense-download-loading-screen').hide();

                    $('#sy-crm-core-depense-download-sidebar-msg').html('<span style="color:red;">' + response.data.message + '</span>');

                }, 1000);
            }

        });

        //  $('#sy-crm-core-depense-download-sidebar').hide().removeClass('open');
    });
})