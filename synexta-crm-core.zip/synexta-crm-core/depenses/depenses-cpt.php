<?php

function crm_register_depense_post_type() {
    $labels = array(
        'name'               => 'Dépenses',
        'singular_name'      => 'Dépense',
        'menu_name'          => 'Dépenses',
        'name_admin_bar'     => 'Dépenses',
        'add_new'            => 'Ajouter Nouvelle',
        'add_new_item'       => 'Ajouter Nouvelle dépense',
        'new_item'           => 'Nouvelle dépense',
        'edit_item'          => 'Modifier la dépense',
        'view_item'          => 'Voir la dépense',
        'all_items'          => 'Dépenses',
        'search_items'       => 'Rechercher dépenses',
        'parent_item_colon'  => 'Dépense Parente :',
        'not_found'          => 'Aucune dépense trouvée.',
        'not_found_in_trash' => 'Aucune dépense trouvée dans la corbeille.'
    );

    $args = array(
        'labels'             => $labels,
        'public'             => false,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'show_in_menu'       => 'crm-dashboard',
        'capability_type'    => 'post',
       /* 'capabilities'  => [
            'create_posts' => 'do_not_allow', 
        ],*/
        'map_meta_cap'       => true,
        'hierarchical'       => false,
        'menu_position'      => 25,
        'menu_icon'          => 'dashicons-media-spreadsheet',
        'supports'           => array('title'),
        'has_archive'        => false,
        'rewrite'            => false,
    );

    register_post_type('crm-depenses', $args);
}


add_action('init', 'crm_register_depense_post_type');

// Fonction pour ajouter des métadonnées personnalisées
function crm_depenses_meta_boxes() {
    add_meta_box(
        'crm_depenses_meta_box',
        'Détails de la dépense',
        'crm_depenses_meta_box_callback',
        'crm-depenses',
        'normal',
        'default'
    );
}

add_action('add_meta_boxes', 'crm_depenses_meta_boxes');

// Callback pour afficher les champs de métadonnées
function crm_depenses_meta_box_callback($post) {
    $currency      = get_option('woocommerce_currency');

    $date_depense = get_post_meta($post->ID, '_depense_date', true);
    $date_format = get_option('date_format'); 
    if (!empty($date_depense)) {
        $timestamp = strtotime($date_depense); // Convertir en timestamp
        $formatted_date = date($date_format, $timestamp); // Formater selon WP
    } else {
        $formatted_date = "";
    }
    $date_depense=$formatted_date;
    $tiersId = get_post_meta($post->ID, '_depense_tiers', true);
    $billing_company = get_user_meta($tiersId, 'billing_company', true);
    $prenom_nom = get_user_meta($tiersId, 'last_name', true) . ' ' . get_user_meta($tiersId, 'first_name', true);
    $entreprise_affichee = $billing_company ?: esc_html($prenom_nom);
    if (!$entreprise_affichee) {
        $user_email = get_userdata($tiersId)->user_email;
        $entreprise_affichee = $user_email;  
    }
        
    $pays = get_post_meta($post->ID, '_depense_pays', true);
   
$pays = WC()->countries->countries[$pays] ?? $pays; 
    $moyen_reglement = get_post_meta($post->ID, '_depense_moyen_reglement', true);
    $commentaire = get_post_meta($post->ID, '_depense_commentaire', true);
    $produits = get_post_meta($post->ID, '_depense_products', true);
    $total_ht = get_post_meta($post->ID, '_depense_total_prix_ht', true);
    $total_ttc = get_post_meta($post->ID, '_depense_total_prix_ttc', true);
    $file_links=get_post_meta($post->ID, '_depense_pieces_jointes',true);
    echo '<style>
   
       .error-message {
        color: red;
        font-size: 12px;
    }
    .sy-crm-core-depense-row{
          display: flex
;
    gap: 5px;
    margin: 9px 0px;
    width: 100%;
    }
    .sy-crm-core-depense-row .form-group{
        width: 25%;
        display: flex
;
    flex-direction: column;
    }
    .sy-crm-core-depense-row .form-group label{
        margin-bottom: 5px;
        height: 27px;
    }
    .form-group.form-group-comments{
        width: 100%;
    }
    .sy-crm-core-depense-row input,.sy-crm-core-depense-row select{
        height: 38px ;
    
    }
    .sy_crm_core_depense_group_quantity{
        max-width: 69px;
    width: 100%;
    }
    .sy_crm_core_depense_group_price{
            max-width: 169px;
    width: 100% !important;
    }
        .sy-crm-core-depense-produit:not(:last-child){
border-bottom:1px solid gray;
    margin: 24px 0px;
    padding-bottom: 6px;
}

        .sy-crm-core-depense-produits-list{
        margin:5px 0px;
}
</style>';

    $fields = [
        'Date de dépense' => $date_depense,
        'Entreprise' => $entreprise_affichee,
        'Pays' => $pays,
        'Moyen de reglement' => $moyen_reglement,
        'Total ht'=>$total_ht,
        'Total Ttc'=>$total_ttc
       
       
    ];


    echo ' <div class="sy-crm-core-depense-row">';
    foreach ($fields as $label => $value) {
        echo '<div class="form-group ' . (($label == "Total ht" || $label == "Total Ttc") ? 'sy_crm_core_depense_group_price' : '') . '">';
        echo '<label>' . esc_html($label) . (($label == "Total ht" || $label == "Total Ttc") ? ' ( ' . esc_html($currency) . ' ) ' : '') . ' :</label>';
        echo '<input type="text" value="' . esc_attr($value) . '" readonly />';
        echo '</div>';
    }
    echo '</div>';

    echo '<div class="sy-crm-core-depense-row"><div class="form-group form-group-comments">';
    echo '<label>Commentaire:</label>';
    echo '<textarea rows="4" cols="50" name="crm-depenses_commentaire"readOnly>' . esc_textarea($commentaire) . '</textarea>';
    echo '</div></div>';
  
    if (!empty($produits) && is_array($produits)) {
        echo '<h4>Produits</h4>';
        echo '<div class="produit sy-crm-core-depense-produits-list">';
        foreach ($produits as $produit) {
            echo '<div class=" sy-crm-core-depense-produit">
            <div class="sy-crm-core-depense-row">
                <div class="form-group"><label>Produit :</label>
                <input type="text" value="' . esc_attr($produit['nomProduit']) . '" readonly />
            </div>
           <div class="form-group sy_crm_core_depense_group_quantity">
            <label>Quantité :</label>
            <input type="text" value="' . esc_attr($produit['quantite']) . '" readonly />
           </div>';

            echo '<div class="form-group sy_crm_core_depense_group_price">';
            echo '<label>Prix Unitaire (' .esc_html($currency).') :</label>';
            echo '<input type="text" value="' . esc_attr($produit['prixUnitaire_ht']) . '" readonly />';
            echo '</div>';

            echo '<div class="form-group sy_crm_core_depense_group_price">';
            echo '<label>Total HT (' .esc_html($currency).') :</label>';
            echo '<input type="text" value="' . esc_attr($produit['total_ht'] ) . '" readonly />';
            echo '</div>';
            echo '<div class="form-group sy_crm_core_depense_group_price">';
            echo '<label>TVA :</label>';
            echo '<input type="text" value="' . esc_attr($produit['tva']) . '" readonly />';
            echo '</div>';
            echo '<div class="form-group  sy_crm_core_depense_group_price">';
            echo '<label>Prix Unitaire TTC (' .esc_html($currency).') :</label>';
            echo '<input type="text" value="' . esc_attr($produit['prixUnitaire_ttc']) . '" readonly />';
            echo '</div>';

            echo '<div class="form-group sy_crm_core_depense_group_price">';
            echo '<label>Total TTC (' .esc_html($currency).') :</label>';
            echo '<input type="text" value="' . esc_attr($produit['total_ttc'] ) . '" readonly />';
            echo '</div></div>';

            if (isset($produit['description'])) {
                echo '<div class="sy-crm-core-depense-row">
                <div class="form-group form-group-comments">';
                echo '<label>Description :</label>';
                echo '<textarea type="text" value="' . esc_attr($produit['description']) . '" readonly />' . esc_attr($produit['description']) . '</textarea>';
                echo '</div></div>';
            }
            echo'</div>';    
        }
        echo'</div>';
    }
    if (!empty($file_links)) {
        echo '<h3>Pièces jointes :</h3><ul>';
        
        foreach ($file_links as $file_link) {
              echo '<li><a href="' . esc_url($file_link) . '" target="_blank">Télécharger le fichier</a></li>';
        }
    
        echo '</ul>';
    }
}
// Ajouter des colonnes personnalisées pour le type de post 'crm-depenses'
function crm_add_custom_columns($columns) {
    $columns['date_depense'] = __('Date de dépense', 'textdomain');
    $columns['tiers'] = __('Tiers', 'textdomain');
    $columns['total_ht'] = __('Total HT', 'textdomain');
    return $columns;
}
add_filter('manage_crm-depenses_posts_columns', 'crm_add_custom_columns');

// Afficher le contenu des colonnes personnalisées
function crm_custom_column_content($column, $post_id) {
    $currency      = get_option('woocommerce_currency');
      
    switch ($column) {

        case 'date_depense':
            $date_depense = get_post_meta($post_id, '_depense_date', true);
            $date_format = get_option('date_format'); 
            if (!empty($date_depense)) {
                $timestamp = strtotime($date_depense);
                $formatted_date = date($date_format, $timestamp); 
            } else {
                $formatted_date = "";
            }
            $date_depense=$formatted_date;
            echo esc_html($formatted_date);
            break;
        case 'tiers':
            $tiersId = get_post_meta($post_id, '_depense_tiers', true);
            $billing_company = get_user_meta($tiersId, 'billing_company', true);
            $prenom_nom = get_user_meta($tiersId, 'last_name', true) . ' ' . get_user_meta($tiersId, 'first_name', true);
            $entreprise_affichee = $billing_company ?: esc_html($prenom_nom);
            if (!$entreprise_affichee) {
                $user_email = get_userdata($tiersId)->user_email;
                $entreprise_affichee = $user_email;  
            }
            echo esc_html($entreprise_affichee);
            break;
        case 'total_ht':
            $totaux_ht = get_post_meta($post_id, '_depense_total_prix_ht', true);
            echo esc_html($totaux_ht) . ' (' . esc_html($currency) . ')';
            break;
    }
}
add_action('manage_crm-depenses_posts_custom_column', 'crm_custom_column_content', 10, 2);

add_action('init', 'crm_register_depense_post_type');

function supprimer_pieces_jointes_depense($post_id) {
    if (get_post_type($post_id) !== 'crm-depenses') {
        return;
    }

    $upload_dir = wp_upload_dir();
    $base_dir = $upload_dir['basedir'] . '/crm-core/depense/' . get_post_meta($post_id, '_depense_tiers', true) . '/' . $post_id;

    $file_links = get_post_meta($post_id, '_depense_pieces_jointes', true);

    if (!empty($file_links) && is_array($file_links)) {
        foreach ($file_links as $file_url) {
            $file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $file_url);

            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
    }

    if (is_dir($base_dir)) {
        rmdir($base_dir);
    }

    delete_post_meta($post_id, '_depense_pieces_jointes');
}
add_action('before_delete_post', 'supprimer_pieces_jointes_depense');


//add_action('admin_menu', 'crm_register_depenses_settings_page');
function crm_register_depenses_settings_page() {
    add_submenu_page(
        'edit.php?post_type=crm-depenses',
        'Configuration des Dépenses',
        'Configuration',
        'manage_options',
        'crm-don-settings',
        'crm_depense_settings_page'
    );
}
function crm_depense_settings_page() {
    ?>
    <div class="wrap">
                <h2 style="font-size: 1.5em; margin-bottom: 10px;">Type de post "CRM Dépenses"</h2>
                <p>Le type de post <strong>CRM Dépenses</strong> permet de gérer les dépenses.</p>

                <p><strong>Fonctionnalités principales :</strong></p> 
                <ul style="list-style-type: disc; margin-left: 20px;"> 
                    <li>Création et gestion des dépenses</li>
                    <li>Affichage de la liste des dépenses créées</li>
                </ul> 

        <div class="test"style="border: 1px solid #ddd; background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin-top: 20px;">
            <h3 style="font-size: 1.2em; margin-bottom: 10px;">Shortcodes disponibles</h3> 

            <!-- 1er shortcode -->
            <h4 style="font-size: 1.1em; margin-bottom: 5px;">1. [crm_creation_depenses]</h4>
            <p>Ce shortcode permet de créer une dépense :</p>
            <ul style="list-style-type: disc; margin-left: 20px;">
                <li>Formulaire de création de dépense</li>
                <li>Ajout automatique du tiers si inexistant</li>
                <li>Synchronisation avec Vos Factures si activée</li>
            </ul>
            <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">[crm_creation_depense]</pre>

            <!-- 2ème shortcode -->
            <h4 style="font-size: 1.1em; margin-bottom: 5px;">2. [crm_liste_depenses]</h4>
            <p>Affiche la liste des dépenses avec les fonctionnalités suivantes :</p>
            <ul style="list-style-type: disc; margin-left: 20px;">
                <li>Affichage, recherche et filtrage de dépenses</li>
                <li>Affichage d'une barre latérale contenant les détails de la dépense avec possibilité de modification</li>
            </ul>
            <p><strong>Attributs disponibles :</strong></p>
            <ul style="list-style-type: disc; margin-left: 20px;">
                <li><code>departements</code> : par defaut <code>vide</code>, Permet de filtrer les dépenses par identifiants de départements (séparés par des virgules). Exemple : <code>[crm_liste_depenses departements="1,2,3"]</code></li>
                <li><code>readonly</code> : Par defaut <code>false</code>, si défini à <code>true</code>, empêche toute modification des dépenses (mode lecture seule). Exemple : <code>[crm_liste_depenses readonly="yes"]</code></li>
            </ul>

            <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">[crm_liste_depenses]</pre>
            <h4 style="font-size: 1.1em; margin-bottom: 5px;">3. [crm_tiers_depenses]</h4>
            <p>Affiche la liste des dépenses d'un tiers, il faut utiliser ce shortcode sur la fichier d'un tiers  :</p>
            <ul style="list-style-type: disc; margin-left: 20px;">
                <li>Affiche la liste des dépenses groupé par date</li>
                <li>Affichage d'une barre latérale contenant les détails de la dépense avec possibilité de modification</li>
            </ul>
            <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">[crm_tiers_depenses]</pre>
            <h4 style="font-size: 1.1em; margin-bottom: 5px;">3. [download_attachements_depense]</h4>
            <p>Permet le téléchargement manuel des attachements d'un dépense avec les fonctionnalités suivantes :</p>
            <ul style="list-style-type: disc; margin-left: 20px;">
                <li>Affichage d'une icône téléchargeable, permettant de récupérer le document.</li>
                <li>Texte personnalisable au-dessus de l'icône via l'attribut <code>text</code> du shortcode.</li>
                <li>Masquage automatique du shortcode si l'URL fournie est invalide ou expirée, garantissant la sécurité des informations.</li>
                <li>Utilisation d'une icône au format SVG nommée <code>download_files.svg</code> pour l'action de téléchargement, qui peut être remplacée par l'utilisateur.</li>
            </ul>
            <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">[download_attachements_depense text="Pour télécharger l'attachement, cliquez sur l’icône ci-dessous"]</pre>
            <p><strong>Note :</strong> Ce shortcode doit être ajouté à la page <code>crm-attachements-depenses</code>. L'URL de la page doit contenir un lien crypté vers le fichier pour garantir la validité et l'accès sécurisé au document.</p>
        
    </div>
    </div>
    <?php
}
