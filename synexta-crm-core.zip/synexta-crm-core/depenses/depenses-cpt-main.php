<?php
require_once plugin_dir_path(__FILE__) . 'depenses-cpt.php';
require_once plugin_dir_path(__FILE__) . 'depensesShortcode.php'; 
require_once plugin_dir_path(__FILE__) . 'shortcode-liste-depenses.php'; 
