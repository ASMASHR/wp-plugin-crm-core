<?php
/**
 * Shortcode [liste_depenses]
 * 
 * Ce shortcode affiche la liste des dépenses associées à un utilisateur spécifique.
 * Il récupère les dépenses stockées dans le type de post personnalisé "crm-depenses",
 * filtre les résultats par l'ID du tiers (utilisateur), et affiche les dépenses sous forme de tableau.
 * 
 * Fonctionnalités :
 * - Vérification et récupération de l'ID utilisateur via l'URL.
 * - Récupération des dépenses associées depuis les métadepensenées.
 * - Affichage des dépenses par année avec sous-totaux.
 * - Archivage automatique des dépenses de plus de 2 ans.
 * - Affichage d'un formulaire de modification de dépense.
 * 
 * Paramètres :
 * Aucun paramètre spécifique n'est requis pour ce shortcode.
 * 
 * Retour :
 * - Une table HTML listant les dépenses de l'utilisateur.
 * - Un message si aucune dépense n'est trouvée ou si l'ID utilisateur est invalide.
 */
function display_all_depenses($atts) {

    wp_enqueue_script('liste-depenses-js', plugin_dir_url(__FILE__) . 'shortcode-liste-depenses.js', array(), '1.0', true);
    wp_enqueue_style('liste-depenses-css', plugin_dir_url(__FILE__) . 'depenses.css', array(), '1.0', 'all');
    wp_enqueue_script('shortcode-depenses-data-table-js', plugin_dir_url(__FILE__) . '../assets/js/jquery.dataTables.js', array(), '1.0', true);
    wp_enqueue_script('shortcode-depenses-data-table-responsive-js', plugin_dir_url(__FILE__) . '../assets/js/dataTables.responsive.min.js', array(), '1.0', true);
    wp_enqueue_style('shortcodes-depenses-data-table-css', plugin_dir_url(__FILE__) . '../assets/styles/jquery.dataTables.css', array(), '1.0', 'all');
    wp_enqueue_style('shortcodes-depenses-data-table-responsive-css', plugin_dir_url(__FILE__) . '../assets/styles/responsive.dataTables.min.css', array(), '1.0', 'all');
    
   
    $atts = shortcode_atts([
        'count' => 10,
        'departements' => '', 
    'readonly' => 'false'  
    ], $atts, 'crm_liste_depenses');
    $readonly = ($atts['readonly'] === 'true');
    $departement_ids =$atts['departements']!=''? array_filter(array_map('trim', explode(',', $atts['departements']))):[];
    $count = intval($atts['count']);
    $eyeIcon=plugin_dir_url(__FILE__) . '../assets/icons/eye.svg';
    $menuIcon=plugin_dir_url(__FILE__) . '../assets/icons/menu.svg';
    $tiersIcon=plugin_dir_url(__FILE__) . '../assets/icons/tiers-account.svg';
    $config = array(
        'currency'        => get_option('woocommerce_currency'), 
        'currency_pos'    => get_option('woocommerce_currency_pos'), 
        'decimal_sep'     => get_option('woocommerce_price_decimal_sep'), 
        'thousand_sep'    => get_option('woocommerce_price_thousand_sep'), 
        'num_decimals'    => get_option('woocommerce_price_num_decimals'), 
    );
    $tax_based_on = get_option('woocommerce_tax_based_on'); 
    $countryTva = get_option('woocommerce_default_country'); 
   
    $tax_rates = WC_Tax::get_rates_for_tax_class( $tax_based_on );
    $tax_rate_found = null;
    foreach ($tax_rates as $rate) {
       if ($rate->tax_rate_country == $countryTva) {
            $tax_rate_found = $rate;
            break;
        }

    } 
    $tax_rate=$tax_rate_found->tax_rate;
  
        $args = [
            'post_type' => 'crm-depenses',
            'posts_per_page' => -1,
            
            'orderby' => 'meta_value',
            'meta_key' => '_depense_date',
            'order' => 'DESC',
        ];
 

    $query = new WP_Query($args);
    if (!$query->have_posts()) {
        return 'Aucune dépense trouvée.';
    }
    $currency = get_option('woocommerce_currency');
    $output = '';

    $output .= '
    <div class="sy-crm-core-depense-table-header">
<div class="sy-crm-core-depense-table-header-left">
<input type="text" placeholder="recherche"id="sy-crm-core-depense-table-search"style=" max-width: 300px;">
';


/*if (get_option('vosfactures_sync_enabled') == 'yes') {
 */   $departments_vf = get_option('_crm_vosfactures_departments', []);
    $departments_manual = get_option('_crm_departements_manuels', []);


$filtered_vf = [];
$filtered_manual = [];

if (!empty($departement_ids)) {
    foreach ($departments_vf as $dept) {
        if (in_array($dept['id'], $departement_ids)) {
            $filtered_vf[] = $dept;
        }
    }
    foreach ($departments_manual as $dept) {
        if (in_array($dept['id'], $departement_ids)) {
            $filtered_manual[] = $dept;
        }
    }
} 
else {
    $filtered_vf = $departments_vf;
    $filtered_manual = $departments_manual;
 

}

$all_filtered = array_merge($filtered_vf, $filtered_manual);

if (!empty($all_filtered) ) {
    $output .= '<select style="max-width: 300px;" id="sy-crm-core-depense-table-departement-search">
                    <option value="">--Département--</option>';

    if (!empty($filtered_vf)) {
        $output .= '<optgroup label="Depuis VosFactures">';
        foreach ($filtered_vf as $dept) {
            $output .= '<option value="' . esc_attr($dept['nom_usage']) . '">' . esc_html($dept['nom_usage']) . '</option>';
        }
        $output .= '</optgroup>';
    }

    if (!empty($filtered_manual)) {
        $output .= '<optgroup label="Ajout manuel">';
        foreach ($filtered_manual as $dept) {
            $output .= '<option value="' . esc_attr($dept['nom_usage']) . '">' . esc_html($dept['nom_usage']) . '</option>';
        }
        $output .= '</optgroup>';
    }

    $output .= '</select>';
}

    
/*

} else {
    $departments_manual = get_option('_crm_departements_manuels', []);
    if (!empty($departement_ids)) {
       
        foreach ($departments_manual as $dept) {
            if (in_array($dept['id'], $departement_ids)) {
                $filtered_manual[] = $dept;
            }
        }
    } 
    else {
        $filtered_manual = $departments_manual;
    }
    if(!empty($filtered_manual)){
        
            $output .= '<select style="max-width: 300px;" id="sy-crm-core-depense-table-departement-search">
                            <option value="">--Département--</option>
                        ';
            foreach ($departments_manual as $dept) {
                $output .= '<option value="' . esc_attr($dept['nom_usage']) . '">' . esc_html($dept['nom_usage']) . '</option>';
            }
            $output .= '</select>';
        
    }
   
}*/


$output.='<select style=" max-width: 300px;"id="sy-crm-core-depense-table-reglement-search">
     <option value="">--Règlement--</option>
     <option value="Espèce" >Espèce</option>
    <option value="Chèque" >Chèque</option>
    <option value="Virement" >Virement</option>
    <option value="Prélèvement" >Prélèvement</option>
    <option value="Internet" >Internet</option>
    <option value="Carte bancaire">Carte bancaire</option>
           
</select>
</div>
<div class="sy-crm-core-depense-table-header-right">
<button id="crm-don-download-list-btn" class="sy-crm-core-depense-table-header-btn">export</button>
   
    <div class="sy-sy-crm-core-depense-table-info">
        <div id="sy-sy-crm-core-depense-table-custom-info"></div>
    </div>
</div>
</div>
<div id="sy-crm-core-depense-table-result"></div>
<table class="sy-crm-core-depenses-table"id="sy-crm-core-depense-table"data-count="' . esc_html($count) . '">';
    $output .= '<thead><tr><th>Date</th><th>Tiers</th><th>Libellé</th><th>Département</th><th>Réglement</th><th>Total HT (' . esc_html($currency) . ')</th><th>Total TTC (' . esc_html($currency) . ')</th><th>Documents</th><th>Actions</th></tr></thead><tbody>';
  
    while ($query->have_posts()) {
        $query->the_post();
        $depense_id = get_the_ID();
        $nom = get_the_title();
        $total_ht = get_post_meta($depense_id, '_depense_total_prix_ht', true);
        $total_ttc = get_post_meta($depense_id, '_depense_total_prix_ttc', true);
        $total_ht= (float) str_replace(',', '.',$total_ht);
        $total_ttc=(float) str_replace(',', '.', $total_ttc);
        $pieces_joints=get_post_meta($depense_id, '_depense_pieces_jointes', true)!="" ?get_post_meta($depense_id, '_depense_pieces_jointes', true): [];
        //echo var_dump($pieces_joints);
        $moyen_reglement  = get_post_meta($depense_id, '_depense_moyen_reglement', true) ;
        $vendeur = get_post_meta($depense_id, '_depense_vendeur', true) ?? '';
        $vendeurNom="--";
          
        $departments = get_option('_crm_vosfactures_departments', []);  
        $synchronisationActive = get_option('_crm_vosfactures_synchro'); // true ou false
        $tousLesDepartments = get_option('_crm_vosfactures_departments', []);
        $departmentsManuels = get_option('_crm_departements_manuels', []);

if ($vendeur != "") {
    $listeADepartments = $synchronisationActive ? $tousLesDepartments : $departmentsManuels;

    
        foreach ($departmentsManuels as $department) {
            if ($department['id'] == $vendeur) {
          
                $vendeurNom = $department['nom_usage'];
                break;
            }
        }
    
    foreach ($tousLesDepartments as $department) {
        if ($department['id'] == $vendeur) {
            $vendeurNom = $department['nom_usage'];
            break;
        }
    }

    if ($vendeurNom == "--") {
        $vendeurNom = $vendeur; 
    }
}
      

        $date_depense = get_post_meta($depense_id, '_depense_date', true);
        $formatted_date = date_i18n(get_option('date_format'), strtotime($date_depense));
        $tiersId=get_post_meta($depense_id, '_depense_tiers', true);
        $billing_company = get_user_meta($tiersId, 'billing_company', true);
        $prenom_nom = get_user_meta($tiersId, 'last_name', true) . ' ' . get_user_meta($tiersId, 'first_name', true);
        $entreprise_affichee = $billing_company ?: esc_html($prenom_nom);
        if (!$entreprise_affichee) {
            $user_email = get_userdata($tiersId)->user_email;
            $entreprise_affichee = $user_email;  
        }
        $hashedId=  crm_events_generate_user_hash($tiersId);  
        $user_profil=home_url('crm-customer/' . $hashedId);
        if ($departement_ids!=""&&!empty($departement_ids)) {
            if($vendeur&&in_array($vendeur, $departement_ids)){
                $output .= '<tr>';
                $output .= '<td>' . esc_html($formatted_date) . '</td>';
                $output .= '<td>' . esc_html($entreprise_affichee) . '</td>';
                $output .= '<td>' . esc_html($nom) . '</td>';        
                $output .= '<td>' . esc_html($vendeurNom) . '</td>'; 
                $output .= '<td>' . esc_html($moyen_reglement) . '</td>';
            
                $output .= '<td>' . wp_kses_post(wc_price(($total_ht))) . '</td>';price: 
                $output .= '<td>' . wp_kses_post(wc_price(($total_ttc))) . '</td>';
                $output .='<td>'; 
                if(!empty($pieces_joints) && is_array($pieces_joints)){
                  
                    foreach ($pieces_joints as $key => $file) {
                
                        $file_extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                        $icon_url=synexta_core_get_file_icon($file_extension);
                        $output .= '<a href="' . $file . '" target="_blank">
                                            <img src="' . $icon_url . '"  file" style="width: 20px; height: 20px; margin-right: 5px;">
                                            
                                        </a>
                                    ';
                    } 
                    
        
                }
                else{
                $output .= '--';
        
                }$output .='</td>';
                $output .= '<td>  <div class="sy-crm-core-depense-table-menu">';
                $output .= '<a href="' . esc_url($user_profil) . '"  title="Visiter fiche tiers ">
                                            <img src="' . esc_html($tiersIcon) . '"> 
                                        </a>
                    <a href="#" class="sy-crm-core-depense-table-menu-detail-btn"title="Voir détails" data-id="' . $depense_id . '"><img src="' . esc_html($eyeIcon) . '"> </a>';
                    
                     
                  
                
               
               
                   $output .=   '</div></td>';
       
            $output .= '</tr>';
            }
           
       

        }
        else{
        $output .= '<tr>';
        $output .= '<td data-order="' . date('Y-m-d', strtotime($date_depense)) . '">' . esc_html($formatted_date) . '</td>';
        $output .= '<td>' . esc_html($entreprise_affichee) . '</td>';
        $output .= '<td>' . esc_html($nom) . '</td>';        
        $output .= '<td>' . esc_html($vendeurNom) . '</td>'; 
        $output .= '<td>' . esc_html($moyen_reglement) . '</td>';
      
        $output .= '<td>' . wp_kses_post(wc_price(($total_ht))) . '</td>'; 
        $output .= '<td>' . wp_kses_post(wc_price(($total_ttc))) . '</td>';
        if(!empty($pieces_joints) && is_array($pieces_joints)){
            $output .= '<td>';
            foreach ($pieces_joints as $key => $file) {
        
                $file_extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                $icon_url=synexta_core_get_file_icon($file_extension);
                $output .= '<a href="' . $file . '" target="_blank">
                                    <img src="' . $icon_url . '"  file" style="width: 20px; height: 20px; margin-right: 5px;">
                                    
                                </a>
                            ';
            } 
            $output .= '</td>';

        }
        else{
        $output .= '<td>--</td>';

        }
        $output .= '<td>  <div class="sy-crm-core-depense-table-menu">';
        $output .= '<a href="' . esc_url($user_profil) . '"  title="Visiter fiche tiers">
                                    <img src="' . esc_html($tiersIcon) . '"> 
                                </a>
            <a href="#" class="sy-crm-core-depense-table-menu-detail-btn"title="Voir détails" data-id="' . $depense_id . '"><img src="' . esc_html($eyeIcon) . '"> </a>';
              
                 
              
            
           
           
               $output .=   '</div></td>';
   
        $output .= '</tr>';
        }
        
        
    }
    $output .= '</tbody></table>';
   

  
 

    $output.='<div class="sy-crm-core-depense-sidebar"id="sy-crm-core-depense-edit-sidebar"style="display:none;">
            <div class="sy-crm-core-depense-sidebar-header">
             <h5 class="">Dépense</h5>
            <button class="sy-crm-core-depense-sidebar-header-btn sy-crm-core-depense-edit-sidebar-header-btn">X</button>

             </div>

             <form id="sy-crm-core-depense-edit-form" novalidate>
                <div id="sy-crm-core-depense-edit-result"></div>
                <p class="sy-crm-core-depense-section-title">Détails de la Dépense</p>

                <div class="sy-crm-core-depense-row">
                     <div class="form-group">
                        <label>Entreprise :</label>
                       
                        <input type="text" name="pays" id="sy-crm-core-depense-edit-tiers-entreprise" value=""required>
                   </div>
                    <div class="form-group">
                        <label>Pays :</label>
                       
                        <input type="text" name="pays" id="sy-crm-core-depense-edit-tiers-pays" value=""required>
                   </div> 
                    <div class="form-group">
                        <label>Date de dépense :</label>
                        <input type="date" name="date_depense" id="sy-crm-core-depense-edit-date-depense" value="" required>
                    </div> 
                    
                    <div class="form-group sy_crm_core_depense_group_price">
                        <label>Moyen de règlement :</label>
                        <select name="moyen_reglement"id="sy-crm-core-depense-edit-moyen-reglement">
                            <option value="Espèce">Espèce</option>
                            <option value="Chèque">Chèque</option>
                            <option value="Virement">Virement</option>
                            <option value="Prélèvement">Prélèvement</option>
                            <option value="Internet">Internet</option>
                            <option value="Carte bancaire">Carte bancaire</option>
                        </select>
                    </div>
                    ';
                
                
                        
            $output.='
                <input type="hidden" id="sy-crm-core-depense-edit-tiers" name="tiers" >
               
              ';        

          
           if (get_option('vosfactures_sync_enabled') == 'yes') {
            $departments_vf = get_option('_crm_vosfactures_departments', []);
            $departments_manual = get_option('_crm_departements_manuels', []);
        
            $output.= '<div class="form-group"><label for="departement_vendeur">Département :</label><select name="departement_vendeur" id="sy-crm-core-depense-edit-departement-vendeur"><option value="">-- Sélectionnez --</option>';
        
            // Départements VosFactures
            if (!empty($departments_vf)) {
                $output.= '<optgroup label="Depuis VosFactures">';
                foreach ($departments_vf as $dept) {
                    $output.= '<option value="' . esc_attr($dept['id']) . '" >' . esc_html($dept['nom_usage']) . '</option>';
                }
                $output.= '</optgroup>';
            }
        
            // Départements ajoutés manuellement
            if (!empty($departments_manual)) {
                $output.= '<optgroup label="Ajout manuel">';
                foreach ($departments_manual as $dept) {
                    $output.= '<option value="' . esc_attr($dept['id']) . '" >' . esc_html($dept['nom_usage']) . '</option>';
                }
                $output.= '</optgroup>';
            }
        
            $output.= '</select>';
            $output.= '</div>';
        } else {
            // VosFactures désactivé → seulement les départements CRM manuels
            $departments_manual = get_option('_crm_departements_manuels', []);
            $output.= '<div class="form-group"><label for="departement_vendeur">Département :</label><select name="departement_vendeur" id="sy-crm-core-depense-edit-departement-vendeur"><option value="">-- Sélectionnez --</option>';
            if (!empty($departments_manual)) {
                foreach ($departments_manual as $dept) {
                    $output.='<option value="' . esc_attr($dept['id']) . '" >' . esc_html($dept['nom_usage']) . '</option>';
                }
            }
            $output.= '</select></div>';
        }
            $output.='
        </div>

        <div class="sy-crm-core-depense-row">
            <input type="hidden" name="id_depense"  id="sy-crm-core-depense-edit-id" value="" required >
            <div  class="form-group form-group-title">
                <label>Libellé :</label>
                <input type="text" name="titre_depense" id="sy-crm-core-depense-edit-titre-depense" value="" required>
            </div>
            <div class="form-group form-group-comments">
                <label>Commentaire :</label>
                <textarea name="commentaire"id="sy-crm-core-depense-edit-commentaire"rows=1></textarea>
            </div>
        </div>
    <input type="hidden" id="woo_config" data-currency="'. $config['currency'].'" data-currency-pos="'. $config['currency_pos'].'" data-decimal-sep="'. $config['decimal_sep'].'" data-thousand-sep="'. $config['thousand_sep'].'" data-num-decimals="'. $config['num_decimals'].'">
    
        <div id="sy-crm-core-depense-edit-products-list"></div>
        
        <div id="sy-crm-core-depense-edit-new-product"style="display:none">
            <div class="sy-crm-core-depense-product-col">
                <div class="sy_crm_core_depense_tiers_search_container">
                        <input type="text"  class="sy-crm-core-depense-edit-nouveau-produit-name" placeholder="Nom du produit" />
                        
                       
                        <ul class="sy_crm_core_depense_products_suggestions"></ul>
                

                </div>
          
                <input type="hidden" name="" class="sy-crm-core-depense-edit-nouveau-produit-id" value="0">
            <input type="hidden" name="" class="sy-crm-core-depense-edit-nouveau-produit-flag" value="0">
                <button type="button" class="sy-crm-core-depense-button sy-crm-core-depense-edit-new-produit-btn ">Créer?</button>

                  
            </div>  
        </div>

    <button type="button" id="sy-crm-core-depense-edit-ajout-produit-btn"class="sy-crm-core-depense-button sy-crm-core-add-produit"style="display:none;"> + produit</button>
            <div class="sy-crm-core-depense-bottom-row">

                <div class="sy-crm-core-depense-attachement-row">
                    <div id="sy-crm-core-depense-edit-file-list"style="display:none;    min-width: 500px;">
                    
                    </div>
                </div>
            <div class="sy-crm-core-depense-row-prices">
                <div class="form-group sy_crm_core_depense_group_price">
                    <label>Total HT ('. $config['currency'].') :</label>
                    <input type="text" name="total_depense_ht" id="sy-crm-core-depense-edit-total-ht" value="" readepensely>
                </div>
                <div class="form-group sy_crm_core_depense_group_price">
                    <label>Total TTC ('. $config['currency'].') :</label>
                    <input type="text" name="total_depense_ttc" id="sy-crm-core-depense-edit-total-ttc" value="" readepensely>
                </div>
            </div>
            </div>
    
    
    <div class="sy-crm-core-depense-sidebar-footer">
        <button type="button"class="sy-crm-core-depense-button discard-edit-depense-sidebar">Fermer</button>';
        if (!$readonly) {
        $output.='<button type="button"id="sy-crm-core-depense-delete-btn" data-id=""class="sy-crm-core-depense-button sy-crm-core-depense-delete">Supprimer</button>';}
        $output.='<button type="submit"class="sy-crm-core-depense-button sy-crm-core-depense-edit-submit"style="display:none;">Enregistrer</button>';
        if (!$readonly) {
        $output.='<button type="button"class="sy-crm-core-depense-button sy-crm-core-depense-edit-btn"style="">Modifier</button>';
        }
   $output.=' </div>
          

       
</form></div>
';
$output.='<div id="sy-crm-core-depense-download-sidebar"class="sy-crm-core-depense-download-sidebar" style="display:none;">
 <div class="sy-crm-core-depense-sidebar-header">
    <h5 class=""id="sy-crm-core-depense-download-sidebar-title">Télécharger dépense</h5>
    
    <button class="sy-crm-core-depense-sidebar-header-btn sy-crm-core-depense-download-header-discard-btn ">X</button>

    </div>
    <div class="sy-crm-core-depense-sidebar-content">
        <p id="sy-crm-core-depense-download-sidebar-info"></p>
        <div class="sy-crm-core-depense-row ">
            <div class="form-group w-full">
                <label for="sy-crm-core-depense-download-sidebar-date-debut">Date Début :</label>
                <input type="date" id="sy-crm-core-depense-download-sidebar-date-debut">
            </div>
            <div class="form-group w-full">
                <label for="sy-crm-core-depense-download-sidebar-date-fin">Date Fin :</label>
                <input type="date" id="sy-crm-core-depense-download-sidebar-date-fin">
            </div>
            <div class="form-group w-full">
                <label for="sy-crm-core-depense-download-sidebar-departement-vendeur">Département :</label>';
                    $departments_vf = get_option('_crm_vosfactures_departments', []);
                    $departments_manual = get_option('_crm_departements_manuels', []);
                
                    $output.= '<select name="departement_vendeur" id="sy-crm-core-depense-download-sidebar-departement-vendeur"><option value="">-- Sélectionnez --</option>';
                
                    if (!empty($departments_vf)) {
                        foreach ($departments_vf as $dept) {
                            $output.= '<option value="' . esc_attr($dept['id']) . '" >' . esc_html($dept['nom_usage']) . '</option>';
                        }
                    
                    }
                
                    if (!empty($departments_manual)) {
                        foreach ($departments_manual as $dept) {
                            $output.= '<option value="' . esc_attr($dept['id']) . '" >' . esc_html($dept['nom_usage']) . '</option>';
                        }
                    
                    }
                
                    $output.= '</select>';
                
               
            $output.= '</div>
        </div>
        <div class="sy-crm-core-depense-row-checkbox "id="sy-crm-core-depense-download-sidebar-options">
                <input type="checkbox" value="1" id="sy-crm-core-depense-download-sidebar-options-checkbox"> 
               <label for="sy-crm-core-depense-download-sidebar-options-checkbox">INCLURE LES DOCUMENTS JOINTS EN ZIP.</label>
        </div>
        <div id="sy-crm-core-depense-download-sidebar-msg"class="sy-crm-core-depense-download-sidebar-msg"></div>
        <a href=""id="sy-crm-core-depense-download-sidebar-link"></a>
         
    </div>
    
    
     <div class="sy-crm-core-depense-sidebar-footer">
    <button class="sy-crm-core-depense-download-footer-discard-btn">Fermer</button>
    <button id="sy-crm-core-depense-button-validate-download" class="sy-crm-core-depense-button sy-crm-core-depense-button-validate-download">Valider</button>
    </div>
</div>
<div id="sy-crm-core-depense-download-loading-screen"class="sy-crm-core-depense-download-loading-screen">
    <div class="sy-crm-core-depense-download-loading-screen-spinner-container"style="">
        <p>Veuillez patienter, le document est en cours de création...</p>
        <div class="sy-crm-core-depense-download-loading-screen-spinner"></div>
    </div>
</div>
';


    wp_reset_postdata();

    return $output;
}

add_shortcode('crm_liste_depenses', 'display_all_depenses');

/**
 * Shortcode [crm_tiers_depenses]
 * 
 * Ce shortcode affiche la liste des dépenses associées à un utilisateur spécifique.
 * Il récupère les dépenses stockées dans le type de post personnalisé "crm-depenses",
 * filtre les résultats par l'ID du tiers (utilisateur), et affiche les dépenses sous forme de tableau.
 * 
 * Fonctionnalités :
 * - Vérification et récupération de l'ID utilisateur via l'URL.
 * - Récupération des dépenses associées depuis les métadonnées.
 * - Affichage des dépenses par année avec sous-totaux.
 * - Archivage automatique des dépenses de plus de 2 ans.
 * - Affichage d'un formulaire de modification de dépense.
 * 
 * Paramètres :
 * Aucun paramètre spécifique n'est requis pour ce shortcode.
 * 
 * Retour :
 * - Une table HTML listant les dépenses de l'utilisateur.
 * - Un message si aucune dépense n'est trouvée ou si l'ID utilisateur est invalide.
 */
function afficher_depenses_tiers($atts) {

    wp_enqueue_script('depenses-list-tiers-js', plugin_dir_url(__FILE__) . 'shortcode-liste-depenses-tiers.js', array(), '1.0', true);
    wp_enqueue_style('depenses-css', plugin_dir_url(__FILE__) . 'depenses.css', array(), '1.0', 'all');
    $atts = shortcode_atts([], $atts, 'liste_depenses');
    $current_url = $_SERVER['REQUEST_URI'];
    $user_id = null;
   
    if (strpos($current_url, 'crm-customer/') !== false) {
        $hashedId = get_hashed_id_from_url();
        $user_id = $hashedId ? get_user_id_from_hash($hashedId) : null;
        if (!$user_id || !get_userdata($user_id)) {
            return 'ID invalid';
        }
    }
    /* else {
        return 'ID invalid';
    }*/
    $config = array(
        'currency'        => get_option('woocommerce_currency'), 
        'currency_pos'    => get_option('woocommerce_currency_pos'), 
        'decimal_sep'     => get_option('woocommerce_price_decimal_sep'), 
        'thousand_sep'    => get_option('woocommerce_price_thousand_sep'), 
        'num_decimals'    => get_option('woocommerce_price_num_decimals'), 
    );
    $tax_based_on = get_option('woocommerce_tax_based_on'); 
    $countryTva = get_option('woocommerce_default_country'); 
   
    $tax_rates = WC_Tax::get_rates_for_tax_class( $tax_based_on );
    $tax_rate_found = null;
    foreach ($tax_rates as $rate) {
       if ($rate->tax_rate_country == $countryTva) {
            $tax_rate_found = $rate;
            break;
        }

    } 
    $tax_rate=$tax_rate_found->tax_rate;
    if($user_id){
        $args = [
            'post_type' => 'crm-depenses',
            'posts_per_page' => -1,
            'meta_query' => [
                [
                    'key' => '_depense_tiers',
                    'value' => $user_id,
                    'compare' => '='
                ]
            ],
            'orderby' => 'meta_value',
            'meta_key' => '_depense_date',
            'order' => 'DESC',
        ];
    }
    else{
        $args = [
            'post_type' => 'crm-depenses',
            'posts_per_page' => -1,
            
            'orderby' => 'meta_value',
            'meta_key' => '_depense_date',
            'order' => 'DESC',
        ];
    }

    $query = new WP_Query($args);
    if (!$query->have_posts()) {
        return 'Aucune dépense trouvée.';
    }

    $currency = get_option('woocommerce_currency');
    $output = '';
    $current_year = date('Y');
    $current_displayed_year = null;
    $year_subtotals = [];
    $archive_years = [];

    while ($query->have_posts()) {
        $query->the_post();
        $depense_id = get_the_ID();
        $nom = get_the_title();
        $total_ht = get_post_meta($depense_id, '_depense_total_prix_ht', true);
        $total_ttc = get_post_meta($depense_id, '_depense_total_prix_ttc', true);

        /*$vendeur = get_post_meta($depense_id, '_depense_vendeur', true) ?? '';
        $vendeurNom="--";
          
        $departments = get_option('_crm_vosfactures_departments', []);  
        if (!empty($departments)&&$vendeur!="")
        {
            foreach ($departments as $department) {
                if ($department['id'] == $vendeur) {
                    $vendeurNom = $department['nom_usage'];
                    break;
                }
            }
            if($vendeurNom=="--"&&$vendeur!=""){
                $vendeurNom=$vendeur;
            }
    
             
        }*/

        $date_depense = get_post_meta($depense_id, '_depense_date', true);
        $year = date('Y', strtotime($date_depense));

        // Archivage des dépenses de plus de 2 ans
        if ($current_year - $year > 2) {
            $archive_years[] = [
                'id' => $depense_id,
                'nom' => $nom,
                'date' => $date_depense,
                'total_ht' =>  (float) str_replace(',', '.',$total_ht),
                'total_ttc' => (float) str_replace(',', '.', $total_ttc)
       
               // 'vendeur' => $vendeurNom,
            ];
            continue;
        }

        if ($current_displayed_year !== $year) {
            if ($current_displayed_year !== null) {
                // Afficher le sous-total de l'année précédente
                $output .= '<tr class="soustotal"><td colspan="3">Sous-total ' . esc_html($current_displayed_year) . '</td>';
                $output .= '<td>' . wp_kses_post(wc_price($year_subtotals[$current_displayed_year]['ht'])) . '</td>';
                $output .= '<td>' . wp_kses_post(wc_price($year_subtotals[$current_displayed_year]['ttc'])) . '</td>';
                $output .= '</tr>';
                $output .= '</table>';
            }
            $current_displayed_year = $year;
            $output .= '<h4>Dép. ' . esc_html($year) . '</h4>';
            $output .= '<table class="sy-crm-core-user-depenses-table">';
            $output .= '<tr><th>ID</th><th>Date</th><th>Nom</th><th>Total HT (' . esc_html($currency) . ')</th><th>Total TTC (' . esc_html($currency) . ')</th></tr>';

            if (!isset($year_subtotals[$year])) {
                $year_subtotals[$year] = ['ht' => 0, 'ttc' => 0];
            }
        }
        $year_subtotals[$year]['ht'] += (float) str_replace(',', '.',$total_ht);
        $year_subtotals[$year]['ttc'] +=(float) str_replace(',', '.', $total_ttc);
        $total_ht= (float) str_replace(',', '.',$total_ht);
        $total_ttc=(float) str_replace(',', '.', $total_ttc);

        $formatted_date = date_i18n(get_option('date_format'), strtotime($date_depense));

        $output .= '<tr>';
        $output .= '<td>' . esc_html($depense_id) . '</td>';
        $output .= '<td>' . esc_html($formatted_date) . '</td>';
        $output .= '<td>' . esc_html($nom) . '</td>';
        $output .= '<td>' . wp_kses_post(wc_price($total_ht)) . '</td>';
        $output .= '<td>' . wp_kses_post(wc_price($total_ttc)) . '</td>';
        $output .= '</tr>';
    }

    // Afficher le sous-total de la dernière année
    if ($current_displayed_year !== null) {
        $output .= '<tr class="soustotal"><td colspan="3">Sous-total ' . esc_html($current_displayed_year) . '</td>';
        $output .= '<td>' . wp_kses_post(wc_price($year_subtotals[$current_displayed_year]['ht']))  . '</td>';
        $output .= '<td>' . wp_kses_post(wc_price($year_subtotals[$current_displayed_year]['ttc'])) . '</td>';
      
        //$output .= '<td>' . esc_html(wc_price($year_subtotals[$current_displayed_year]['ht'], $config)) . '</td>';
       // $output .= '<td>' . esc_html(wc_price($year_subtotals[$current_displayed_year]['ttc'], $config)) . '</td>';
        $output .= '</tr>';
        $output .= '</table>';
    }

    // Afficher les archives
    if (!empty($archive_years)) {
        $output .= '<h4>Archives</h4>';
        $output .= '<table class="sy-crm-core-user-depenses-table">';
        $output .= '<tr><th>ID</th><th>Date</th><th>Nom</th><th>Total HT (' . esc_html($currency) . ')</th><th>Total TTC (' . esc_html($currency) . ')</th></tr>';
        foreach ($archive_years as $archive) {
            $formatted_date = date_i18n(get_option('date_format'), strtotime($archive['date']));
            $output .= '<tr>';
            $output .= '<td>' . esc_html($archive['id']) . '</td>';
            $output .= '<td>' . esc_html($formatted_date) . '</td>';
            $output .= '<td>' . esc_html($archive['nom']) . '</td>';
         
            $output .= '<td>' . wp_kses_post(wc_price(($archive['total_ht']))) . '</td>';
            $output .= '<td>' . wp_kses_post(wc_price(($archive['total_ttc']))) . '</td>';
           
            $output .= '</tr>';
        }
        $output .= '</table>';
    }

    $tiersPays=  get_user_meta($user_id, 'billing_country',true);
    $tiersPays = WC()->countries->countries[$tiersPays] ?? $tiersPays; 

    $output.='<div class="sy-crm-core-depense-sidebar"id="sy-crm-core-depense-edit-sidebar"style="display:none;">
            <div class="sy-crm-core-depense-sidebar-header">
             <h5 class="">Dépense</h5>
            <button class="sy-crm-core-depense-sidebar-header-btn sy-crm-core-depense-edit-sidebar-header-btn">X</button>

             </div>

             <form id="sy-crm-core-depense-edit-form" novalidate>
                <div id="sy-crm-core-depense-edit-result"></div>
                <p class="sy-crm-core-depense-section-title">Détails de la Dépense</p>

                <div class="sy-crm-core-depense-row">
                    <div class="form-group">
                        <label>Pays :</label>
                       
                        <input type="text" name="pays" id="sy-crm-core-depense-edit-tiers-pays" value="'. $tiersPays .'"required>
                   </div> 
                    <div class="form-group">
                        <label>Date de dépense :</label>
                        <input type="date" name="date_depense" id="sy-crm-core-depense-edit-date-depense" value="" required>
                    </div> 
                    
                    <div class="form-group sy_crm_core_depense_group_price">
                        <label>Moyen de règlement :</label>
                        <select name="moyen_reglement"id="sy-crm-core-depense-edit-moyen-reglement">
                            <option value="Espèce">Espèce</option>
                            <option value="Chèque">Chèque</option>
                            <option value="Virement">Virement</option>
                            <option value="Prélèvement">Prélèvement</option>
                            <option value="Internet">Internet</option>
                            <option value="Carte bancaire">Carte bancaire</option>
                        </select>
                    </div>
                    ';
                
                
                        
            $output.='
                <input type="hidden" id="sy-crm-core-depense-edit-tiers" name="tiers" value="'. $user_id .'">
               
              ';        

            if (get_option('vosfactures_sync_enabled')=='yes')
            {
                    $departments = get_option('_crm_vosfactures_departments', []);
                    if (!empty($departments)) {
                
                    $output.='
                    
                        <div class="form-group">
                            <label for="departement_vendeur">Département :</label>
                            <select name="departement_vendeur" id="sy-crm-core-depense-edit-departement-vendeur">

                                ';
                            
                                
                                    foreach ($departments as $dept) {
                                        $output.='   <option value="' . esc_attr($dept['id']) . '">' . esc_html($dept['nom_usage']) . '</option>';
                                
                                    }
                                
                            
                            $output.=' </select>
                        </div>';
                    
                }
            }
           else{
            $output.='
                   
            <div class="form-group">
                <label for="departement_vendeur">Département :</label>
                <input type="text" name="departement_vendeur" id="sy-crm-core-depense-edit-departement-vendeur" value="" >
                    ';
                 
                    
                      
                   
                $output.=' 
            </div>';

           }
            $output.='
        </div>

        <div class="sy-crm-core-depense-row">
            <input type="hidden" name="id_depense"  id="sy-crm-core-depense-edit-id" value="" required >
            <div  class="form-group form-group-title">
                <label>Libellé :</label>
                <input type="text" name="titre_depense" id="sy-crm-core-depense-edit-titre-depense" value="" required>
            </div>
            <div class="form-group form-group-comments">
                <label>Commentaire :</label>
                <textarea name="commentaire"id="sy-crm-core-depense-edit-commentaire"rows=1></textarea>
            </div>
        </div>
    <input type="hidden" id="woo_config" data-currency="'. $config['currency'].'" data-currency-pos="'. $config['currency_pos'].'" data-decimal-sep="'. $config['decimal_sep'].'" data-thousand-sep="'. $config['thousand_sep'].'" data-num-decimals="'. $config['num_decimals'].'">
    
        <div id="sy-crm-core-depense-edit-products-list"></div>
        
        <div id="sy-crm-core-depense-edit-new-product"style="display:none">
             <div class="sy-crm-core-depense-product-col">
                   
                    <div class="sy_crm_core_depense_tiers_search_container">
                        <input type="text"  class="sy-crm-core-depense-edit-nouveau-produit-name" placeholder="Nom du produit" />
                        
                       
                        <ul class="sy_crm_core_depense_products_suggestions"></ul>
                

                    </div>
          
                    <input type="hidden" name="" class="sy-crm-core-depense-edit-nouveau-produit-id" value="0">
                    <input type="hidden" name="" class="sy-crm-core-depense-edit-nouveau-produit-flag" value="0">

                  
            </div>
            </div>

    <button type="button" id="sy-crm-core-depense-edit-ajout-produit-btn"class="sy-crm-core-depense-button sy-crm-core-add-produit"style="display:none;"> + produit</button>
             <div class="sy-crm-core-depense-bottom-row">

                <div class="sy-crm-core-depense-attachement-row">
                    <div id="sy-crm-core-depense-edit-file-list"style="display:none;    min-width: 500px;">
                    
                    </div>
                </div>
        <div class="sy-crm-core-depense-row-prices">
            <div class="form-group sy_crm_core_depense_group_price">
                <label>Total HT ('. $config['currency'].') :</label>
                <input type="text" name="total_depense_ht" id="sy-crm-core-depense-edit-total-ht" value="" readOnly>
            </div>
            <div class="form-group sy_crm_core_depense_group_price">
                <label>Total TTC ('. $config['currency'].') :</label>
                <input type="text" name="total_depense_ttc" id="sy-crm-core-depense-edit-total-ttc" value="" readOnly>
            </div>
        </div>
        </div>
  
    
    <div class="sy-crm-core-depense-sidebar-footer">
        <button type="button"class="sy-crm-core-depense-button discard-edit-depense-sidebar">Fermer</button>
        <button type="button"id="sy-crm-core-depense-delete-btn" data-id=""class="sy-crm-core-depense-button sy-crm-core-depense-delete">Supprimer</button>
        <button type="submit"class="sy-crm-core-depense-button sy-crm-core-depense-edit-submit"style="display:none;">Enregistrer</button>
        <button type="button"class="sy-crm-core-depense-button sy-crm-core-depense-edit-btn"style="">Modifier</button>

    </div>
          

       
</form></div>
';

    wp_reset_postdata();

    return $output;
}

add_shortcode('crm_tiers_depenses', 'afficher_depenses_tiers');

add_action('wp_ajax_export_depenses', 'export_depenses');


function export_depensesOld() {
    $date_debut = sanitize_text_field($_POST['date_debut']);
    $date_fin = sanitize_text_field($_POST['date_fin']);
    $include_pdfs = sanitize_text_field($_POST['include_pdfs']);

    // Vérification de la période
    $date_diff = (strtotime($date_fin) - strtotime($date_debut)) / (60 * 60 * 24);
    if ($date_diff > 30) {
        
        wp_send_json_error(['message' => 'La période ne doit pas dépasser 30 jours.']);
    }

    $args = [
        'post_type'      => 'crm-depenses',
        'posts_per_page' => -1,
        'meta_query'     => [
            [
                'key'     => '_depense_date',
                'value'   => [$date_debut, $date_fin],
                'compare' => 'BETWEEN',
                'type'    => 'DATE'
            ]
        ]
    ];

    $query = new WP_Query($args);

    if ($query->have_posts()) {
      $uploadDir = wp_upload_dir();
        $depensesDir = $uploadDir['basedir'] . "/crm-depenses/export";
        if (!file_exists($depensesDir)) {
            mkdir($depensesDir, 0755, true);
        }  
        $tempDir = $depensesDir . '/temp_files';
        if (!file_exists($tempDir)) {
            mkdir($tempDir, 0755, true);
        }
        $xlsContent = " <style>
                table { border-collapse: collapse; width: 100%; }
                th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
                
            </style><table border='1'><tr><th  colspan='2'>Société</th><th  colspan='2'>Ville</th><th  colspan='2'>Pays</th><th colspan='2'>Total HT</th><th colspan='2'>Total TTC</th><th colspan='2'>Montant TVA</th><th colspan='5'>Libellé</th><th colspan='5'>Commentaire</th><th colspan='15'>PDF</th></tr>";

        while ($query->have_posts()) {
            $query->the_post();
            $post_id = get_the_ID();
            $post_hash = crm_depense_generate_post_hash($post_id);
            $tiersId = get_post_meta($post_id, '_depense_tiers', true);
            $ville = get_post_meta($post_id, '_depense_ville', true);
            $pays = get_post_meta($post_id, '_depense_pays', true) ?? '';
            $currency = get_option('woocommerce_currency');
             $currency_symbol = get_woocommerce_currency_symbol($currency);

$total_ht = number_format((float)str_replace(',', '.', get_post_meta($post_id, '_depense_total_prix_ht', true)), 2, '.', '');
$total_ttc = number_format((float)str_replace(',', '.', get_post_meta($post_id, '_depense_total_prix_ttc', true)), 2, '.', '');
$montant_tva = number_format($total_ttc - $total_ht, 2, '.', '');

            $libelle = html_entity_decode(get_the_title($post_id));
            $commentaire = str_replace(["\n", "\r"], ' ', html_entity_decode(get_post_meta($post_id, '_depense_commentaire', true)));

            $pieces_jointes = get_post_meta($post_id, '_depense_pieces_jointes', true);
            $pdfLinks = [];

            if (!empty($pieces_jointes)) {
                foreach ($pieces_jointes as $file) {
                    $file_hash = crm_depense_generate_file_hash($file);
                    $pdfLinks[] = site_url("/crm-attachements-depenses/{$post_hash}/{$file_hash}");
                    if($include_pdfs==1){
                        $file_path = get_attached_file($file);
                        $file_content = file_get_contents($file);
                        if ($file_content !== false) {
                            file_put_contents($file_path, $file_content);
                                //$filename = basename($file_path);
                            // copy($file_path, $tempDir . '/' . $filename);
                        
                        }
                    }
                }
            }

            $billing_company = get_user_meta($tiersId, 'billing_company', true);
            $prenom_nom = get_user_meta($tiersId, 'last_name', true) . ' ' . get_user_meta($tiersId, 'first_name', true);
            $societe = $billing_company ?: trim($prenom_nom);
            if (!$societe) {
                $societe = get_userdata($tiersId)->user_email;
            }

            $pays = WC()->countries->countries[$pays] ?? $pays;
            $pdfLinksFormatted = implode("<br>", $pdfLinks);
            $xlsContent .= "<tr><td  colspan='2'>{$societe}</td><td  colspan='2'>{$ville}</td><td  colspan='2'>{$pays}</td><td colspan='2'>{$total_ht} {$currency_symbol}</td><td colspan='2'>{$total_ttc} {$currency_symbol}</td><td colspan='2'>{$montant_tva} {$currency_symbol}</td><td colspan='5'>{$libelle}</td><td colspan='5'>{$commentaire}</td><td colspan='15'>{$pdfLinksFormatted}</td></tr>";
       
        
        }
        $xlsContent .= "</table>";

        // Répertoire d'exportation
       

        // Fichier à télécharger
        $downloadedDepensesFile = $depensesDir . '/export-depenses.xls';
        
        // Sauvegarde du contenu dans un fichier
        file_put_contents($downloadedDepensesFile, $xlsContent);

        // URL du fichier pour téléchargement
        $xlsUrl = str_replace('http://', 'https://', $uploadDir['baseurl']) . "/crm-depenses/export/" . basename($downloadedDepensesFile);
        if($include_pdfs==1){
            $zipFilePath = $depensesDir . '/depenses-attachments.zip';
            $zipCommand = "zip -r {$zipFilePath} {$tempDir}";
            exec($zipCommand);

            // Supprimer le dossier temporaire contenant les fichiers
            //$this->delete_dir($tempDir);

            // URL du fichier ZIP pour téléchargement
            $zipUrl = str_replace('http://', 'https://', $uploadDir['baseurl']) . "/crm-depenses/export/" . basename($zipFilePath);

            wp_send_json_success(['xls_url' => str_replace('http://', 'https://', $uploadDir['baseurl']) . "/crm-depenses/export/" . basename($downloadedDepensesFile), 'zip_url' => $zipUrl]);
        }
        else{
        wp_send_json_success(['xls_url' => $xlsUrl]);

        }
    } else {
        wp_send_json_error(['message' => 'Aucune dépense trouvée pour cette période.']);
    }
}
function export_depenses() {
    $date_debut = sanitize_text_field($_POST['date_debut']);
    $date_fin = sanitize_text_field($_POST['date_fin']);
    $include_pdfs = sanitize_text_field($_POST['include_pdfs']);
    $departement = sanitize_text_field($_POST['departement']);
    $upload_dir = wp_upload_dir();
    // Vérification de la période
    $date_diff = (strtotime($date_fin) - strtotime($date_debut)) / (60 * 60 * 24);
    if ($date_diff > 30) {
        crm_core_update_logs_option(
            'Shortcode list des depenses (export des depenses)',  
            'La période ne doit pas dépasser 30 jours.', 
            get_current_user_id(), 
            []
        );
        wp_send_json_error(['message' => 'La période ne doit pas dépasser 30 jours.']);
    }

    $args = [
        'post_type'      => 'crm-depenses',
        'posts_per_page' => -1,
        'meta_query'     => [
            'relation' => 'AND',
            [
                'key'     => '_depense_date',
                'value'   => [$date_debut, $date_fin],
                'compare' => 'BETWEEN',
                'type'    => 'DATE',
            ],
        ],
    ];
    if (!empty($departement)) {
        $args['meta_query'][] = [
            'key'     => '_depense_vendeur',
            'value'   => $departement,
            'compare' => '=',
        ];
    }
    

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        $uploadDir = wp_upload_dir();
        $depensesDir = $uploadDir['basedir'] . "/crm-depenses/export";
        if (!file_exists($depensesDir)) {
            mkdir($depensesDir, 0755, true);
        }  
        $tempDir = $depensesDir . '/temp_files';
        if (!file_exists($tempDir)) {
            mkdir($tempDir, 0755, true);
        }
        $currency = get_option('woocommerce_currency');
        $currency_symbol = get_woocommerce_currency_symbol($currency);
        if (empty($currency_symbol)) {
           $currency_symbol = '€ '; 
       }
        $xlsContent = "<style>
                table { border-collapse: collapse; width: 100%; }
                th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
            </style><table border='1'><tr><th colspan='2'>Société</th><th colspan='2'>Ville</th><th colspan='2'>Pays</th><th colspan='2'>Total HT</th><th colspan='2'>Total TTC</th><th colspan='2'>Montant TVA</th><th colspan='5'>Libellé</th><th colspan='5'>Commentaire</th><th colspan='15'>PDF</th></tr>";

        while ($query->have_posts()) {
            $query->the_post();
            $post_id = get_the_ID();
            $post_hash = crm_depense_generate_post_hash($post_id);
            $tiersId = get_post_meta($post_id, '_depense_tiers', true);
            $ville = get_post_meta($post_id, '_depense_ville', true);
            $pays = get_post_meta($post_id, '_depense_pays', true) ?? '';
            $total_ht = number_format((float)str_replace(',', '.', get_post_meta($post_id, '_depense_total_prix_ht', true)), 2, '.', '');
            $total_ttc = number_format((float)str_replace(',', '.', get_post_meta($post_id, '_depense_total_prix_ttc', true)), 2, '.', '');
            $montant_tva = number_format($total_ttc - $total_ht, 2, '.', '');

            $libelle = html_entity_decode(get_the_title($post_id));
            $commentaire = str_replace(["\n", "\r"], ' ', html_entity_decode(get_post_meta($post_id, '_depense_commentaire', true)));

            $pieces_jointes = get_post_meta($post_id, '_depense_pieces_jointes', true);
            $pdfLinks = [];

            if (!empty($pieces_jointes)) {
                foreach ($pieces_jointes as $file) {
                    $file_hash = crm_depense_generate_file_hash($file);
                    $pdfLinks[] = site_url("/crm-attachements-depenses/{$post_hash}/{$file_hash}");
                    if($include_pdfs == 1){
                     
                        $file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $file);
                       
                        ///////////
                        if (file_exists($file_path)) {
                            $filename = basename($file_path);

                            $destinationPath = $tempDir . '/' . $filename;

                            copy($file_path, $destinationPath)  ;     
                        
                                            }
                }
            }
        }

            $billing_company = get_user_meta($tiersId, 'billing_company', true);
            $prenom_nom = get_user_meta($tiersId, 'last_name', true) . ' ' . get_user_meta($tiersId, 'first_name', true);
            $societe = $billing_company ?: trim($prenom_nom);
            if (!$societe) {
                $societe = get_userdata($tiersId)->user_email;
            }

            $pays = WC()->countries->countries[$pays] ?? $pays;
            $pdfLinksFormatted = implode("<br>", $pdfLinks);
            $xlsContent .= "<tr><td colspan='2'>{$societe}</td><td colspan='2'>{$ville}</td><td colspan='2'>{$pays}</td><td colspan='2'>{$total_ht} {$currency_symbol}</td><td colspan='2'>{$total_ttc} {$currency_symbol}</td><td colspan='2'>{$montant_tva} {$currency_symbol}</td><td colspan='5'>{$libelle}</td><td colspan='5'>{$commentaire}</td><td colspan='15'>{$pdfLinksFormatted}</td></tr>";
        }
        $xlsContent .= "</table>";

        $downloadedDepensesFile = $depensesDir . '/export-depenses.xls';

        file_put_contents($downloadedDepensesFile, $xlsContent);

        // URL du fichier pour téléchargement
        $xlsUrl = str_replace('http://', 'https://', $uploadDir['baseurl']) . "/crm-depenses/export/" . basename($downloadedDepensesFile);

        // Créer le fichier ZIP si nécessaire
        if($include_pdfs == 1){
            $zipFilePath = $depensesDir . '/depenses-attachments.zip';
            if (file_exists($zipFilePath)) {
                unlink($zipFilePath);  
            }
            $zipCommand = "zip -rj {$zipFilePath} {$tempDir}/*";
    exec($zipCommand);

            if ($dir = opendir($tempDir)) {
                while (($file = readdir($dir)) !== false) {
                    if ($file != '.' && $file != '..') {
                        unlink($tempDir . '/' . $file);
                    }
                }
                closedir($dir);
            }

            rmdir($tempDir);

            $zipUrl = str_replace('http://', 'https://', $uploadDir['baseurl']) . "/crm-depenses/export/" . basename($zipFilePath);

            wp_send_json_success(['xls_url' => str_replace('http://', 'https://', $uploadDir['baseurl']) . "/crm-depenses/export/" . basename($downloadedDepensesFile), 'zip_url' => $zipUrl]);
        } else {
            wp_send_json_success(['xls_url' => $xlsUrl,'zip_url'=>'']);
        }
    } else {
        crm_core_update_logs_option(
            'Shortcode list des depenses (export des depenses)',  
            'Aucune dépense trouvée pour cette période.', 
            get_current_user_id(), 
            []
        );
        wp_send_json_error(['message' => 'Aucune dépense trouvée pour cette période.']);
    }
}

function crm_depense_generate_post_hash($post_id) {
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
    return hash_hmac('sha256', $post_id, $secret_key);
}

function crm_depense_generate_file_hash($file_name) {
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
    return hash_hmac('sha256', $file_name, $secret_key);
}

function crm_depense_get_post_id_from_hash($hash) {
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
    $args = ['post_type' => 'crm-depenses', 'posts_per_page' => -1];
   
    foreach (get_posts($args) as $post) {
        if ($hash === hash_hmac('sha256', $post->ID, $secret_key)) {
            return $post->ID;
        }
    }

    return false; 
}

function crm_depense_get_file_name_from_hash($userId, $postId, $hash) {
    $upload_dir = wp_upload_dir();
    $base_dir = $upload_dir['basedir'] . '/crm-core/depense/' . $userId . '/' . $postId;
    $base_url = $upload_dir['baseurl'] . '/crm-core/depense/' . $userId . '/' . $postId;

    if (!is_dir($base_dir)) return false;
//return var_dump(scandir($base_dir));

    foreach (scandir($base_dir) as $file) {
        $hashedFileUrl= crm_depense_generate_file_hash($base_url.'/'.$file) ;
        if ($hash ===$hashedFileUrl){
            return $file;
        }/**/
    }
   // return var_dump($test);
    return false;
}

function download_attachements_shortcode($atts) {
    $atts = shortcode_atts(['text' => 'Téléchargement'], $atts, 'download_attachements_depense');
    $current_url = trim($_SERVER['REQUEST_URI'], '/');

    if (!preg_match('#^crm-attachements-depenses/([a-f0-9]{64})/([a-f0-9]{64})$#', $current_url, $matches)) {
        return '';
    }

    $hashed_id = $matches[1];
    $hashedFileName = $matches[2];

    $post_id = crm_depense_get_post_id_from_hash($hashed_id);
    if (!$post_id) return '';

    $user_id = get_post_meta($post_id, '_depense_tiers', true);
    $file_name = crm_depense_get_file_name_from_hash($user_id, $post_id, $hashedFileName);
    
    //if (!$file_name) return '';

    $upload_dir = wp_upload_dir();
    $file_url = str_replace('http://', 'https://', $upload_dir['baseurl'] . "/crm-core/depense/$user_id/$post_id/$file_name");

    $svg_icon_path = plugin_dir_url(__FILE__) . '../assets/icons/download-files.svg';
    
    return "<div style='text-align:center;'>
                <p>" . esc_html($atts['text']) . "</p>
                <a href='" . esc_url($file_url) . "' download>
                    <img src='" . esc_url($svg_icon_path) . "' alt='Télécharger' style='width:50px;height:50px;'>
                </a>
            </div>";
}

add_shortcode('download_attachements_depense', 'download_attachements_shortcode');

function crm_depense_custom_rewrite_rule() {
    add_rewrite_rule(
      '^crm-attachements-depenses/([a-f0-9]{64})/([a-f0-9]{64})/?$',  
        'index.php?pagename=crm-attachements-depenses&hashedPostId=$matches[1]&hashedFileName=$matches[2]', 
        'top'
    );
   // flush_rewrite_rules();
    
}
add_action('init', 'crm_depense_custom_rewrite_rule',10,0);
function synexta_core_get_file_icon($file_extension)
{
    switch ($file_extension) {
        case 'pdf':
            $icon_url = plugin_dir_url(__FILE__) . '../assets/icons/pdf-icon.svg';
            break;
        case 'doc':
        case 'docx':
            $icon_url = plugin_dir_url(__FILE__) . '../assets/icons/word-icon.svg';
            break;
        case 'xls':
        case 'xlsx':
            $icon_url = plugin_dir_url(__FILE__) . '../assets/icons/excel-icon.svg';
            break;
        case 'jpg':
        case 'jpeg':
        case 'png':
            $icon_url = plugin_dir_url(__FILE__) . '../assets/icons/image-icon.svg';
            break;
        case 'zip':
        case 'rar':
            $icon_url = plugin_dir_url(__FILE__) . '../assets/icons/zip-icon.svg';
            break;
        default:
            $icon_url = plugin_dir_url(__FILE__) . '../assets/icons/image-icon.svg';
            break;
    }
    return $icon_url;

}
