<?php 
function display_users_list($atts) {
    $atts = shortcode_atts([
        'role' => '',
        'count' => 10, 
    ], $atts, 'users-list');

    $count = isset($atts['count']) ? $atts['count'] : 10;
    ob_start();

    if (!is_user_logged_in()) {
        return '';
    }

    $current_user = wp_get_current_user();
    $roles = $current_user->roles;

    if (!in_array('administrator', $roles) && !in_array('responsable_crm', $roles)&& !in_array('utilisateur_crm', $roles)) {
        return ''; 
    }

    global $wpdb;
    $editIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/edit-icon.svg';
    $searchIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/recherche.svg';
    $args = [
        'orderby' => 'user_registered',
        'order' => 'DESC',
        'number' => -1,
    ];
    
    // Arguments de la requête pour récupérer les utilisateurs, 'subscriber'
    if (in_array('administrator', $roles)) {
        $args['role__in'] = ['utilisateur_crm', 'responsable_crm', 'administrator'];
    }
    elseif(in_array('responsable_crm', $roles)){
        $args['role__in'] = ['utilisateur_crm', 'responsable_crm'];
    
    } else {
        $args['role__in'] = ['utilisateur_crm'];
    }

    $users = get_users($args);

    wp_enqueue_style('users-list-style', plugin_dir_url(__FILE__) . '../../global.css');

    wp_enqueue_script('users-list-script', plugin_dir_url(__FILE__) . 'list-admins-shortcode.js', array('jquery'), null, true);
    wp_enqueue_script('shortcode-users-data-table-js', plugin_dir_url(__FILE__) . '../../assets/js/jquery.dataTables.js', array('jquery'), '1.0', true);
    wp_enqueue_script('shortcode-users-data-table-responsive-js', plugin_dir_url(__FILE__) . '../../assets/js/dataTables.responsive.min.js', array('jquery'), '1.0', true);
    wp_enqueue_style('shortcodes-users-data-table-css', plugin_dir_url(__FILE__) . '../../assets/styles/jquery.dataTables.css', array(), '1.0', 'all');
    wp_enqueue_style('shortcodes-users-data-table-responsive-css', plugin_dir_url(__FILE__) . '../../assets/styles/responsive.dataTables.min.css', array(), '1.0', 'all');


    $output="<div class='sy-crm-core-admins-list-container'>
    <div class='sy-crm-core-admins-list-header'>
        <div class='sy-crm-core-admins-list-header-quick-filter'>
                <input type='text' id='sy-crm-core-admins-list-search' value='' placeholder='Rechercher...'>
                <button id='filter-btn'>  
                    <img src='" . esc_url($searchIconUrl) . "' alt='Rechercher'>
                </button>
        </div>
        <div class='sy-crm-core-admins-list-header-right'>
           <select class='sy-crm-core-admins-list-header-role-filter' id='sy-crm-core-admins-list-role-filter'>
                        <option value=''>Tous les rôles</option>";
                         if (in_array('administrator', $roles)) {
    
                       $output.=" <option value='Administrateur'>Administrateur</option>";}
                       if (!in_array('utilisateur_crm', $roles)) {
    
                       $output.=" <option value='Responsable CRM'>Responsable CRM</option>";
                    }

                       $output.=" 
                        <option value='Utilisateur CRM'>Utilisateur CRM</option>";
                       
                    $output.="</select>
                </div></div>";
                
    $output .= '<table id="sy-crm-core-admins-list-table" style="width:100%"  data-count="'.$count.'">';
    $output .= '<thead><tr>
                <th>Entreprise</th><th>Nom / Prénom</th><th>Email</th><th>Rôle</th>
                </tr></thead><tbody>';

    if (!empty($users)) {
        foreach ($users as $user) {
            $billing_company = get_user_meta($user->ID, 'billing_company', true);
            $prenom_nom = get_user_meta($user->ID, 'last_name', true) . ' ' . get_user_meta($user->ID, 'first_name', true);
            $entreprise_affichee = $billing_company ?: '<i>' . esc_html($prenom_nom) . '</i>';
            $email = $user->user_email;
            $user_role = !empty($user->roles) ? $user->roles[0] : '';

            //$row_class = ($user_role === 'subscriber') ? ' strikethrough' : '';

            $edit_url = site_url('/crm-customer/');
            $user_id_hash = generate_user_hash($user->ID);
            $user_role_arr=[
                'utilisateur_crm'=>'Utilisateur CRM',
                'responsable_crm'=>'Responsable CRM',
                'administrator'=>'Administrateur',
            ];
            $output .= '<tr class="">';
            $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . $entreprise_affichee . '</td>';
            $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($prenom_nom) . '</td>';
            $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($email) . '</td>';
            $output .= '<td>' . esc_html($user_role_arr[$user_role]) . '</td>';
            $output .= '</tr>';
        }
    }

    $output .= '</tbody></table></div>';

    return $output;
}

add_shortcode('users-list', 'display_users_list');
