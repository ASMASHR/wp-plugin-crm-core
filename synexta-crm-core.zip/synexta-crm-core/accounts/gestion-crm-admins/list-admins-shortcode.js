jQuery(document).ready(function($) {
    $.fn.dataTable.ext.pager.numbers_length = 4;
    var usersTables = $('#sy-crm-core-admins-list-table').DataTable({
        "paging": true,
        "pageLength": $('#sy-crm-core-admins-list-table').data('count'),
        "searching": true,
        "ordering": true,
        "search": {
            "smart": false,
            "caseInsensitive": true
        },
        "searchDelay": 100,
        "columnDefs": [
            { "responsivePriority": 1, "targets": [0, 1] },
            { "responsivePriority": 2, "targets": '_all' }
        ],
        "order": [
            [0, 'asc']
        ],
        "lengthChange": false,
        "info": true,
        "responsive": true,
        "language": {
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            "info": " _START_ - _END_ / _TOTAL_",
            "infoEmpty": "Aucune utilisateur disponible",
            "zeroRecords": "Aucune utilisateur correspondant trouvée",
            "emptyTable": "Aucun utilisateur trouvée",
            "infoFiltered": "(filtré à partir de _MAX_ entrées )"
        },
        "drawCallback": function() {
            //$('.dataTables_paginate').appendTo('.sy-sy-crm-core-depense-table-info');
            // $('#sy-sy-crm-core-depense-table-custom-info').html($('.dataTables_info').html());
        }
    });

    if ($('#sy-crm-core-admins-list-table_filter').length > 0) {
        $('#sy-crm-core-admins-list-table_filter').hide()
    }



    $('#sy-crm-core-admins-list-search').on('keyup', function() {
        let value = $(this).val();
        usersTables.search(value).draw();

    });




    // Appliquer le filtre lorsque le rôle change
    $('#sy-crm-core-admins-list-role-filter').on('change', function() {
        let value = $(this).val();
        usersTables.search(value).draw();
    });
    $(document).on("click", '.clickable-row', function() {
        const userId = $(this).data('id');
        const href = '/crm-customer/' + userId;

        window.location.href = href;
    });
})