jQuery(document).ready(function($) {
    function validateForm() {
        let isValid = true;
        const userType = $('#user_type').val();
        const lastName = $('#last_name').val().trim();
        const firstName = $('#first_name').val().trim();
        const company = $('#company').val().trim();
        const taxNo = $('#tax_no').val().trim();
        $('#crm-creation-form .text-error').remove();


        if (userType === 'entreprise') {
            if (!taxNo || (!(lastName && firstName) && !company)) {
                $('#tax_no').after('<div class="text-error"  >Identifiant commercial requis.</div>');
                if (!(lastName && firstName) && !company) {
                    $('#company').after('<div class="text-error"  >Nom et Prénom ou Entreprise requis.</div>');
                }
                isValid = false;
            }
        } else if (userType === 'particulier') {
            if (!lastName || !firstName) {
                $('#first_name').after('<div class="text-error"  > Ce champ est obligatoire.</div>');
                $('#last_name').after('<div class="text-error"  >Ce champ est obligatoire.</div>');
                isValid = false;
            }
        }

        return isValid;
    }
    $('#user_type').on('change', function() {
        const selectedType = $(this).val();

        if (selectedType === 'entreprise') {
            $('.entreprise-field').slideDown();
            $('#user_type').parent().parent().addClass('container-third').removeClass('container');
            $('#last_name').siblings('label').text('Nom :');
            $('#first_name').siblings('label').text('Prénom :');
        } else {
            $('.entreprise-field').slideUp();
            $('#user_type').parent().parent().removeClass('container-third').addClass('container');

            $('#last_name').siblings('label').text('Nom * :');
            $('#first_name').siblings('label').text('Prénom * :');
        }

    });
    $('#first_name, #last_name').on('input', function() {
        $('#company').next('.text-error').remove();
    });

    $('#company').on('input', function() {
        $('#first_name, #last_name').next('.text-error').remove();
    });
    $('#tax_no').on('input', function() {
        $('#tax_no').next('.text-error').remove();
    });

    $(document).on("submit", '#crm-creation-form', function(e) {
        e.preventDefault();

        if (validateForm()) {
            const formData = $(this).serialize();

            $.ajax({
                url: ajax_object.ajax_url,
                type: 'POST',
                data: {
                    action: 'create_new_crm_admin',
                    form_data: formData
                },
                beforeSend: function() {
                    $('#crm-creation-result').html('<p style="color: blue;">Traitement en cours...</p>');
                },
                success: function(response) {
                    if (response.success) {
                        $('#crm-creation-result').html('<p style="color: green;">Utilisateur créé avec succès.</p>');
                        setTimeout(function() {

                            //  location.reload();
                            window.location.href = response.data.redirect_url;
                        }, 2000);
                    } else {
                        $('#crm-creation-result').html('<p style="color: red;">' + response.data.message + '</p>');
                    }
                },
                error: function() {
                    $('#crm-creation-result').html('<p style="color: red;">Une erreur s\'est produite. Veuillez réessayer.</p>');
                }
            });
        }
    });
});