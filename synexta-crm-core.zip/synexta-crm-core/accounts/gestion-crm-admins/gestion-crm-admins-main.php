<?php

require_once plugin_dir_path(__FILE__) . 'create-admins-shortcode.php';
require_once plugin_dir_path(__FILE__) . 'list-admins-shortcode.php';