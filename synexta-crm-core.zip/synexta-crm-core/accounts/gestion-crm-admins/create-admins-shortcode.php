<?php



function crm_create_admins_form() {
    $result_message = '';
    global $wpdb;
    $table_name = $wpdb->prefix . 'users';

    $last_user = $wpdb->get_row("SELECT * FROM $table_name ORDER BY ID DESC LIMIT 1");
    $selected_type = "";

    if ($last_user) {
        $user_id = $last_user->ID;
        $selected_type = get_user_meta($user_id, 'user_type', true);
    }
    $connected_user = wp_get_current_user();
    $user_role = $connected_user->roles[0];   
    $is_crm_user = $user_role=='utilisateur_crm';

    wp_enqueue_script('create-admins-script', plugin_dir_url(__FILE__) . 'create-admins-shortcode.js', array('jquery'), null, true);

    ob_start();
    ?>
    <form method="post" id="crm-creation-form" novalidate>
       
        <div class="container-third">
           
           <div class="form-group thirdsize">

           <label>Civilité : </label>
           <select name="civilite" id="civilite"   >
                       <option value="">--Choisir--</option>
                       <option value="Monsieur">Monsieur</option>
                       <option value="Madame">Madame</option>
                       <option value="Monsieur ou Madame">Monsieur ou Madame</option>
                       <option value="Non binaire">Non binaire</option>
               </select>
           
           </div>
           <div class="form-group thirdsize">
               <label class="label"for="last_name">Nom <?php echo ($selected_type == 'entreprise') ? '' : '* '; ?>:</label>
               <input type="text" name="last_name"id="last_name" required>
           </div>

           <div class="form-group thirdsize">
               <label class="label"for="first_name">Prénom <?php echo ($selected_type == 'entreprise') ? '' : '* '; ?> :</label>
               <input type="text" name="first_name" id="first_name">
           </div>
       </div>
       <div class="<?php echo ($selected_type == 'entreprise') ? 'container-third' : 'container'; ?>  ">
           <div class="form-group thirdsize obligatoire">
               <label class="label" for="user_type">Type * :</label>
               <select name="user_type" id="user_type" class="dynamic-width" required>
                   <option value="" disabled>-- Séléctionnez --</option>
                   <option value="entreprise"<?php echo ($selected_type == 'entreprise') ? 'selected' : ''; ?>>Entreprise</option>
                   <option value="particulier"<?php echo ($selected_type == 'particulier') ? 'selected' : ''; ?>>Particulier</option>
               </select>
           </div>

           <!-- Champs Entreprise et Siren -->
           <div class="form-group thirdsize entreprise-field obligatoire" style="<?php echo ($selected_type == 'particulier') ? 'display: none;' : ''; ?>">
               <label class="label" for="company">Entreprise * :</label>
               <input type="text" name="company" id="company"required>
           </div>

           <div class="form-group thirdsize entreprise-field obligatoire" style="<?php echo ($selected_type == 'particulier') ? 'display: none;' : ''; ?>">
               <label class="label" for="tax_no">Identifiant commercial(Siren, TVA, ..) * :  </label>
               <input type="text" name="tax_no" id="tax_no"required>
           </div>
       </div>

   
       

       <div class="form-group">
           <label class="label"for="billing_address_1">Adresse :</label>
           <textarea type="text" name="billing_address_1"id="billing_address_1"rows="2"></textarea>
       </div>

       <div class="container-third">
           <div class="form-group thirdsize">
               <label class="label" for="billing_postcode">Code postal :</label>
               <input type="text" name="billing_postcode"id="billing_postcode">
           </div>
   
           <div class="form-group thirdsize">
               <label class="label"for="billing_city">Ville :</label>
               <input type="text" name="billing_city"id="billing_city">
           </div>
   
           <div class="form-group thirdsize obligatoire">
               <label class="label"for="billing_country" >Pays/région * :</label>
               <?php
                   if (class_exists('WC_Countries')) {
                       $countries_obj = new WC_Countries();
                       $countries = $countries_obj->get_countries();
                   } else {
                       $countries = array('FR' => 'France'); // Valeur par défaut si WooCommerce n'est pas actif
                   }
                   $default_country = 'FR';
               ?>
               <select name="billing_country" id="billing_country" required>
                   <?php foreach ($countries as $code => $name) : ?>
                       <option value="<?php echo esc_attr($code); ?>"<?php echo $code === $default_country ? 'selected' : ''; ?>><?php echo esc_html($name); ?></option>
                   <?php endforeach; ?>
               </select>
           </div>
       </div>

       <div class="container-third">
           <div class="form-group thirdsize">
               <label class="label"for="user_email" >E-mail :</label>
               <input type="email" name="user_email" id="user_email" required>
           </div>
           <div class="form-group thirdsize">
                <label class="label" for="user_password">Mot de passe * :</label>
                <input type="password" name="user_password" id="user_password" required>
            </div>
           <div class="form-group thirdsize obligatoire">
               <label class="label" for="user_role">Rôle :</label>
               
               <select name="user_role" id='user_role'>
               <option value="" disabled>-- Sélectionnez --</option>
                    <option value="utilisateur_crm" selected>Utilisateur CRM</option>
                    <option value="responsable_crm">Gestionnaire CRM</option>
                    <?php
                    if ($user_role=="administrator"){

                    
                    ?>
                    <option value="administrator">Adminstrateur</option>
                <?php }
                    ?>
                   
               </select>
           </div>
   
       </div>

       <div class="container-third">
           <div class="form-group thirdsize">
               <label class="label"for="user_url" >Site web :</label>
               <input type="text" name="user_url"id="user_url">
           </div>

           <div class="form-group thirdsize">
               <label class="label"for="billing_phone">Téléphone :</label>
               <input type="text" name="billing_phone" id="billing_phone">
           </div>

           <div class="form-group thirdsize">
               <label class="label"for="user_mailing">Publipostage :</label>
               <select name="user_mailing"id="user_mailing">
                   <option value="yes" selected>Oui</option>
                   <option value="no">Non</option>
               </select>
           </div>
       </div>

       <input type="hidden" name="user_status" value="active">
       <!--<div class="container-third">
            
            <div class="form-group thirdsize">
                <label class="label" for="smtp_emission">SMTP Émission :</label>
                <input type="text" name="smtp_emission" id="smtp_emission">
            </div>
            
            <div class="form-group thirdsize">
                <label class="label" for="port_emission">Port Émission :</label>
                <input type="text" name="port_emission" id="port_emission">
            </div>
            
            <div class="form-group thirdsize">
                <label class="label" for="login_email_emission">Login Email Émission :</label>
                <input type="email" name="login_email_emission" id="login_email_emission">
            </div>
            
            <div class="form-group thirdsize">
                <label class="label" for="mdp_emission">Mot de passe Émission :</label>
                <input type="password" name="mdp_emission" id="mdp_emission">
            </div>
        </div>-->
        <div class="container">
        <div class="form-group">
            <input type="hidden" name="autoriser_envoi_email" value="0">
            <input class="form-check-input"
                   type="checkbox"
                   name="autoriser_envoi_email" value="1"
                   id="autoriser_envoi_email" checked
                   <?php echo $is_crm_user ? ' disabled' : ''; ?> />
            <label class="form-check-label" for="autoriser_envoi_email">
                Autoriser cet utilisateur à envoyer des emails à des prospects ou tiers
            </label>
        </div>
    </div>
        <div class="container">
            <div class="form-group">
                <label class="label" for="bio">Bio :</label>
                <textarea name="bio" id="bio" rows="2"></textarea>
            </div>
        </div>
        

            

            

            <!-- Bouton de soumission -->
            <button type="submit">Valider la création</button>
        </div>
    </form>
    <div id="crm-creation-result"></div>
   
    <?php
    return ob_get_clean();
}

add_shortcode('user-create', 'crm_create_admins_form');




function create_new_crm_admin() {
    $current_user_id = get_current_user_id();
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        crm_core_update_logs_option(
            'Shortcode de création d’administrateurs',
            'Échec : méthode de requête invalide',
            $current_user_id,
            ['request_method' => $_SERVER['REQUEST_METHOD']]
        );
        wp_send_json_error(array('message' => 'Méthode de requête invalide.'));
        return;
    }

    parse_str($_POST['form_data'], $form_data);
    $form_data['user_mailing'] = 'yes';

    // Vérification des champs requis
    if (empty($form_data['user_email']) && empty($form_data['user_password'])) {
        crm_core_update_logs_option(
            'Shortcode de création d’administrateurs',
            'Échec : Email et mot de passe sont manquants',
            $current_user_id,
            $form_data
        );
        wp_send_json_error(array('message' => 'Email et mot de passe sont requis.'));
        return;
    }

    if (empty($form_data['user_email'])) {
        $counter = 1;
        do {
            $new_email = 'aucun-email-fournis-' . $counter . '@void.com';
            $counter++;
        } while (email_exists($new_email));

        $form_data['user_mailing'] = 'no';
        $form_data['user_email'] = $new_email;
    } else {
        if (email_exists($form_data['user_email'])) {
            $form_data['user_email'] = generate_unique_email($form_data['user_email']);
        }
        $form_data['user_mailing'] = 'no';
    }

    $form_data['first_name'] = !empty($form_data['first_name']) ? custom_normalize_and_uppercase($form_data['first_name']) : '';
    $form_data['last_name'] = custom_normalize_and_uppercase($form_data['last_name']);
    $form_data['company'] = !empty($form_data['company']) ? custom_normalize_and_uppercase($form_data['company']) : '';
    $form_data['billing_address_1'] = !empty($form_data['billing_address_1']) 
        ? custom_normalize_and_uppercase(str_replace('<br>', '-', $form_data['billing_address_1'])) 
        : '';
    $form_data['billing_city'] = !empty($form_data['billing_city']) ? custom_normalize_and_uppercase($form_data['billing_city']) : '';
    $form_data['billing_country'] = !empty($form_data['billing_country']) ? custom_normalize_and_uppercase($form_data['billing_country']) : 'FRANCE';
    $form_data['user_role'] = !empty($form_data['user_role']) ? $form_data['user_role'] : 'prospect';
    $civilite = $form_data['civilite'];

    $timestamp = date('Ymd-His');
    $user_login = $timestamp;

    $user_id = wp_insert_user(array(
        'user_login' => $user_login,
        'user_email' => $form_data['user_email'],
        'first_name' => $form_data['first_name'],
        'last_name' => $form_data['last_name'],
        'role' => $form_data['user_role'],
        'user_pass' => $form_data['user_password']
    ));

    if (is_wp_error($user_id)) {
        crm_core_update_logs_option(
            'Shortcode de création d’administrateurs',
            'Échec : erreur lors de la création de l’utilisateur WordPress',
            $current_user_id,
            $form_data,
                
            
        );
        wp_send_json_error(array('success' => false, 'message' => 'Erreur lors de la création de l\'utilisateur WordPress.'));
        return;
    }

    // Si l’on veut être rigoureux → loguer aussi si une update_user_meta échoue (facultatif mais je te le mets proprement)
    $meta_updates = [
        'billing_first_name' => $form_data['first_name'],
        'billing_last_name' => $form_data['last_name'],
        'billing_company' => !empty($form_data['company']) ? $form_data['company'] : '',
        'tax_no' => $form_data['tax_no'],
        'billing_address_1' => $form_data['billing_address_1'],
        'billing_city' => $form_data['billing_city'],
        'billing_postcode' => $form_data['billing_postcode'],
        'billing_country' => $form_data['billing_country'],
        'billing_phone' => $form_data['billing_phone'],
        'url' => $form_data['user_url'],
        'user_mailing' => $form_data['user_mailing'],
        'user_status' => 'active',
        'user_civilite' => custom_normalize_and_uppercase($civilite),
        'account_creation_date' => current_time('mysql'),
        'account_last_modified_date' => current_time('mysql'),
        'description' => $form_data['bio'],
        'user_can_send_email' => $form_data['autoriser_envoi_email'],
        'user_type' => !empty($form_data['company']) ? 'entreprise' : 'particulier',
        'shipping_first_name' => $form_data['first_name'],
        'shipping_last_name' => $form_data['last_name'],
        'shipping_company' => !empty($form_data['company']) ? $form_data['company'] : '',
        'shipping_address_1' => $form_data['billing_address_1'],
        'shipping_city' => $form_data['billing_city'],
        'shipping_postcode' => $form_data['billing_postcode'],
        'shipping_country' => $form_data['billing_country'],
        'shipping_phone' => $form_data['billing_phone']
    ];

    foreach ($meta_updates as $meta_key => $meta_value) {
        $result = update_user_meta($user_id, $meta_key, $meta_value);
        /*if ($result === false) {
            crm_core_update_logs_option(
                'Shortcode de création d’administrateurs',
                'Échec : échec update_user_meta (' . $meta_key . ')',
                $current_user_id
                ,
                [
                    'user_id' => $user_id,
                    'meta_key' => $meta_key,
                    'meta_value' => $meta_value
                ]
            );
        }*/
    }

    $hashedId = generate_user_hash($user_id);
    wp_send_json_success(array('redirect_url' => site_url('/crm-customer/' . $hashedId)));
}

add_action('wp_ajax_create_new_crm_admin', 'create_new_crm_admin');

add_action('wp_ajax_create_new_crm_admin', 'create_new_crm_admin');
?>