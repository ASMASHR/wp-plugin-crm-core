<?php
function user_bio_shortcode() {
    if (!is_user_logged_in()) {
        return '';
    }

    $hashedId = get_hashed_id_from_url();
    if (!$hashedId) {
        return '';
    }

    $user_id = get_user_id_from_hash($hashedId);
    if (!$user_id) {
        return '';
    }

    $user_bio = get_user_meta($user_id, 'description', true);
    $user_bio = trim($user_bio);

    // Marquer que le shortcode est utilisé
    global $shortcode_user_bio_used;
    $shortcode_user_bio_used = true;

    ob_start();
    ?>
    <div class="userbio">
        <div class="edit-btn" style="float: right;">
            <img src="<?php echo esc_url(home_url('/wp-content/plugins/synexta-crm-core/assets/icons/edition.svg')); ?>" alt="Edit" onclick="toggleEditMode()"/>
        </div>
        <div id="bio-content">
            <?php 
            if (empty($user_bio)) {
                echo '<span class="no_bio">Aucune description du client n\'est disponible. Rajoutez-en une !</span>';
            } else {
                echo wpautop(wp_kses_post($user_bio));
            }
            ?>
        </div>
        <textarea id="bio-editor" style="display: none;"><?php  echo wpautop(wp_kses_post($user_bio)); ?></textarea>
        <button id="save-bio" style="display: none;" onclick="saveBio(<?php echo esc_js($user_id); ?>)">Enregistrer</button>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('user-bio', 'user_bio_shortcode');

// Charger le script uniquement si le shortcode est utilisé
function conditional_enqueue_bio_script() {
    global $shortcode_user_bio_used;
    if ($shortcode_user_bio_used) {
        wp_enqueue_script('bio-js', plugins_url('user-bio-shortcode.js', __FILE__), array('jquery'), null, true);
    }
}
add_action('wp_footer', 'conditional_enqueue_bio_script');

// Gestion de l'action AJAX
add_action('wp_ajax_save_user_bio', 'save_user_bio');
function save_user_bio() {
    $user_id = intval($_POST['user_id']);
    $new_bio = ($_POST['new_bio']); 

    $current_user = wp_get_current_user();
    $user_roles = $current_user->roles;
    if(in_array('administrator', $user_roles)|| in_array('responsable_crm', $user_roles)){
                                
        $can_edit=true;
        
    }
    elseif(in_array('utilisateur_crm', $user_roles)){
        $associer_crm = get_user_meta($user_id, 'associer_crm', true);
        $can_edit= $associer_crm && in_array($current_user->ID,  $associer_crm);
        
    }
    

    if (!$can_edit) {
        crm_core_update_logs_option(
            'Shortcode de mise à jour de la description de l’utilisateur',
            'Échec : droits insuffisants pour modifier la bio de l’utilisateur (user_id : ' . $user_id . ')',
            $current_user->ID,
            [
                'user_id' => $user_id,
                'new_bio' => $new_bio,
                'current_user_roles' => $user_roles
            ]
        );
        wp_send_json_error();
        return;
    }

    $updated = update_user_meta($user_id, 'description', $new_bio);
    if ($updated === false) {
        crm_core_update_logs_option(
            'Shortcode de  mise à jour de la description de l’utilisateur',
            'Échec de la mise à jour de la bio de l’utilisateur (user_id : ' . $user_id . ')',
            $current_user->ID,
            [
                'user_id' => $user_id,
                'new_bio' => $new_bio,
                'current_user_roles' => $user_roles
            ]
        );
        wp_send_json_error('Échec de la mise à jour.');
        return;
    }
    wp_send_json_success();
}
