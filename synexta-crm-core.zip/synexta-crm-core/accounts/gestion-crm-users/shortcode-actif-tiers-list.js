jQuery(document).ready(function($) {
    // $.fn.dataTable.ext.pager.numbers_length = 4;
    var actifUsersTable = $('#sy-crm-core-actif-users-table').DataTable({
        "paging": true,
        "pageLength": $('#sy-crm-core-actif-users-table').data('count'),
        "searching": true,
        "ordering": true,
        "search": {
            "smart": false,
            "caseInsensitive": true
        },
        "searchDelay": 100,
        "columnDefs": [
            { "responsivePriority": 1, "targets": [0, 1] },
            { "responsivePriority": 2, "targets": '_all' }
        ],
        "order": [
            [0, 'asc']
        ],
        "lengthChange": false,
        "info": true,
        "responsive": true,
        "language": {
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            "info": " _START_ - _END_ / _TOTAL_",
            "infoEmpty": "Aucune entreprise disponible",
            "zeroRecords": "Aucune entreprise correspondant trouvée",
            "emptyTable": "Aucune entreprise trouvée",
            "infoFiltered": "(filtré à partir de _MAX_ entrées )"
        },
        "drawCallback": function() {
            //$('.dataTables_paginate').appendTo('.sy-sy-crm-core-depense-table-info');
            // $('#sy-sy-crm-core-depense-table-custom-info').html($('.dataTables_info').html());
        }
    });

    if ($('#sy-crm-core-actif-users-table_filter').length > 0) {
        $('#sy-crm-core-actif-users-table_filter').hide()
    }



    $('#sy-crm-core-actif-users-table-search').on('keyup', function() {
        let value = $(this).val();
        actifUsersTable.search(value).draw();

    });
    $('#sy-crm-core-actif-users-tag-filter').on('change', function() {
        actifUsersTable.draw();

    });

    $.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
        var selectedRole = $('#sy-crm-core-actif-users-role-filter').val().toLowerCase();
        var rowRole = $(actifUsersTable.row(dataIndex).node()).data('role') ? $(actifUsersTable.row(dataIndex).node()).data('role').toLowerCase() : '';

        var selectedTag = $('#sy-crm-core-actif-users-tag-filter').val().toLowerCase();
        var rowTag = $(actifUsersTable.row(dataIndex).node()).data('tags') ? $(actifUsersTable.row(dataIndex).node()).data('tags').toLowerCase() : '';

        var roleMatches = !selectedRole || rowRole === selectedRole;
        var tagMatches = !selectedTag || rowTag.includes(selectedTag);

        return roleMatches && tagMatches;
    });


    // Appliquer le filtre lorsque le rôle change
    $('#sy-crm-core-actif-users-role-filter').on('change', function() {
        actifUsersTable.draw();
    });

    ////////////////////////////////////
    $(document).on("click", '.clickable-row', function() {
        const userId = $(this).data('id');
        const href = '/crm-customer/' + userId;

        window.location.href = href;
    });
});