<?php
/**
 * [tiers-inactifs] affiche la liste des entreprises inactifs
 * @param mixed $atts
 * @return string
 */

 function display_inactifs_users($atts) {
    // Vérifier si l'utilisateur est connecté
    $atts = shortcode_atts([
        'role' => '', 
        'count' => 10, 
    ], $atts, 'tiers-inactifs');
    ob_start();
    //wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../../global.css');
    wp_enqueue_script(
        'list-inactifs-tiers-shortcode',
        plugin_dir_url(__FILE__) . 'shortcode-inactif-tiers-list.js',
        array('jquery'),
        null,
        true
    );
    wp_enqueue_script('shortcode-inactif-tiers-data-table-js', plugin_dir_url(__FILE__) . '../../assets/js/jquery.dataTables.js', array(), '1.0', true);
    wp_enqueue_script('shortcode-inactif-tiers-data-table-responsive-js', plugin_dir_url(__FILE__) . '../../assets/js/dataTables.responsive.min.js', array(), '1.0', true);
    wp_enqueue_style('shortcodes-inactif-tiers-data-table-css', plugin_dir_url(__FILE__) . '../../assets/styles/jquery.dataTables.css', array(), '1.0', 'all');
    wp_enqueue_style('shortcodes-inactif-tiers-data-table-responsive-css', plugin_dir_url(__FILE__) . '../../assets/styles/responsive.dataTables.min.css', array(), '1.0', 'all');
    
    $editIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/edit-icon.svg';
    $searchIconUrl = plugin_dir_url(__FILE__) . '../../assets/icons/recherche.svg';
    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_users_tags';
    $user_tags = $wpdb->get_results("SELECT * FROM $table_name");
    
    wp_enqueue_script(
        'gestion-tiers-shortcode',
        plugin_dir_url(__FILE__) . 'gestion-tiers-front.js',
        array('jquery'),
        null,
        true
    );
    wp_localize_script(
        'gestion-tiers-shortcode',
        'ajax_object',
        array('ajax_url' => admin_url('admin-ajax.php'))
    );

     
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        $roles = $current_user->roles;
        
         
           
         
        if (in_array('administrator', $roles) || in_array('responsable_crm', $roles) || in_array('utilisateur_crm', $roles)) {
          $paged = isset($_GET['page-number']) ? intval($_GET['page-number']) : 1;
            $offset = ($paged - 1) * $atts['count'];
            $count = isset($atts['count']) ? $atts['count'] : 10;
            
            $args = [
                'meta_query' => [
                    [
                        'key' => 'user_status',
                        'value' => ['inactive', 'INACTVE', 'NOT EXISTS','inactif'],
                        'compare' => 'IN',
                    ],
                ],
                'role__in' => !empty($atts['role']) ? [$atts['role']] : ['prospect', 'customer', 'tiers', 'non_qualifie', 'hors_cible','fournisseur'],
                //'number' => isset($atts['count']) ? $atts['count'] : 10, 
                //'offset' => isset($offset) ? $offset : 0,
                'number' => -1, 
                'orderby' => 'user_registered',
                'order' => 'DESC',
            ];
          
        
           
            

            
            $users = get_users($args);
           
            $filtredUsers=[];
            if(in_array('utilisateur_crm', $roles))
            {
                foreach ($users as $user) {
                    $associates_users=get_user_meta($user->ID, 'associer_crm', true);
                    if (is_array($associates_users) && in_array($current_user->ID, $associates_users)) {
                        $filtredUsers[] = $user;
                    }
                }
                $users=$filtredUsers;
                
            }
            $total_users = count($users);
            $users = array_slice($users, $offset, $count);

            $total_pages = ceil($total_users / $count);
            
            $countries = new WC_Countries();
    
    
            $countries_list = $countries->get_countries();
            // Crer une table d'utilisateurs à afficher
            $output="<div class='crm-table-container'>
            <div class='crm-table-header'>
                <div class='crm-table-header-quick-filter'>
                        <input type='text' id='sy-crm-core-inactif-users-table-search' value='' placeholder='Rechercher...'>
                        <button id='filter-btn'>  
                            <img src='" . esc_url($searchIconUrl) . "' alt='Rechercher'>
                        </button>
                </div>
                <div class='crm-table-header-right'>
                <select class='tags-filter' id='sy-crm-core-inactif-users-tag-filter'>
                                <option value=''>Tous les tags</option>";
                    if (!empty($user_tags) ):
                  
    foreach ($user_tags as $tag) {
      
       $output.=' <option value="'.$tag->tag_name.'">
            '.$tag->tag_name.'
        </option>';
       
  
}
               
    endif;

                                
                       $output.="     </select><select class='role-filter' id='sy-crm-core-inactif-users-role-filter'>
                                <option value=''>Tous les rôles</option>
                                <option value='tiers'>Tiers</option>
                                <option value='customer'>Client</option>
                                <option value='prospect'>Prospect</option>
                                <option value='non_qualifie'>Non qualifié</option>
                                <option value='hors_cible'>Hors cible</option>
                            </select>
                        </div></div>";
                        
                        $output .= '<table class="" id="sy-crm-core-inactif-users-table"data-count="'.$count.'"style="width:100%">';
                       $output .= '<thead><tr>
                        <th>Entreprise</th><th>Nom / Prénom</th><th>Adresse</th><th>CP/ville/Pays</th><th>Tél</th><th>Email</th>
                        </tr></thead><tbody>';
            if (!empty($users)) {
                $countries = new WC_Countries();
    
    
                $countries_list = $countries->get_countries();

                foreach ($users as $user) {
                    $billing_company = get_user_meta($user->ID, 'billing_company', true);
                    $prenom_nom = get_user_meta($user->ID, 'last_name', true) . ' ' . get_user_meta($user->ID, 'first_name', true);
                    $billing_address_1 = get_user_meta($user->ID, 'billing_address_1', true);
                    $billing_city = get_user_meta($user->ID, 'billing_city', true);
                    $billing_postcode = get_user_meta($user->ID, 'billing_postcode', true);
                    $pays = get_user_meta($user->ID, 'billing_country', true) ;
                    $billing_country =isset($countries_list[$pays]) ?strtoupper($countries_list[$pays]) : $pays;
                    $billing_phone = get_user_meta($user->ID, 'billing_phone', true);
                    $email = $user->user_email;
                    $entreprise_affichee = $billing_company ?: '<i>' . esc_html($prenom_nom) . '</i>';
                    
                    $userTags = get_user_meta($user->ID, '_user_tags', true)??[];
                    $user_tags_list="";
                    if (!empty($userTags) && is_array($userTags)) {
                        foreach ($user_tags as $tag) {
                            if(is_array($userTags) && in_array($tag->id, $userTags)){
                        
                                $user_tags_list .= esc_html($tag->tag_name) . ' ';
                            }
                        }
                    }  
                                
                    // Construction du champ CP/ville/Pays
                    $cp_ville = '';
                    if ($billing_postcode) {
                        $cp_ville .= esc_html($billing_postcode);
                    }
                    if ($billing_city) {
                        $cp_ville .= ($cp_ville ? ', ' : '') . esc_html($billing_city);
                    }
                    if ($billing_country) {
                        $cp_ville .= ($cp_ville ? ' ' : '') . '(' . esc_html($billing_country) . ')';
                    }

                    // Correction de l'ACTIF / INACTIF
                    $user_status = get_user_meta($user->ID, 'user_status', true);
                    $is_actif = ($user_status === 'active');

                    $edit_url = site_url('/crm-customer/');
                    $user_id_hash = generate_user_hash($user->ID);
                    $user_role = !empty($user->roles) ? $user->roles[0] : '';

                    $output .= '<tr class="user-row" data-tags="' . esc_attr(trim($user_tags_list)) . '"data-role="' . esc_attr($user_role) . '">';
                    $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . $entreprise_affichee . '</td>';
                    $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($prenom_nom) . '</td>';
                    $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($billing_address_1) . '</td>';
                    $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . $cp_ville . '</td>';
                    $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($billing_phone) . '</td>';
                    $output .= '<td  data-id="' . esc_attr($user_id_hash) . '" data-href="' . esc_url($edit_url) . '" class="clickable-row">' . esc_html($email) . '</td>';
                    $output .= '</tr>';
                }
                }
            else {
                    $output .= '<tr><td colspan="7"style="text-align: center;">Aucun utilisateur n\'a été trouvé.</td></tr>';
                }
            $output .= '</tbody></table>';
        
           
		}
	
        else {
            $base_url = site_url('/crm-customer/');
            $user_id_hash = generate_user_hash($current_user->ID);
        
            $redirect_url = ($base_url . $user_id_hash);
        
            wp_redirect($redirect_url);
            exit;
        }   
    } 

     else {
        // Si l'utilisateur n'est pas connecté
        $output = 'Veuillez vous connecter pour voir vos informations.';
    }

	



    return $output;
}
add_shortcode('tiers-inactifs', 'display_inactifs_users');

