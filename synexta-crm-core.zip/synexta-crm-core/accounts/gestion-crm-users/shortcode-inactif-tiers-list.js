jQuery(document).ready(function($) {
    $.fn.dataTable.ext.pager.numbers_length = 4;
    var inactifUsersTable = $('#sy-crm-core-inactif-users-table').DataTable({
        "paging": true,
        "pageLength": $('#sy-crm-core-inactif-users-table').data('count'),
        "searching": true,
        "ordering": true,
        "search": {
            "smart": false,
            "caseInsensitive": true
        },
        "searchDelay": 100,
        "columnDefs": [
            { "responsivePriority": 1, "targets": [0, 1] },
            { "responsivePriority": 2, "targets": '_all' }
        ],
        "order": [
            [0, 'asc']
        ],
        "lengthChange": false,
        "info": true,
        "responsive": true,
        "language": {
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            "info": " _START_ - _END_ / _TOTAL_",
            "infoEmpty": "Aucune entreprise disponible",
            "zeroRecords": "Aucune entreprise correspondant trouvée",
            "emptyTable": "Aucune entreprise trouvée",
            "infoFiltered": "(filtré à partir de _MAX_ entrées )"
        },
        "drawCallback": function() {
            //$('.dataTables_paginate').appendTo('.sy-sy-crm-core-depense-table-info');
            // $('#sy-sy-crm-core-depense-table-custom-info').html($('.dataTables_info').html());
        }
    });

    if ($('#sy-crm-core-inactif-users-table_filter').length > 0) {
        $('#sy-crm-core-inactif-users-table_filter').hide()
    }



    $('#sy-crm-core-inactif-users-table-search').on('keyup', function() {
        let value = $(this).val();
        inactifUsersTable.search(value).draw();

    });
    $('#sy-crm-core-inactif-users-tag-filter').on('change', function() {
        let value = $(this).val();
        inactifUsersTable.search(value).draw();

    });

    $.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
        // Récupérer le rôle sélectionné
        var selectedRole = $('#sy-crm-core-inactif-users-role-filter').val().toLowerCase();
        // Récupérer le rôle de la ligne
        var rowRole = $(inactifUsersTable.row(dataIndex).node()).data('role') ? $(inactifUsersTable.row(dataIndex).node()).data('role').toLowerCase() : '';

        var selectedTag = $('#sy-crm-core-inactif-users-tag-filter').val().toLowerCase();
        var rowTag = $(inactifUsersTable.row(dataIndex).node()).data('tags') ? $(inactifUsersTable.row(dataIndex).node()).data('tags').toLowerCase() : '';

        var roleMatches = !selectedRole || rowRole === selectedRole;
        var tagMatches = !selectedTag || rowTag.includes(selectedTag);

        return roleMatches && tagMatches;
    });

    // Appliquer le filtre lorsque le rôle change
    $('#sy-crm-core-inactif-users-role-filter').on('change', function() {
        inactifUsersTable.draw();
    });

    ////////////////////////////////////
    $(document).on("click", '.clickable-row', function() {
        const userId = $(this).data('id');
        const href = '/crm-customer/' + userId;

        window.location.href = href;
    });
})