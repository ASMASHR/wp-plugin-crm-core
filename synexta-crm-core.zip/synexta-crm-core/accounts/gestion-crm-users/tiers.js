jQuery(document).ready(function($) {
    $('#vosfactures-import-link').click(function(e) {
        e.preventDefault();

        $('#message_outputbox').html('<p>Import en cours... <span id="import-progress">0</span>%</p>');

        var importContacts = function(currentPage) {
            $.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                type: 'POST',
                data: {
                    action: 'import_contacts_from_vosfactures',
                    current_page: currentPage
                },
                success: function(response) {
                    if (response.success) {
                        var progressData = response.data;
                        var progressPercentage = Math.round((progressData.current_page / progressData.total_pages) * 100);
                        $('#import-progress').text(progressPercentage);

                        if (progressData.current_page < progressData.total_pages) {
                            importContacts(progressData.current_page + 1);
                        } else {
                            var message = progressData.imported_count + ' contacts importés avec succès. ' + progressData.skipped_count + ' contacts ignorés car déjà existants.';
                            $('#message_outputbox').html('<p class="crm-alert">' + message + '</p>');
                        }
                    } else {
                        $('#message_outputbox').html('<p class="crm-alert">' + response.data + '</p>');
                    }
                },
                error: function() {
                    $('#message_outputbox').html('<p class="crm-alert">Une erreur s\'est produite lors de l\'importation des contacts.</p>');
                }
            });
        };

        importContacts(1);
    });
});
