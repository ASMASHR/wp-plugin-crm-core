<?php
/**
 * [societe_baseinfo] affiche les informations de base d'une entreprise 
 * @param mixed $atts
 * @return string
 */



function societe_baseinfo($atts) {
  //  wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../../global.css');
    wp_enqueue_script(
        'gestion-tiers-shortcode',
        plugin_dir_url(__FILE__) . 'gestion-tiers-front.js',
        array('jquery'),
        null,
        true
    );
    wp_localize_script(
        'gestion-tiers-shortcode',
        'ajax_object',
        array('ajax_url' => admin_url('admin-ajax.php'))
    );
    ob_start();
    $editIcon=plugin_dir_url(__FILE__) . '../../assets/icons/edition.svg';
    $infoIcon=plugin_dir_url(__FILE__) . '../../assets/icons/nfo-icon.svg';
   
    if (!is_user_logged_in()) {
        return '';
    }
    $hashedId = get_hashed_id_from_url();
    $user_id=null;
    if ($hashedId) {
        $user_id = get_user_id_from_hash($hashedId);
    }

    if ($user_id === null || !get_userdata($user_id)) {
        return '<p>ID utilisateur invalide ou expiré.</p>';
    }
    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_users_tags';
    $user_tags = $wpdb->get_results("SELECT * FROM $table_name");
    
    
    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $connected_user = wp_get_current_user();
    $connected_user_role = $connected_user->roles;    
    $user_role = get_userdata($user_id)->roles[0]; 
    $connected_user_id=$user_id;
 
    $is_admin = in_array('administrator', $connected_user_role);

    $is_responsable_crm = in_array('responsable_crm', $connected_user_role);
    $is_utilisateur_crm = in_array('utilisateur_crm', $connected_user_role);

$user_crm_can_edit = (
    $is_utilisateur_crm &&
    (
        (is_array($associates_users) && in_array($connected_user_id, $associates_users)) || 
        ($connected_user_id === $user_id && $user_role !== 'administrator' && $user_role !== 'responsable_crm')
    )
);
$can_view_user = false;

if ($is_admin) {
    $can_view_user = true; 
} elseif ($is_responsable_crm) {
    $can_view_user = ($user_role !== 'administrator'); 
} elseif ($connected_user_id === $user_id) {
    $can_view_user = true; 
} elseif ($user_crm_can_edit) {
    $can_view_user = true; 
}

if ($can_view_user) {
  
        $countries = new WC_Countries();
    
    //
        $countries_list = $countries->get_countries();

        $roles_mapping = [
            'tiers' => 'Tiers',
            'utilisateur_crm' => 'Utilisateur CRM',
            'responsable_crm' => 'Responsable CRM',
            'administrator'=>'Adminstrateur',
            'non_qualifie' => 'Non qualifié',
            'hors_cible' => 'Hors cible',
            'prospect' => 'Prospect',
            'customer' => 'Client',
            'fournisseur' => 'Fournisseur',
        ];
        
        // Affichage du rôle formaté
        $role_display = $roles_mapping[$user_role] ?? 'Rôle inconnu';
        $nom_societe = get_user_meta($user_id, 'billing_company', true);
        $adresse = get_user_meta($user_id, 'billing_address_1', true);
        $ville = get_user_meta($user_id, 'billing_city', true);
        $code_postal = get_user_meta($user_id, 'billing_postcode', true);
        $pays = get_user_meta($user_id, 'billing_country', true) ;
        $user_status = get_user_meta($user_id, 'user_status', true);
        $is_actif = ($user_status === 'active');

        $billing_country =isset($countries_list[$pays]) ?strtoupper($countries_list[$pays]) : $pays;
        // Construction du champ CP/ville/Pays
        /*$cp_ville = '';
        if ($code_postal) {
            $cp_ville .= esc_html($code_postal);
        }
        if ($ville) {
            $cp_ville .= ($cp_ville ? ', ' : '') . esc_html($ville);
        }
        if ($billing_country) {
            $cp_ville .= ($cp_ville ? ' ' : '') . '(' . esc_html($billing_country) . ')';
        }    
        // Lien pour l'adresse cliquable vers Google Maps
        $adresse_complete = trim("$adresse, $code_postal $ville, $billing_country");
        $adresse_link = 'https://www.google.com/maps/search/?api=1&query=' . urlencode($adresse_complete);
*/
//
$cp_ville_parts = [];
if (!empty(trim($code_postal))) {
    $cp_ville_parts[] = esc_html($code_postal);
}
if (!empty(trim($ville))) {
    $cp_ville_parts[] = esc_html($ville);
}
$cp_ville = implode(', ', $cp_ville_parts);

if (!empty(trim($billing_country))) {
    $cp_ville .= $cp_ville ? ' ' : ''; // Ajouter espace si déjà CP/Ville
    $cp_ville .= '(' . esc_html($billing_country) . ')';
}

// Construire adresse complète (même logique = que les non vides)
$adresse_parts = [];
if (!empty(trim($adresse))) {
    $adresse_parts[] = trim($adresse);
}
if (!empty(trim($code_postal))) {
    $adresse_parts[] = trim($code_postal);
}
if (!empty(trim($ville))) {
    $adresse_parts[] = trim($ville);
}
if (!empty(trim($billing_country))) {
    $adresse_parts[] = trim($billing_country);
}

$adresse_complete = implode(', ', $adresse_parts);
$adresse_link = 'https://www.google.com/maps/search/?api=1&query=' . urlencode($adresse_complete);

//
        $siren =get_user_meta($user_id, 'tax_no', true);
        $userTags = get_user_meta($user_id, '_user_tags', true)??[];
        $user_info = get_userdata($user_id);
        $email =$user_info->user_email;

        //
        $user_can_send_mail =get_user_meta($user_id, 'user_can_send_email', true);
        $telephone = get_user_meta($user_id, 'billing_phone', true);
        
        $url = get_user_meta($user_id, 'url', true);
        $first_name = get_user_meta($user_id, 'first_name', true);
        $civilite = get_user_meta($user_id, 'user_civilite', true);
        $last_name = get_user_meta($user_id, 'last_name', true);
        $parts = [];
        if (!empty(trim($civilite))) {
            $parts[] = trim($civilite);
        }
        if (!empty(trim($last_name))) {
            $parts[] = trim($last_name);
        }
        if (!empty(trim($first_name))) {
            $parts[] = trim($first_name);
        }
        
        $prenom_nom = implode(' ', $parts);
        if ($pays === 'FR' && !empty($siren)) {
            $siren_link = '<a href="https://www.pappers.fr/entreprise/' . esc_attr($siren) . '" target="_blank">' . esc_html($siren) . '</a>';
        } else {
            $siren_link = esc_html($siren);
        }
    
        

        $user_type=get_user_meta($user_id, 'user_type', true);
        // Gestion de l'affichage du champ "Entreprise"
        $entreprise_affichee = $nom_societe && $user_type === "entreprise" ?$nom_societe: '<i>' . esc_html($prenom_nom) . '</i>';
        //shipping infoo
        $nom_societe_shipping =  get_user_meta($user_id, 'shipping_company', true) ;

        $adresse_shipping = get_user_meta($user_id, 'shipping_address_1', true) ;

        $ville_shipping =  get_user_meta($user_id, 'shipping_city', true) ;
                

        $code_postal_shipping =get_user_meta($user_id, 'shipping_postcode', true) ;

        $pays_shipping = get_user_meta($user_id, 'shipping_country', true) ;

    

        $telephone_shipping =get_user_meta($user_id, 'shipping_phone', true) ;
        $first_name_shipping =get_user_meta($user_id, 'shipping_first_name', true) ;

        $last_name_shipping =get_user_meta($user_id, 'shipping_last_name', true);
        $id_facture = get_user_meta($user_id, 'vosfactures_id', true);
        $date_creation = get_user_meta($user_id, 'account_creation_date', true);
        $date_creation = $date_creation ? date("d-m-Y", strtotime($date_creation)) : '';
        $date_update = get_user_meta($user_id, 'account_last_modified_date', true);
        $date_update = $date_update ? date("d-m-Y H:i:s", strtotime($date_update)) : '';
        
        $publipostage=get_user_meta($user_id, 'user_mailing', true);
        $status=get_user_meta($user_id, 'user_status', true);
        $role_asso = [];
 
        if (('tiers'==$user_role) ||('non_qualifie'== $user_role) ||( 'hors_cible'==$user_role) ||('prospect'== $user_role) ||('customer'==$user_role) ||('fournisseur'== $user_role)) {
            $role_asso = ['utilisateur_crm'];
        
        }
       
        $args = array(
            'role__in' => $role_asso, 
            'exclude' => array($user_id), 
            'fields' => array('ID', 'display_name','email'),
        );
        if (!empty($role_asso)) {
            $users_list_for_asso = get_users($args);
        } else {
            $users_list_for_asso = [];
        }
        $associer_crm = get_user_meta($user_id, 'associer_crm', true);
       
        //fin
        //smtp data 
        $smtp_emission=get_user_meta($user_id, 'smtp_emission', true)?get_user_meta($user_id, 'smtp_emission', true):'';
        $smtp_port=get_user_meta($user_id, 'port_emission', true)?get_user_meta($user_id, 'port_emission', true):''; 
        $smtp_login=get_user_meta($user_id, 'login_email_emission', true)?get_user_meta($user_id, 'login_email_emission', true):''; 
        $smtp_password=get_user_meta($user_id, 'mdp_emission', true)?get_user_meta($user_id, 'mdp_emission', true):'';
        $notif="";
        $fields_visibility = get_option('crm_user_management_fields_visibility', array()); 
        if(get_option('vosfactures_sync_enabled') === 'yes'){
            if($id_facture!=""){
            $api_key = get_option('vosfactures_api_key');
            $api_url = get_option('vosfactures_api_url') . "invoices.json?api_token=$api_key&client_id=$id_facture&page=";
            $check_client_url = $api_url . "clients/$id_facture.json?api_token=$api_key";
            $client_response = wp_remote_get($check_client_url);

            $bodyArr = json_decode(wp_remote_retrieve_body($client_response), true);
            if (isset($bodyArr['code'])&&$bodyArr['code']=="error"&&$bodyArr['message']=="Contact non trouvé") {
       
                $notif = "Client n'existe pas dans VosFactures.";
            }
        }    

        }
        
        ?>
        
        
    
        <div class="societe_baseinfo <?php echo !$is_actif?'status-inactif':''; ?>">
            
            <div class="info-view"id="societe_baseinfo_info_view">
                <h3 class="sy-crm-core-title-container <?php echo 'sy_crm_core_role_' . esc_attr($user_role); ?>"> 
                    <span id="nom-entreprise-data"><?php echo ($entreprise_affichee); ?></span>
                    <span class="edit-btn"id='societe_baseinfo_edit_btn' >
                        <img src="<?php echo $editIcon ?>">
                    </span>
                </h3>
                <?php
                if($notif!=""){
                    ?>
                    <p class="societe_baseinfo_account_vf">
                    <?php echo $notif ?>
                    </p>
                    <?php
                }
                ?>
                <?php if (!empty($user_tags) &&!empty($userTags)):
                    ?>
                <div class="crm_user_display_tags_list">
                                <?php
                                    foreach ($user_tags as $tag) {
                                        if(is_array($userTags) && in_array($tag->id, $userTags)):
                                        ?>
                                        <span class="crm_user_displayed_tag user_tag "style=" <?php echo esc_attr($tag->tag_style); ?>">
                                            <?php echo esc_html($tag->tag_name); ?>
                                        </span>
                                        <?php
                                    endif;
                                }
                            
                                ?>
                            </div>
                            <?php
                                    endif;
                                
                            
                                ?>
                
              <?php  if (!empty($adresse_complete) && isset($fields_visibility['billing_address_1']) && $fields_visibility['billing_address_1'] == '1'
    && isset($fields_visibility['billing_city']) && $fields_visibility['billing_city'] == '1'
    && isset($fields_visibility['billing_country']) && $fields_visibility['billing_country'] == '1'
    && isset($fields_visibility['billing_postcode']) && $fields_visibility['billing_postcode'] == '1'): ?>
    
    <a id="adress-link-entreprise-data" href="<?php echo esc_url($adresse_link); ?>" target="_blank">
        <?php if (!empty(trim($adresse))): ?>
            <p><?php echo esc_html($adresse); ?></p>
        <?php endif; ?>
        <?php if (!empty(trim($cp_ville))): ?>
            <p><?php echo $cp_ville; ?></p>
        <?php endif; ?>
    </a>


    <?php endif; ?>  
                <?php if (isset($fields_visibility['user_type']) && $fields_visibility['user_type'] == '1'&&$user_type !=""): ?>
                    
                <p><strong>Type :</strong> <span><?php  echo esc_html($user_type === "particulier" ? "Particulier" : "Entreprise");  ?></span></p>
                
                <?php endif; ?>
                <?php if (isset($fields_visibility['tax_no']) && $fields_visibility['tax_no'] == '1'&&$siren_link!="") :?>
                <p style="<?php echo $user_type=='particulier'?'display:none':''?>"><strong>Identifiant commercial :</strong><span> <?php echo ($siren_link); ?></span></p>
                
                <?php endif; ?>
                <?php if ($prenom_nom!=""): ?>
                    <p><strong>Contact :</strong> <span><?php echo esc_html($prenom_nom); ?></span> </p>
                    <?php endif; ?>    
                <?php if (isset($fields_visibility['role']) && $fields_visibility['role'] == '1'): ?>
                    <p><strong>Rôle :</strong> <span><?php  echo esc_html($role_display); ?></span></p>
                <?php endif; ?>  
                <?php if (isset($fields_visibility['url']) && $fields_visibility['url'] == '1'&&$url!=""): ?>
                    <p><strong>Site web :</strong><a  href="<?php echo esc_attr($url); ?>" target="_blank"> <?php echo esc_html($url); ?></a></p>
                    <?php endif; ?> 
                    <?php if ($email!=""): ?>
                 
                    <p><strong>Email :</strong> <a  href="mailto:<?php echo esc_attr($email); ?>"> <?php echo esc_html($email); ?></a></p>
                    <?php endif; ?>     
                <?php if (isset($fields_visibility['billing_phone']) && $fields_visibility['billing_phone'] == '1'&& $telephone!=""): ?>
                    <p><strong>Téléphone :</strong> <a href="tel:<?php echo esc_attr($telephone); ?>"><?php echo esc_html($telephone); ?></a></p>
                    <?php endif; ?>
                    
            </div>

            <div class="sy-crm-core-edit-info-sidebar"id="edit-info-sidebar"style="display:none;">
                <div class="sidebar-header">
                        <h5 class="">Édition tiers</h5>
                        <button class="sy-crm-core-edit-info-sidebar-discard">X</button>
                </div>
                <form method="post" id="update-societe-baseinfo-form"novalidate>
                    <div class="sy-crm-core-edit-info-sidebar-content">
                        <div class="sidebar-msg-container" id="societe_baseinfo_update_msg"></div>

                        <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">

                        <!-- Section Informations Générales -->
                        <div class="form-section">
                            <h3>Informations Générales</h3>
                            <div class="crm_user_tags_container">
                            <?php if (!empty($user_tags)) :?>
                            <div class="crm_user_tags_list"style="">
                                <?php
                                    foreach ($user_tags as $tag) {
                                        ?>
                                        <span class="crm_user_tags_tag user_tag <?php echo esc_attr($tag->tag_name); ?>" data-id="<?php echo esc_attr($tag->id); ?>" style="<?php echo esc_attr($tag->tag_style); ?> 
                                            <?php if ((is_array($userTags) && in_array($tag->id, $userTags))) echo '; display:none;'; ?>">
                                            <?php echo esc_html($tag->tag_name); ?>
                                        </span>
                                        <?php
                                   
                                }
                            
                                ?>
                            </div>
                            <?php
                                    endif;
                                
                            
                                ?>
                            
                        <div class="crm_user_tags_selected_list ">
                        <?php
                        if (!empty($user_tags)) {
                        foreach ($user_tags as $tag) {
                            if (is_array($userTags) && in_array($tag->id, $userTags)):?>
                                     
                                        <span class="crm_user_tags_selected user_tag <?php echo esc_attr($tag->tag_name); ?>" data-id="<?php echo esc_attr($tag->id); ?>" style=" <?php echo esc_attr($tag->tag_style); ?>">
                                            <?php echo esc_html($tag->tag_name); ?><span class="crm_users_tags_remove" data-id="<?php echo esc_html($tag->id); ?>">x</span>
                                        </span>
                                        <?php
                                    endif;
                                }
                            }
                                ?>
                        </div>
                        
                        </div>
            
                            <div class="form-row">

                                
                    
                            <div class="info-form-group" <?php echo (!isset($fields_visibility['user_type']) || !$fields_visibility['user_type'] == '1') ? 'style="display:none;"' : ''; ?>>
                                <label for="user_type" class="label">Type : *</label>
                                <select name="user_type" id="user_type">
                                    <option value="entreprise" <?php echo $user_type === "entreprise" ? "selected" : ""; ?>>Entreprise</option>
                                    <option value="particulier" <?php echo $user_type === "particulier" ? "selected" : ""; ?>>Particulier</option>
                                </select>
                            </div>
                                 
                                <!-- Section pour Particulier uniquement  echo $user_type == 'particulier' ? 'display:none' : '';  -->
                                <div class="info-form-group"<?php echo (!isset($fields_visibility['billing_company']) || !$fields_visibility['billing_company'] == '1') ? 'style="display:none;"' : ''; ?>>
                                    <label for="billing_company" class="label">Société : *</label>
                                    <input type="text" id="billing_company" name="billing_company" value="<?php echo esc_attr($nom_societe); ?>"<?php echo $user_type == 'particulier' ? 'readOnly disabled' : ''; ?>>
                                </div>
                                
                                <?php if (isset($fields_visibility['tax_no']) && $fields_visibility['tax_no'] == '1'): ?>
                                 

                                <div class="info-form-group">
                                    <label for="tax_no" class="label">Identifiant commercial(Siren, TVA, ..) : </label>
                                    <input type="text" id="tax_no" name="tax_no" value="<?php echo esc_attr($siren); ?>" <?php echo $user_type == 'particulier' ? 'readOnly disabled' : ''; ?>>
                                </div>
                                <?php endif; ?>  


                            </div>
                            
                            <div class="form-row">
                            <div class="info-form-group">
                                <label>Civilité : </label>
                                <select name="user_civilite" id="user_civilite"   >
                                            <option value=""<?php echo $civilite==""?'selected':'';?>></option>
                                            <option value="Monsieur" <?php echo $civilite=="MONSIEUR"?'selected':'';?>>Monsieur</option>
                                            <option value="Madame" <?php echo $civilite=="MADAME"?'selected':'';?>>Madame</option>
                                            <option value="Monsieur ou Madame" <?php echo $civilite=="MONSIEUR OU MADAME"?'selected':'';?>>Monsieur ou Madame</option>
                                            <option value="Non binaire" <?php echo $civilite=="NON BINAIRE"?'selected':'';?>>Non binaire</option>
                                    </select>

                                </div>

                               
                                    <div class="info-form-group">
                                        <label for="last_name" class="label">Nom : <?php echo $user_type === "entreprise" ? "" : "*"; ?> </label>
                                        <input type="text" id="last_name" name="last_name" value="<?php echo esc_attr($last_name); ?>">
                                    </div>
                                
                                    <div class="info-form-group">
                                        <label for="first_name" class="label">Prénom : <?php echo $user_type === "entreprise" ? "" : "*"; ?></label>
                                        <input type="text" id="first_name" name="first_name" value="<?php echo esc_attr($first_name); ?>">
                                    </div>
                                
                            </div>
                            
                        </div>


                        <!-- Section Contact -->
                        <div class="form-section">
                            <h3>Contact</h3>

                            <div class="form-row">
                                <?php if (isset($fields_visibility['role']) && $fields_visibility['role'] == '1'): ?>
                                    <?php if (($user_role ==='utilisateur_crm'||$user_role ==='responsable_crm'||$user_role ==='administrator')): ?>
                                        <div class="info-form-group">
                                        <label for="role" class="label">Rôle : *</label>
                                        <select name="role" id="role">
                                            <option value="utilisateur_crm" <?php echo $user_role === "utilisateur_crm" ? "selected" : ""; ?>>Utilisateur CRM</option>
                                            <option value="responsable_crm" <?php echo $user_role === "responsable_crm" ? "selected" : ""; ?>>Responsable CRM</option>
                                            <?php
                                                if ($user_role=="administrator"){

                                                
                                                ?>
                                                <option value="administrator"<?php echo $user_role === "administrator" ? "selected" : ""; ?>>Adminstrateur</option>
                                            <?php }
                                                ?>
                                        </select>
                                  </div>
                                    <?php else: ?>
                   
                                    <div class="info-form-group">
                                        <label for="role" class="label">Rôle : *</label>
                                        <select name="role" id="role">
                                            <option value="prospect" <?php echo $user_role === "prospect" ? "selected" : ""; ?>>Prospect</option>
                                            <option value="tiers" <?php echo $user_role === "tiers" ? "selected" : ""; ?>>Tiers</option>
                                            <option value="non_qualifie" <?php echo $user_role === "non_qualifie" ? "selected" : ""; ?>>Non qualifié</option>
                                            <option value="hors_cible" <?php echo $user_role === "hors_cible" ? "selected" : ""; ?>>Hors cible</option>
                                            <option value="customer" <?php echo $user_role === "customer" ? "selected" : ""; ?>>Client</option>
                                            <option value="fournisseur" <?php echo $user_role === "fournisseur" ? "selected" : ""; ?>>Fournisseur</option>
                                        </select>
                                  </div>
                                        <?php endif; ?>  

                                 <?php endif; ?>  
                                
                                <div class="info-form-group">
                                    <label for="email" class="label">Email : *</label>
                                    <input type="email" id="email" name="email" value="<?php echo esc_attr($email); ?>" <?php echo $user_role === 'customer' ? '' : 'required'; ?>>
                                </div>
                                 <?php if (isset($fields_visibility['billing_phone']) && $fields_visibility['billing_phone'] == '1'): ?>
                   

                                <div class="info-form-group">
                                    <label for="billing_phone" class="label">Téléphone : </label>
                                    <input type="text" id="billing_phone" name="billing_phone" value="<?php echo esc_attr($telephone); ?>">
                                </div>
                                <?php endif; ?>  
                                 <?php if (isset($fields_visibility['url']) && $fields_visibility['url'] == '1'): ?>
                   
                                <div class="info-form-group">
                                    <label for="url" class="label">Site web : </label>
                                    <input type="text" id="url" name="url" value="<?php echo esc_attr($url); ?>">
                                </div>
                                <?php endif; ?>  
                            </div>
                            
                            <?php 
                            $connected_user_role_string=$connected_user_role[0];
                            //if ((($user_role ==='utilisateur_crm'||$user_role ==='responsable_crm')&&(in_array('administrator', $connected_user_role)) ||in_array('utilisateur_crm', $connected_user_role) || in_array('responsable_crm', $connected_user_role))):
                              if ( in_array($connected_user_role_string,['utilisateur_crm','responsable_crm','administrator'])&& in_array($user_role,['utilisateur_crm','responsable_crm','administrator'])):                                 
                                $user_can_edit=($connected_user_role_string=='administrator'&& in_array($user_role,['utilisateur_crm','responsable_crm','administrator']))||($connected_user_role_string=='responsable_crm'&& in_array($user_role,['utilisateur_crm']));
                                 ?>
                                <div class="form-row">
                                    <input type="hidden" name="user_can_send_email" value="0">
                                    <input class="form-check-input"
                                        type="checkbox"
                                        name="user_can_send_email" value="1"
                                        id="user_can_send_email"  
                                        <?php echo $user_can_send_mail==1 ? ' checked' : ''; ?>
                                        <?php echo $user_can_edit==false ? ' disabled' : ''; ?> />
                                    <label class="form-check-label" for="user_can_send_email">
                                        Autoriser cet utilisateur à envoyer des emails à des prospects ou tiers
                                    </label>
                                </div>
                                <div class="form-row"style="display:none;">
                                    <div class="info-form-group">
                                        <label class="label" for="smtp_emission">SMTP Émission :</label>
                                        <input type="text" name="smtp_emission" id="smtp_emission" value="<?php echo esc_attr($smtp_emission); ?>">
                                    </div>
                                    
                                    <div class="info-form-group">
                                        <label class="label" for="port_emission">Port Émission :</label>
                                        <input type="text" name="port_emission" id="port_emission"value="<?php echo esc_attr($smtp_port); ?>">
                                    </div>
                                    
                                    <div class="info-form-group">
                                        <label class="label" for="login_email_emission">Login Émission :</label>
                                        <input type="email" name="login_email_emission" id="login_email_emission"value="<?php echo esc_attr($smtp_login); ?>">
                                    </div>
                                    
                                    <div class="info-form-group">
                                        <label class="label" for="mdp_emission">Mot de passe Émission :</label>
                                        <input type="password" name="mdp_emission" id="mdp_emission"value="<?php echo esc_attr($smtp_password); ?>">
                                    </div>
                                </div>
                            <?php endif; ?>       
                        </div>
                        <!-- Section Adresse -->
                         <?php if ((isset($fields_visibility['billing_country']) && $fields_visibility['billing_country'] == '1')||(isset($fields_visibility['billing_address_1']) && $fields_visibility['billing_address_1'] == '1')||(isset($fields_visibility['billing_postcode']) && $fields_visibility['billing_postcode'] == '1')||(isset($fields_visibility['billing_city']) && $fields_visibility['billing_city'] == '1')): ?>
                    
                        <div class="form-section">
                             <h3>Adresse de facturation </h3>

                            <?php if (isset($fields_visibility['billing_address_1']) && $fields_visibility['billing_address_1'] == '1'): ?>
                   
                                <div class="info-form-group">
                                    <label for="billing_address_1" class="label">Adresse : *</label>
                                    <input type="text" id="billing_address_1" name="billing_address_1" value="<?php echo esc_attr($adresse); ?>">
                                </div>
                            <?php endif; ?> 
                           
                            <div class="form-row">


                                <?php if (isset($fields_visibility['billing_postcode']) && $fields_visibility['billing_postcode'] == '1'): ?>
                    
                                    <div class="info-form-group">
                                        <label for="billing_postcode" class="label">CP : </label>
                                        <input type="text" id="billing_postcode" name="billing_postcode" value="<?php echo esc_attr($code_postal); ?>">
                                    </div>
                                <?php endif; ?>  

                                <?php if (isset($fields_visibility['billing_city']) && $fields_visibility['billing_city'] == '1'): ?>
                    
                                <div class="info-form-group">
                                    <label for="billing_city" class="label">Ville : *</label>
                                    <input type="text" id="billing_city" name="billing_city" value="<?php echo esc_attr($ville); ?>">
                                </div>
                                <?php endif; ?> 

                                <?php if (isset($fields_visibility['billing_country']) && $fields_visibility['billing_country'] == '1'): ?>
                   
                                    <div class="info-form-group">
                                        <label for="billing_country" class="label">Pays : *</label>
                                        <select id="billing_country" name="billing_country">
                                            <?php foreach (WC()->countries->get_countries() as $key => $value): ?>
                                                <option value="<?php echo esc_attr($key); ?>" <?php echo strtoupper($pays) === strtoupper($value) || strtoupper($pays) === strtoupper($key) ? 'selected' : ''; ?>>
                                                    <?php echo esc_html($value); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                <?php endif; ?>  
                            </div>
                        </div>
                        
                        <?php endif; ?> 

                        <!-- Section Adresse Livraison -->
                        <?php if ((isset($fields_visibility['shipping_country']) && $fields_visibility['shipping_country'] == '1')||(isset($fields_visibility['shipping_city']) && $fields_visibility['shipping_city'] == '1')||(isset($fields_visibility['shipping_postcode']) && $fields_visibility['shipping_postcode'] == '1')||(isset($fields_visibility['shipping_phone']) && $fields_visibility['shipping_phone'] == '1')||(isset($fields_visibility['shipping_first_name']) && $fields_visibility['shipping_first_name'] == '1')||(isset($fields_visibility['shipping_last_name']) && $fields_visibility['shipping_last_name'] == '1')||(isset($fields_visibility['shipping_address_1']) && $fields_visibility['shipping_address_1'] == '1')||(isset($fields_visibility['shipping_company']) && $fields_visibility['shipping_company'] == '1')): ?>
                    
                        <div class="form-section">
                            <h3>Adresse de Livraison</h3>

                        <?php if (isset($fields_visibility['shipping_company']) && $fields_visibility['shipping_company'] == '1'): ?>
                    
                            <div class="info-form-group">
                                <label for="shipping_company" class="label">Société : </label>
                                <input type="text" id="shipping_company" name="shipping_company" value="<?php echo esc_attr($nom_societe_shipping); ?>">
                            </div>
                        <?php endif; ?> 
                            

                            <?php if (isset($fields_visibility['shipping_address_1']) && $fields_visibility['shipping_address_1'] == '1'): ?>
                   
                    
                                <div class="info-form-group">
                                    <label for="shipping_address_1" class="label">Adresse : </label>
                                    <input type="text" id="shipping_address_1" name="shipping_address_1" value="<?php echo esc_attr($adresse_shipping); ?>">
                                </div>
                            <?php endif; ?> 

                            <div class="form-row">

                            <?php if (isset($fields_visibility['shipping_last_name']) && $fields_visibility['shipping_last_name'] == '1'): ?>
                   
                                <div class="info-form-group">
                                    <label for="shipping_last_name" class="label">Nom : </label>
                                    <input type="text" id="shipping_last_name" name="shipping_last_name" value="<?php echo esc_attr($first_name_shipping); ?>">
                                </div>
                            <?php endif; ?>  

                            <?php if (isset($fields_visibility['shipping_first_name']) && $fields_visibility['shipping_first_name'] == '1'): ?>
                   
                                <div class="info-form-group">
                                    <label for="shipping_first_name" class="label">Prénom : </label>
                                    <input type="text" id="shipping_first_name" name="shipping_first_name" value="<?php echo esc_attr($last_name_shipping); ?>">
                                </div>
                            <?php endif; ?>  

                            <?php if (isset($fields_visibility['shipping_phone']) && $fields_visibility['shipping_phone'] == '1'): ?>
                   
                                <div class="info-form-group">
                                    <label for="shipping_phone" class="label">Téléphone : </label>
                                    <input type="text" id="shipping_phone" name="shipping_phone" value="<?php echo esc_attr($telephone_shipping); ?>">
                                </div>
                            <?php endif; ?>  
                            </div>   
                            <div class="form-row">

                                <?php if (isset($fields_visibility['shipping_postcode']) && $fields_visibility['shipping_postcode'] == '1'): ?>
                    
                                    <div class="info-form-group">
                                        <label for="shipping_postcode" class="label">CP : </label>
                                        <input type="text" id="shipping_postcode" name="shipping_postcode" value="<?php echo esc_attr($code_postal_shipping); ?>">
                                    </div>
                                <?php endif; ?>  

                                <?php if (isset($fields_visibility['shipping_city']) && $fields_visibility['shipping_city'] == '1'): ?>
                   
                 
                                    <div class="info-form-group">
                                        <label for="shipping_city" class="label">Ville : </label>
                                        <input type="text" id="shipping_city" name="shipping_city" value="<?php echo esc_attr($ville_shipping); ?>">
                                    </div>
                                <?php endif; ?>  
                                <?php if (isset($fields_visibility['shipping_country']) && $fields_visibility['shipping_country'] == '1'): ?>
                   
                                    <div class="info-form-group">
                                        <label for="shipping_country" class="label">Pays : </label>
                                        <select id="shipping_country" name="shipping_country">
                                            <?php foreach (WC()->countries->get_countries() as $key => $value): ?>
                                                <option value="<?php echo esc_attr($key); ?>" <?php echo strtoupper($pays_shipping) === strtoupper($value) || strtoupper($pays_shipping) === strtoupper($key) ? 'selected' : ''; ?>>
                                                    <?php echo esc_html($value); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                <?php endif; ?>  


                            </div>

                            
                            
                        </div>
                        <?php endif; ?>

                        <!-- Section Compte -->

                    <?php if (isset($fields_visibility['associer_crm']) && $fields_visibility['associer_crm'] == '1'&&!('administrator'== $user_role) && !('responsable_crm'== $user_role)&& !('utilisateur_crm'== $user_role)): ?>
                    
                        <div class="form-section">
                            <h3>Administration tiers </h3>
                            <div class="form-row">
                                <?php if (!in_array('utilisateur_crm', $connected_user_role)&&!in_array('responsable_crm', $connected_user_role)): ?>
                                <div class="info-form-group">
                                    <label for="vosfactures_id" class="label">vosfactures :</label>
                                    <input type="text" id="vosfactures_id" name="vosfactures_id" value="<?php echo esc_attr($id_facture); ?>" required readOnly disabled>
                                </div>
                                <?php endif; ?>

                                <div class="info-form-group">
                                    <label for="user_mailing" class="label">Publipostage :</label>
                                    <select name="user_mailing" id="user_mailing">
                                        <option value="yes" <?php echo $publipostage === "yes" ? "selected" : ""; ?>>Oui</option>
                                        <option value="no" <?php echo $publipostage === "no" ? "selected" : ""; ?>>Non</option>
                                    </select>
                                </div>

                                <div class="info-form-group">
                                    <label for="user_status" class="label">Statut :</label>
                                    <select name="user_status" id="user_status">
                                        <option value="active" <?php echo $status === "active" ? "selected" : ""; ?>>Actif</option>
                                        <option value="inactive" <?php echo $status === "inactive" ? "selected" : ""; ?>>Inactif</option>
                                    </select>
                                </div>
                            </div>

                            <div class="info-form-group">
                                <div class="sy-crm-core-associer-crm-info">
                                    <label for="associer_crm" class="label">Associé à :</label>
                                    <span class="sy-crm-core-info-container">
                                        <img src="<?php echo $infoIcon ?>">
                                        <span class="sy-crm-core-tooltip-custom">Tous les utilisateurs (tiers, prospects, clients) sont automatiquement associés à tous les gestionnaires de CRM.</span>
                                    </span>
                                </div>
                                <div class="users_list  <?php echo (in_array('utilisateur_crm', $connected_user_role)? 'disabled':'') ?>"data-edit="<?php echo (in_array('utilisateur_crm', $connected_user_role)? '0':'1') ?>">
                                    
                                    <?php foreach ($users_list_for_asso as $user):
                                         $isSelected = is_array($associer_crm) && in_array($user->ID, $associer_crm); 
       
                                        ?>
                                        <div class="form-group">
                                            <span class="user-tag <?php echo $isSelected ? 'selected' : ''; ?>" data-id="<?php echo esc_attr($user->ID); ?>">
                                                <?php echo esc_html($user->display_name); ?>
                                            </span>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="users_select_list <?php echo (in_array('utilisateur_crm', $connected_user_role)? 'disabled':'') ?>"data-edit="<?php echo (in_array('utilisateur_crm', $connected_user_role)? '0':'1') ?>">
                                    <?php foreach ($users_list_for_asso as $user):
                                         if (is_array($associer_crm) && in_array($user->ID, $associer_crm)):?>
                                            <span class="selected-user-tag" id="selected-user-tag-<?php echo esc_attr($user->ID); ?>" data-id="<?php echo esc_attr($user->ID) ?>">
                                                    <?php echo esc_html($user->display_name); ?>
                                                <span class="remove-tag" style="margin-left: 5px; cursor: pointer;">&times;</span>
                                            </span>
                                            
                                        <?php 
                                        endif;
                                         endforeach; ?>
                                  
                                </div>
                            </div>
                        </div>

                   <?php endif; ?> 
                        <input type="hidden" id="societe_baseinfo_security" name="security" value="<?php echo wp_create_nonce('update_user_nonce'); ?>">

                    </div>
                    <div id="sy-crm-core-edit-info-sidebar-notif"></div>

                    <div class="sy-crm-core-edit-info-sidebar-footer">
                        <button type="button" class="sy-crm-core-edit-info-sidebar-discard" >Annuler</button>
                        <?php if (($user_role ==='utilisateur_crm'||$user_role ==='responsable_crm')&&(in_array('administrator', $connected_user_role) || in_array('responsable_crm', $connected_user_role))&&$connected_user->ID != $user_id): ?>
                        <button id="sy-crm-core-delete-user-sidebar-btn" class="sy-crm-core-delete-user-btn"data-user-id="<?= $user_id ?>" data-user-email="<?= esc_attr($email) ?>">Supprimer l'utilisateur</button>
                        <?php endif; ?>
                        <button type="submit" class="sy-crm-core-edit-info-sidebar-submit">Modifer</button>


                    </div>
                </form>
            </div>

        </div>
        
        <?php

        return ob_get_clean();
    } else {
        return '';
    }
}
add_shortcode('societe_baseinfo', 'societe_baseinfo');

// Fonction AJAX pour mise à jour
function ajax_update_user_info() {
    // Vérification de la sécurité via nonce
    check_ajax_referer('update_user_nonce', 'security');

    // Vérifie si l'utilisateur est connecté
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Vous devez être connecté pour effectuer cette action.']);
    }
   
    $form_data_raw = $_POST['formData'];
    $form_data = [];
 $civilite = $form_data['user_civilite'];

    foreach ($form_data_raw as $item) {
        //||$item['name'] === 'user_civilite'
        $form_data[$item['name']] = ($item['name'] === 'associer_crm'||$item['name'] === 'user_tag') ? $item['value'] : (sanitize_text_field($item['value']));
    }
    
    $form_data['first_name'] = !empty($form_data['first_name']) ? custom_normalize_and_uppercase($form_data['first_name']) : '';
    $form_data['last_name'] = custom_normalize_and_uppercase($form_data['last_name']);
    $form_data['billing_company'] = !empty($form_data['billing_company']) ? custom_normalize_and_uppercase($form_data['billing_company']) : '';
    //$form_data['billing_address_1'] = !empty($form_data['billing_address_1']) ? custom_normalize_and_uppercase($form_data['billing_address_1']) : '';
    $form_data['billing_address_1'] = !empty($form_data['billing_address_1']) 
    ? custom_normalize_and_uppercase(str_replace('<br>', '-', $form_data['billing_address_1'])) 
    : '';
	$form_data['billing_city'] = !empty($form_data['billing_city']) ? custom_normalize_and_uppercase($form_data['billing_city']) : '';
    $form_data['billing_country'] = !empty($form_data['billing_country']) ? custom_normalize_and_uppercase($form_data['billing_country']) : 'FRANCE';
    $form_data['user_civilite'] = !empty($form_data['user_civilite']) ? custom_normalize_and_uppercase($form_data['user_civilite']) : '';
    $form_data['smtp_emission'] = !empty($form_data['smtp_emission']) ? ($form_data['smtp_emission']) :  '';
    $form_data['login_email_emission'] = !empty($form_data['login_email_emission']) ? ($form_data['login_email_emission']) : '';
    $form_data['mdp_emission'] = !empty($form_data['mdp_emission']) ? ($form_data['mdp_emission']) : '';
    $form_data['port_emission'] = !empty($form_data['port_emission']) ? ($form_data['port_emission']) : '';
   
    switch ($civilite) {
        case 'Monsieur':
            $civilite_vosfacture = 'mr'; 
            break;
        case 'Madame':
            $civilite_vosfacture = 'mrs'; 
            break;
        case 'Monsieur ou Madame':
            $civilite_vosfacture = 'mr_mrs'; 
            break;
        case 'Non binaire':
            $civilite_vosfacture = 'more'; 
            break;
        default:
            $civilite_vosfacture = ''; 
            break;
    }
    
    $billing_fields = [
        'shipping_postcode',
        'shipping_company',
        'shipping_address_1',
        'shipping_city',
        'shipping_last_name',
        'shipping_first_name',
        'shipping_phone'
        
    ];
    
    foreach ($billing_fields as $field) {
        $billing_field = str_replace('shipping', 'billing', $field);
        if (empty($form_data[$field]) && !empty($form_data[$billing_field])) {
            $form_data[$field] = $form_data[$billing_field];
        }
    }
    
    $user_id = intval($form_data['user_id']);
    $connected_user_id = get_current_user_id();
    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $connected_user = wp_get_current_user();
      
    $user_role = get_userdata($user_id)->roles[0]; 
   
    $connected_user_roles = $connected_user->roles;
   // $user_crm_can_edit=is_array($associates_users) && in_array($connected_user->ID, $associates_users);
    $user_crm_can_edit=(in_array('utilisateur_crm', $connected_user_roles)&&is_array($associates_users) && in_array($connected_user->ID, $associates_users))
    ||( in_array('utilisateur_crm', $connected_user_roles) &&$connected_user->ID === $user_id && !('administrator'== $user_role) && !('responsable_crm'== $user_role));
   
    
    $canEdit=in_array('responsable_crm', $connected_user_roles) || in_array('administrator', $connected_user_roles) || $connected_user->ID === $user_id||$user_crm_can_edit;
   
    if (!$canEdit) {
        crm_core_update_logs_option(
            'Shortcode mise à jour des données d\'utilisateur',
            'Échec : droits insuffisants pour modifier les meta de cet utilisateur',
            get_current_user_id(),
            $form_data
        );
        wp_send_json_error(['message' => 'Vous n\'avez pas la permission de modifier ces informations.']);
       
        
    }

   // wp_send_json_error($form_data);
    $allowed_fields = [
        'last_name',
        'first_name',
        'billing_company',
        'billing_address_1',
        'billing_city',
        'billing_postcode',
        'billing_country',
        'tax_no',
        'billing_phone',
        'url',
        'user_type',
        'shipping_company',
        'shipping_address_1',
        'shipping_city',
        'shipping_postcode',
        'shipping_country',
        'shipping_phone',
        'shipping_last_name', 
        'shipping_first_name',
        'url',
        'user_civilite',
        'user_can_send_email'
        
    ];
    /*
    'smtp_emission',
        'login_email_emission',
        'mdp_emission',
        'port_emission'
        */ 

    $data_modified = false;
    $associer_crm =  $form_data['associer_crm'];
    //wp_send_json_error([$form_data['associer_crm']]);
            
    $current_value = get_user_meta($user_id, 'associer_crm', true);
    if ($associer_crm !== $current_value) {
        $data_modified = true; 
        update_user_meta($user_id, 'associer_crm', $associer_crm);

    }   
    $user_tag=$form_data['user_tag'];
    //wp_send_json_error([$user_tag]);
    $old_user_tag= get_user_meta($user_id, '_user_tags', true);
    if ($user_tag !== $old_user_tag) {
        $data_modified = true; 
        update_user_meta($user_id, '_user_tags', $user_tag);

    } 
    if (isset($form_data['user_status'])) {
    $new_value = sanitize_text_field($form_data['user_status']);
    $current_value =get_user_meta($user_id, 'user_status', true);
    if ($new_value != $current_value) {
        $data_modified = true; 
        update_user_meta($user_id,'user_status',$form_data['user_status']);

    } 
    
}
if (isset($_POST['user_mailing'])) {
    $new_value = sanitize_text_field($form_data['user_mailing']);
    $current_value =get_user_meta($user_id, 'user_mailing', true);
    if ($new_value != $current_value) {
        $data_modified = true; 
        update_user_meta($user_id,'user_mailing',$form_data['user_mailing']);

    } 
    
}

    // Validation et mise à jour de l'email
    if (!empty($form_data['email'])) {
        $new_email = sanitize_email($form_data['email']);
        $current_email = get_userdata($user_id)->user_email;

        if ($new_email && $new_email !== $current_email) {
            if (!is_email($new_email)) {
                wp_send_json_error(['message' => 'L\'adresse email fournie n\'est pas valide.']);
            }
            $update_result = wp_update_user([
                'ID' => $user_id,
                'user_email' => $new_email
            ]);

            if (is_wp_error($update_result)) {
                wp_send_json_error(['message' => 'Erreur lors de la mise à jour de l\'email.']);
            }
            $data_modified = true;
        }
    }

    // Mise à jour des métadonnées utilisateur
    foreach ($allowed_fields as $field) {
        if (isset($form_data[$field])) {
            $new_value = sanitize_text_field($form_data[$field]);
            $current_value = get_user_meta($user_id, $field, true);

            if ($new_value !== $current_value) {
                update_user_meta($user_id, $field, $new_value);
                $data_modified = true;
            }
        }
    }
    $user_data = get_userdata($user_id);
   
    $tax_no = get_user_meta($user_id, 'tax_no', true);

    $vosfactures_id = get_user_meta($user_id, 'vosfactures_id', true);
    $data = [
           
        'user_id'=>$user_id,
        'email' => get_userdata($user_id)->user_email,
        'first_name' => $user_data->first_name,
        'last_name' => $user_data->last_name,
        'billing_company'=>custom_normalize_and_uppercase(get_user_meta($user_id, 'billing_company', true)),
        'billing_address_1'=>custom_normalize_and_uppercase(get_user_meta($user_id, 'billing_address_1', true)),
        'billing_city'=>custom_normalize_and_uppercase(get_user_meta($user_id, 'billing_city', true)),
        'billing_postcode'=>get_user_meta($user_id, 'billing_postcode', true),
        'billing_country'=>custom_normalize_and_uppercase(get_user_meta($user_id, 'billing_country', true)),
        'tax_no'=>$tax_no,
        'name' => get_user_meta($user_id, 'billing_company', true) ? custom_normalize_and_uppercase(get_user_meta($user_id, 'billing_company', true)) : custom_normalize_and_uppercase(trim($user_data->first_name . ' ' . $user_data->last_name)),
        'title' =>  $civilite_vosfacture , 
        
        'billing_phone'=>get_user_meta($user_id, 'billing_phone', true),
        'url'=>get_user_meta($user_id, 'url', true),
        'user_type'=>get_user_meta($user_id, 'user_type', true)
    ];
    if (isset($form_data['role'])) {
        $new_role = $form_data['role'];
 
       
        $user = get_userdata($user_id);
        $user_role = $user->roles[0];
        if($user_role!=$new_role)
        {
        $user->set_role($new_role);
        $data_modified = true;
        }
    }
    if ($data_modified) {
        update_user_meta($user_id, 'account_last_modified_date', current_time('mysql'));
        if(get_option('vosfactures_sync_enabled') === 'yes'&&!('administrator'== $user_role) && !('responsable_crm'== $user_role)&& !('utilisateur_crm'== $user_role))
        {
            $response = sync_with_vosfacture($vosfactures_id, $data);

            if ($response['success']) {
                if ($response['action'] === 'updated') {
                    wp_send_json_success(['message' => 'Tiers modifié avec succès et synchronisées avec l\'utilisateur VosFacture.']);
                } 
                elseif ($response['action'] === 'created') {
                    wp_send_json_success(['message' => 'Tiers modifié et utilisateur créé sous VosFacture avec l\'ID : ' . $response['new_id']]);
                }
            } else {
                if($response['message']=="Utilisateur non trouvé sur VosFacture."){
                    wp_send_json_success(['message' => 'Tiers modifié avec succès, mais introuvable sur VosFacture.']);

             
                }
                else{
                    crm_core_update_logs_option(
                        'Shortcode mise à jour des données d\'utilisateur',
                        'Erreur lors de la synchronisation avec VosFacture.',
                        get_current_user_id(),
                        $form_data
                    );
                     wp_send_json_error(['message' => 'Erreur lors de la synchronisation avec VosFacture.', 'body' => $response['body']]);
          
                }
                 }
        }
        else{
            wp_send_json_success(['message' => 'Tiers modifié avec succès.']);
              
        }
    } else {
        wp_send_json_success(['message' => 'Aucune modification détectée.']);
    }

    wp_send_json_error(['message' => 'Erreur lors de la mise à jour des informations.']);
}

add_action('wp_ajax_update_user_info', 'ajax_update_user_info');


/**
 * Synchronise les données de l'utilisateur avec VosFacture.
 *
 * Si l'ID VosFacture existe, les données de l'utilisateur sont mises à jour.
 * Si l'ID VosFacture n'est pas trouvé ou que l'utilisateur correspondant n'existe pas,
 * un nouvel utilisateur est créé avec les données fournies.
 *
 * @param mixed $vosfactures_id L'ID VosFacture de l'utilisateur, s'il existe.
 * @param mixed $form_data Les données du formulaire utilisateur à synchroniser.
 * @return void
 */
function sync_with_vosfacture($vosfactures_id, $form_data) {
    
    $api_key = get_option('vosfactures_api_key');
    $api_url = rtrim(get_option('vosfactures_api_url'), '/');

    if (empty($api_key) || empty($api_url)) {
        crm_core_update_logs_option(
            'Shortcode mise à jour des données d\'utilisateur',
            'La clé API ou l\'URL VosFactures n\'est pas configurée.',
            get_current_user_id(),
            $form_data
        );
        wp_send_json_error( array('success' => false, 'message' => 'La clé API ou l\'URL VosFactures n\'est pas configurée.'));
    }



     $contact_data = array(
        'client' => array(
            'name' => $form_data['name'],
            'first_name' => $form_data['first_name'],
            'last_name' => $form_data['last_name'],
            'email' => $form_data['email'],
            'street' => $form_data['billing_address_1'],
            'post_code' => $form_data['billing_postcode'],
            'city' => $form_data['billing_city'],
            'country' => $form_data['billing_country'],
            'phone' => $form_data['billing_phone'],
            'tax_no' => $form_data['tax_no'],
            'www'=>$form_data['url'],
            'title' =>  $form_data['title'] , 
        
            'company'=>$form_data['user_type']=="entreprise"?true: false,
        )
    );
   

    // Envoyer les données à VosFactures
    $endpoint = $vosfactures_id ? "/clients/{$vosfactures_id}.json" : "/clients.json";
    $method = $vosfactures_id ? 'PUT' : 'POST';
    $action =  $vosfactures_id ? 'updated' : "created";

    $response = wp_remote_request($api_url . $endpoint, array(
        'method'      => $method,
        'headers'     => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
        ),
        'body'        => json_encode($contact_data),
        'data_format' => 'body'
    ));

    if (is_wp_error($response)) {
        crm_core_update_logs_option(
            'Shortcode mise à jour des données d\'utilisateur',
            'Erreur lors de la connexion à VosFacture.',
            get_current_user_id(),
            $form_data
        );
        wp_send_json_error(array('success' => false, 'message' => 'Erreur lors de la connexion à VosFacture.'));
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    /*if($method=="PUT"&&isset($body['error'])&&$body['error']=="Not Found"){
        $endpoint="/clients.json";
        $responseNew = wp_remote_request($api_url . $endpoint, array(
            'method'      => 'POST',
            'headers'     => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ),
            'body'        => json_encode($contact_data),
            'data_format' => 'body'
        ));

    $body = json_decode(wp_remote_retrieve_body($responseNew), true);
    
    $action =   "created";
    }*/
    $reponse=[];
        
    if (isset($body['id'])) {
        update_user_meta($form_data['user_id'], 'vosfactures_id', $body['id']);
        
        $reponse=['success' => true, 'message' => 'Utilisateur synchronisé avec succès.','new_id' => $body['id'] ?? null,'action'=>$action];
    } 
    else {

         $reponse=['success' => false, 'message' => 'Utilisateur non trouvé sur VosFacture.','body'=>$body];
        
    }

    return $reponse;


}