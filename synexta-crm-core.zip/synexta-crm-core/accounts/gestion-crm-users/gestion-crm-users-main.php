<?php

/*
 * Ce fichier PHP gère l'affichage des contacts depuis l'API VosFactures dans WordPress.
 *
 * Fonctionnalités principales :
 * - Vérifie la configuration de la clé API VosFactures et affiche un message si elle n'est pas configurée.
 * - Cre le shortcode `[tiers]` pour afficher les informations des contacts sous forme de tableau pagin.
 *
 * Variables et données :
 * - `vosfactures_api_key` : Clé API pour authentifier les requtes à l'API VosFactures.
 * - `vosfactures_api_url` : URL de base pour accéder à l'API VosFactures.
 * - `current_page` : Numro de la page courante pour la pagination des résultats.
 * - `per_page` : Nombre de contacts à afficher par page (défaut : 100).
 *
 * Utilisation :
 * - Le shortcode `[tiers]` peut tre inséré dans les publications ou pages pour afficher un tableau des contacts.
 * - Les résultats incluent les informations de chaque contact, y compris les dates de création et de modification.
 * - Les données sont récuprées et affichées en utilisant les fonctions WordPress `wp_remote_get()` et `wp_enqueue_style()`.
 * 
 *  * Shortcode [tiers-actifs] :
 * Affiche la liste des entreprises activées dans l'application VosFactures.
 * Présente les informations sous forme de tableau paginé, avec des détails tels que la date de création et de modification.
 * Attributs :
 * 
 * - count (facultatif) : Détermine le nombre d'utilisateurs affichés par page. Si cet attribut est spécifié, le tableau intègre automatiquement un système de pagination pour
 * naviguer entre les différentes pages de résultats. Par exemple, count="10" affichera 10 utilisateurs par page, avec des liens de navigation pour accéder aux pages suivantes ou
 * précédentes.
 * - role (facultatif) : Si spécifié, le shortcode filtre les utilisateurs selon ce rôle. 
 *   Exemple : [tiers-actifs role="customer"count=15]
 * - Si l'attribut role n'est pas défini, le shortcode récupère tous les utilisateurs ayant l'un des rôles suivants :
 *   'prospect', 'customer', 'tiers', 'non_qualifie', 'hors_cible'.




 * Shortcode [tiers-inactifs] :
 * Affiche la liste des entreprises inactives.
 * Les informations sont également présentées sous forme de tableau paginé.
 * 
 * Attributs :
 *  - count (facultatif) : Détermine le nombre d'utilisateurs affichés par page. Si cet attribut est spécifié, le tableau intègre automatiquement un système de pagination pour
 * naviguer entre les différentes pages de résultats. Par exemple, count="10" affichera 10 utilisateurs par page, avec des liens de navigation pour accéder aux pages suivantes ou
 * précédentes.
 * - role (facultatif) : Si spécifié, le shortcode filtre les utilisateurs selon ce rôle. 
 *   Exemple : [tiers-inactifs role="customer"count=15]
 * - Si l'attribut role n'est pas défini, le shortcode récupère tous les utilisateurs ayant l'un des rôles suivants :
 *   'prospect', 'customer', 'tiers', 'non_qualifie', 'hors_cible'.
 
 * Shortcode [societe_baseinfo] :
 * Présente les informations de base d'une société, incluant :
 * Nom de la société, adresse, code postal, ville, pays, SIREN, contact, email et téléphone.
 * Fournit une interface pour modifier ces informations via un formulaire sécurisé :
 * Les champs sont vérifiés et nettoyés avant de mettre à jour les métadonnées utilisateur.
 * Si les données sont modifiées, un message de succès s'affiche.
 * Possibilité d'éditer ou d'annuler les modifications à l'aide de boutons intégrés.
 
 * Shortcode [societe_adresseslivraison] :
 * Affiche l'adresse de livraison et les informations associées :
 * Société, adresse, code postal, ville, pays, contact et téléphone.
 * Permet l'édition des informations de livraison grâce à un formulaire :
 * Les données saisies sont vérifiées avant mise à jour des métadonnées utilisateur.
 * Confirmation visuelle en cas de succès des modifications.

 * Utilisation :
 * - Cette implémentation garantit que la page crm-customer est créée et contient les shortcodes suivants : [societe_technique], [societe_adresseslivraison], et [societe_baseinfo]. Ces shortcodes permettent d'afficher des informations spécifiques en fonction d'un identifiant (hashedId) transmis via l'URL.
 * - Lorsque l'utilisateur accède à une URL sous la forme site.com/crm-customer/{hashedId}, la page récupère automatiquement l'identifiant et affiche les données correspondantes grâce aux shortcodes intégrés dans la page.

 */

// Inclusion des fichiers nécessaires pour le fonctionnement du module
require_once plugin_dir_path(__FILE__) . 'tiers-create-new.php';
require_once plugin_dir_path(__FILE__) . 'tiers-import-contact-coorectionmanuelle.php';
require_once plugin_dir_path(__FILE__) . 'tiers-import-contacts.php';
require_once plugin_dir_path(__FILE__) . 'tiers-update.php';

require_once plugin_dir_path(__FILE__) . 'shortcode-inactif-tiers-list.php';
require_once plugin_dir_path(__FILE__) . 'shortcode-actif-tiers-list.php';
require_once plugin_dir_path(__FILE__) . 'shortcode-edit-user-info.php';
require_once plugin_dir_path(__FILE__) . 'shortcode-user-technique-info.php';
require_once plugin_dir_path(__FILE__) . 'shortcode-user-facturation-info.php';
require_once plugin_dir_path(__FILE__) . 'shortcode-user-livraison-info.php';


 function ensure_edit_user_page_exists() {
    // Définir le titre et le contenu de la page
    $page_title = 'Gestion des tiers';
    $page_slug = 'crm-customer';
    $page_content = '[societe_baseinfo]'; // Shortcode que vous utiliserez pour afficher le contenu

    // Vérifier si une page avec ce slug existe déjà
    $page = get_page_by_path($page_slug);

    if (!$page) {
        // La page n'existe pas, la créer
        $new_page_id = wp_insert_post([
            'post_title'     => $page_title,
            'post_name'      => $page_slug,
            'post_content'   => $page_content,
            'post_status'    => 'publish',
            'post_type'      => 'page',
        ]);

        
    } 
}

function ensure_Liste_disabled_companies_page_exists() {
    // Définir le titre et le contenu de la page
    $page_title = 'Tiers inactifs';
    $page_slug = 'crm-customer-inactif';
    $page_content = '[tiers-inactifs]'; 
    // Vérifier si une page avec ce slug existe déj
    $page = get_page_by_path($page_slug);

    if (!$page) {
        // La page n'existe pas, la créer
        $new_page_id = wp_insert_post([
            'post_title'     => $page_title,
            'post_name'      => $page_slug,
            'post_content'   => $page_content,
            'post_status'    => 'publish',
            'post_type'      => 'page',
        ]);

        
    } 
}
add_action('after_setup_theme', 'ensure_Liste_disabled_companies_page_exists');

add_action('init', 'remove_page_rewrite_rule', 10, 0);

function remove_page_rewrite_rule() {
    global $wp_rewrite;
    $wp_rewrite->rules = array();
    $wp_rewrite->flush_rules();  // Cela vide les règles existantes
}

function custom_rewrite_rule() {
    add_rewrite_rule(
        '^crm-customer/([a-f0-9]{64})/?$',  
        'index.php?pagename=crm-customer&hashedId=$matches[1]', 
        'top'
    );
    add_rewrite_rule(
        '^page/([0-9]+)/?$',  // Si l'URL est de la forme /page/{numéro}, redirige vers un format compatible.
        'index.php?paged=$matches[1]',  // Redirige vers la page avec le paramètre ?paged={numéro}
        'top'
    );
    
}
add_action('init', 'custom_rewrite_rule',10,0);





function generate_user_hash($user_id) {
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
    return hash_hmac('sha256', $user_id, $secret_key);
}

function get_user_id_from_hash($hash) {
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
    $users = get_users(); 

    foreach ($users as $user) {
        if ($hash === hash_hmac('sha256', $user->ID, $secret_key)) {
            return $user->ID;
        }
    }

    return false; 
}
function get_hashed_id_from_url() {
    // Récuprer l'URL complète de la page
    $current_url = $_SERVER['REQUEST_URI'];
    
    // Vérifier si l'URL contient 'crm-customer'
    if (preg_match('#^/crm-customer/([a-f0-9]{64})#', $current_url, $matches)) {
        // Si l'ID est trouvé, renvoyer le premier match (le hashedId)
        return $matches[1];
    }
    
    // Si aucun hashedId n'est trouvé, retourner null ou une valeur par défaut
    return null;
}
add_action('wp_enqueue_scripts', 'enqueue_tiers_js');

function enqueue_tiers_js() {
    wp_enqueue_script('tiers-js', plugin_dir_url(__FILE__) . 'tiers.js', array('jquery'), '1.0', true);
}

function display_tiers_accounts($atts) {
    $api_key = get_option('vosfactures_api_key');
    $api_url = rtrim(get_option('vosfactures_api_url'), '/');

    if (empty($api_key)) {
        return '<p>La clé API VosFactures n\'est pas configure. Veuillez la configurer dans les paramètres du plugin.</p>';
    }

    $current_page = isset($_GET['tiers_page']) ? intval($_GET['tiers_page']) : 1;
    $per_page = 100;

    $api_url .= '/clients.json?api_key=' . urlencode($api_key) . '&page=' . $current_page . '&per_page=' . $per_page;

    $args = array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
        ),
    );

    $response = wp_remote_get(esc_url_raw($api_url), $args);

    if (is_wp_error($response)) {
        return 'Erreur lors de la connexion à l\'API VosFactures : ' . esc_html($response->get_error_message());
    }

    $status_code = wp_remote_retrieve_response_code($response);
    if ($status_code !== 200) {
        return 'Erreur HTTP : ' . esc_html($status_code) . '. Veuillez vrifier l\'API.';
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        return 'Erreur lors du dcodage des données JSON : ' . json_last_error_msg();
    }

    $clients = $data ?? array();
    $total_clients = count($clients);

    wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../../global.css');

    $output = '<p>Affichage des contacts ' . (($current_page - 1) * $per_page + 1) . ' à ' . min($current_page * $per_page, ($current_page - 1) * $per_page + $total_clients) . '</p>';

    $output .= '<table class="crm-table">
                    <thead>
                        <tr>
                            <th>ID Tiers</th>
                            <th>Company</th>
                            <th>Nom</th>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Adresse</th>
                            <th>CP et ville</th>
                            <th>Email</th>
                            <th>ID Commercial</th>
                            <th>Date de Création</th>
                            <th>Date de Modification</th>
                        </tr>
                    </thead>
                    <tbody>';

    foreach ($clients as $client) {
        $client_id = $client['id'] ?? '';
        $company = $client['company'] ? 'Oui' : 'Non';
        $name = $client['company'] ? $client['name'] : $client['title'];
        $last_name = $client['last_name'] ?? '';
        $first_name = $client['first_name'] ?? '';
        $street = $client['street'] ?? '';
        $post_code = $client['post_code'] ?? '';
        $city = $client['city'] ?? '';
        $country = $client['country'] ?? '';
        $email = $client['email'] ? explode(',', $client['email'])[0] : '';
        $tax_no = $client['tax_no'] ?? '';

        // Convertir les dates au format désir
        $creation_date = !empty($client['created_at']) ? (new DateTime($client['created_at']))->format('d-m-Y H:i:s') : '';
        $modification_date = !empty($client['updated_at']) ? (new DateTime($client['updated_at']))->format('d-m-Y H:i:s') : '';

        $output .= '<tr>
                        <td>' . esc_html($client_id) . '</td>
                        <td>' . esc_html($company) . '</td>
                        <td>' . esc_html($name) . '</td>
                        <td>' . esc_html($last_name) . '</td>
                        <td>' . esc_html($first_name) . '</td>
                        <td>' . esc_html($street) . '</td>
                        <td>' . esc_html($post_code . ' ' . $city . ' (' . $country . ')') . '</td>
                        <td>' . esc_html($email) . '</td>
                        <td>' . esc_html($tax_no) . '</td>
                        <td>' . esc_html($creation_date) . '</td>
                        <td>' . esc_html($modification_date) . '</td>
                    </tr>';
    }

    $output .= '</tbody></table>';

    $output .= '<div class="pagination">';
    if ($current_page > 1) {
        $prev_page_url = add_query_arg('tiers_page', $current_page - 1);
        $output .= '<a href="' . esc_url($prev_page_url) . '">&laquo; Prcdent</a>';
    }
    if ($total_clients === $per_page) {
        $next_page_url = add_query_arg('tiers_page', $current_page + 1);
        $output .= '<a href="' . esc_url($next_page_url) . '">Suivant &raquo;</a>';
    }
    $output .= '</div>';

    return $output;
}

add_shortcode('tiers', 'display_tiers_accounts');
