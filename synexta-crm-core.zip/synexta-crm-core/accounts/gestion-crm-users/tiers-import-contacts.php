<?php
/*
 * Ce fichier PHP crée deux shortcodes : 
 * [tiers_import_all] pour importer tous les contacts depuis VosFactures vers WordPress.
 * [tiers_import_specific] pour importer un contact spécifique en utilisant l'ID VosFactures.
 */

// fonction 1 : Normalisation du texte
function normalize_and_uppercase($text) {
    $unwanted_array = array(
        'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A', 'Å' => 'A', 'Æ' => 'AE',
        'Ç' => 'C',
        'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
        'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I',
        'Ñ' => 'N',
        'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O',
        'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U',
        'Ý' => 'Y',
        'ß' => 'SS',
        'à' => 'A', 'á' => 'A', 'â' => 'A', 'ã' => 'A', 'ä' => 'A', 'å' => 'A', 'æ' => 'AE',
        'ç' => 'C',
        'è' => 'E', 'é' => 'E', 'ê' => 'E', 'ë' => 'E',
        'ì' => 'I', 'í' => 'I', 'î' => 'I', 'ï' => 'I',
        'ñ' => 'N',
        'ò' => 'O', 'ó' => 'O', 'ô' => 'O', 'õ' => 'O', 'ö' => 'O', 'ø' => 'O',
        'ù' => 'U', 'ú' => 'U', 'û' => 'U', 'ü' => 'U',
        'ý' => 'Y', 'ÿ' => 'Y'
    );
    $text = strtr($text, $unwanted_array);
    $text = preg_replace("/[&\/:,']/u", " ", $text);
    $text = preg_replace('/\s+/', ' ', $text); // Remove multiple spaces
    return strtoupper(trim($text));
}

// fonction 2 : Importer un contact spécifique
function import_contact($client_id) {
    $api_key = get_option('vosfactures_api_key');
    $api_url = rtrim(get_option('vosfactures_api_url'), '/');

    if (empty($api_key)) {
        return 'La clé API VosFactures n\'est pas configurée. Veuillez la configurer dans les paramètres du plugin.';
    }

    $api_url_contact = $api_url . '/clients/' . $client_id . '.json?api_key=' . urlencode($api_key);

    $response = wp_remote_get(esc_url_raw($api_url_contact), array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
        ),
    ));

    if (is_wp_error($response)) {
        return 'Erreur lors de la connexion à l\'API VosFactures : ' . esc_html($response->get_error_message());
    }

    $body = wp_remote_retrieve_body($response);
    $contact = json_decode($body, true);

    if (empty($contact)) {
        return 'Contact introuvable pour l\'ID VosFactures : ' . esc_html($client_id);
    }

    $existing_user_query = get_users(array(
        'meta_key' => 'vosfactures_id',
        'meta_value' => $client_id,
        'number' => 1,
        'count_total' => false,
    ));

    // fonction 3 : Gestion de l'email
    $email = $contact['email'] ? explode(',', $contact['email'])[0] : '';
    $counter = 1;
    if (empty($email)) {
        // Générer un email factice unique
        do {
            $email = 'aucun-email-fournis-' . $counter . '@void.com';
            $counter++;
        } while (email_exists($email));

        // Mettre "publipostage" à "non" pour ces contacts
        update_user_meta($user_id, 'user_mailing', 'non');
    }

    $email_exists_user = email_exists($email);

    if ($email_exists_user && (!$existing_user_query || $existing_user_query[0]->ID !== $email_exists_user)) {
        // Générer un alias d'email
        $email_parts = explode('@', $email);
        $new_email = $email_parts[0] . '+' . $client_id . '@' . $email_parts[1];

        // Mettre à jour l'email dans VosFactures
        $api_url_update = $api_url . '/clients/' . $client_id . '.json';
        $update_response = wp_remote_post($api_url_update, array(
            'method' => 'PUT',
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array('client' => array('email' => $new_email))),
        ));

        if (is_wp_error($update_response)) {
            return 'Erreur lors de la mise à jour de l\'email dans VosFactures pour l\'ID : ' . esc_html($client_id);
        }

        $email = $new_email;
    }

    if (!empty($existing_user_query)) {
        $user_id = $existing_user_query[0]->ID;
    } else {
        if (empty($email)) {
            return 'Email manquant pour l\'ID VosFactures : ' . esc_html($client_id);
        }

        $user_data = array(
            'user_login' => sanitize_user($client_id), // Utiliser l'identifiant VosFactures comme user_login
            'user_email' => $email,
            'first_name' => normalize_and_uppercase($contact['first_name'] ?? ''),
            'last_name' => normalize_and_uppercase($contact['last_name'] ?? ''),
            'display_name' => normalize_and_uppercase($contact['name']),
            'role' => 'prospect', // Mettre le type de compte à prospect pour les nouveaux comptes
        );

        $user_id = wp_insert_user($user_data);
        if (is_wp_error($user_id)) {
            return 'Erreur lors de la création de l\'utilisateur pour l\'ID VosFactures : ' . esc_html($client_id);
        }

        // Définir les métadonnées par défaut pour un nouvel utilisateur
        update_user_meta($user_id, 'user_status', 'active');
        update_user_meta($user_id, 'user_mailing', 'yes');
        update_user_meta($user_id, 'user_type', 'client');

        // Pour les nouveaux utilisateurs, copier l'adresse de facturation dans l'adresse de livraison
        update_user_meta($user_id, 'shipping_address_1', normalize_and_uppercase($contact['street'] ?? ''));
        update_user_meta($user_id, 'shipping_postcode', $contact['post_code'] ?? '');
        update_user_meta($user_id, 'shipping_city', normalize_and_uppercase($contact['city'] ?? ''));
        update_user_meta($user_id, 'shipping_country', normalize_and_uppercase($contact['country'] ?? ''));
    }

    // fonction 4 : Mise à jour des métadonnées utilisateur
    update_user_meta($user_id, 'vosfactures_id', $client_id);
    update_user_meta($user_id, 'tax_no', normalize_and_uppercase($contact['tax_no'] ?? ''));
    update_user_meta($user_id, 'billing_company', normalize_and_uppercase($contact['company'] ? $contact['name'] : ''));
    update_user_meta($user_id, 'billing_address_1', normalize_and_uppercase($contact['street'] ?? ''));
    update_user_meta($user_id, 'billing_postcode', $contact['post_code'] ?? '');
    update_user_meta($user_id, 'billing_city', normalize_and_uppercase($contact['city'] ?? ''));
    update_user_meta($user_id, 'billing_country', normalize_and_uppercase($contact['country'] ?? ''));
    update_user_meta($user_id, 'billing_phone', $contact['phone'] ?? ''); // Téléphone facturation
    update_user_meta($user_id, 'user_url', $contact['website'] ?? ''); // Site web
    update_user_meta($user_id, 'account_creation_date', $contact['created_at']);
    update_user_meta($user_id, 'account_last_modified_date', $contact['updated_at']);

    // Définir le type d'utilisateur en fonction de la présence du nom de l'entreprise
    if (!empty($contact['company'])) {
        update_user_meta($user_id, 'user_type', 'entreprise');
    } else {
        update_user_meta($user_id, 'user_type', 'particulier');
    }

    // fonction 5 : Mise à jour dans VosFactures
    $contact_data = array(
        'street' => normalize_and_uppercase($contact['street'] ?? ''),
        'city' => normalize_and_uppercase($contact['city'] ?? ''),
        'country' => normalize_and_uppercase($contact['country'] ?? ''),
        'name' => normalize_and_uppercase($contact['name']),
        'first_name' => normalize_and_uppercase($contact['first_name'] ?? ''),
        'last_name' => normalize_and_uppercase($contact['last_name'] ?? ''),
        'company' => normalize_and_uppercase($contact['company'] ? $contact['name'] : ''),
    );

    $api_url_update = $api_url . '/clients/' . $client_id . '.json';
    wp_remote_post($api_url_update, array(
        'method' => 'PUT',
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
        ),
        'body' => json_encode(array('client' => $contact_data)),
    ));

    return 'Importation réussie pour l\'ID VosFactures : ' . esc_html($client_id);
}

// fonction 6 : Gestion des résultats d'importation
function handle_import_result($ignored_contacts) {
    $ignored_message = '';
    if (!empty($ignored_contacts)) {
        $ignored_message = '<br>Contacts ignorés :<ul>';
        foreach ($ignored_contacts as $ignored) {
            $link = sprintf('<a href="https://portail-client.vosfactures.fr/clients/%s" target="_blank">%s</a>', esc_html($ignored['id']), esc_html($ignored['id']));
            $ignored_message .= sprintf('<li>ID: %s, Raison: %s</li>', $link, esc_html($ignored['reason']));
        }
        $ignored_message .= '</ul>';
    }
    return $ignored_message;
}

// fonction 7 : Importer tous les contacts
function import_all_contacts() {
    $api_key = get_option('vosfactures_api_key');
    $api_url = rtrim(get_option('vosfactures_api_url'), '/');

    if (empty($api_key)) {
        wp_send_json_error('La clé API VosFactures n\'est pas configurée. Veuillez la configurer dans les paramètres du plugin.');
    }

    $current_page = 1;
    $per_page = 100;
    $new_import_count = 0;
    $update_count = 0;
    $ignored_contacts = [];

    while (true) {
        $api_url_contacts = $api_url . '/clients.json?api_key=' . urlencode($api_key) . '&page=' . $current_page . '&per_page=' . $per_page;

        $response = wp_remote_get(esc_url_raw($api_url_contacts), array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
            ),
        ));

        if (is_wp_error($response)) {
            wp_send_json_error('Erreur lors de la connexion à l\'API VosFactures : ' . esc_html($response->get_error_message()));
        }

        $body = wp_remote_retrieve_body($response);
        $contacts = json_decode($body, true);

        if (empty($contacts)) {
            break;
        }

        foreach ($contacts as $contact) {
            $client_id = $contact['id'];
            $result = import_contact($client_id);
            if (strpos($result, 'Erreur') !== false) {
                $ignored_contacts[] = ['id' => $client_id, 'reason' => $result];
            } else {
                $new_import_count++;
            }
        }

        $current_page++;
    }

    $ignored_message = handle_import_result($ignored_contacts);
    wp_send_json_success(sprintf('Importation terminée. %d nouveaux contacts importés, %d contacts mis à jour.%s', $new_import_count, $update_count, $ignored_message));
}

// fonction 8 : Importer un contact spécifique depuis le shortcode
function import_specific_contact() {
    $client_id = isset($_POST['client_id']) ? sanitize_text_field($_POST['client_id']) : '';
    if ($client_id) {
        $ignored_contacts = [];
        $result = import_contact($client_id);
        if (strpos($result, 'Erreur') !== false) {
            $ignored_contacts[] = ['id' => $client_id, 'reason' => $result];
        }
        $ignored_message = handle_import_result($ignored_contacts);
        wp_send_json_success('Importation terminée.' . $ignored_message);
    } else {
        wp_send_json_error('Aucun ID VosFactures fourni.');
    }
}

// fonction 9 : Shortcode pour importer tous les contacts
function tiers_import_all_shortcode() {
    ob_start();
    ?>
    <button class="importbutton" id="import-contacts-button">Importer les contacts depuis VosFactures</button>
    <div id="import-contacts-result"></div>

    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#import-contacts-button').click(function(e) {
                e.preventDefault();

                $.ajax({
                    url: "<?php echo admin_url('admin-ajax.php'); ?>",
                    type: "POST",
                    data: { action: 'import_all_contacts_action' },
                    success: function(response) {
                        if (response.success) {
                            $('#import-contacts-result').html('<p>' + response.data + '</p>');
                        } else {
                            $('#import-contacts-result').html('<p>Erreur: ' + response.data + '</p>');
                        }
                    },
                    error: function() {
                        $('#import-contacts-result').html('<p>Erreur lors de l\'importation des contacts.</p>');
                    }
                });
            });
        });
    </script>
    <?php
    return ob_get_clean();
}

// fonction 10 : Shortcode pour importer un contact spécifique
function tiers_import_specific_shortcode() {
    ob_start();
    ?>
    <div>
        <button class="importbutton-short" id="import-specific-contact-button">Importer un contact spécifique</button>
        <input type="text" id="specific-client-id" placeholder="Entrez l'ID VosFactures" style="width: 170px; margin-left: 10px; padding: 2px 10px; font-size: 14px; height: 30px;">
    </div>
    <div id="import-specific-contact-result"></div>

    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#import-specific-contact-button').click(function(e) {
                e.preventDefault();
                var clientId = $('#specific-client-id').val().trim();

                if (clientId === '') {
                    $('#import-specific-contact-result').html('<p>Veuillez entrer un ID VosFactures.</p>');
                    return;
                }

                $.ajax({
                    url: "<?php echo admin_url('admin-ajax.php'); ?>",
                    type: "POST",
                    data: { action: 'import_specific_contact_action', client_id: clientId },
                    success: function(response) {
                        if (response.success) {
                            $('#import-specific-contact-result').html('<p>' + response.data + '</p>');
                        } else {
                            $('#import-specific-contact-result').html('<p>Erreur: ' + response.data + '</p>');
                        }
                    },
                    error: function() {
                        $('#import-specific-contact-result').html('<p>Erreur lors de l\'importation du contact spécifique.</p>');
                    }
                });
            });
        });
    </script>
    <?php
    return ob_get_clean();
}

// fonction 11 : Actions et shortcodes WordPress
add_action('wp_ajax_import_all_contacts_action', 'import_all_contacts');
add_action('wp_ajax_import_specific_contact_action', 'import_specific_contact');
add_shortcode('tiers_import_all', 'tiers_import_all_shortcode');
add_shortcode('tiers_import_specific', 'tiers_import_specific_shortcode');
