<?php
/**
 * [societe_technique] affiche les informations thecniques d'une entreprise 
 * @param mixed $atts
 * @return string
 */   

 function societe_technique($atts) {

    //wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../../global.css');

    ob_start();
    $editIcon=plugin_dir_url(__FILE__) . '../../assets/icons/edition.svg';
    // session_start();
    if (!is_user_logged_in()) {
        return '<p>Vous devez être connecté pour accéder à cette page.</p>';
    }

    $hashedId = get_hashed_id_from_url();
    $user_id=null;
    if ($hashedId) {
        $user_id = get_user_id_from_hash($hashedId);
    }

    if ($user_id === null || !get_userdata($user_id)) {
        return '<p>ID utilisateur invalide ou expiré.</p>';
    }

    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $connected_user = wp_get_current_user();
    $connected_user_role = $connected_user->roles;    
    $user_role = get_userdata($user_id)->roles[0];
    $connected_user_id=$user_id;
 
    $is_admin = in_array('administrator', $connected_user_role);

    $is_responsable_crm = in_array('responsable_crm', $connected_user_role);
    $is_utilisateur_crm = in_array('utilisateur_crm', $connected_user_role);

$user_crm_can_edit = (
    $is_utilisateur_crm &&
    (
        (is_array($associates_users) && in_array($connected_user_id, $associates_users)) || 
        ($connected_user_id === $user_id && $user_role !== 'administrator' && $user_role !== 'responsable_crm')
    )
);
$can_view_user = false;

if ($is_admin) {
    $can_view_user = true; 
} elseif ($is_responsable_crm) {
    $can_view_user = ($user_role !== 'administrator'); 
} elseif ($connected_user_id === $user_id) {
    $can_view_user = true; 
} elseif ($user_crm_can_edit) {
    $can_view_user = true; 
}

if ($can_view_user) {
  
    
   
        $id_facture = $_POST['vosfactures_id']??get_user_meta($user_id, 'vosfactures_id', true);
        $date_creation = get_user_meta($user_id, 'account_creation_date', true);
        $date_creation = $date_creation ? date("d-m-Y", strtotime($date_creation)) : '';
        
    
        $date_update = get_user_meta($user_id, 'account_last_modified_date', true);
        $date_update = $date_update ? date("d-m-Y H:i:s", strtotime($date_update)) : '';
    
        //get_user_meta($user_id, 'last_login', true);
        $publipostage=get_user_meta($user_id, 'user_mailing', true);
        $status=$_POST['user_status']??get_user_meta($user_id, 'user_status', true);
            //$email = get_user_meta($user_id, 'billing_email', true);
        $user_info = get_userdata($user_id);
        $email = $user_info->user_email;
       
    
    
    
    $associer_crm = get_user_meta($user_id, 'associer_crm', true);
    
    $fields_visibility = get_option('crm_user_management_fields_visibility', array()); 
    $vosfactures_sync_enabled=get_option('vosfactures_sync_enabled', 'yes');
    $smtp_emission=get_user_meta($user_id, 'smtp_emission', true)?get_user_meta($user_id, 'smtp_emission', true):'';
    $smtp_port=get_user_meta($user_id, 'port_emission', true)?get_user_meta($user_id, 'port_emission', true):''; 
    $smtp_login=get_user_meta($user_id, 'login_email_emission', true)?get_user_meta($user_id, 'login_email_emission', true):''; 
    $smtp_password=get_user_meta($user_id, 'mdp_emission', true)?get_user_meta($user_id, 'mdp_emission', true):'';
   
        ?>
    
        
    <div class="technical_info">
            <div id="sy-crm-core-technical-info-notif"></div>
            <div class="info-view"id="technical_info_view">
                <p><strong>Mise à jour  : </strong> <?php echo esc_html($date_update ); ?></p> 
                <p><strong>Création  : </strong> <?php echo esc_html($date_creation); ?></p>           
                <?php if (isset($fields_visibility['user_mailing']) && $fields_visibility['user_mailing'] == '1') :?>
                
                <p><strong>Publipostage  :</strong> <?php echo esc_html($publipostage === "yes" ? "Oui" : "Non"); ?></p>            
                 <?php endif;?>
               <?php if (isset($fields_visibility['user_status']) && $fields_visibility['user_status'] == '1') :?>
                    <p><strong>Etat : </strong> <?php echo esc_html($status === "active" ? "Actif" : "Inactif"); ?></p>            
                
                <?php endif;?>
                <?php if ($vosfactures_sync_enabled == 'yes'&&!in_array($user_role ,['utilisateur_crm','responsable_crm','administrator'])&&!empty($id_facture)) :?>
                    <p><strong>Id VF : </strong> <?php echo esc_html($id_facture); ?></p>
                <?php endif;?>    <!--class="title-vosfactures"-->
                <?php if (isset($fields_visibility['associer_crm']) && $fields_visibility['associer_crm'] == '1'&&!in_array($user_role ,['utilisateur_crm','responsable_crm','administrator'])) :?>
                   
                <p>  <strong>Associé à : </strong></p>  
                <ul> 
                    <?php if (!empty($associer_crm)) {
                   
                        foreach ($associer_crm as $user) {
                            $user_info = get_userdata($user);
                            $email = $user_info->user_email;
                            
                            echo '<li>' . esc_html($email) . '</li>';
                        }
                    
            }
            ?>
                            <li>Gestionnaires CRM</li>
                    
                </ul>
            
                <?php endif;?>
                <?php if (($user_role ==='utilisateur_crm'||$user_role ==='responsable_crm')&&(in_array('administrator', $connected_user_role) ||in_array('utilisateur_crm', $connected_user_role) || in_array('responsable_crm', $connected_user_role))): ?>
                        <p style="display:none"><strong>Emission SMTP :</strong> <?php echo esc_html($smtp_emission   ); ?></p>
                        <p style="display:none"><strong>Login SMTP :</strong> <a href="mailto:<?php echo esc_attr($smtp_login); ?>"><?php echo esc_html($smtp_login); ?></a></p>
                        <p style="display:none"><strong>Port SMTP :</strong><?php echo esc_html($smtp_port); ?></p>
                        <p style="display:none"><strong>Mot de passe SMTP :</strong><?php //echo esc_html($smtp_password); ?>*********</p>
                    
                    <?php endif; ?>
                    <?php if (($user_role ==='utilisateur_crm'||$user_role ==='responsable_crm')&&(in_array('administrator', $connected_user_role) || in_array('responsable_crm', $connected_user_role))&&$connected_user->ID != $user_id): ?>
                        <button id="sy-crm-core-delete-user" class="sy-crm-core-delete-user-btn"data-user-id="<?= $user_id ?>" data-user-email="<?= esc_attr($email) ?>">Supprimer l'utilisateur</button>
                        <?php endif; ?>

            </div>
    

    </div>
    <script>jQuery(document).ready(function($) {
$(document).on('click', '#sy-crm-core-delete-user', function(e) {
    e.preventDefault();

    const userId = $(this).data('user-id');
    const userEmail = $(this).data('user-email');

    if (confirm("⚠️ Attention, vous êtes sur le point de désactiver le compte de " + userEmail +
        ".\nCette personne ne pourra plus interagir avec le présent logiciel. Son compte sera archivé.\n\nContinuer ?")) {

        $.post(ajax_object.ajax_url, {
            action: 'sy_crm_disable_user',
            user_id: userId
        }, function(response) {
            let message = '';
            let cssClass = '';

            if (response.success) {
                message = response.data.message;
                cssClass = 'text-success';
            } else {
                message = response.data.message || "Une erreur est survenue.";
                cssClass = 'text-error';
            }

            $('#sy-crm-core-technical-info-notif').html('<div class="' + cssClass + '">' + message + '</div>');

            if (response.success) {
                setTimeout(function() {
                    window.location.href = '/';
                }, 2000); 
            }
        });
    }
});

  })  </script>
        
        <?php
    
    
    
    return ob_get_clean();
} 
else {
    return '';
}
    
    }
add_shortcode('societe_technique', 'societe_technique');
add_action('wp_ajax_sy_crm_disable_user', 'sy_crm_disable_user_callback');

function sy_crm_disable_user_callback() {
    

    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;

 

    $user = get_user_by('ID', $user_id);
    if (!$user) {
        crm_core_update_logs_option(
            'Shortcode information technique d\'utilisateur',
            'Utilisateur introuvable ',
            get_current_user_id(),
            ['user_id'=>$user_id]
        );
        wp_send_json_error(['message' => "Utilisateur introuvable."], 404);
    }

    // Vérifie si c’est bien un compte CRM ou CRM gestionnaire
    $roles = $user->roles;
   /* if (!in_array('utilisateur_crm', $roles) && !in_array('responsable_crm', $roles)) {
        wp_send_json_error(['message' => "Ce compte ne peut pas être désactivé."], 403);
    }*/

    // On remplace tous ses rôles par 'subscriber'
    $user->set_role('subscriber');

    wp_send_json_success(['message' => "Le compte a été archivé avec succès."]);
}
