jQuery(document).ready(function($) {
    //


    $('#update-societe-baseinfo-form').on('input', 'input, select', function() {
        $(this).next('.text-error').remove();

        $('#sy-crm-core-edit-info-sidebar-notif').html('');
    });
    $('#user_type').change(function() {
        if ($(this).val() == 'entreprise') {
            $('#billing_company').attr('readOnly', false).attr('disabled', false);
            $('#tax_no').attr('readOnly', false).attr('disabled', false);
            $('#last_name').siblings('label').text('Nom :');
            $('#first_name').siblings('label').text('Prénom :');

        } else {
            $('#billing_company').attr('readOnly', true).attr('disabled', true);
            $('#tax_no').attr('readOnly', true).attr('disabled', true);
            // $('#tax_no');
            // $('#billing_company');
            $('#last_name').siblings('label').text('Nom : *');
            $('#first_name').siblings('label').text('Prénom : *');
        }
    });
    $(document).on('click', '.user-tag', function() {
        let userId = $(this).data('id');
        let userName = $(this).text();
        if ($('.users_list').data('edit') == 1) {
            if ($(this).hasClass('selected')) {
                $(this).removeClass('selected');

                $(`#selected-user-tag-${userId}`).remove();
            } else {
                $(this).addClass('selected');

                $('.users_select_list').append(`
                <span class="selected-user-tag" id="selected-user-tag-${userId}" data-id="${userId}">
                    ${userName}
                    <span class="remove-tag" style="margin-left: 5px; cursor: pointer;">&times;</span>
                </span>
            `);
            }
        }

    });

    $(document).on('click', '.remove-tag', function() {
        let userId = $(this).closest('.selected-user-tag').data('id');
        if ($('.users_list').data('edit') == 1) {
            $(this).closest('.selected-user-tag').remove();
            $(`.user-tag[data-id="${userId}"]`).removeClass('selected');
        }

    });


    $(document).on("click",'.sy-crm-core-edit-info-sidebar-discard', function(e) {
                $("#edit-info-sidebar").removeClass("open").hide();
                $('#sy-crm-core-edit-info-sidebar-notif').html('');
               
                          /*  $('.user-tag').removeClass('selected');
            
                            $('.users_select_list,.crm_user_tags_selected_list ').html('');
                            $('.user_tag').show();*/

                         
          
    });
    $('#societe_baseinfo_edit_btn').click(function(e) {
        e.stopPropagation();
        $('#edit-info-sidebar').show().addClass('open');
        $('#sy-crm-core-edit-info-sidebar-notif').html('');
    });
    $('#first_name, #last_name').on('input', function() {
        $('#billing_company').next('.text-error').remove();
    });
    $('#billing_company').on('input', function() {
        $('#first_name, #last_name').next('.text-error').remove();
    });
    $('#update-societe-baseinfo-form').on('submit', function(e) {
        e.preventDefault();
        let isValid = true;
        let missingFields = [];

        $('.text-error').remove();
        $('#sy-crm-core-edit-info-sidebar-notif').empty();
        $('#update-societe-baseinfo-form input:visible:not(:disabled), #update-societe-baseinfo-form select:visible:not(:disabled)').each(function() {

            let $input = $(this);
            let inputId = $input.attr('id');
            let inputName = $input.attr('name') || inputId;

            const excludedIds = ['last_name', 'user_civilite', 'first_name', 'tax_no', 'billing_company', 'billing_phone', 'shipping_postcode', 'shipping_company', 'shipping_address_1', 'shipping_city', 'shipping_last_name', 'shipping_first_name', 'billing_postcode', 'shipping_phone', 'url'];
            let labelText = $('label[for="' + inputId + '"]').text().replace(/\*/g, '').replace(/:.*$/, '').trim();

            if (!excludedIds.includes($input.attr('id')) && $input.length && $input.val().trim() === '') {
                isValid = false;

                // Ajouter un message d'erreur si le champ est vide
                $input.after('<span class="text-error">Ce champ est obligatoire.</span>');
                if (labelText) {
                    missingFields.push(labelText);
                } else {
                    missingFields.push(inputName);
                }
            }
        });
        userType = $('#user_type').val();
        const lastName = $('#last_name').length ? $('#last_name').val().trim() : '';
        const firstName = $('#first_name').length ? $('#first_name').val().trim() : '';
        const company = $('#billing_company').length ? $('#billing_company').val().trim() : '';
        if (userType === 'entreprise') {
            if (!(lastName && firstName) && !company) {
                isValid = false;
                $('#last_name, #first_name, #billing_company').after('<span class="text-error">Nom et prénom, ou entreprise requis.</span>');
                missingFields.push('Nom et prénom ou entreprise');
            }
        } else if (userType === 'particulier') {
            if (!lastName) {
                isValid = false;
                missingFields.push('Nom');
                $('#last_name').after('<span class="text-error">Ce champ est obligatoire.</span>');
            }
            if (!firstName) {
                $('#first_name').after('<span class="text-error">Ce champ est obligatoire.</span>');
                missingFields.push('Prénom');
            }
        }
        if (!isValid && missingFields.length > 0) {
            const uniqueFields = [...new Set(missingFields)];
            $('#sy-crm-core-edit-info-sidebar-notif').html(
                '<div class="text-error">Les champs suivants sont obligatoires :<strong>' +
                uniqueFields.join(', ') +
                '</strong></div>'
            );
        }
        if (isValid) {
            var formData = $(this).serializeArray();
            var formValues = {};
            $('.sy-crm-core-edit-info-sidebar-submit').attr('disabled', true);
            formData.forEach(function(item) {
                formValues[item.name] = item.value;
            });
            let selectedTags = [];
            $('.users_select_list .selected-user-tag').each(function() {
                selectedTags.push($(this).data('id'));

                //formData.push('associer_crm[]', $(this).data('id'));
            });
            let userTag = [];
            $('.crm_user_tags_selected').each(function() {
                userTag.push($(this).data('id'));

            });
            // Ajouter les IDs des tags dans les données envoyées
            formData.push({ name: 'user_tag', value: userTag });
            formData.push({ name: 'associer_crm', value: selectedTags });

            $.post(ajax_object.ajax_url, {
                    action: 'update_user_info',

                    security: $('#societe_baseinfo_security').val(),
                    formData: formData,
                },
                function(response) {
                    if (response.success) {

                        $("#edit-info-sidebar").animate({ scrollTop: 0 }, 500, function() {

                            $('#societe_baseinfo_update_msg')
                                .text(response.data.message)
                                .addClass('text-success')
                                .removeClass('text-error')
                                .fadeIn()
                                .delay(1000)
                                .fadeOut(function() {
                                    $("#edit-info-sidebar").removeClass("open").hide();
                                    location.reload();

                                });

                        });
                    } else {
                        $("#edit-info-sidebar").animate({ scrollTop: 0 }, 500, function() {

                            $('#societe_baseinfo_update_msg')
                                .text(response.data.message || 'Une erreur est survenue.')
                                .removeClass('text-success')
                                .addClass('text-error')
                                .fadeIn()
                                .delay(1000)
                                .fadeOut(function() {

                                    $("#edit-info-sidebar").removeClass("open").hide();
                                });
                        });
                    }
                }).fail(function() {
                $("#edit-info-sidebar").animate({ scrollTop: 0 }, 500, function() {
                    $('#societe_baseinfo_update_msg')
                        .text('La requête a échoué. Veuillez réessayer.')
                        .removeClass('text-success')
                        .addClass('text-error')
                        .fadeIn(1000)

                    .fadeOut(500, function() {

                        $("#edit-info-sidebar").removeClass("open").hide();
                    });
                });
            });

        }

    });
    $(".sy-crm-core-info-container").hover(
        function() {
            $(this).find(".sy-crm-core-tooltip-custom").fadeIn(200);
        },
        function() {
            $(this).find(".sy-crm-core-tooltip-custom").fadeOut(200);
        }
    );

    $(document).on('click', '.crm_user_tags_tag', function() {
        var tagName = $(this).text();
        var tagClass = tagName.toLowerCase().replace(/[^a-z0-9\-_]/g, '-');
        var tagId = $(this).data('id');
        var style = $(this).attr('style')
        $(this).hide();
        var selectedContainer = $(this).parent().next('.crm_user_tags_selected_list');
        if (selectedContainer.find('.crm_user_tags_selected[data-id="' + tagId + '"]').length === 0) {
            var tagElement = $('<span class="crm_user_tags_selected user_tag " data-id="' + tagId + '"style="' + style + '">' + tagName + ' <span class="crm_users_tags_remove" data-id="' + tagId + '">x</span></span>');

            selectedContainer.append(tagElement);
        }
    });
    $(document).on('click', '.crm_users_tags_remove', function(e) {
        // e.preventDefault()
        selectedContainer = $(this).parent();
        var tagId = $(this).data('id');
        $('.crm_user_tags_list').find('.crm_user_tags_tag[data-id="' + tagId + '"]').show();

        $('.crm_user_tags_selected_list').find('.crm_user_tags_selected[data-id="' + tagId + '"]').remove();
        //   $(this).closest('.crm_user_tags_selected').remove();

    });
    $(document).on('click', '#sy-crm-core-delete-user-sidebar-btn', function(e) {
        e.preventDefault();

        const userId = $(this).data('user-id');
        const userEmail = $(this).data('user-email');

        if (confirm("⚠️ Attention, vous êtes sur le point de désactiver le compte de " + userEmail +
                ".\nCette personne ne pourra plus interagir avec le présent logiciel. Son compte sera archivé.\n\nContinuer ?")) {

            $.post(ajax_object.ajax_url, {
                action: 'sy_crm_disable_user',
                user_id: userId
            }, function(response) {
                let message = '';
                let cssClass = '';

                if (response.success) {
                    message = response.data.message;
                    cssClass = 'text-success';
                } else {
                    message = response.data.message || "Une erreur est survenue.";
                    cssClass = 'text-error';
                }

                $('#sy-crm-core-edit-info-sidebar-notif').html('<div class="' + cssClass + '">' + message + '</div>');

                if (response.success) {
                    setTimeout(function() {
                        window.location.href = '/';
                    }, 2000);
                }
            });
        }
    });


});