<?php
/*
 * Ce fichier PHP crée un shortcode [correction-useraccounts]
 * qui vérifie tous les comptes utilisateurs pour détecter les emails bidons
 * et met à jour leur statut de publipostage.
 */

// fonction 1 : Vérifier et corriger les comptes utilisateurs
function correction_useraccounts_ajax() {
    // Vérifier le nonce pour des raisons de sécurité
    check_ajax_referer('correction_useraccounts_nonce', 'nonce');

    // Obtenir tous les utilisateurs
    $users = get_users();

    // Parcourir chaque utilisateur
    foreach ($users as $user) {
        $email = $user->user_email;

        // Vérifier si l'email contient un "+xxx" ou commence par "aucun-email-fournis"
        if (preg_match('/\+\d+@/', $email) || strpos($email, 'aucun-email-fournis') === 0) {
            // Mettre à jour user_mailing à "non"
            update_user_meta($user->ID, 'user_mailing', 'no');
        }
    }

    wp_send_json_success('Correction des comptes utilisateurs terminée.');
}
add_action('wp_ajax_correction_useraccounts', 'correction_useraccounts_ajax');

// fonction 2 : Créer le shortcode [correction-useraccounts]
function correction_useraccounts_shortcode() {
    ob_start();
    ?>
    <button id="correction-useraccounts-button">Corriger les comptes utilisateurs</button>
    <div id="correction-useraccounts-result"></div>

    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#correction-useraccounts-button').click(function() {
                $.ajax({
                    url: "<?php echo admin_url('admin-ajax.php'); ?>",
                    type: "POST",
                    data: {
                        action: 'correction_useraccounts',
                        nonce: "<?php echo wp_create_nonce('correction_useraccounts_nonce'); ?>"
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#correction-useraccounts-result').text(response.data);
                        } else {
                            $('#correction-useraccounts-result').text('Erreur lors de la correction.');
                        }
                    },
                    error: function() {
                        $('#correction-useraccounts-result').text('Erreur de communication avec le serveur.');
                    }
                });
            });
        });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('correction-useraccounts', 'correction_useraccounts_shortcode');
