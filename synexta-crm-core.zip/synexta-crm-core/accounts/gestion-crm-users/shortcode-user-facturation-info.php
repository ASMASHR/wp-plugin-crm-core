<?php

/**
 * [societe_factinfo] affiche les informations de livraison d'une entreprise 
 * @param mixed $atts
 * @return string
 */

 function societe_factinfo($atts) {

    //wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../../global.css');
    ob_start();
    $editIcon=plugin_dir_url(__FILE__) . '../../assets/icons/edition.svg';
   // session_start();
    if (!is_user_logged_in()) {
        return '<p>Vous devez être connecté pour accéder à cette page.</p>';
    }

    $hashedId = get_hashed_id_from_url();
    $user_id=null;
    if ($hashedId) {
        $user_id = get_user_id_from_hash($hashedId);
    }

    if ($user_id === null || !get_userdata($user_id)) {
        return '<p>ID utilisateur invalide ou expiré.</p>';
    }

    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $connected_user = wp_get_current_user();
    $connected_user_role = $connected_user->roles;    
    $user_role = get_userdata($user_id)->roles[0];
    $access_by_role = [
        'tiers',
        'utilisateur_crm',
        'responsable_crm',
        'administrator',
        'non_qualifie',
        'hors_cible',
        'prospect',
        'customer',
        'fournisseur',
    ];
    $connected_user_id=$user_id;
 
    $is_admin = in_array('administrator', $connected_user_role);

    $is_responsable_crm = in_array('responsable_crm', $connected_user_role);
    $is_utilisateur_crm = in_array('utilisateur_crm', $connected_user_role);

$user_crm_can_edit = (
    $is_utilisateur_crm &&
    (
        (is_array($associates_users) && in_array($connected_user_id, $associates_users)) || 
        ($connected_user_id === $user_id && $user_role !== 'administrator' && $user_role !== 'responsable_crm')
    )
);
$can_view_user = false;

if ($is_admin) {
    $can_view_user = true; 
} elseif ($is_responsable_crm) {
    $can_view_user = ($user_role !== 'administrator'); 
} elseif ($connected_user_id === $user_id) {
    $can_view_user = true; 
} elseif ($user_crm_can_edit) {
    $can_view_user = true; 
}

if ($can_view_user) {
  
     $countries = new WC_Countries();
   
   
    $countries_list = $countries->get_countries();
   
    $nom_societe =  get_user_meta($user_id, 'billing_company', true);

    $adresse =  get_user_meta($user_id, 'billing_address_1', true);

    $ville = get_user_meta($user_id, 'billing_city', true);

    $code_postal = get_user_meta($user_id, 'billing_postcode', true);

    $pays =get_user_meta($user_id, 'billing_country', true);

    $billing_country = isset($countries_list[$pays]) 
        ? strtoupper($countries_list[$pays]) 
        : $pays;

    $telephone = get_user_meta($user_id, 'billing_phone', true);

    $billing_email = get_user_meta($user_id, 'billing_email', true);

    $first_name = get_user_meta($user_id, 'billing_first_name', true);
    $civilite = get_user_meta($user_id, 'user_civilite', true);
    $last_name = get_user_meta($user_id, 'billing_last_name', true);
    $parts = [];
    if (!empty(trim($civilite))) {
        $parts[] = trim($civilite);
    }
    if (!empty(trim($last_name))) {
        $parts[] = trim($last_name);
    }
    if (!empty(trim($first_name))) {
        $parts[] = trim($first_name);
    }
    
    $prenom_nom = implode(' ', $parts);
       
        // Charger les pays WooCommerce  
       
    // Construction du champ CP/ville/Pays
  /*  $cp_ville = '';
    if ($code_postal) {
        $cp_ville .= esc_html($code_postal);
    }
    if ($ville) {
        $cp_ville .= ($cp_ville ? ', ' : '') . esc_html($ville);
    }
    if ($billing_country) {
        $cp_ville .= ($cp_ville ? ' ' : '') . '(' . esc_html($billing_country) . ')';
    }
    
    $adresse_complete = trim("$adresse, $code_postal $ville, $billing_country");
    $adresse_link = 'https://www.google.com/maps/search/?api=1&query=' . urlencode($adresse_complete);

*/

//
$cp_ville_parts = [];
if (!empty(trim($code_postal))) {
    $cp_ville_parts[] = esc_html($code_postal);
}
if (!empty(trim($ville))) {
    $cp_ville_parts[] = esc_html($ville);
}
$cp_ville = implode(', ', $cp_ville_parts);

if (!empty(trim($billing_country))) {
    $cp_ville .= $cp_ville ? ' ' : ''; // Ajouter espace si déjà CP/Ville
    $cp_ville .= '(' . esc_html($billing_country) . ')';
}

// Construire adresse complète (même logique = que les non vides)
$adresse_parts = [];
if (!empty(trim($adresse))) {
    $adresse_parts[] = trim($adresse);
}
if (!empty(trim($code_postal))) {
    $adresse_parts[] = trim($code_postal);
}
if (!empty(trim($ville))) {
    $adresse_parts[] = trim($ville);
}
if (!empty(trim($billing_country))) {
    $adresse_parts[] = trim($billing_country);
}

$adresse_complete = implode(', ', $adresse_parts);
$adresse_link = 'https://www.google.com/maps/search/?api=1&query=' . urlencode($adresse_complete);

//
    $telephone =get_user_meta($user_id, 'billing_phone', true);    
    $entreprise_affichee = $nom_societe ?: '<i>' . esc_html($prenom_nom) . '</i>';
    
    $fields_visibility = get_option('crm_user_management_fields_visibility', array()); 


    ?>
    
 
    <div class="facturation_info">
        <p id="facturation_info_update_msg"></p>
        
       <div class="info-view"id="facturation_info_view">
            <p class="sy-crm-core-title-container  <?php echo 'sy_crm_core_role_' . esc_attr($user_role); ?>"> <?php echo ($entreprise_affichee); ?></p>
            <?php  if (!empty($adresse_complete) && isset($fields_visibility['billing_address_1']) && $fields_visibility['billing_address_1'] == '1'
    && isset($fields_visibility['billing_city']) && $fields_visibility['billing_city'] == '1'
    && isset($fields_visibility['billing_country']) && $fields_visibility['billing_country'] == '1'
    && isset($fields_visibility['billing_postcode']) && $fields_visibility['billing_postcode'] == '1'): ?>
    
    <a id="adress-link-entreprise-data" href="<?php echo esc_url($adresse_link); ?>" target="_blank">
        <?php if (!empty(trim($adresse))): ?>
            <p><?php echo esc_html($adresse); ?></p>
        <?php endif; ?>
        <?php if (!empty(trim($cp_ville))): ?>
            <p><?php echo $cp_ville; ?></p>
        <?php endif; ?>
    </a>


    <?php endif; ?>  
        
            <?php if (isset($fields_visibility['billing_last_name']) && $fields_visibility['billing_last_name'] == '1'&&isset($fields_visibility['billing_first_name']) && $fields_visibility['billing_first_name'] == '1'&&$prenom_nom!="") :?>
               
            <p><strong>Contact :</strong> <?php echo esc_html($prenom_nom); ?></p>
            
            <?php endif;?>
            <?php if (isset($fields_visibility['billing_phone']) && $fields_visibility['billing_phone'] == '1' && $telephone!="") :?>
            
            <p><strong>Téléphone :</strong> <a href="tel:<?php echo esc_attr($telephone); ?>"><?php echo esc_html($telephone); ?></a></p>
            
            
            <?php endif;?>
            <?php if (isset($fields_visibility['billing_email']) && $fields_visibility['billing_email'] == '1') :?>
           
            <p><strong>Email :</strong> <a href="mailto:<?php echo esc_attr($billing_email); ?>"><?php echo esc_html($billing_email); ?></a></p>
        
            <?php endif;?>
        </div>

        
    </div>
   
    <?php
    
    
    
        return ob_get_clean();
    } else {
        return '';
    }
  
}
add_shortcode('societe_factinfo', 'societe_factinfo');

