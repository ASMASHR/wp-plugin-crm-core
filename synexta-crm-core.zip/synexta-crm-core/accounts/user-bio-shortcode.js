function toggleEditMode() {
    const bioContent = document.getElementById('bio-content');
    const bioEditor = document.getElementById('bio-editor');
    const saveButton = document.getElementById('save-bio');

    if (bioEditor.style.display === 'none') {
        bioContent.style.display = 'none';
        bioEditor.style.display = 'block';
        saveButton.style.display = 'block';
    } else {
        bioContent.style.display = 'block';
        bioEditor.style.display = 'none';
        saveButton.style.display = 'none';
    }
}

function saveBio(userId) {
    const bioEditor = document.getElementById('bio-editor');
    const newBio = bioEditor.value;

    fetch('/wp-admin/admin-ajax.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            action: 'save_user_bio',
            user_id: userId,
            new_bio: newBio,
        }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('bio-content').innerHTML = newBio.replace(/\n/g, "<br/>");
            toggleEditMode();
        } else {
            alert('Une erreur est survenue lors de l\'enregistrement.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}
