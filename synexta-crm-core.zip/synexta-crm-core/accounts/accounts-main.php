<?php

require_once plugin_dir_path(__FILE__) . 'user-bio-shortcode.php';
require_once plugin_dir_path(__FILE__) . 'user-account-addons.php';
require_once plugin_dir_path(__FILE__) . 'gestion-crm-users/gestion-crm-users-main.php';
require_once plugin_dir_path(__FILE__) . 'gestion-crm-admins/gestion-crm-admins-main.php';