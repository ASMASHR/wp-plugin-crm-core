<?php
// Enregistrement du type de post personnalisé
function register_crm_documents_generes_post_type() {
    register_post_type('crm_docs_gen', [ 
        'labels' => [
            'name'               => 'CRM documents générés',
            'singular_name'      => 'Document CRM',
            'add_new'            => 'Générer un document',
            'add_new_item'       => 'Générer un document',
            'edit_item'          => 'Modifier le document',
            'new_item'           => 'Nouveau document',
            'view_item'          => 'Voir le document',
            'search_items'       => 'Rechercher des documents',
            'not_found'          => 'Aucun document trouvé',
            'not_found_in_trash' => 'Aucun document trouvé dans la Corbeille',
        ],
        'public'        => false,
        'show_ui'       => true,
        'has_archive'   => false,
        'menu_icon'     => 'dashicons-media-text',
        'supports'      => ['title', 'editor'],
        'rewrite'       => true,
        'show_in_menu'  => true,
        'capabilities'  => [
            'create_posts' => 'do_not_allow', 
        ],
        'map_meta_cap' => true, 
    
    ]);
}
add_action('init', 'register_crm_documents_generes_post_type');
function crm_docs_gen_columns($columns) {
    // Supprimer les colonnes non nécessaires
    unset($columns['date']);
    
    // Ajouter des colonnes personnalisées
    $columns['tiers_associe'] = 'Tiers associé';
    $columns['expire_dans']   = 'Expire le';
    $columns['cree_le']       = 'Créé le';
    $columns['taille']        = 'Taille';

    return $columns;
}
add_filter('manage_crm_docs_gen_posts_columns', 'crm_docs_gen_columns');

// Remplir les colonnes personnalisées
function crm_docs_gen_custom_column($column, $post_id) {
    switch ($column) {
        case 'tiers_associe':
            // Récupérer la valeur du champ personnalisé ou autre logique

            $tiers_associe = get_post_meta($post_id, '_generated_doc_user_id', true);
            if ($tiers_associe) {
                $user = get_userdata($tiers_associe);
            
                if ($user) {
                    $first_name = get_user_meta($tiers_associe, 'first_name', true);
                    $last_name = get_user_meta($tiers_associe, 'last_name', true);
                    $nom_societe = get_user_meta($tiers_associe, 'billing_company', true);
            
                    // Combine les informations utilisateur !empty($nom_societe) ? $nom_societe :
                    $prenom_nom = trim($last_name . ' ' . $first_name);
                    $entreprise_affichee = $prenom_nom ?:$user->display_name ;
            
                    // Affiche le résultat
                    echo ($entreprise_affichee);
                } else {
                    echo 'Utilisateur introuvable';
                }
            } else {
                echo '—';
            }
            break;
            
            case 'expire_dans':
                $expiration_date = get_post_meta($post_id, '_generated_doc_expiration_date', true);
                
                if ($expiration_date) {
                     $today = time(); // 
                    $expiration_timestamp = strtotime($expiration_date);
                    
                    $diff_in_seconds = $expiration_timestamp - $today; 
                    $diff_in_days = floor($diff_in_seconds / (60 * 60 * 24)); 
                    
                    if ($diff_in_days > 0) {
                        $dateFormatter = new IntlDateFormatter(
                            'fr_FR', // Locale française
                            IntlDateFormatter::LONG, // Format long
                            IntlDateFormatter::NONE // Pas d'heure, seulement la date
                        );
                        
                        // Formater la date en français
                        $formatted_expiration_date = $dateFormatter->format($expiration_timestamp);
                        
        echo $formatted_expiration_date;
                        //echo " {$diff_in_days} jour" . ($diff_in_days > 1 ? 's' : '');
                    } elseif ($diff_in_days == 0) {
                        echo 'Aujourd\'hui'; 
                    } else {
                        echo 'Expiré'; 
                    }
                } else {
                    echo 'Jamais'; 
                }
                break;
            

        case 'cree_le':
            // Afficher la date de création
            echo get_the_date('', $post_id);
            break;

        case 'taille':
            $file_url = get_post_meta($post_id, '_pdf_url', true);
            if ($file_url) {
                // Convertir l'URL en chemin de fichier local
                $file_path = str_replace(site_url('/'), ABSPATH, $file_url);
        
                if (file_exists($file_path)) {
                    $file_size = filesize($file_path);
                    echo size_format($file_size);
                } else {
                    echo 'Fichier introuvable';
                }
            } else {
                echo '—';
            }
            break;
    }
}
add_action('manage_crm_docs_gen_posts_custom_column', 'crm_docs_gen_custom_column', 10, 2);

// Rendre les colonnes triables si nécessaire

add_filter('manage_edit-crm_docs_gen_sortable_columns', function($columns) {
    $columns['tiers_associe'] = 'tiers_associe';
    $columns['expire_dans'] = 'expire_dans';
    $columns['cree_le'] = 'date';
    $columns['taille'] = 'taille';
    return $columns;
});
add_action('pre_get_posts', function($query) {
    if (!is_admin() || !$query->is_main_query()) {
        return;
    }

    if ('expire_dans' === $query->get('orderby')) {
        // Trier par le champ _generated_doc_expiration_timestamp
        $query->set('meta_key', '_generated_doc_expiration_date_timestamp');
        $query->set('orderby', 'meta_value_num');
    }
});
// Ajouter les metaboxes
function ajouter_metaboxes_crm_documents_generes() {
    add_meta_box(
        'metabox_info_document',
        'Information sur la document',
        'afficher_metabox_info_doc',
        'crm_docs_gen',
        'advanced',
        'high'
    );
}
add_action('add_meta_boxes', 'ajouter_metaboxes_crm_documents_generes');

function afficher_metabox_info_doc($post) {
    //$users = get_users();
    $args = array(
        //'role__in' => array('prospect', 'customer', 'tiers'),
        'meta_query' => array(
            'relation' => 'OR', 
            array(
                'key' => 'user_status',
                'value' => 'ACTIF',
                'compare' => '='
            ),
            array(
                'key' => 'user_status',
                'value' => 'actif',
                'compare' => '='
            ),
            array(
                'key' => 'user_status',
                'value' => 'active',
                'compare' => '=',
            ),
        ),
        'fields' => array('ID', 'user_login', 'billing_first_name', 'billing_last_name', 'billing_address_1', 'billing_postcode', 'billing_city', 'billing_country', 'billing_phone', 'user_email'),
    );
    $users = get_users($args);
    $post_id = $post->ID;

    // Récupérer les métadonnées 
    $userId = get_post_meta($post_id, '_generated_doc_user_id', true);
    $templateId = get_post_meta($post_id, '_used_template_id', true);
    $templateVersion = get_post_meta($post_id, '_used_template_version', true);
    $documentsIds = get_post_meta($post_id, '_documents_associes_list', true);
    //$documentsIds = $documentsIds ? json_decode($documentsIds, true) : [];
            
    $variablesdocument = get_post_meta($post_id, '_generated_doc_vars', true);
    $template_associes= $templateId?get_post_meta($templateId, '_associes_list', true):null;

     $template_associes = $template_associes ? json_decode($template_associes, true) : [];
    $templates = get_posts([
        'post_type' => 'crm_documents',
        'numberposts' => -1,
        'post_status' => 'publish',
    ]);
    ?>
    <div class="metabox_info_document">
        <div class="user_select_container">
            <label for="user_select">Choisir une entreprise :</label>
            <select id="user_select" name="user_select" <?php echo $userId ? 'disabled' : ''; ?>>
                <?php foreach ($users as $user): 
                     $nom_societe =get_user_meta($user->ID, 'billing_company', true);
                     $first_name =get_user_meta($user->ID, 'billing_first_name', true);
                     $last_name = get_user_meta($user->ID, 'billing_last_name', true);
                    
                     $prenom_nom=$last_name .' '.$first_name;
                     $entreprise_affichee = !empty($nom_societe) ? $nom_societe :( $user->display_name?$user->display_name:$prenom_nom);
         
         ?>
                    <option value="<?php echo esc_attr($user->ID); ?>" <?php selected($userId, $user->ID); ?>>
                        <?php echo esc_html($entreprise_affichee); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="template_vars_container">
            <div class="template_select_container">
                <label for="template_select">Choisir un template :</label>
                <select id="template_select" name="template_select" <?php echo $templateId ? 'disabled' : ''; ?>>
                    <?php foreach ($templates as $template): ?>
                        <option value="<?php echo esc_attr($template->ID); ?>" <?php selected($templateId, $template->ID); ?>>
                            <?php echo esc_html($template->post_title); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div id="templates-list-error"></div>
                    </div>
        <div class="template_version_container"style="<?php echo $templateVersion ? 'display: flex;' : 'display: none;'; ?>">
            <label for="template_version">Version template :</label>
            <input type="text" id="template_version" name="template_version" value="<?php echo esc_attr($templateVersion); ?>"disabled >
        </div>          
        <?php 
        if (!empty($documentsIds)) : ?>
            <div id="">
            <p>Liste des documents associés générés :<small> (Documents générés basés sur le template associé).</small></p>
                <?php
                foreach($documentsIds as $id){
                    $post_title = get_the_title($id);
                    $edit_link = get_edit_post_link($id);
                    echo '<a href="' . esc_url($edit_link) . '">' . esc_html($post_title) . '</a><br>';
                }
                ?>
            </div>
        <?php endif; ?>
</div>

    <?php
}
function save_crm_document_genere($post_id, $post, $update) {
    if ($post->post_type !== 'crm_docs_gen') {
        return;
    }

    // Sauvegarde des métadonnées
    $userId = sanitize_text_field($_POST['user_select'] ?? '');
    $templateId = sanitize_text_field($_POST['template_select'] ?? '');
    $templateVersion = sanitize_text_field($_POST['template_version'] ?? '');
    $associeIds = sanitize_text_field($_POST['associe_list_ids'] ?? '');
    $variablesdocument = sanitize_text_field($_POST['generated_doc_vars'] ?? '');

    if ($userId) {
        update_post_meta($post_id, '_generated_doc_user_id', $userId);
    }    
    if ($templateId) {
        update_post_meta($post_id, '_used_template_id', $templateId);
    }
    if ($variablesdocument) {
        update_post_meta($post_id, '_generated_doc_vars', $variablesdocument);
    }
    if ($templateVersion) {
        update_post_meta($post_id, '_used_template_version', $templateVersion);
    }

    $contenu = $post->post_content;
       
}
add_action('save_post', 'save_crm_document_genere', 10, 3);


function load_templates_by_user_role() {
    // Vérifiez si l'ID utilisateur est fourni
    if (!isset($_POST['user_id']) || empty($_POST['user_id'])) {
        wp_send_json_error(['message' => 'ID utilisateur manquant.']);
    }

    $user_id = intval($_POST['user_id']);
    $user = get_userdata($user_id);

    if (!$user) {
        wp_send_json_error(['message' => 'Utilisateur non trouvé.']);
    }
    $templatesDispo = get_posts([
        'post_type' => 'crm_documents',
        'numberposts' => -1,
    ]);
    $templates = [];
    foreach ($templatesDispo as $template) {

        $roles_selectionnes = get_post_meta($template->ID, '_template_roles_acces', true);
        $roles_selectionnes = $roles_selectionnes ? json_decode($roles_selectionnes, true):[];
        if (array_intersect($roles_selectionnes, $user->roles) || in_array("administrator", $user->roles) || in_array("responsable_crm", $user->roles)) {
            $templates[] =['id'=>$template->ID,'title'=>$template->post_title];
        }
    }

    wp_send_json_success(['templates' => $templates]);
}
add_action('wp_ajax_load_templates_by_user_role', 'load_templates_by_user_role');

//
add_action('wp_ajax_load_associated_templates', 'load_associated_templates');

function load_associated_templates() {
    if (!isset($_POST['template_id']) || !isset($_POST['post_id'])) {
        wp_send_json_error(['message' => 'Paramètres manquants.']);
    }

    $templateId = intval($_POST['template_id']);
    $postId = intval($_POST['post_id']);

    $associes_list = get_post_meta($templateId, '_associes_list', true);
    $associeIds = $associes_list ? json_decode($associes_list, true) : [];
    $associatedTemplates = [];
    $templates = get_posts([
        'post_type' => 'crm_documents',
        'post__in' => $associeIds,
        'numberposts' => -1,
    ]);

    foreach ($templates as $template) {
        $associatedTemplates[] = [
            'id' => $template->ID,
            'label' => $template->post_title,
            'checked' => in_array($template->ID, $associeIds)
        ];
    }

    wp_send_json_success(['associated_templates' => $associatedTemplates]);
}
add_action('wp_ajax_load_templates_version', 'load_templates_version');

function load_templates_version() {
    if (!isset($_POST['template_id']) ) {
        wp_send_json_error(['message' => 'Paramètres manquants.']);
    }

    $templateId = intval($_POST['template_id']);

    $version = get_post_meta($templateId, '_template_version', true);
   

    wp_send_json_success(['version' => $version]);
}

function generer_documents_associes() {
    if (!isset($_POST['templates'])) {
        wp_send_json_error('Données manquantes.');
    }

    global $post;
    $post_id = $_POST['post_id'];
    if (!$post_id) {
        wp_send_json_error('Paramètres id inva.');
    }
    //$templates = array_map('intval', $_POST['templates']);
     $templates =  $_POST['templates'];
   $variablesValues = get_post_meta($post_id, '_generated_doc_vars', true);
    //$variablesValues = json_decode($variablesValues, true);
    $variablesValues = json_decode($variablesValues, true);

    if (empty($templates) ) {
        wp_send_json_error('Paramètres invalides.');
    }

    $nouveaux_documents = [];
    
    foreach ($templates as $associe) {
        $associe_id= $associe['id'];
        $nom_doc=$associe['nom_doc'];
        $template_post = get_post($associe_id);
        if (!$template_post) {
            continue;
        }

        $templateRacine = get_post_meta($associe_id, '_racine', true);
        $formattedDate = date('y') . date('m');;

    
        $compteur = count(get_posts([
            'post_type'   => 'crm_docs_gen',
            'meta_key'    => '_used_template_id',
            'meta_value'  => $associe_id,
            'numberposts' => -1,
        ]));

        $template_version = get_post_meta($associe_id, '_template_version', true);
        
        //$compteurFormate = str_pad($compteur, 4, '0', STR_PAD_LEFT);
        $compteurFormate = $compteur; 
        $generatedPostTitle = $templateRacine .'-' . $formattedDate. '-'.$compteurFormate;
        $used_values = [];
        // Remplacer les variables par les valeurs
        $associeContenu = $template_post->post_content;
        
            preg_match_all('/\{([\w]+)\}/', $associeContenu, $matches);
            $used_variables = $matches[1];

            // Associer les valeurs correspondantes
        
            foreach ($used_variables as $variable) {
                if (isset($variables[$variable])) {
                    if($variable=="reference_template")
                    {
                        $used_values[$variable]=$templateRacine.'-' . $formattedDate.'-'.$compteurFormate;
                    }
                    elseif ($variable === 'template_name') {
                        $used_values[$variable]= get_the_title($associe_id);
                      }
                      elseif ($variable === 'creation_date') {
                        $day = str_pad(date('d'), 2, '0', STR_PAD_LEFT); // Jour avec deux chiffres
                        $month = str_pad(date('m'), 2, '0', STR_PAD_LEFT); // Mois avec deux chiffres
                        $year = date('Y'); 
                        $used_values[$variable] = "{$day} {$month} {$year}"; 
                    }
                    else{

                    $used_values[$variable] = $variablesValues[$variable];
                    }
                }
            }
            foreach ($variablesValues as $variable => $value) {
                if($variable=="reference_template")
                {
                    $value=$templateRacine.'-' . $formattedDate.'-'.$compteurFormate;
                }
                elseif ($variable === 'template_name') {
                    $value= get_the_title($associe_id);
                  }
                  elseif ($variable === 'creation_date') {
                    $day = str_pad(date('d'), 2, '0', STR_PAD_LEFT); // Jour avec deux chiffres
                    $month = str_pad(date('m'), 2, '0', STR_PAD_LEFT); // Mois avec deux chiffres
                    $year = date('Y'); 
                    $value= "{$day} {$month} {$year}"; 
                }
                $regex = "/\{" . preg_quote($variable, '/') . "\}/";
                $associeContenu = preg_replace($regex, ' <b>' . esc_html($value) . '</b> ', $associeContenu); // Correction de $content à $contenu
            }
       

        // Ajouter un nouveau post avec ses métadonnées
        $nouveau_document_id = wp_insert_post([
            'post_type' => 'crm_docs_gen',
            //'post_title' => $generatedPostTitle,
            'post_title' => $nom_doc,
            'post_content' => $associeContenu,
            'post_status' => 'publish',
            'post_author' => get_current_user_id(),
        ]);

        if ($nouveau_document_id) {

       
        $documents_associe[]=['post_id' => $nouveau_document_id,
        'post_title'=>$nom_doc,
        //'file_url'=>$pdf_url1
        ];
            add_post_meta($nouveau_document_id, '_used_template_version', $template_version);
            add_post_meta($nouveau_document_id, '_generated_doc_user_id', $_POST['user_id']);
            add_post_meta($nouveau_document_id, '_used_template_id', $associe_id);
            add_post_meta($nouveau_document_id, '_generated_doc_vars', wp_json_encode($used_values));
            $nouveaux_documents[] = $nouveau_document_id;
        }
    }

    // Vérification avant de mettre à jour le post_meta
    if (!empty($nouveaux_documents)) {
        
        update_post_meta($post_id, '_documents_associes_list', $nouveaux_documents);
        wp_send_json_success();
    } 
    else {
        wp_send_json_error('Aucun document n\'a été généré.');
    }

}

//add_action('wp_ajax_generer_documents_associes', 'generer_documents_associes');
function generer_documents_associes1() {
    if (!isset($_POST['templates'])) {
        wp_send_json_error('Données manquantes.');
    }

    global $post;
    $post_id = $_POST['post_id'];
    if (!$post_id) {
        wp_send_json_error('Paramètres id inva.');
    }
    $templates = array_map('intval', $_POST['templates']);
    $variablesValues = get_post_meta($post_id, '_generated_doc_vars', true);
    //$variablesValues = json_decode($variablesValues, true);
    $variablesValues = json_decode($variablesValues, true);

    if (empty($templates) ) {
        wp_send_json_error('Paramètres invalides.');
    }

    $nouveaux_documents = [];
    foreach ($templates as $template_id) {
        $template_post = get_post($template_id);
        if (!$template_post) {
            continue;
        }

        $templateRacine = get_post_meta($template_id, '_racine', true);
        $formattedDate = date('y') . date('m');

    $compteur = 0;
    $generatedDocs = get_posts([
        'post_type'   => 'crm_docs_gen',
        'numberposts' => -1,
    ]);

    $template_version = get_post_meta($template_id, '_template_version', true);
    foreach ($generatedDocs as $doc) {
        $usedTemplateId = get_post_meta($doc->ID, '_used_template_id', true);
        if (intval($usedTemplateId) === $template_id) {
            $compteur++;
        }
    }
    $compteurFormate = str_pad($compteur, 4, '0', STR_PAD_LEFT);
        $generatedPostTitle = $templateRacine .'-' . $formattedDate. '-'.$compteurFormate;
        $used_values = [];
        // Remplacer les variables par les valeurs
        $contenu = $template_post->post_content;
        if (is_array($variablesValues)) {
            preg_match_all('/\{([\w]+)\}/', $contenu, $matches);
            $used_variables = $matches[1];

            // Associer les valeurs correspondantes
          
            foreach ($used_variables as $variable) {
                if (isset($variablesValues[$variable])) {
                    if($variable=="reference_template")
                    {
                        $used_values[$variable]=$templateRacine.'-'.$compteurFormate;
                    }
                    else{

                    $used_values[$variable] = $variablesValues[$variable];
                    }
                }
            }
            foreach ($variablesValues as $variable => $value) {
                if($variable=="reference_template")
                {
                    $value=$templateRacine.'-'.$compteurFormate;
                }
                $regex = "/\{" . preg_quote($variable, '/') . "\}/";
                $contenu = preg_replace($regex, '<b>' . esc_html($value) . '</b>', $contenu); // Correction de $content à $contenu
            }
            //wp_send_json_error($contenu);
            
    
        } else {
            wp_send_json_error('Les variables ne sont pas sous un format valide.');
        }

        // Ajouter un nouveau post avec ses métadonnées
        $nouveau_document_id = wp_insert_post([
            'post_type' => 'crm_docs_gen',
            'post_title' => $generatedPostTitle,
            'post_content' => $contenu,
            'post_status' => 'publish',
            'post_author' => get_current_user_id(),
        ]);

        if ($nouveau_document_id) {
            add_post_meta($nouveau_document_id, '_used_template_version', $template_version);
            add_post_meta($nouveau_document_id, '_generated_doc_user_id', $_POST['user_id']);
            add_post_meta($nouveau_document_id, '_used_template_id', $template_id);
            add_post_meta($nouveau_document_id, '_generated_doc_vars', wp_json_encode($used_values));
            $nouveaux_documents[] = $nouveau_document_id;
        }
    }


    // Vérification avant de mettre à jour le post_meta
    if (!empty($nouveaux_documents)) {
        // Mettre à jour les documents associés à l'ID du post actuel
        update_post_meta($post_id, '_documents_associes_list', $nouveaux_documents);
        wp_send_json_success();
    } 
    else {
        wp_send_json_error('Aucun document n\'a été généré.');
    }
    
}

//add_action('wp_ajax_generer_documents_associes1', 'generer_documents_associes1');

//






function enqueue_admin_custom_script($hook_suffix) {
    global $post;

    // Vérifier si on est sur l'écran d'édition ou d'ajout
    if (in_array($hook_suffix, ['post.php', 'post-new.php'])) {
        // Charger le script uniquement pour le type de post 'crm_docs_gen'
        if (isset($post->post_type) && $post->post_type === 'crm_docs_gen') {
            wp_enqueue_script(
                'admin-custom-js',
                plugin_dir_url(__FILE__) . './crm-documents-generes.js', // Remplacez par le chemin réel de votre fichier JS
                ['jquery'],
                '1.0',
                true
            );
        }
    }
}

add_action('admin_enqueue_scripts', 'enqueue_admin_custom_script');


add_action('before_delete_post', 'delete_attachments_on_post_delete');

function delete_attachments_on_post_delete($post_id) {
    $upload_dir = wp_upload_dir();
    $base_dir = $upload_dir['basedir'];
    $base_url = $upload_dir['baseurl'];

    // Suppression du fichier PDF principal
    $pdf_url = get_post_meta($post_id, '_pdf_url', true);
    if (!empty($pdf_url)) {
        $file_path = str_replace($base_url, $base_dir, $pdf_url);
        if (file_exists($file_path)) {
            unlink($file_path); // Suppression du fichier
        }
        delete_post_meta($post_id, '_pdf_url'); // Suppression des métadonnées associées
    }

    // Suppression des pièces jointes générées
    $generated_doc_pieces_joints = get_post_meta($post_id, '_generated_doc_pieces_joints', true);
    if (!empty($generated_doc_pieces_joints) && is_array($generated_doc_pieces_joints)) {
        foreach ($generated_doc_pieces_joints as $doc_url) {
            $doc_path = str_replace($base_url, $base_dir, $doc_url);
            if (file_exists($doc_path)) {
                unlink($doc_path); // Suppression de chaque pièce jointe
            }
        }
        delete_post_meta($post_id, '_generated_doc_pieces_joints'); // Suppression des métadonnées des pièces jointes
    }
}

function make_crm_docs_gen_readonly() {
    global $post;

    // Vérifie si on est sur l'écran d'édition d'un post de type 'crm_docs_gen'
    if ($post && $post->post_type === 'crm_docs_gen') {
        ?>
        <style>
            /* Désactiver les champs texte, textarea et select */
            #poststuff input[type="text"],
            #poststuff textarea,
            #poststuff select,
            .acf-input input,
            .acf-input textarea,
            .acf-input select {
                pointer-events: none;
                background-color: #f5f5f5; /* Couleur de fond pour montrer que c'est en lecture seule */
            }

            /* Désactiver les éditeurs TinyMCE */
            .wp-editor-container textarea {
                pointer-events: none;
                background-color: #f5f5f5;
            }

            /* Désactiver les boutons */
            #poststuff button,
            #poststuff .button,
            #poststuff .button-primary,
            #poststuff .button-secondary {
                pointer-events: none;
                opacity: 0.5;
            }

            /* Désactiver la barre de publication */
            #submitdiv .inside {
                pointer-events: none;
                opacity: 0.5;
            }
            .page-title-action{
                display: none;
            }
        </style>
        <script>
            jQuery(document).ready(function($) {
                // Désactiver le TinyMCE (éditeur visuel)
                if (typeof tinymce !== 'undefined') {
                    tinymce.activeEditor.setMode('readonly');
                }

                // Désactiver les boutons de mise à jour et de publication
                $('#publish').prop('disabled', true).css('opacity', 0.5);
            });
        </script>
        <?php
    }
}
add_action('admin_head', 'make_crm_docs_gen_readonly');
