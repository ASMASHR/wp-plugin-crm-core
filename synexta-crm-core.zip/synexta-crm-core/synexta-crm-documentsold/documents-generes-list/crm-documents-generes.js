jQuery(document).ready(function($) {
    /*const $titleField = $('#title');

    if ($titleField.length) {
        $titleField.prop('readonly', true);
    }*/
    $('#user_select').on('change', function() {
        const userId = $(this).val();


        $('#template_select').empty();

        if (userId) {
            $.ajax({

                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'load_templates_by_user_role',
                    user_id: userId,
                },
                success: function(response) {

                    if (response.success) {
                        //$('#templates-list').slideDown();
                        const templates = response.data.templates;
                        const templateSelect = $('#template_select');

                        if (templates.length > 0) {
                            $('#template_select').parent().show();
                            $('#load_template_variables').show();
                            $('#template_select').append('<option value="">-- Sélectionnez un modèle --</option>');

                            templates.forEach(function(template) {
                                $('#template_select').append(`<option value="${template.id}">${template.title}</option>`);
                            });


                            $('#templates-list-error').html('').hide();

                        } else {
                            $('#template_select').parent().hide();
                            $('#load_template_variables').hide();

                            $('#templates-list-error').html('Aucune template disponible pour le role de cet utilisateur.').show();

                        }


                    } else {
                        alert(response.data.message || 'Erreur lors de la récupération des templates.');
                    }


                }

            });
        }
    });


    $('#load_template_variables').on('click', function() {
        const templateId = $('#template_select').val();
        const userId = $('#user_select').val();

        if (!templateId || !userId) {
            alert('Veuillez sélectionner un utilisateur et un template.');
            return;
        }

        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'load_template_variables',
                template_id: templateId,
                user_id: userId,
            },
            success: function(response) {

                if (response.success) {
                    var uniqueVariables = response.data.variables;
                    if (!Array.isArray(uniqueVariables)) {
                        uniqueVariables = Object.values(uniqueVariables);
                    }
                    const today = new Date();
                    //const formattedDate = `${today.getFullYear()}-${(today.getMonth() + 1).toString().padStart(2, '0')}-${today.getDate().toString().padStart(2, '0')}`;
                    const formattedDate = `${today.getFullYear().toString().slice(-2)}${(today.getMonth() + 1).toString().padStart(2, '0')}`;

                    const templateNom = response.data.nom;
                    $('#variables_list').empty();
                    const templateRacine = response.data.racine || sanitizeTitle(response.data.nom);
                    const compteur = (response.data.compteur || 1).toString().padStart(4, '0');
                    const labelsArray = {
                        'user_status': 'Statut utilisateur',
                        'display_name': 'Nom affiché',
                        'nickname': 'Surnom',
                        'first_name': 'Prénom',
                        'last_name': 'Nom',
                        'description': 'Description',
                        'wc_last_active': 'Dernière activité WooCommerce',
                        'tax_no': 'Numéro fiscal',
                        'user_mailing': 'Adresse de messagerie utilisateur',
                        'shipping_first_name': 'Prénom (livraison)',
                        'shipping_last_name': 'Nom (livraison)',
                        'shipping_company': 'Entreprise (livraison)',
                        'shipping_address_1': 'Adresse 1 (livraison)',
                        'shipping_address_2': 'Adresse 2 (livraison)',
                        'shipping_city': 'Ville (livraison)',
                        'shipping_postcode': 'Code postal (livraison)',
                        'shipping_country': 'Pays (livraison)',
                        'shipping_state': 'Région/État (livraison)',
                        'shipping_phone': 'Téléphone (livraison)',
                        'shipping_email': 'E-mail (livraison)',
                        'reference_template': 'Référence modèle',
                        'creation_date': 'Date de création',
                        'template_name': 'Nom template'

                    };



                    uniqueVariables.forEach(variable => {
                        var inputValue = response.data.meta[variable] || '';

                        if (variable === 'reference_template') {
                            inputValue = `${templateRacine}-${formattedDate}-${compteur}`;

                            $('#variables_list').append(`
                               
                            `);
                        } else if (variable === 'template_name') {
                            inputValue = `${templateNom}`;
                        } else if (variable === 'creation_date') {
                            const day = today.getDate().toString().padStart(2, '0');
                            const month = (today.getMonth() + 1).toString().padStart(2, '0');
                            const year = today.getFullYear();
                            inputValue = `${day} ${month} ${year}`;
                        }
                        $('#variables_list').append(`
                            <div class="variable_item">
                                <label for="${variable}">${labelsArray[variable] || variable} :</label>
                                <input type="text" name="${variable}"id="${variable}" value="${inputValue}" />
                            </div>
                        `);


                    });
                    //const updatedTitle = `${templateRacine}-${formattedDate}-${compteur}`;
                    //

                    const docTitle = `${templateNom} ${formattedDate}`;
                    //$('#title').val(updatedTitle).attr('readOnly', true);

                    $('#title').val(docTitle);
                    //$('#template_version').val(response.data.template_version).attr('readOnly', true);
                    $('#variables_modal,.template_version_container').show();

                    $('#template_content').val(response.data.contenu);
                    /*if (window.tinymce && tinymce.activeEditor) {
                        tinymce.activeEditor.execCommand("mceInsertContent", false, response.data.contenu);
                    }*/
                    $('#title-prompt-text').hide();

                } else {
                    alert('Aucune variable trouvée dans ce template.');
                }
            },

        });
    });
    $('#template_select').on('change', function() {
        var templateId = $(this).val();

        /* if (!templateId) {
             $('#associated_templates').empty(); // 
             return;
         }

         // Requête AJAX pour récupérer les templates associés
         $.ajax({
             url: ajaxurl,
             method: 'POST',
             data: {
                 action: 'load_associated_templates',
                 template_id: templateId,
                 post_id: $('#post_ID').val() // Récupérer l'ID du post actuel
             },
             success: function(response) {
                 if (response.success) {
                     var associatedTemplates = response.data.associated_templates;

                     // Vider la liste avant d'ajouter les nouveaux éléments
                     $('#associated_templates').empty();

                     // Ajouter les templates associés sous forme de cases à cocher
                     associatedTemplates.forEach(function(template) {
                         var checked = template.checked ? 'checked' : '';
                         var label = template.label;
                         var templateId = template.id;

                         $('#associated_templates').append(
                             '<div><input type="checkbox" class="template-checkbox" value="' + templateId + '" ' + checked + '>' +
                             '<label>' + label + '</label></div>'
                         );
                     });
                 } else {
                     alert('Erreur lors du chargement des templates associés.');
                 }
             },
             error: function() {
                 alert('Une erreur s\'est produite lors de la requête AJAX.');
             }
         });*/
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'load_templates_version',
                template_id: templateId,
            },
            success: function(response) {
                if (response.success) {

                    // Vider la liste avant d'ajouter les nouveaux éléments
                    $('.template_version_container').show()
                    $('#template_version').val(response.data.version);


                } else {
                    alert('Erreur lors du chargement des templates associés.');
                }
            },
            error: function() {
                alert('Une erreur s\'est produite lors de la requête AJAX.');
            }
        });
    })

    $('#add_to_editor').on('click', function() {
        // Récupérer le contenu actuel de TinyMCE
        let content = '';

        content = $('#template_content').val();


        let variablesValues = {};
        let valid = true;
        $('#variables_list input').each(function() {
            const variable = $(this).attr('name');
            const value = $(this).val();
            variablesValues[variable] = value;
            if (value.trim() === '') {
                valid = false;

                // Ajouter un message d'erreur si le champ est vide
                $(this).next('.error-msg').remove(); // Supprimer un message d'erreur existant
                $(this).parent().after('<div class="error-msg" style="color: red;">Ce champ est requis</div>');
            } else {
                $(this).parent().next('.error-msg').remove();
            }
        });

        if (valid) {
            Object.keys(variablesValues).forEach(variable => {
                const regex = new RegExp(`\\{${variable}\\}`, 'g');
                const boldValue = `<b> ${variablesValues[variable]} </b>`;
                content = content.replace(regex, boldValue);
            });

            // Remplacer le contenu dans TinyMCE
            if (window.tinymce && tinymce.activeEditor) {
                tinymce.activeEditor.setContent(content);
            }
            let postData = {
                action: 'save_associated_templates',
                post_id: $('#template_select').val(),
                user_id: $('#user_select').val(),
                variables_values: JSON.stringify(variablesValues)
            };
            $('#variables_documents_generes').val(JSON.stringify(variablesValues));

            /*$.post(ajaxurl, postData, function(response) {
                console.log(response, 'cvvvvvvvvvvvvvvvvvv');
                console.log('Réponse du serveur :', response);
                if (response.success) {
                    $('#associe_list').val(JSON.stringify(response.data.document_ids));
                    alert('Les documents associés ont été sauvegardés avec succès!');
                } else {
                    alert('Erreur lors de la sauvegarde des documents associés.');
                }
            }) */


            // Masquer la modal
            $('#variables_modal').hide();
        }
    });


    function sanitizeTitle(title) {
        return title
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, '-')
            .replace(/[^\w-]/g, '');
    }
    $(document).on('change', '#variables_list input', function() {
        const value = $(this).val();

        // Vérifier si la valeur du champ n'est pas vide
        if (value.trim() !== '') {
            // Cacher le message d'erreur si la valeur est remplie
            $(this).parent().next('.error-msg').remove();
        }
    });
    $('#generer_documents_associes').on('click', function() {
        const selectedTemplates = [];
        $('.template-checkbox:checked').each(function() {
            const templateId = $(this).val();
            const nomDoc = $(`#nom_doc_${templateId}`).val();

            selectedTemplates.push({
                id: templateId,
                nom_doc: nomDoc
            });
            // selectedTemplates.push($(this).val());
        });

        if (selectedTemplates.length === 0) {
            alert('Veuillez sélectionner au moins un template.');
            return;
        }

        const postId = $(this).data('postid');
        const userId = $('#user_select').val();

        let variablesValues = {};
        $('#variables_list input').each(function() {
            const variable = $(this).attr('name');
            const value = $(this).val();
            variablesValues[variable] = value;

        });
        console.log('variablesValues', variablesValues);


        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'generer_documents_associes',
                templates: selectedTemplates,
                post_id: postId,
                user_id: userId,
                variablesValues: JSON.stringify(variablesValues)
            },
            success: function(response) {
                if (response.success) {
                    alert('Les documents ont été générés avec succès.');
                    // Actualiser la page pour mettre à jour les données
                    location.reload();
                } else {
                    alert('Une erreur s\'est produite : ' + response.data);
                }
            },
            error: function() {
                alert('Erreur lors de la requête.');
            }
        });
    });


});