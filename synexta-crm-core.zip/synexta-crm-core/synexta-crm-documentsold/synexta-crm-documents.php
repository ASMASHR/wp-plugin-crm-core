<?php
/*
Plugin Name: Synexta CRM Documents
Description: Gestion des modèles et documents personnalisés.
Version: 1.1.3
Author: Synexta
Author URI: https://synexta.com/
Plugin URI: https://synexta.com/
*/

// Définition des constantes
define('CRM_DOCUMENTS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CRM_DOCUMENTS_PLUGIN_URL', plugin_dir_url(__FILE__));

// Inclusion des fichiers nécessaires
require_once CRM_DOCUMENTS_PLUGIN_DIR . 'templates-list/templates-list.php';
require_once CRM_DOCUMENTS_PLUGIN_DIR . 'shortcodes/shortcodes.php';
require_once CRM_DOCUMENTS_PLUGIN_DIR . 'documents-generes-list/generation-functions.php';


// Enregistrement des hooks d'activation et de désactivation
register_activation_hook(__FILE__, 'synexta_generation_documents_crm_activate');
register_deactivation_hook(__FILE__, 'synexta_generation_documents_crm_deactivate');

/**
 * Activation du plugin : création des tables
 */
function synexta_generation_documents_crm_activate() {
    //synexta_generation_documents_crm_create_tables();
}
/**
 * Désactivation du plugin : suppression des tables si nécessaire
 */
function synexta_generation_documents_crm_deactivate() {
    global $wpdb;
    $table_crm_templates = $wpdb->prefix . 'crm_templates';
    $table_crm_documents = $wpdb->prefix . 'crm_generated_documents';
    
    $post_types = ['crm_documents', 'crm_docs_gen'];

    // Prépare une requête sécurisée pour supprimer les posts des deux types
   /* $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->posts} 
             WHERE post_type IN (%s, %s)",
            $post_types[0],
            $post_types[1]
        )
    ); */
    //$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}crm_generated_documents");
   if ($wpdb->get_var("SHOW TABLES LIKE '$table_crm_templates'") == $table_crm_templates) {
        $wpdb->query("DROP TABLE $table_crm_templates");
    }
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_crm_documents'") == $table_crm_documents) {
        $wpdb->query("DROP TABLE $table_crm_documents");
    } /**/
}

/**
 * Création des tables
 */

function synexta_generation_documents_crm_create_tables(){
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // Table des modèles de templates
    $table_templates = $wpdb->prefix . 'crm_templates';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_templates'") != $table_templates) {
        $sql_templates = "CREATE TABLE $table_templates (
            id INT NOT NULL AUTO_INCREMENT,
            nom TEXT NOT NULL,
            contenu LONGTEXT NOT NULL,
            racine TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            variables_list LONGTEXT,
            associes_list LONGTEXT,
            version_template VARCHAR(255),
            PRIMARY KEY (id)
        ) $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_templates);
        error_log("Création de crm_templates exécutée : " . $wpdb->last_error);
    }

    // Table des documents générés
    $table_documents = $wpdb->prefix . 'crm_generated_documents';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_documents'") != $table_documents) {
        $sql_documents = "CREATE TABLE $table_documents (
            id INT NOT NULL AUTO_INCREMENT,
            user_id INT NOT NULL,
            template_id INT NOT NULL,
            variables TEXT NOT NULL,
            content LONGTEXT NOT NULL,
            documents_associes LONGTEXT,
            file_url TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            version_template VARCHAR(255),
            PRIMARY KEY (id)
        ) $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_documents);
        error_log("Création de crm_generated_documents exécute : " . $wpdb->last_error);
    }
    // Ajouter les contraintes FOREIGN KEY
    /*$wpdb->query("
    ALTER TABLE $table_documents
    ADD CONSTRAINT fk_user_id FOREIGN KEY (user_id) REFERENCES {$wpdb->prefix}users(ID) ON DELETE CASCADE,
    ADD CONSTRAINT fk_template_id FOREIGN KEY (template_id) REFERENCES $table_templates(id) ON DELETE CASCADE;
    ");*/
}

/**
 * Chargement des scripts et styles spécifiques au plugin
 */
function synexta_generation_documents_crm_enqueue_admin_assets($hook_suffix) {
    wp_enqueue_style('synexta-crm-style', plugin_dir_url(__FILE__) . '/templates-list/templates-style.css');
   //
   //wp_enqueue_script('crm-documents-generes-js', plugin_dir_url(__FILE__) . '/documents-generes-list/crm-documents-generes.js', array(), '1.0', true);
   
}
add_action('admin_enqueue_scripts', 'synexta_generation_documents_crm_enqueue_admin_assets');
