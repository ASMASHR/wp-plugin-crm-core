<?php

// Enregistrement du type de post personnalisé
function register_crm_documents_post_type() {
    register_post_type('crm_documents', [
        'labels' => [
            'name'               => 'CRM Templates',
            'singular_name'      => 'Template CRM',
            'add_new'            => 'Ajouter un template',
            'add_new_item'       => 'Ajouter un template',
            'edit_item'          => 'Modifier le template',
            'new_item'           => 'Nouveau template',
            'view_item'          => 'Voir le template',
            'search_items'       => 'Rechercher des templates',
            'not_found'          => 'Aucun template trouvé',
            'not_found_in_trash' => 'Aucun template trouvé dans la Corbeille',
        ],
        'public'        => false,
        'show_ui'       => true,
        'has_archive'   => false,
        'menu_icon'     => 'dashicons-media-text',
        'supports'      => ['title', 'editor'],
        'rewrite'       => false,
       
        'show_in_menu'  => true,
       
    ]);
}
add_action('init', 'register_crm_documents_post_type');
function crm_documents_admin_menu() {
    // Ajoute "Accueil" comme premier sous-menu du type de post
    add_submenu_page(
        'edit.php?post_type=crm_documents', 
        'Configuration',                         
        'Configuration',                         
        'manage_options',                  
        'crm-documents-config',            
        'crm_documents_config_page'        
    );

    // Réordonne le sous-menu pour afficher "Accueil" en premier

}
add_action('admin_menu', 'crm_documents_admin_menu');
/*add_action('admin_head', function() {
    global $submenu;
    if (isset($submenu['edit.php?post_type=crm_documents'])) {
        $submenu['edit.php?post_type=crm_documents'] = array_merge(
            [$submenu['edit.php?post_type=crm_documents'][1]], 
            [$submenu['edit.php?post_type=crm_documents'][0]], 
            array_slice($submenu['edit.php?post_type=crm_documents'], 2) 
        );
    }
});*/

function crm_documents_config_page() {
    ?>
    <div class="wrap">
        <h1>Configuration des Documents CRM</h1>
        <h2 class="nav-tab-wrapper">
        <a href="#presentation" class="nav-tab nav-tab-active " data-tab="presentation">Présentation</a>
    <a href="#configuration" class="nav-tab" data-tab="configuration">Configuration</a>
 </h2>
<div id="presentation" class="tab-content" style="display:block;">
        <div style="border-bottom: 1px solid #ddd; margin-bottom: 20px; padding-bottom: 20px;">
            <h2 style="font-size: 1.5em; margin-bottom: 10px;">Type de post "CRM Documents"</h2>
            <p>Le type de post <strong>CRM Documents</strong> permet d’ajouter et de gérer des templates destinés à la génération de documents. Ces templates sont réutilisables pour produire des documents personnalisés selon vos besoins.</p>
            
             <p><strong>Fonctionnalités principales :</strong></p> 
             <ul style="list-style-type: disc; margin-left: 20px;"> 
                <li>Créer des templates structurés pour générer des documents et rapports standardisés.</li> 
                <li>Gérer facilement les documents générés à partir des templates.</li> 
                <li>Personnaliser les documents à l’aide des variables dynamiques incluses dans les templates.</li> 
                <li>Offrir la possibilité d'attacher les documents générés à d'autres documents en fonction de la configuration des templates via la case à cocher "Autoriser l’ajout de documents joints supplémentaires ?".</li>

             </ul> 
             <div style="margin-top: 20px;">
                <h3 style="font-size: 1.2em; margin-bottom: 10px;">Différence entre Documents et Rapports</h3>
                <p>Les <strong>Documents</strong> sont créés à partir des templates générés, incluant la possibilité de créer un fichier PDF attaché à chaque document. Chaque template génère un document où le PDF est autorisés.</p>
                <p>Les <strong>Rapports</strong> diffèrent des documents dans le sens où un rapport est un document généré à partir d'un template, mais il n'a pas de fichier PDF associé. Ce sont des documents générés via des templates qui n'autorisent pas la création de PDF, mais qui peuvent tout de même être utilisés pour rapporter des informations.</p>
                <p>Le <strong>crm_template</strong> est utilisé pour créer et gérer les templates qui servent à générer ces documents et rapports. Ces templates définissent les structures des documents et leur comportement, comme la possibilité de générer ou non un fichier PDF attaché.</p>
                
            </div>
             <div style="border: 1px solid #ddd; background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin-top: 20px;">
                <h3 style="font-size: 1.2em; margin-bottom: 10px;">Shortcodes disponibles</h3>
                
                <p>Utilisez les shortcodes suivants pour interagir avec les templates et les documents générés :</p>
                
                <!--1eme shortcode-->
                <h4 style="font-size: 1.1em; margin-bottom: 5px;">1. [generation_document]</h4>
                <p>Ce shortcode permet de générer un document en choisissant une entreprise et un template. Le document est basé sur les variables définies dans le template. Il accepte les attributs suivants (facultatifs) :</p>
                <ul style="list-style-type: disc; margin-left: 20px;">
                <li><strong>ico</strong> : <br>
                    <em>Permet d'ajouter une icône au bouton via une URL. Si une URL est spécifiée, l'image correspondante sera affichée avant le label du bouton. Si `ico=""`, aucune icône ne sera affichée. Par exemple, `ico="https://example.com/icon.png"` affichera l'icône provenant de cette URL.</em>
                </li>
                <li><strong>title</strong> : Permet de changer le texte affiché sur le bouton. Par défaut, le bouton portera le texte "Générer un document". Si `title=""`, aucun texte ne sera affiché sur le bouton. Ce paramètre est facultatif. <br>
                    <em>En modifiant le paramètre `title`, une classe spécifique sera ajoutée au bouton sous la forme `template-btn-<title>`. Les espaces, caractères spéciaux et majuscules seront convertis en minuscules pour générer une classe CSS personnalisée. Par exemple, si `title="relance"`, la classe sera `template-btn-relance`.</em>
                </li>

                
                <li>Si utilisé sur la fiche d’un tiers, il permet de générer un document directement lié à ce tiers.</li>
                </ul>
                <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">[generation_document title="relance" ico="https://example.com/icon.png"]</pre>


 <!--2eme shortcode-->

                <h4 style="font-size: 1.1em; margin-bottom: 5px;">2. [crm_notes]</h4>
                <p>Ce shortcode permet de générer une note sur le fiche d'un tiers à partir de la template par defaut du module . La note est basé sur les variables définies dans le template. Il accepte les attributs suivants (facultatifs) :</p>
                <ul style="list-style-type: disc; margin-left: 20px;">
                <li><strong>ico</strong> : <br>
                    <em>Permet d'ajouter une icône au bouton via une URL. Si une URL est spécifiée, l'image correspondante sera affichée avant le label du bouton. Si `ico=""`, aucune icône ne sera affichée. Par exemple, `ico="https://example.com/icon.png"` affichera l'icône provenant de cette URL.</em>
                </li>
                <li><strong>title</strong> : Permet de changer le texte affiché sur le bouton. Par défaut, le bouton portera le texte "Ajouter une note". Si `title=""`, aucun texte ne sera affiché sur le bouton. Ce paramètre est facultatif. <br>
                    <em>En modifiant le paramètre `title`, une classe spécifique sera ajoutée au bouton sous la forme `crm-gen-notes-btn-<title>`. Les espaces, caractères spéciaux et majuscules seront convertis en minuscules pour générer une classe CSS personnalisée. Par exemple, si `title="relance"`, la classe sera `template-btn-relance`.</em>
                </li>

                
                <li>Assurer d'utiliser ce shortcode sur la fiche d’un tiers, et de définir le modele par defaut  .</li>
                </ul>
                <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">[crm_notes title="note" ico="https://example.com/icon.png"]</pre>

                
                <!--3eme shortcode-->

                <h4 style="font-size: 1.1em; margin-bottom: 5px;">3. [crm_documents_generes]</h4>
                <p>Ce shortcode affiche une liste des documents générés. Il accepte les attributs suivants :</p>
                <ul style="list-style-type: disc; margin-left: 20px;">
                    <li><strong>nom_template</strong> : Nom du template pour filtrer les documents affichés selon le nom du template utilisée (facultatif).</li>
                    <li>Si utilisé sur la fiche d’un tiers, il affichera uniquement les documents liés à ce tiers.</li>
                </ul>
                <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">[crm_documents_generes nom_template="Nom du template"]</pre>
                
                
            </div>
            
 
        
        </div>
</div>
<div id="configuration" class="tab-content" style="display:none;">
       
            <form method="post" action="options.php">
                <?php
                settings_fields('crm_documents_options');
                do_settings_sections('crm-documents-config');
                submit_button();
                ?>
            </form>

    </div>
    <script>
        jQuery(document).ready(function($) {
    $('.nav-tab').on('click', function(e) {
        e.preventDefault();

        const targetTab = $(this).data('tab');

        $('.tab-content').hide();

        $('#' + targetTab).show();
        $('.nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
    });
});
    </script>
    <?php
}

// Enregistrer les réglages de configuration
function crm_documents_settings_init() {
    register_setting('crm_documents_options', 'crm_footer_text');

    add_settings_section(
        'crm_documents_footer_section',
        'Configuration du pied de page des documents',
        function() {
            echo '<p>Ce texte sera inséré dans la section footer de tous les documents générés. 
            Vous pouvez personnaliser l\'apparence du texte en appliquant des styles à la classe <code>.crm-documents-footer-text</code> dans votre fichier CSS <strong>pdf-css-file.css</strong>.</p>';
        },
        'crm-documents-config'
    );

    add_settings_field(
        'crm_footer_text',
        'Texte du Footer',
        function() {
            $value = get_option('crm_footer_text', '');
            wp_editor($value, 'crm_footer_text', ['textarea_name' => 'crm_footer_text', 'textarea_rows' => 5]);
        },
        'crm-documents-config',
        'crm_documents_footer_section'
    );
}
add_action('admin_init', 'crm_documents_settings_init');
function render_generate_documents_page() {
    echo '<div class="wrap">';
    echo '<h1>Générer des Documents</h1>';
    include CRM_DOCUMENTS_PLUGIN_DIR . 'documents-generes-list/generation-functions.php';
    echo '</div>';
}

// Ajouter les metaboxes
function ajouter_metaboxes_crm_templates() {
    add_meta_box(
        'metabox_variables',
        'Variables',
        'afficher_metabox_variables',
        'crm_documents',
        'advanced',
        'high'
    );

    add_meta_box(
        'metabox_racine_associes',
        'Racine et Associés',
        'afficher_metabox_racine_associes',
        'crm_documents',
        'normal',
        'high'
    );
    add_meta_box(
        'droits_utilisation',
        'Droits d\'utilisation',
        'afficher_metabox_droits_utilisation',
        'crm_documents',
        'advanced',
        'default'
    );
    add_meta_box(
        'configuration_template',           
        'Configuration de la Template',     
        'afficher_metabox_configuration_template',  
        'crm_documents',                         
        'normal', 
        'high'                             
    );
}
add_action('add_meta_boxes', 'ajouter_metaboxes_crm_templates');
add_action('edit_form_after_title', function() {
    global $post, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'advanced', $post);
unset($wp_meta_boxes[get_post_type($post)]['advanced']);
},3,2);
// Metabox Variables
// Metabox pour afficher et gérer les variables
function afficher_metabox_variables($post) {
    wp_nonce_field('sauvegarder_template', 'template_nonce');

    echo '<p><strong>Liste des variables Disponibles :</strong></p>';
    echo '<p>Les variables sélectionnées seront remplacées par les données de l\'utilisateur lors de la génération du document spécifique à un utilisateur.</p>';
    echo '<p>Cliquez sur le nom d\'une variable pour l\'insérer dans le modèle. Si vous souhaitez ajouter une nouvelle variable, cliquez sur "Ajouter".</p>';

    // Description des types de variables
    echo '<p><strong>Format des Variables :</strong></p>';
    echo '<ul>';
    echo '<li><strong>*</strong> : Indique que la variable est obligatoire et ne peut pas être vide.</li>';
    echo '<li><strong>@</strong> : Indique que la variable est un champ "texte long" avec une barre d\'édition riche (textarea).</li>';
    echo '<li><strong>|</strong> : Permet de définir un champ de type dropdown avec des choix spécifiques, séparés par des | (ex. {nom_variable|choix1|choix2|choix3}). La première valeur est le nom de la variable et les suivantes sont les options à afficher dans le dropdown.</li>';
    echo '<li><strong>#</strong> : Indique que la variable est un champ de type "date". Le format sera converti au format date de WordPress.</li>';
    echo '</ul>';
    echo '<p><strong>Exemples :</strong></p>';
    echo '<ul>';
    echo '<li><code>{nom_variable *}</code> : Un champ input obligatoire.</li>';
    echo '<li><code>{nom_variable *|choix1|choix2|choix3}</code> : Un champ dropdown avec des choix, et la variable est obligatoire.</li>';
    echo '<li><code>{nom_variable *@}</code> : Un champ de texte long (textarea) avec la variable obligatoire.</li>';
    echo '<li><code>{date_contrat#}</code> : Un champ de type date (facultatif) pour "date_contrat".</li>';
    echo '</ul>';
    $tags = [
        'template_name','document_name','user_status', 'display_name','display_author_name','display_author_bio', 'nickname', 'first_name', 'last_name', 'description', 
        'wc_last_active', 'tax_no', 'user_mailing',  'shipping_first_name', 'shipping_last_name', 'shipping_company',
        'shipping_address_1', 'shipping_address_2', 'shipping_city', 'shipping_postcode',
        'shipping_country', 'shipping_state', 'shipping_phone', 'shipping_email',
        'reference_template', 'creation_date','billing_first_name', 'billing_last_name',
        'billing_company', 'billing_address_1', 'billing_address_2', 'billing_city',
        'billing_postcode', 'billing_country', 'billing_state', 'billing_phone',
        'billing_email',
    ];
/**/
    $visible_tags = array_slice($tags, 0, 5);
    $hidden_tags = array_slice($tags, 5);

    echo '<div id="tags-container" class="tags-container">';
    foreach ($visible_tags as $tag) {
        echo "<span class='tag-item' data-tag='{$tag}'>{$tag}</span>";
    }
    echo '<span id="more-tags"class="more-tags-container" style="display: none;">';
    foreach ($hidden_tags as $tag) {
        echo "<span class='tag-item' data-tag='{$tag}'>{$tag}</span>";
    }
    echo '</span>';
    echo '<a href="#" id="show-more-tags">Afficher +</a>';
    echo '</div>';

    echo '<textarea name="variables_list" id="variables_list" rows="5" class="large-text" readonly hidden>';
    echo esc_textarea(json_encode([], JSON_PRETTY_PRINT));
    echo '</textarea>';

    echo '<p>Si une variable n\'est pas trouvée, vous pouvez l\'ajouter :</p>';
    echo '<button type="button" id="add_variable_button" class="button">Ajouter une Variable</button>';
    echo '<div id="variable_form" style="display:none; margin-top: 10px;">';
    echo '<p><strong>Nom de la variable :</strong> <input type="text" id="variable_name" class="regular-text"style="width:auto"></p>';
   // echo '<p><strong>Type de la variable :</strong> ';
    //echo '<select id="variable_type">';
    //echo '<option value="text">Texte</option>';
    //echo '<option value="number">Nombre</option>';
    //echo '<option value="date">Date</option>';
    //echo '</select></p>';
    echo '<button type="button" id="insert_variable" class="button">Ajouter</button>';
    echo '</div>';
}
function afficher_metabox_configuration_template($post) {
    // Sécurisation du formulaire
    wp_nonce_field('sauvegarder_configuration_template', 'configuration_template_nonce');

    // Nom de la metabox
    echo '<h3>Configuration de la Template</h3>';

    // Autoriser d'autres documents joints (par défaut décoché)
    $autoriser_documents = get_post_meta($post->ID, '_template_autorise_documents_joints', true);
    echo '<p><label for="autoriser_documents"><input type="checkbox" id="autoriser_documents" name="autoriser_documents" ' . checked($autoriser_documents, 'on', false) . '> Autoriser l’ajout de documents joints supplémentaires ?</label></p>';

    // Générer le PDF (par défaut coché)
    $generer_pdf = get_post_meta($post->ID, '_template_autorise_generation_pdf', true);
 
    $checked = (isset($generer_pdf) && $generer_pdf === 'on') ? 'checked' : '';

    echo '<p><label for="template_autorise_generation_pdf"><input type="checkbox" id="template_autorise_generation_pdf" name="template_autorise_generation_pdf" ' . $checked . '> Générer le PDF lors de la création du document ?</label></p>';
 // Générer le PDF (par défaut coché)
    $crm_document_default_template = get_option( 'crm_document_plugin_default_template');
    $is_default = false ;
    if($crm_document_default_template ==$post->ID){
        $is_default=true;

    }
    echo '<p><label for="default_template">
    <input type="checkbox" id="default_template"name="default_template" value="1" ' . checked($is_default, true, false) . ' /> 
    Définir comme modèle par défaut
</label></p>';


}

// Metabox pour gérer les modèles associés
function afficher_metabox_racine_associes($post) {
    wp_nonce_field('sauvegarder_associes', 'associes_nonce');
    
    $racine = get_post_meta($post->ID, '_racine', true);
    $associes_list = get_post_meta($post->ID, '_associes_list', true);
    $associes_list = $associes_list ? json_decode($associes_list, true) : [];
    $current_version = get_post_meta($post->ID, '_template_version', true);
    $current_version = $current_version ? $current_version : 'version_' . date('d_m_Y') . '_0000';

    $expire_dans = get_post_meta($post->ID, '_template_expire_dans', true);
    $expire_dans = $expire_dans !== '' ? $expire_dans : 0;

    $associes = get_posts(['post_type' => 'crm_documents', 'numberposts' => -1]);
    
    echo '<table class="form-table">';
    echo '<tr>';
    echo '<th><label for="expire_dans">Expiration (en jours)</label></th>';
    echo '<td>';
    echo '<input type="number" id="expire_dans" name="expire_dans" value="' . esc_attr($expire_dans) . '" min="0" step="1">';
    echo '<p class="description">Définissez dans combien de jours ce template expirera. Par défaut : 0 (pas d\'expiration).</p>';
    echo '</td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th><label for="template_version">Version actuelle</label></th>';
    echo '<td><input type="text" id="template_version" value="' . esc_attr($current_version) . '" class="regular-text" readonly></td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th><label for="racine">Racine</label></th>';
    echo '<td><input type="text" name="racine" id="racine" value="' . esc_attr($racine) . '" class="regular-text"></td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th><label for="associes_list">Modèles Associés</label></th>';
    echo '<td>';
    echo '<div id="available-templates" style="margin-bottom: 10px;">';
    foreach ($associes as $associe) {
        if ($associe->ID != $post->ID) {
            echo "<span class='template-tag' data-id='{$associe->ID}'>{$associe->post_title}</span>";
        }
    }
    echo '</div>';
    echo '<div id="associated-templates" style="border: 1px dashed #ccc; padding: 10px; min-height: 40px;">';
    foreach ($associes_list as $id) {
        $associe = get_post($id);
        if ($associe) {
            echo "<span class='associated-template' data-id='{$associe->ID}'>{$associe->post_title} <span class='remove-template' style='color: red; cursor: pointer;'>×</span></span>";
        }
    }
    echo '</div>';
    echo '<input type="hidden" id="associes_list_input" name="associes_list" value="' . esc_attr(json_encode($associes_list)) . '">';
    echo '</td>';
    echo '</tr>';
    echo '</table>';
   
}
function afficher_metabox_droits_utilisation($post) {
    wp_nonce_field('sauvegarder_droits_utilisation', 'droits_utilisation_nonce');
    
    $roles_utilisateurs = wp_roles()->roles;
    $roles_selectionnes = get_post_meta($post->ID, '_template_roles_acces', true);
    $roles_selectionnes = $roles_selectionnes ? json_decode($roles_selectionnes, true) : ['responsable_crm','administrator','utilisateur_crm','prospect','customer','tiers'];
    
    echo '<table class="form-table">';
    echo '<tr>';
    echo '<th><label for="droits_utilisation">Droits d\'utilisation</label></th>';
    echo '<td>';
    echo '<p>Définissez qui peut utiliser ce modele en sélectionnant les rôles d\'utilisateur ci-dessous ( Tous les roles et type de fiches qui peuvent utiliser ce modele ):</p>';
    echo '<div id="available-roles"class="available-roles">';
    foreach ($roles_utilisateurs as $role_slug => $role_details) {
        if (!in_array($role_slug, $roles_selectionnes)) {
            
            echo "<span class='role-tag' data-role='{$role_slug}'>{$role_details['name']}</span>";
        }
    }
    echo '</div>';
    echo '<div id="selected-roles"class="selected-roles" >';
    foreach ($roles_selectionnes as $role_slug) {
        if (isset($roles_utilisateurs[$role_slug])) {
            echo "<span class='selected-role' data-role='{$role_slug}'>{$roles_utilisateurs[$role_slug]['name']} ";
            
                echo "<span class='remove-role' style='color: red; cursor: pointer;'>×</span>";
            
            echo "</span>";
        }
    }
    echo '</div>';
    echo '<input type="hidden" id="roles_utilisation_input" name="roles_utilisation" value="' . esc_attr(json_encode($roles_selectionnes)) . '">';
    echo '</td>';
    echo '</tr>';
    echo '</table>';
}

// Sauvegarde des métadonnées
function sauvegarder_metadonnees($post_id) {
    if (!isset($_POST['template_nonce']) || !wp_verify_nonce($_POST['template_nonce'], 'sauvegarder_template')) {
        return;
    }
    if (!isset($_POST['associes_nonce']) || !wp_verify_nonce($_POST['associes_nonce'], 'sauvegarder_associes')) {
        return;
    }
    if (!isset($_POST['droits_utilisation_nonce']) || !wp_verify_nonce($_POST['droits_utilisation_nonce'], 'sauvegarder_droits_utilisation')) {
        return;
    }
    if (!isset($_POST['configuration_template_nonce']) || !wp_verify_nonce($_POST['configuration_template_nonce'], 'sauvegarder_configuration_template')) {
        return ;
    }/**/

    
    //$racine=sanitize_text_field($_POST['racine']);
    
        $racine = !empty($_POST['racine'])?$_POST['racine']:sanitize_title($_POST['post_title']);  // 
        update_post_meta($post_id, '_racine', $racine);  //
    
        if (isset($_POST['expire_dans'])) {
            $expire_dans = intval($_POST['expire_dans']);
            update_post_meta($post_id, '_template_expire_dans', $expire_dans);
        }
            update_post_meta($post_id, '_associes_list', json_encode(array_map('intval', json_decode(stripslashes($_POST['associes_list']), true))));
            

        $current_version = get_post_meta($post_id, '_template_version', true);
        $current_version = $current_version ?: 'version_' . date('d_m_Y') . '_0000';

        // Extraire la partie de la version (jj, mm, aaaa) et le compteur (0000)
        preg_match('/version_(\d{2})_(\d{2})_(\d{4})_(\d{4})/', $current_version, $matches);

        if (!empty($matches)) {
            // Reconstruire la date à partir des matches
            $version_date = "{$matches[1]}_{$matches[2]}_{$matches[3]}";
            $current_count = (int)$matches[4];

            $current_date = date('d_m_Y');

            // Comparer les dates pour réinitialiser ou incrémenter le compteur
            if ($version_date !== $current_date) {
                $new_version = 'version_' . $current_date . '_0001';
            } else {
                $current_count++;
                $new_version = 'version_' . $current_date . '_' . str_pad($current_count, 4, '0', STR_PAD_LEFT);
            }
        } else {
            // Si la version actuelle n'est pas valide, définir une version initiale
            $new_version = 'version_' . date('d_m_Y') . '_0001';
        }
        if (isset($_POST['autoriser_documents'])) {
            update_post_meta($post_id, '_template_autorise_documents_joints', 'on');
        } else {
            update_post_meta($post_id, '_template_autorise_documents_joints', 'off');
        }
    
        if (isset($_POST['default_template']) && $_POST['default_template'] == '1') {
            update_option('crm_document_plugin_default_template', $post_id);
        }
        if (isset($_POST['template_autorise_generation_pdf'])) {
            update_post_meta($post_id, '_template_autorise_generation_pdf', 'on');
        } else {
            update_post_meta($post_id, '_template_autorise_generation_pdf', 'off');
        }

        // Mettre à jour la version dans le post_meta
        update_post_meta($post_id, '_template_version', $new_version);
        // Sauvegarder les rôles sélectionnés
        if (isset($_POST['roles_utilisation'])) {
            $roles_utilisation = array_map('sanitize_text_field', json_decode(stripslashes($_POST['roles_utilisation']), true));
            update_post_meta($post_id, '_template_roles_acces', json_encode($roles_utilisation));
    }
}
add_action('save_post', 'sauvegarder_metadonnees');
// Ajouter la metabox pour les droits d'utilisation


// Sauvegarder les droits d'utilisation



function charger_scripts_crm_templates() {
    global $post;
    if (isset($post->post_type) && $post->post_type === 'crm_documents') {
        

        wp_enqueue_script(
            'crm-templates',
            plugin_dir_url(__FILE__) . './crm-templates.js', //
            [],
            '1.0',
            true
        );
    }
}
add_action('admin_enqueue_scripts', 'charger_scripts_crm_templates');


function disable_autosave_for_specific_post_type() {
    global $post;
    if (isset($post) && ($post->post_type === 'crm_documents'||$post->post_type === 'crm_docs_gen')) {
        wp_deregister_script('autosave');
    }
}
add_action('admin_enqueue_scripts', 'disable_autosave_for_specific_post_type');
function supprimer_template_crm($post_id) {
    if (get_post_type($post_id) !== 'crm_documents') {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'crm_templates';

    $wpdb->delete(
        $table_name,
        ['id' => $post_id], 
        ['%d']
    );
}

add_action('before_delete_post', 'supprimer_template_crm');


