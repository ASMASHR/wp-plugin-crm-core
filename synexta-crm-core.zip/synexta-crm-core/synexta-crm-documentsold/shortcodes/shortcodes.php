<?php
require_once plugin_dir_path(__FILE__) . '../includes/dompdf/autoload.inc.php';

use Dompdf\Dompdf;
use Dompdf\Options;

/**
 * Le shortcode [crm_generation_document] Génère un formulaire pour permettre à l'utilisateur de choisir un template et de générer un document à partir de ce template.
 *
 * Ce shortcode permet à l'utilisateur de sélectionner un template à partir d'une liste de templates disponibles
 * et de générer un document basé sur ce template. Il offre également la possibilité de personnaliser le titre du document
 * généré ainsi que d'associer des documents supplémentaires à partir des templates configurés. Si l'utilisateur n'a pas de template
 * spécifié ou si l'utilisateur n'est pas validé, un message d'erreur s'affiche.
 *
 * Paramètres :
 * - title (string) : Le texte affiché sur le bouton pour générer le document. Par défaut : 'Générer un document' et peut être vide.
 * - ico (lien) : L'icone affiché avant le text sur le bouton pour générer le document. Par défaut : vide.
 *
 * Le formulaire de génération de document inclut :
 * - Un bouton pour afficher les templates.
 * - Un sélecteur pour choisir une entreprise si l'utilisateur est dans le CRM.
 * - Un sélecteur pour choisir un template disponible pour l'utilisateur courant.
 * - Un champ pour personnaliser le titre du document.
 * - La possibilité d'afficher les champs nécessaires pour le template sélectionné.
 * - Un bouton pour générer le document une fois que tous les champs sont remplis.
 *
 * @param mixed $atts Les attributs passés au shortcode, y compris 'ico' et 'title'.
 * @return bool|string Le contenu HTML du formulaire pour générer un document, ou un message d'erreur en cas de problème.
 */
function shortcode_generation_document($atts) {
    $atts = shortcode_atts([
        'title' => 'Générer un document', 
        'ico' => '', 
    ], $atts, 'crm_generation_document');
    ob_start();
    $template_id=null;
    /*if (!empty($atts['nom_template'])) {
        $template_id=get_post_id_from_title($atts['nom_template']); 
    }*/
    $current_url = $_SERVER['REQUEST_URI'];
    $user_id=null;
    $button_class = strtolower(preg_replace('/[^a-z0-9]+/', '-', $atts['title'])); 

    
    if (strpos($current_url, 'crm-customer/') !== false) {
        $hashedId = get_hashed_id_from_url(); 
        $user_id = $hashedId ? get_user_id_from_hash($hashedId) : null;
    
        if (!$user_id) {
            $output= '<p>ID utilisateur invalide ou expiré.</p>';
            return $output; 
        }
    }

    else
    {
        return '' ;
    }

    
    $current_user = wp_get_current_user();
    $user_roles = $current_user->roles;
    $args = array();
    if (in_array('utilisateur_crm', $user_roles)) {
        $args = array(
            'meta_query' => array(
                'relation' => 'OR',
                array(
                    'key' => 'user_status',
                    'value' => array('ACTIF', 'actif', 'active'),
                    'compare' => 'IN',
                ),
            ),
            //'fields' => array('ID', 'user_login', 'billing_first_name', 'billing_last_name', 'billing_address_1', 'billing_postcode', 'billing_city', 'billing_country', 'billing_phone', 'user_email'),
        );
            $users = [];
        $Allusers = get_users($args);

        foreach ($Allusers as $u){
            $associer_crm = get_user_meta($u->ID, 'associer_crm', true);
            if ($associer_crm &&in_array($current_user->ID,$associer_crm)){
                $users[] = $u;
            }
            

        }
    }
    elseif (in_array('responsable_crm', $user_roles) || in_array('administrator', $user_roles)) {
        $args = array(
            'meta_query' => array(
                'relation' => 'OR',
                array(
                    'key' => 'user_status',
                    'value' => array('ACTIF', 'actif', 'active'),
                    'compare' => 'IN',
                ),
            ),
            //'fields' => array('ID', 'user_login', 'billing_first_name', 'billing_last_name', 'billing_address_1', 'billing_postcode', 'billing_city', 'billing_country', 'billing_phone', 'user_email'),
        );
    $users = get_users($args);
    }
    else
    {
        return '';
    }
      
    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $user_crm_can_edit=is_array($associates_users) && in_array($current_user->ID, $associates_users);
    
  
      
    if (in_array('responsable_crm', $user_roles) || in_array('administrator', $user_roles) || $current_user->ID === $user_id||$user_crm_can_edit) {
    
  
    ?>
    <div id="generation-document-app">
     
        <button id="show-gen-document-sidebar-btn" class="crm-generation-document-btn <?php echo !empty($atts['ico']) ? 'crm-doc-with-icon' : ''; ?>  <?php echo !empty($button_class) ? 'template-btn-' . esc_attr($button_class) : ''; ?>" data-user-id="<?php echo $user_id ? $user_id : ''; ?>">
            <?php echo !empty($atts['ico']) ? '<img src="' . esc_url($atts['ico']) . '">' : ''; ?>
            <?php echo ($atts['title']=="Générer un document")? 'Générer un document' : esc_html($atts['title']) ; ?>
        </button>
        <div class="gen-document-sidebar"id="gen-document-sidebar"style="display:none;">
            <div class="gen-document-sidebar-header">
                    <h5 class="">Ajouter un document</h5>
                    <button class="discard-document-sidebar">X</button>
            </div>
            <div class="gen-note-sidebar-content">

            <div class="sidebar-msg-container"id="gen-document-msg"></div>

                <div class="user_select__container" style="display:none">
                    <label for="user_select"class="crm-doc-label">Choisir une entreprise :</label>
                    <select id="user_select"class="crm-doc-select" name="user_select" >
                        <?php if ($user_id==null) : ?>
                            <option value="">-- Sélectionnez une entreprise --</option>
                        <?php 
                        endif;
                        foreach ($users as $user): 
                            $nom_societe =get_user_meta($user->ID, 'billing_company', true);
                            $first_name =get_user_meta($user->ID, 'billing_first_name', true);
                            $last_name = get_user_meta($user->ID, 'billing_last_name', true);
                        
                            $prenom_nom=$last_name .' '.$first_name;
                            $entreprise_affichee = !empty($nom_societe) ? $nom_societe :( $user->display_name?$user->display_name:$prenom_nom);
                

                        ?>
                            
                            <option value="<?php echo esc_attr($user->ID); ?>"<?php echo $user_id?($user_id == $user->ID ? 'selected' : 'hidden'):''; ?> >
                            <?php echo esc_html($entreprise_affichee) ; ?>
        
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div id="templates-list"class="template_select__container" style="">
                    <label for="template-select"class="crm-doc-label">Choisir un template :</label>
                    <select id="template-select"class="crm-doc-select">
                
                    <?php 
                        if ($user_id!=null )  : ?>
                        <option value="">-- Sélectionnez un template --</option>
                        <?php
                        $user = get_userdata($user_id);
                        $templates = get_posts([
                            'post_type' => 'crm_documents',
                            'numberposts' => -1,
                        ]);
                        
                        foreach ($templates as $template) {

                        $roles_selectionnes = get_post_meta($template->ID, '_template_roles_acces', true);
                        $roles_selectionnes = $roles_selectionnes ? json_decode($roles_selectionnes, true):[];
                        if (array_intersect($roles_selectionnes, $user->roles) || in_array("administrator", $user_roles) || in_array("responsable_crm", $user_roles)) {
                            echo '<option value="' . esc_attr($template->ID) . '" ' . 
                            ($template_id ? ($template_id == $template->ID ? 'selected' : 'hidden') : '') . '>' . 
                            esc_html($template->post_title) . 
                            '</option>';}
                        }
                        ?>
                        <?php endif ;?>
                        
                    </select>
                </div>
                <div id="gen-document-sidebar-variables-list"class="crm_gen_variables_list" style="display:none;">
                
                    <p class="variables__container_title">Champs nécessaire :</p>
                    <div class="document_title_container"id="gen-document-sidebar-document-title-container"style="display:none;">
                            <label class="crm-doc-label"for="gen-document-sidebar-document-title">Titre * :</label>
                            <input class="crm-doc-input"value="" id="gen-document-sidebar-document-title" type="text" ></input>
                        </div>
                        <div class="error-message" style="color:red;display:none;">Le titre est requis.</div>
                    <div id="gen-document-sidebar-variables-container"class="variables__container"></div>
                  
                </div>  
                    
                <div id="gen-document-sidebar-associated-templates"class="associated__templates" style="display: none;"></div>
                    
                <div id="gen-document-sidebar-options-container" style="display:none;">
                </div>
                     
            </div>
            <div class="gen-document-sidebar-footer">
                    <button type="button" class="discard-document-sidebar">Fermer</button>
                            
                    <button type="submit"class="gen-document-sidebar-submit" id="gen-document-sidebar-submit"disabled>Générer le document</button>
                        
                       
                        
            </div>

            

            <div id="templates-list-error"></div>
        </div>
    </div>

    <?php
    }
   else{
    return '';
} 
return ob_get_clean();
}
add_shortcode('crm_generation_document', 'shortcode_generation_document');

/**
 * Récupère les templates accessibles à un utilisateur en fonction de son rôle.
 * 
 * Cette fonction est utilisée pour récupérer la liste des templates CRM disponibles pour un utilisateur spécifique.
 * Elle prend en compte l'ID de l'utilisateur passé via la requête GET et vérifie si l'utilisateur a le droit d'accéder aux templates,
 * en fonction des rôles qui lui sont assignés. Si l'utilisateur est un administrateur ou un responsable CRM, tous les templates sont renvoyés.
 * Sinon, seuls les templates dont les rôles d'accès sont compatibles avec ceux de l'utilisateur seront retournés.
 * 
 * Fonctionnement :
 * - Vérifie si l'ID de l'utilisateur est fourni et valide.
 * - Vérifie que l'utilisateur existe et récupère ses rôles.
 * - Récupère tous les templates CRM enregistrés.
 * - Filtre les templates en fonction des rôles associés à chaque template et des rôles de l'utilisateur.
 * - Renvoie une liste de templates accessibles sous forme de tableau avec leurs ID et titres.
 * - En cas d'erreur (ID manquant ou utilisateur introuvable), retourne un message d'erreur.
 * 
 * @return void
 */
function ajax_get_templates_by_user_role() {
    // Vérifiez si l'ID utilisateur est fourni
    if (!isset($_GET['user_id']) || empty($_GET['user_id'])) {
        wp_send_json_error(['message' => 'ID utilisateur manquant.']);
    }
    $current_user = wp_get_current_user();
    $user_roles = $current_user->roles;
    

    $user_id = intval($_GET['user_id']);
    $user = get_userdata($user_id);

    if (!$user) {
        wp_send_json_error(['message' => 'Utilisateur non trouvé.']);
    }
    $templatesDispo = get_posts([
        'post_type' => 'crm_documents',
        'numberposts' => -1,
    ]);
    $templates = [];
    foreach ($templatesDispo as $template) {

        $roles_selectionnes = get_post_meta($template->ID, '_template_roles_acces', true);
        $roles_selectionnes = $roles_selectionnes ? json_decode($roles_selectionnes, true):[];
        if (array_intersect($roles_selectionnes, $user->roles) || in_array("administrator", $user_roles) || in_array("responsable_crm", $user_roles)) {
            $templates[] =['id'=>$template->ID,'title'=>$template->post_title];
        }
    }

    wp_send_json_success(['templates' => $templates]);
    ob_end_clean();
}
add_action('wp_ajax_get_templates_by_user_role', 'ajax_get_templates_by_user_role');

/**
 * Récupère les variables d'un template et les informations associées à un utilisateur.
 * 
 * Cette fonction est utilisée pour extraire les variables d'une template (contenu dynamique entre accolades)
 * et les informations pertinentes liées à l'utilisateur qui demande ces variables.
 * Elle permet également de récupérer les templates associés au template principal, ainsi que les variables de ces templates associés.
 * Les informations utilisateur comme le nom, le prénom, et le nom de société sont utilisées pour remplir les variables prédéfinies.
 * 
 * Fonctionnement :
 * - Récupère l'ID du template et de l'utilisateur via les paramètres GET.
 * - Extrait toutes les variables (entre accolades) du contenu du template.
 * - Récupère les templates associés au template principal, et pour chaque template associé :
 *   - Vérifie si l'utilisateur a le droit d'y accéder en fonction de ses rôles.
 *   - Extrait également les variables du contenu des templates associés.
 * - Récupère des informations utilisateurs comme le nom de société, le prénom et le nom pour remplir certaines variables.
 * - Regroupe toutes les variables uniques du template et de ses templates associés.
 * - Récupère des données supplémentaires comme la version du template et les documents générés associés.
 * - Renvoie un objet JSON contenant :
 *   - Les variables uniques.
 *   - Les métadonnées du template.
 *   - Les valeurs pré-remplies des variables à partir des informations de l'utilisateur.
 *   - Les templates associés et leurs données.
 *   - Le nombre de documents générés à partir du template.
 * 
 * @return void
 */


function ajax_get_template_variables() {
    $template_id = intval($_GET['template_id']);
    $user_id = intval($_GET['user_id']);
    $user = get_userdata($user_id);

    $template_content = get_post_field('post_content', $template_id);
    preg_match_all('/\{([^\}]+)\}/', $template_content, $matches);
    $variables = array_unique($matches[1]);

    $template_meta = get_post_meta($template_id);
    $associated_templates = get_post_meta($template_id, '_associes_list', true); 
    $associated_templates = json_decode($associated_templates, true);
    $associated_variables = [];
    $associated_templates_data= [];
    $nom_societe =get_user_meta($user_id, 'billing_company', true);
    $first_name =get_user_meta($user_id, 'billing_first_name', true);
    $last_name = get_user_meta($user_id, 'billing_last_name', true);
   
    $prenom_nom=$last_name .' '.$first_name;
    $societeNom = !empty($nom_societe) ? $nom_societe :( $prenom_nom?$prenom_nom:$user->display_name);
    $current_user = wp_get_current_user();

// Récupérer le nom et le prénom ou, à défaut, le display_name
$creatorNom = !empty($current_user->user_lastname) && !empty($current_user->user_firstname) 
    ? $current_user->user_firstname . ' ' . $current_user->user_lastname 
    : $current_user->display_name;

    
    $autorise_documents_joints = get_post_meta($template_id, '_template_autorise_documents_joints', true);
    //$formattedDate = date('y') . date('m');
    
    $formattedDate = date('d-m');
    if ($associated_templates) {
        foreach ($associated_templates as $associated_template_id) {
            $roles_selectionnes = get_post_meta($associated_template_id, '_template_roles_acces', true);
            $roles_selectionnes = $roles_selectionnes ? json_decode($roles_selectionnes, true):[];
            if (array_intersect($roles_selectionnes, $user->roles) || in_array("administrator", $user->roles) || in_array("responsable_crm", $user->roles)) {
                $associated_content = get_post_field('post_content', $associated_template_id);
                preg_match_all('/\{([^\}]+)\}/', $associated_content, $assoc_matches);
                $associated_variables = array_merge($associated_variables, $assoc_matches[1]);
                $associated_template_name = get_the_title($associated_template_id);
                $template_version = get_post_meta($associated_template_id, '_template_version', true);
                $templateRacine = get_post_meta($associated_template_id, '_racine', true);
                $generatedPostTitle =$formattedDate.' - '.$societeNom.' - '. $associated_template_name  ;
                $associated_templates_data[]=[
                    'id' => $associated_template_id,
                    'name' => $associated_template_name,
                    'nom_doc'=>$generatedPostTitle
                ];
            }
        }
        $associated_variables = array_unique($associated_variables);
    }
    $variables = array_merge($associated_variables, $variables);
    $variables = array_unique($variables);
    
    $pre_filled = [];
    foreach ($variables as $variable) {
        $meta_value = get_user_meta($user_id, $variable, true);
        if ($meta_value) {
            $pre_filled[$variable] = $meta_value;
        }
        if($variable=="display_author_name"|| $variable=="display_author_name*"||$variable=="display_author_name *"){
         
            $pre_filled[$variable] = $creatorNom;   
        }
        $variable_cleaned = str_replace(['@', '*'], '', $variable);

    if ($variable_cleaned == "display_author_bio") { 
            $pre_filled[$variable] = $current_user->description;;   
        }
    }

    wp_send_json_success([
        'variables' => $variables,
        'template_meta' => $template_meta,
        'pre_filled' => $pre_filled,
        'user_id' => $user_id,
        'racine' => get_post_meta($template_id, '_racine', true),
        'compteur' => count(get_posts([
            'post_type'   => 'crm_docs_gen',
            'meta_key'    => '_used_template_id',
            'meta_value'  => $template_id,
            'numberposts' => -1,
        ])),
        'associated_templates' => $associated_templates,
        'associated_templates_data' => $associated_templates_data,
        'templateNom' => get_the_title($template_id),
        'societeNom'=>$societeNom,
        'autorise_documents_joints'=>$autorise_documents_joints,
        'creatorNom'=>$creatorNom
    ]);
}

add_action('wp_ajax_get_template_variables', 'ajax_get_template_variables');
/**
 * Le shortcode [crm_notes] Génère un note à partir d'une template par defaut.
 *
 *
 * Paramètres :
 * - title (string) : Le texte affiché sur le bouton pour générer le document. Par défaut : 'Ajouter une note' et peut être vide.
 * - ico (lien) : L'icone affiché avant le text sur le bouton pour générer le document. Par défaut : vide.
 *
 * Le formulaire de génération de document inclut :
 * - Un bouton pour afficher le sidebar.
 * - La possibilité d'afficher les champs nécessaires pour le template ajouté par defaut .
 * - Un bouton pour générer la note une fois que tous les champs sont remplis.
 *
 * @param mixed $atts Les attributs passés au shortcode, y compris 'ico' et 'title'.
 * @return bool|string Le contenu HTML du formulaire pour générer un document, ou un message d'erreur en cas de problème.
 */
function shortcode_generation_notes($atts) {
    $atts = shortcode_atts([
        'title' => 'Ajouter une note', 
        'ico' => '', 
    ], $atts, 'crm_notes');
    ob_start();
   
    $current_url = $_SERVER['REQUEST_URI'];
    $user_id=null;
    $button_class = strtolower(preg_replace('/[^a-z0-9]+/', '-', $atts['title'])); 
    $default_template_id=get_option( 'crm_document_plugin_default_template');
    
    if (strpos($current_url, 'crm-customer/') !== false) {
        $hashedId = get_hashed_id_from_url(); 
        $user_id = $hashedId ? get_user_id_from_hash($hashedId) : null;
    
        if (!$user_id) {
            $output= '<p>ID utilisateur invalide ou expiré.</p>';
            return $output; 
        }
    }
    else
    {
        return '' ;
    }

    
    $current_user = wp_get_current_user();

    $associates_users = get_user_meta($user_id, 'associer_crm', true);
    $roles = $current_user->roles;
    $user_crm_can_edit=is_array($associates_users) && in_array($current_user->ID, $associates_users);
    
  
      
    if (in_array('responsable_crm', $roles) || in_array('administrator', $roles) || $current_user->ID === $user_id||$user_crm_can_edit) {
    ?>
    <div id="gen-note-app">
     
        <button id="show-note-sidebar-btn" 
         data-user-id="<?php echo esc_attr($user_id); ?>"  
         data-template-id="<?php echo esc_attr($default_template_id); ?>" 
         class="crm-gen-note-btn <?php echo !empty($atts['ico']) ? 'crm-doc-with-icon' : ''; ?>  <?php echo !empty($button_class) ? 'crm-gen-notes-btn-' . esc_attr($button_class) : ''; ?>" data-user-id="<?php echo $user_id ? $user_id : ''; ?>">
            <?php
            
            echo !empty($atts['ico']) ? '<img src="' . esc_url($atts['ico']) . '">' : ''; ?>
            <?php echo ($atts['title']=="Ajouter une note")? 'Ajouter une note' : esc_html($atts['title']) ; ?>
        </button>

       
        <div id="gen-note-sidebar"class="crm_gen_note_sidebar" style="display:none;">
            <div class="gen-note-sidebar-header">
                    <h5 class="">Ajouter une note</h5>
                    <button class="discard-note-sidebar">X</button>
            </div>
            <div class="gen-note-sidebar-content">
                <div class="sidebar-msg-container"id="gen-note-msg"></div>
                
                
                    <input type="text" value="<?php echo ($user_id?$user_id : '') ; ?>" id="note_user_id" hidden>
                    <input type="text" value="<?php echo ($default_template_id?$default_template_id : '') ; ?>" id="note_template_id" hidden>
                    <div class="document_title_container" style="display:none">
                            <label class="crm-doc-label"for="note-title" >Titre * : </label>
                            <input class="crm-doc-input"type="text"id="note-title" readonly>    
                            <div class="error-message"style="display:none">Le titre est obligatoire</div>
                    
                    </div>
                    <!--<p class="variables__container_title">Champs nécessaire :</p>-->
                    <div id="note-variables-container"class="variables__container">

                    </div>
                    <div id="gen-note-sidebar-options-container" style="display:none;">
                    </div>
                
            </div>
            <div class="gen-note-sidebar-footer">
                    <button type="button" class="discard-note-sidebar">Fermer</button>
                            
                    <button type="submit"class="gen-note-sidebar-submit" id="generate-note-btn">Générer la note</button>
                        
                       
                        
            </div>
            
        </div>
        

    </div>
    

    <?php
    }
    else{
        return '' ;
    }
    return ob_get_clean();
}
add_shortcode('crm_notes', 'shortcode_generation_notes');



/**
 * Génère un fichier PDF à partir du contenu d'un article et l'enregistre dans un répertoire spécifique.
 * 
 * Cette fonction prend le contenu d'un article WordPress, le formate en HTML et génère un PDF avec le contenu 
 * en utilisant la bibliothèque Dompdf. Elle ajoute également un pied de page avec un texte personnalisé et un 
 * numéro de page, puis sauvegarde le fichier PDF dans un répertoire spécifique du système de fichiers WordPress.
 * 
 * Fonctionnement :
 * - Récupère le contenu de l'article via son ID.
 * - Applique les styles CSS par défaut et les styles supplémentaires d'un fichier CSS externe.
 * - Crée un fichier HTML avec le contenu de l'article.
 * - Utilise Dompdf pour générer un fichier PDF à partir de l'HTML.
 * - Ajoute un pied de page avec le texte configuré dans les options WordPress et un numéro de page dynamique.
 * - Sauvegarde le fichier PDF dans un dossier personnalisé sous le répertoire des uploads WordPress.
 * - Renvoie l'URL du fichier PDF généré.
 * 
 * @param mixed $postId ID de l'article dont le contenu sera utilisé pour générer le PDF.
 * @param mixed $content Le contenu de l'article à convertir en PDF.
 * @param mixed $filename Le nom du fichier PDF généré.
 * @return string L'URL du fichier PDF généré.
 */
function generate_pdf($postId, $content, $filename) {
    $post = get_post($postId);
    $user_id=get_post_meta($postId, '_generated_doc_user_id',true);
    $user_info = get_userdata($user_id);
    $vosfactures_id=get_post_meta($user_id, 'vosfactures_id',true);
    $user_login = $user_info->user_login??$vosfactures_id;
    if (empty($user_login)) {
        wp_send_json_error("Le login de l'utilisateur est vide pour l'ID utilisateur : $user_id");
        
    }
    
    $year = date('Y');
    $postContenu = nl2br($post->post_content);

    // Récupération du texte pour le footer
    $footerText = get_option('crm_footer_text', '');

    $cssFilePath = plugin_dir_path(__FILE__) . '../assets/css/pdf-css-file.css';
    $cssStyles = null;
    if (file_exists($cssFilePath)) {
        $cssStyles = file_get_contents($cssFilePath);
    }

    $defaultStyles = "
    body {
        margin: 0;
        padding: 0;
        position: relative;
    }

 
    .content {
        padding-bottom: 40px;
    }
    ";

    $html = "
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            $defaultStyles
            $cssStyles
        </style>
    </head>
    <body>
        <div class='content'>
            $postContenu
        </div>
       
    </body>
    </html>
    ";

    // Crée l'objet Dompdf avec les options
    $options = new Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isPhpEnabled', true);
    $options->set('isRemoteEnabled', true);
    $dompdf = new Dompdf($options);

    // Charge le HTML dans DomPDF
    $dompdf->loadHtml($html);

    $dompdf->setPaper('A4', 'portrait');

    $dompdf->render();

    $canvas = $dompdf->getCanvas();
    $pageCount = $canvas->get_page_count();

    // Script pour insérer le pied de page et la ligne en haut de chaque page
$canvas->page_script(function ($pageNumber, $pageCount, \Dompdf\Canvas $canvas) use ($footerText) {
    $pageWidth = $canvas->get_width();
    $pageHeight = $canvas->get_height();

    // Dessin de la ligne en haut du pied de page
    $footerLineY = $pageHeight - 45; // Ajustez la position Y selon vos besoins
    $canvas->line(20, $footerLineY, $pageWidth - 20, $footerLineY, [0, 0, 0], 1);

    // Texte du pied de page
    $font = 'Arial, Helvetica, sans-serif';
    $fontSize = 9;
    $footerTextPlain = strip_tags(str_replace(['<br>', '<br/>', '<br />'], "\n", $footerText));
    $footerTextPlain = preg_replace('/<\/?p[^>]*>/', "\n", $footerTextPlain);
    $footerTextPlain = trim($footerTextPlain);
    $lines = explode("\n", $footerTextPlain);
    $lineHeight = 12;
    $color = [0.5, 0.5, 0.5];

    foreach ($lines as $i => $line) {
        $textWidth = $canvas->get_text_width($line, $font, $fontSize);
        $startX = ($pageWidth - $textWidth) / 2;
        $canvas->text($startX, $footerLineY + 5 + ($i * $lineHeight), $line, $font, $fontSize, $color);
    }

    // Numéro de page
    $pageText = 'page ' . $pageNumber . ' sur ' . $pageCount;
    $textWidth = $canvas->get_text_width($pageText, $font, $fontSize);
    $canvas->text($pageWidth - $textWidth - 20, $pageHeight - 15, $pageText, $font, $fontSize, $color);
});


    $output = $dompdf->output();

    // Chemin de stockage des fichiers PDF
    $upload_dir = wp_upload_dir();
    //$custom_dir = $upload_dir['basedir'] . '/documents-crm';
    $custom_dir = $upload_dir['basedir'] . "/documents-crm/$user_login/$year";
    if (!file_exists($custom_dir)) {
        mkdir($custom_dir, 0755, true);
    }

    $file_path = $custom_dir . '/' . $filename;
    file_put_contents($file_path, $output);

 $pdf_url = $upload_dir['baseurl'] . "/documents-crm/$user_login/$year/$filename";
   return $pdf_url;
    //return $upload_dir['baseurl'] . '/documents-crm/' . $filename;
}

/**
 * Gère la génération et l'enregistrement de documents basés sur une template, avec prise en charge de la génération de PDF et de pièces jointes.
 *
 * Cette fonction effectue les tâches suivantes :
 * 1. Récupère et valide les données de la requête AJAX, notamment l'ID du modèle, l'ID de l'utilisateur, les variables et le titre du document.
 * 2. Remplace les variables dans le contenu du modèle par les valeurs fournies.
 * 3. Crée un nouveau post WordPress de type `crm_docs_gen` pour stocker le document généré.
 * 4. Si autorisé, génère une version PDF du document et enregistre son URL en tant que métadonnée.
 * 5. Gère l'ajout de fichiers supplémentaires en les téléchargeant dans un répertoire personnalisé et en enregistrant leurs URL.
 * 6. Permet la génération de documents associés à partir des modèles sélectionnés, en appliquant les remplacements de variables et en créant des posts supplémentaires de type `crm_docs_gen`.
 * 7. Met à jour les métadonnées des documents générés, y compris les dates d'expiration, la version du modèle, l'ID de l'utilisateur et les modèles associés.
 *
 * Paramètres (récupérés depuis `$_POST`) :
 * - `template_id` (int) : ID du modèle de base.
 * - `user_id` (int) : ID de l'utilisateur générant le document.
 * - `variables` (array) : Paires clé-valeur pour remplacer les variables dans le modèle.
 * - `doctitle` (string) : Titre du document généré.
 * - `selectedTemplates` (array) : Modèles supplémentaires pour générer des documents associés.
 * - `additional_files` (array) : Fichiers joints optionnels à télécharger.
 *
 * Métadonnées et comportement spécifique :
 * - Vérifie si le modèle autorise la génération de PDF (`_template_autorise_generation_pdf`).
 * - Calcule les dates d'expiration des documents générés à l'aide d'une fonction utilitaire.
 * - Traite et sécurise les téléchargements de fichiers pour empêcher les extensions non sûres.
 * - Génère des documents associés en appliquant les variables et en créant de nouveaux posts.
 *
 * Retourne :
 * - Envoie une réponse JSON contenant le statut et les détails des documents générés.
 *
 * Utilisation :
 * Cette fonction est déclenchée via un appel AJAX dans un environnement WordPress et est utilisée pour créer et gérer dynamiquement des documents liés au CRM.
  * @return void
*/


function ajax_save_generated_document() {

    $template_id = intval($_POST['template_id']);
    $user_id = intval($_POST['user_id']);
    $doctitle = $_POST['doctitle'];
    $selectedTemplates=$_POST['selectedTemplates'];
    $template_version = get_post_meta($template_id, '_template_version', true);
    $template_autorise_generation_pdf = get_post_meta($template_id, '_template_autorise_generation_pdf', true);
    $user_info = get_userdata($user_id);
    $vosfactures_id=get_post_meta($user_id, 'vosfactures_id',true);
    $user_login = $user_info->user_login??$vosfactures_id;

    $year = date('Y');
    $rawVariables = $_POST['variables']; 
    $cleanJson = stripslashes($rawVariables);
    $variables = json_decode($cleanJson, true); 
    if (isset($variables['undefined'])) {
        unset($variables['undefined']);
    }
    //wp_send_json_error([    'message' => $template_autorise_generation_pdf . 'zzzzzzzz' . ($template_autorise_generation_pdf && $template_autorise_generation_pdf == "on" ? 'entre' : 'nnn')]);

    $formattedDate = date('y') . date('m');
    $template_post = get_post($template_id);
    $contenu = $template_post->post_content;
    foreach ($variables as $variable => $value) {
        
            if($variable=="document_name"){
                $value=$doctitle;
            }

            if (strpos($variable, '@') !== false) {
                // Insérer directement du HTML si '#' est présent
                $regex = "/\{" . preg_quote($variable, '/') . "\}/";
                $contenu = preg_replace($regex, $value, $contenu); // Pas d'échappement pour conserver le HTML brut
            } 
            else {
            
            $regex = "/\{" . preg_quote($variable, '/') . "\}/";
            $contenu = preg_replace($regex, ' <b>' . esc_html($value) . '</b> ', $contenu); 
            }
    }
    
    $post_id = wp_insert_post([
        'post_title'   => $doctitle,
        'post_type'    => 'crm_docs_gen',
        'post_content' => $contenu,
        'post_status'  => 'publish',
    ]);
    $documents_associe=[];
    $post_info=[];
    if ($post_id && !is_wp_error($post_id)) {
        $post_info=['post_id' => $post_id,'post_title'=>$doctitle];

        update_post_meta($post_id, '_generated_doc_user_id',$user_id);
        /**/if($template_autorise_generation_pdf&&$template_autorise_generation_pdf=="on")
        {
            //$pdf_url = generate_pdf($post_id,$contenu, 'generated_doc_' . $post_id . '.pdf');

            $pdf_url = generate_pdf($post_id,$contenu, $doctitle . '.pdf');
            //update_post_meta($post_id, '_generated_doc_pdf_url', $pdf_url);
            update_post_meta($post_id, '_pdf_url', $pdf_url);
            $post_info['file_url'] = $pdf_url;
        }
        else{
           // update_post_meta($post_id, '_generated_doc_pdf_url', null);

            update_post_meta($post_id, '_pdf_url', null);
          
        }
        update_post_meta($post_id, '_used_template_id', $template_id);
        update_post_meta($post_id, '_used_template_version', $template_version);
        update_post_meta($post_id, '_generated_doc_vars', json_encode($variables));
        ///////////////////////////////////
        //selectedTemplates:selectedTemplates 
        $date_expiration_doc_principale=calculer_date_expiration($template_id,$post_id);
        update_post_meta($post_id, '_generated_doc_expiration_date', $date_expiration_doc_principale['date_expiration']);
        update_post_meta($post_id, '_generated_doc_expiration_date_timestamp', $date_expiration_doc_principale['date_expiration_timestamp']);
        /////////////////
        $autorise_documents_joints = get_post_meta($template_id, '_template_autorise_documents_joints', true);
        
        if ($autorise_documents_joints && $autorise_documents_joints === "on" && isset($_FILES['additional_files'])) {
            $uploaded_files = [];
            $file_count = count($_FILES['additional_files']['name']);
            $upload_dir = wp_upload_dir();

            $custom_dir = $upload_dir['basedir'] . "/documents-crm/$user_login/$year";
            //$custom_dir = $upload_dir['basedir'] . '/documents-crm';

            
                if (!file_exists($custom_dir)) {
                    mkdir($custom_dir, 0755, true);
                }
        
                for ($i = 0; $i < $file_count; $i++) {
                    $original_name = $_FILES['additional_files']['name'][$i];
                    $tmp_name = $_FILES['additional_files']['tmp_name'][$i];
                    $file_ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
        
                    // Vérification des extensions interdites
                    $forbidden_extensions = ['php', 'js', 'exe', 'bat', 'sh'];
                    if (in_array($file_ext, $forbidden_extensions)) {
                        continue; // Ignorer ce fichier
                    }
        
                    // Génération du nom sécurisé
                    $safe_name = sanitize_file_name($original_name);
                     $new_name = "{$doctitle} - {$safe_name}";
                    $new_name = preg_replace('/[^a-zA-Z0-9._-]/', '', $new_name); 
                    $target_file = $custom_dir . '/' . $new_name;
        
                    if (move_uploaded_file($tmp_name, $target_file)) {
                        $uploaded_files[] = $upload_dir['baseurl'] . "/documents-crm/$user_login/$year/$new_name";
                    }
                }
        
             
        
            if (!empty($uploaded_files)) {
                update_post_meta($post_id, '_generated_doc_pieces_joints', $uploaded_files);
            }

        }
    
        ///////////////////
              
        if(!empty($selectedTemplates)){

            //$templates = array_map('intval', $_POST['selectedTemplates']);
            $nouveaux_documents = [];
            foreach ($selectedTemplates as $associe) {
                $associe_id= $associe['id'];
                $nom_doc=$associe['nom_doc'];
                $template_post = get_post($associe_id);
                $associe_autorise_generation_pdf = get_post_meta($associe_id, '_template_autorise_generation_pdf', true);
    
                if (!$template_post) {
                    continue;
                }

                $templateRacine = get_post_meta($associe_id, '_racine', true);
                $formattedDate = date('y') . date('m');;

            
                $compteur = count(get_posts([
                    'post_type'   => 'crm_docs_gen',
                    'meta_key'    => '_used_template_id',
                    'meta_value'  => $associe_id,
                    'numberposts' => -1,
                ]));

                $template_version = get_post_meta($associe_id, '_template_version', true);
                
                //$compteurFormate = str_pad($compteur, 4, '0', STR_PAD_LEFT);
                $compteurFormate = $compteur; 
                $generatedPostTitle = $templateRacine .'-' . $formattedDate. '-'.$compteurFormate;
                $used_values = [];
                // Remplacer les variables par les valeurs
                $associeContenu = $template_post->post_content;
                
                    preg_match_all('/\{([\w]+)\}/', $associeContenu, $matches);
                    $used_variables = $matches[1];

                    // Associer les valeurs correspondantes
                
                    foreach ($used_variables as $variable) {
                        if (isset($variables[$variable])) {
                            if($variable=="reference_template")
                            {
                                $used_values[$variable]=$templateRacine.'-' . $formattedDate.'-'.$compteurFormate;
                            }
                            elseif ($variable === 'template_name') {
                                $used_values[$variable]= get_the_title($associe_id);
                            }
                            elseif($variable=="document_name"){
                                $used_values[$variable]=$nom_doc;
                            }
                            elseif ($variable === 'creation_date') {
                            $day = str_pad(date('d'), 2, '0', STR_PAD_LEFT); // Jour avec deux chiffres
                            $month = str_pad(date('m'), 2, '0', STR_PAD_LEFT); // Mois avec deux chiffres
                            $year = date('Y'); 
                            $used_values[$variable] = "{$day} {$month} {$year}"; 
                        }
                            else{

                            $used_values[$variable] = $variables[$variable];
                            }
                        }
                    }
                    foreach ($variables as $variable => $value) {
                        if($variable=="reference_template")
                        {
                            $value=$templateRacine.'-' . $formattedDate.'-'.$compteurFormate;
                        }
                        elseif ($variable === 'template_name') {
                            $value= get_the_title($associe_id);
                          }
                          elseif($variable=="document_name"){
                            $_SESSIONvalue=$nom_doc;
                        }
                          elseif ($variable === 'creation_date') {
                            $day = str_pad(date('d'), 2, '0', STR_PAD_LEFT); // Jour avec deux chiffres
                            $month = str_pad(date('m'), 2, '0', STR_PAD_LEFT); // Mois avec deux chiffres
                            $year = date('Y'); 
                            $value= "{$day} {$month} {$year}"; 
                        }
                        $regex = "/\{" . preg_quote($variable, '/') . "\}/";
                        $associeContenu = preg_replace($regex, ' <b>' . esc_html($value) . '</b> ', $associeContenu);                    
                    }
               

                // Ajouter un nouveau post avec ses métadonnées
                $nouveau_document_id = wp_insert_post([
                    'post_type' => 'crm_docs_gen',
                    //'post_title' => $generatedPostTitle,
                    'post_title' => $nom_doc,
                    'post_content' => $associeContenu,
                    'post_status' => 'publish',
                    'post_author' => get_current_user_id(),
                ]);

                if ($nouveau_document_id) {
                    $pdf_url1=null;
                    if($associe_autorise_generation_pdf&&$associe_autorise_generation_pdf=="on")
                    { 
                        //$pdf_url1 = generate_pdf($nouveau_document_id,$associeContenu, 'generated_doc_' . $associe_id . '.pdf');
                        $pdf_url1 = generate_pdf($nouveau_document_id,$associeContenu, $nom_doc.'.pdf');
                       update_post_meta($associe_id, '_pdf_url', $pdf_url1);
               
                    }
                    else{
                        update_post_meta($associe_id, '_pdf_url', null);

                    }

               
                    $documents_associe[]=['post_id' => $nouveau_document_id,
                    'post_title'=>$nom_doc,
                    'file_url'=>$pdf_url1
                    ];

                    $template_expire_dans=get_post_meta($associe_id, '_template_expire_dans');
                    $date_expiration_doc=calculer_date_expiration($associe_id,$nouveau_document_id);
                    add_post_meta($nouveau_document_id, '_used_template_version', $template_version);
                    add_post_meta($nouveau_document_id, '_generated_doc_user_id', $user_id);
                    add_post_meta($nouveau_document_id, '_used_template_id', $associe_id);
                    add_post_meta($nouveau_document_id, '_generated_doc_vars', wp_json_encode($used_values));
                    update_post_meta($nouveau_document_id, '_generated_doc_expiration_date_timestamp', $date_expiration_doc['date_expiration_timestamp']);
       
                    add_post_meta($nouveau_document_id, '_generated_doc_expiration_date', $date_expiration_doc['date_expiration']);
                    $nouveaux_documents[] = $nouveau_document_id;
                }
            }

            if (!empty($nouveaux_documents)) {
                update_post_meta($post_id, '_documents_associes_list', $nouveaux_documents);
            }

        }
                //////////////////wp_send_json_success(['post_info'=>$post_info,'documents_associe'=>$documents_associe]);
                $hashedId=crm_documents_generate_user_hash($user_id);
                $url = "crm-customer/$hashedId";
            wp_send_json_success(['url_redirection'=>$url,'user_id'=>$user_id,'hashedId'=>$hashedId]);
    } 
    else {
        
        wp_send_json_error(['message' => 'Erreur lors de la création du document.']);
    }
}
add_action('wp_ajax_save_generated_document', 'ajax_save_generated_document');

/**
 * Génère un hash unique pour un utilisateur donné en utilisant une clé secrète.
 *
 * Cette fonction utilise l'algorithme HMAC-SHA256 pour créer un hash sécurisé basé sur l'ID de l'utilisateur 
 * et une clé secrète prédéfinie. Le hash peut être utilisé pour identifier de manière unique l'utilisateur 
 * dans des contextes sécurisés, comme la génération de liens temporaires, l'authentification ou d'autres 
 * mécanismes nécessitant une sécurité accrue.
 *
 * @param mixed $user_id L'ID de l'utilisateur pour lequel le hash doit être généré.
 * @return string Le hash généré sous forme de chaîne.
 */
function crm_documents_generate_user_hash($user_id) {
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
    return hash_hmac('sha256', $user_id, $secret_key);
}
/**
 * Calcule la date d'expiration d'un document basé sur un modèle (template).
 *
 * Cette fonction détermine la date d'expiration en fonction de la durée de validité (`_template_expire_dans`) 
 * spécifiée pour le modèle. Elle prend en compte la date de création du modèle et la date d'utilisation du document.
 * Si la durée d'expiration est définie et valide, la date d'expiration est calculée. Sinon, elle renvoie une expiration illimitée.
 *
 * @param int $template_id L'ID du modèle (template).
 * @param int $document_id L'ID du document.
 * @return array Un tableau contenant :
 * - `date_expiration_timestamp` : Le timestamp de la date d'expiration, ou PHP_INT_MAX si illimité.
 * - `date_expiration` : La date d'expiration au format 'Y-m-d', ou `null` si illimité.
 */

function calculer_date_expiration($template_id,$document_id) {
    // Récupérer la valeur de `_template_expire_dans`
    $template_post = get_post($template_id);
    $document_post = get_post($document_id);

    if (!$template_post || !$document_post) {
        return [
            'error' => 'Template ou document introuvable'
        ];
    }

    // Récupérer les dates de création
    $date_creation_template = $template_post->post_date; 
    $date_utilisation_document = $document_post->post_date; 

    $template_expire_dans = get_post_meta($template_id, '_template_expire_dans', true);

   
    if ($template_expire_dans && intval($template_expire_dans) > 0) {
        $template_expire_dans = intval($template_expire_dans); 

        $timestamp_creation = strtotime($date_creation_template);
        $timestamp_utilisation = strtotime($date_utilisation_document);

        $jours_ecoules = ($timestamp_utilisation - $timestamp_creation) / (60 * 60 * 24);

        //$jours_restants = max(0, $template_expire_dans - $jours_ecoules);
        $jours_restants=$template_expire_dans;
        $date_expiration = date('Y-m-d', $timestamp_utilisation + ($jours_restants * 60 * 60 * 24));
        $date_creation_timestamp = strtotime($date_expiration);
        return [
           'date_expiration_timestamp' => $date_creation_timestamp,
            'date_expiration' => $date_expiration
        ];
    }

    // Pas d'expiration (0 ou non défini)
    return [
      //  'jours_restants' => 'Illimité',
      'date_expiration_timestamp' => PHP_INT_MAX,
        'date_expiration' => null
    ];
}

/**
 * Enfile les scripts et les styles nécessaires pour le plugin.
 *
 * Cette fonction charge les fichiers JavaScript et CSS nécessaires au fonctionnement 
 * du plugin. Elle inclut également les bibliothèques externes, comme Quill.js, et 
 * fournit des variables JavaScript via `wp_localize_script` pour permettre la communication 
 * AJAX sécurisée avec le serveur.
 *
 * - `crm-documents-shortcode` : Script principal du plugin pour gérer les shortcodes.
 * - `quill-css` et `quill-js` : Bibliothèque Quill.js pour fournir un éditeur de texte enrichi.
 * - `mon-plugin-style` : Feuille de style CSS spécifique au plugin.
 * - Les données localisées dans `ajax_object` :
 *   - `ajax_url` : L'URL pour effectuer des requêtes AJAX vers WordPress.
 *   - `security` : Un nonce pour sécuriser les requêtes AJAX.
 *
 * @return void
 */

function mon_plugin_enqueue_scripts() {
    wp_enqueue_script(
        'crm-documents-shortcode',
        plugin_dir_url(__FILE__) . 'shortcodes.js',
        array('jquery'),
        null,
        true
    );
    wp_enqueue_style('quill-css', 'https://cdn.quilljs.com/1.3.6/quill.snow.css');
        wp_enqueue_script('quill-js', 'https://cdn.quilljs.com/1.3.6/quill.min.js', array(), null, true);
    wp_localize_script(
        'crm-documents-shortcode',
        'ajax_object',
        array('ajax_url' => admin_url('admin-ajax.php'),
        'security' => wp_create_nonce('delete-document-nonce'),)
    );

    wp_enqueue_style(
        'mon-plugin-style',
        plugin_dir_url(__FILE__) . 'shortcodes.css'
    );
}
add_action('wp_enqueue_scripts', 'mon_plugin_enqueue_scripts');

/**
 * Le shortcode [crm_documents_generes] utilisé pour afficher une liste des documents générés dans le CRM.
 * Ce shortcode permet de récupérer et d'afficher les documents générés par l'utilisateur actuel ou ceux associés à un utilisateur spécifique,
 * en fonction de l'URL ou des rôles de l'utilisateur. Il inclut des filtres par template et utilisateur, ainsi que des options de tri dynamiques.
 * 
 * Fonctionnalités principales :
 * 1. **Filtrage par template** : Permet de filtrer les documents en fonction d'un template spécifique.
 * 2. **Gestion des rôles d'utilisateur** : Affiche les documents en fonction des rôles de l'utilisateur (utilisateur_crm, administrateur, responsable_crm, etc.).
 * 3. **Filtrage par utilisateur spécifique** : Si l'URL contient un identifiant d'utilisateur, seuls les documents associés à cet utilisateur sont affichés.
 * 4. **Critères de récupération des documents** : Récupère les documents en fonction de l'ID du template et de l'ID de l'utilisateur.
 * 5. **Tri des documents** : Permet de trier les documents par date, avec des options pour inverser l'ordre du tri.
 * 6. **Affichage sous forme de tableau** : Affiche les documents sous forme de tableau avec des liens vers les PDF associés.
 * 7. **Modification via Sidebar** : Ajoute une sidebar qui permet à l'utilisateur de modifier le contenu des documents, gérer les documents qui lui sont attachés, et régénérer le document PDF. 

 * 8. **URL de tri dynamique** : Permet de modifier dynamiquement l'ordre de tri des documents via l'interface.
 * 
 * @param mixed $atts Attributs du shortcode (ex. 'nom_template' pour filtrer par template).
 * @return string Tableau HTML contenant les documents générés ou un message si aucun document n'est trouvé.
*/
function crm_documents_generes_shortcode($atts) {
    $atts = shortcode_atts(array(
        'nom_template' => '',
    ), $atts, 'afficher_documents_generes');
    $template_id=null;
    if (!empty($atts['nom_template'])) {
        $template_id=get_post_id_from_title($atts['nom_template']); 
    }
    $current_user = wp_get_current_user();
    $user_roles = $current_user->roles;
    $current_user_id = $current_user->ID;
    
    $current_url = $_SERVER['REQUEST_URI'];
    $user_id = null;

    // Vérification de l'ID utilisateur dans l'URL pour crm-customer
    if (strpos($current_url, 'crm-customer/') !== false) {
        $hashedId = get_hashed_id_from_url();
        $user_id = $hashedId ? get_user_id_from_hash($hashedId) : null;

        if (!$user_id || !get_userdata($user_id)) {
            return '<p>ID utilisateur invalide ou expiré.</p>';
        }
    }

    else
    {
        return '' ;
    }

    // Initialisation des critères de récupération des documents
    $meta_query = array();
    
    if($template_id){
        $meta_query[] = array(
            'key' => '_used_template_id',
            'value' => $template_id,
            'compare' => 'IN',
        );
    }
    if (in_array('utilisateur_crm', $user_roles)) {
        $associated_user_ids = array($current_user_id);

        $all_users = get_users(array(
            'meta_query' => array(
                array(
                    'key' => 'user_status',
                    'value' => array('ACTIF', 'actif', 'active'),
                    'compare' => 'IN',
                ),
            ),
        ));

        foreach ($all_users as $user) {
            $associer_crm = get_user_meta($user->ID, 'associer_crm', true);
            if ($associer_crm && in_array($current_user_id,  $associer_crm)) {
                $associated_user_ids[] = $user->ID;
            }
        }

        // Ajouter les critères de récupération
        $meta_query[] = array(
            'key' => '_generated_doc_user_id',
            'value' => $associated_user_ids,
            'compare' => 'IN',
        );
    } elseif (!in_array('administrator', $user_roles) && !in_array('responsable_crm', $user_roles)) {
        // Si l'utilisateur n'est ni administrateur ni responsable, récupérer seulement ses documents
        $meta_query[] = array(
            'key' => '_generated_doc_user_id',
            'value' => $current_user_id,
            'compare' => '=',
        );
    }
   

    if ($user_id) {

        $meta_query = array(array(
            'key' => '_generated_doc_user_id',
            'value' => $user_id,
            'compare' => '=',
        ));
        
    }

    $args = array(
        'post_type' => 'crm_docs_gen',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'meta_query' => $meta_query,
    );

    // Gestion du tri
    $orderby = isset($_GET['orderby']) ? sanitize_text_field($_GET['orderby']) : 'date';
    $order = isset($_GET['order']) && $_GET['order'] === 'asc' ? 'ASC' : 'DESC';
    $args['orderby'] = $orderby;
    $args['order'] = $order;

    // Récupération des posts
    $documents = get_posts($args);

    if (!$documents) {
        return 'Aucun document généré trouvé.';
    }
   /* $documents = array_filter($documents, function($doc) {
        $pdf_url = get_post_meta($doc->ID, '_pdf_url', true);
        return $pdf_url; 
    }); */
    $base_url = strtok($_SERVER['REQUEST_URI'], '?');
    $generate_sort_url = function($column) use ($base_url, $orderby, $order) {
        $new_order = ($orderby === $column && $order === 'DESC') ? 'asc' : 'desc';
        return add_query_arg(array('orderby' => $column, 'order' => $new_order), $base_url);
    };


    // Construction du tableau de sortie (comme dans votre code initial)
    if (count($documents) > 0) {
        $output = crm_table_output($documents, $current_user_id, $user_roles, $generate_sort_url);
    } else {
        $output = 'Aucun document généré trouvé';
    }
   // $output = crm_table_output($documents, $user_id, $current_user->roles,$generate_sort_url);
    return $output;
}
add_shortcode('crm_documents_generes', 'crm_documents_generes_shortcode');



/**
 * Le shortcode [crm_rapports_generes] utilisé pour afficher une liste des rapports générés dans le CRM.
 * Ce shortcode permet de récupérer et d'afficher les rapports générés par l'utilisateur actuel ou ceux associés à un utilisateur spécifique,
 * en fonction de l'URL ou des rôles de l'utilisateur. Il inclut des filtres par template et utilisateur, ainsi que des options de tri dynamiques.
 * 
 * Fonctionnalités principales :
 * 1. **Filtrage par template** : Permet de filtrer les rapports en fonction d'un template spécifique.
 * 2. **Gestion des rôles d'utilisateur** : Affiche les rapports en fonction des rôles de l'utilisateur (utilisateur_crm, administrateur, responsable_crm, etc.).
 * 3. **Filtrage par utilisateur spécifique** : Si l'URL contient un identifiant d'utilisateur, seuls les rapports associés à cet utilisateur sont affichés.
 * 4. **Critères de récupération des rapports** : Récupère les rapports en fonction de l'ID du template et de l'ID de l'utilisateur.
 * 5. **Tri des rapports** : Permet de trier les rapports par date, avec des options pour inverser l'ordre du tri.
 * 6. **Affichage sous forme de tableau** : Affiche les rapports sous forme de tableau.
 * 7. **Modification via Sidebar** : Ajoute une sidebar qui permet à l'utilisateur de modifier le contenu des rapport et gérer les rapports qui lui sont attachés. 

 * 8. **URL de tri dynamique** : Permet de modifier dynamiquement l'ordre de tri des rapports via l'interface.
 * 
 * @param mixed $atts Attributs du shortcode (ex. 'nom_template' pour filtrer par template).
 * @return string Tableau HTML contenant les rapports générés ou un message si aucun rapport n'est trouvé.
 */

/*function crm_rapports_generes_shortcode($atts) {
    $atts = shortcode_atts(array(
        'nom_template' => '',
        'type' => 'documents', // Par défaut, afficher tous les documents
    ), $atts, 'crm_rapports_generes');
    
    $template_id = !empty($atts['nom_template']) ? get_post_id_from_title($atts['nom_template']) : null;
    $current_user = wp_get_current_user();
    $user_roles = $current_user->roles;
    $current_user_id = $current_user->ID;
    
    $current_url = $_SERVER['REQUEST_URI'];
    $user_id = null;

    // Vérification de l'ID utilisateur dans l'URL pour crm-customer
    if (strpos($current_url, 'crm-customer/') !== false) {
        $hashedId = get_hashed_id_from_url();
        $user_id = $hashedId ? get_user_id_from_hash($hashedId) : null;

        if (!$user_id || !get_userdata($user_id)) {
            return '<p>ID utilisateur invalide ou expiré.</p>';
        }
    }

    $meta_query = array();

    if ($template_id) {
        $meta_query[] = array(
            'key' => '_used_template_id',
            'value' => $template_id,
            'compare' => 'IN',
        );
    }

    if ($user_id) {

        $meta_query = array(array(
            'key' => '_generated_doc_user_id',
            'value' => $user_id,
            'compare' => '=',
        ));
        
    }

    $args = array(
        'post_type' => 'crm_docs_gen',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'meta_query' => $meta_query,
    );
    $orderby = isset($_GET['orderby']) ? sanitize_text_field($_GET['orderby']) : 'date';
    $order = isset($_GET['order']) && $_GET['order'] === 'asc' ? 'ASC' : 'DESC';
    $args['orderby'] = $orderby;
    $args['order'] = $order;


    $documents = get_posts($args);

    if (!$documents) {
        return 'Aucun rapport généré trouvé.';
    }
   
       
        $documents = array_filter($documents, function($doc) {
            $pdf_url = get_post_meta($doc->ID, '_pdf_url', true);
            return !$pdf_url; 
        }); 


 
     
    
    
    
    $base_url = strtok($_SERVER['REQUEST_URI'], '?');
    $generate_sort_url = function($column) use ($base_url, $orderby, $order) {
        $new_order = ($orderby === $column && $order === 'DESC') ? 'asc' : 'desc';
        return add_query_arg(array('orderby' => $column, 'order' => $new_order), $base_url);
    };
    // Générer le tableau avec les documents $output = generate_events_table_output($documents, $current_user_id, $user_roles,$generate_sort_url);
    if (count($documents) > 0) {
        $output = crm_table_output($documents, $current_user_id, $user_roles, $generate_sort_url, 'events');
    } else {
        $output = 'Aucun rapport généré trouvé';
    }
     return $output;
}
add_shortcode('crm_rapports_generes', 'crm_rapports_generes_shortcode');
*/
function crm_table_output($items, $user_id, $user_roles, $generate_sort_url) {
    $can_delete = in_array('administrator', $user_roles) || in_array('responsable_crm', $user_roles) || in_array('utilisateur_crm', $user_roles);
    $show_user_column = !$user_id;
    $current_user = wp_get_current_user();
    $current_user_id = $current_user->ID;

    $pdfIconUrl = plugin_dir_url(__FILE__) . '../assets/icones/pdf-icon.svg';
    $trashIconUrl = plugin_dir_url(__FILE__) . '../assets/icones/trash-icon.svg';
    // Déterminer les options spécifiques en fonction du type

    
    $output = '<div id="generated_document_list">
    <div id="generate_document_notification"></div>';

   
    $output .= '
    <div class="right-sidebar" id="generate_document_edit_right_sidebar">
        <div class="crm-document-sidebar-content">
            <form id="generate_document_edit_form" novalidate>
                <div class="crm-document-sidebar-header">
                    <h5 class="">Modifier le contenu du document</h5>
                    <button class="discard-sidebar">X</button>
                </div>
                <div class="sidebar-msg-container"id="sidebar_document_msg"></div>
                <div class="document-details">
                    <div id="crm_document_content_container"stle="display:none;">
                        <a id="crm_document_content_document_tier"href=""class="crm-doc-tiers"></a>
                                     
                        <p  id="crm_document_content_title" class="crm-doc-title" ></p>
                            
                        <div class="creator-date-container">
                            <p id="crm_document_content_creation_date"class="crm-doc-sysdetail"></p>
                            <p id="crm_document_content_creator"class="crm-doc-sysdetail"></p>
                        </div>
                        
                                
                    </div>
                    
                   <div id="generate_document_edit_content" style="">
                       <div class="sidebar-content">
                            <div class="sidebar-content-left">
                                <a id="document_tier"href=""class="crm-doc-tiers"></a>
                                <input type="text" id="generate_document_edit_id" name="generated_document_id" class="form-control" style="display:none"value="" readonly />
                                    
                                <input type="text" id="generate_document_edit_title"data-original-value="" name="generated_document_title"  class="crm-doc-title"value="" />
                                 
                                <div class="error-message"></div>
                                <div class="creator-date-container">
                                    <p id="document_creation_date"class="crm-doc-sysdetail"></p>
                                    <p id="document_creator"class="crm-doc-sysdetail"></p>
                                </div>
                                <div id="crm_document_content"></div>
                                
                                <div class=""id="crm_document_note_version_container" style="display:none;">
                                    <p><strong>La version du template utilisé dans la création de ce document a été modifiée. Voulez-vous vraiment modifier le contenu de ce document ?</strong></p>
                                </div>
                   
                                <div id="generate_document_edit_contents_container"style="display:none;">
                                    <!-- Conteneur pour les variables -->
                                    <p class="crm-document-container-title" for="document-content">Données à modifier :</p>
                                    <div id="generate_document_edit_contents_vars" ></div>
                                </div>
                            </div>
                            <div class="sidebar-content-right"style="display:none">
                                <!-- Conteneur pour les pièces jointes -->
                                <div id="generate_document_edit_attachement_container" style=""></div>
                                <div id="generate_document_edit_new_attachment_container" style="display:none;" >
                                    <p  class="crm-document-container-title">Ajouter des documents joints : </p>
                                    <div>
                                        <label for="generate_document_edit_new_attachment">Ajouter un fichier</label>
                                        <input type="file" id="generate_document_edit_new_attachment" name="new-attachment[]" multiple />
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        
                        
                        
                       
                    </div>

                    <div class="sidebar-footer-btn">
                        <button type="button" class="regenerate-document" id="sidebar_document_precedent">Précedent</button>
                     
                        <div class="sidebar-footer-btn-center">
                            <button type="button" class="discard-btn" id="generate_document_edit_discard">Fermer</button>
                            <button type="button" class="btn btn-secondary crm-form-btn delete-document" id="sidebar_delete_document_btn"data-id=""data-notif-container="sidebar_document_msg">
                                Supprimer le document
                            </button>
                            <button type="button" class="btn btn-primary crm-form-btn"id="generate_document_confirm_edit_btn"style="display:none">Modifier</button>
            
                            <button type="button" class="btn btn-primary crm-form-btn"id="get_document_data_to_edit_btn" data-id="">Modifier le contenu</button>
                            <button type="submit" class="btn btn-primary crm-form-btn"id="generate_document_edit_submit"style="display:none;" disabled>Mettre à jour</button>
                            
                        </div>
                        <button type="button" id="sidebar_document_suivant"style=""class="regenerate-document btn btn-secondary crm-form-btn " data-id="">
                           Suivant
                        </button>
                        
                    </div>
                    
                </div>
            </form>
        </div>
    </div>
    ';

    // Générer le tableau
    $output .= '<div class="crm-table-container crm-documents-table">
        <table class="crm-table crm-doc-documents ">
            <thead>
                <tr>
                    <th><a href="' . esc_url($generate_sort_url('orderby', 'date')) . '" style="color: black">Date</a></th>';

    if ($show_user_column) {
        $output .= '<th><a href="' . esc_url($generate_sort_url('orderby', 'user')) . '" style="color: black">Entreprises</a></th>';
    }

    $output .= '<th><a href="' . esc_url($generate_sort_url('orderby', 'template_name')) . '" style="color: black">Type</a></th>
                <th><a href="' . esc_url($generate_sort_url('orderby', 'post_title')) . '" style="color: black">Nom du document</a></th>
                ';
    


    $output.='<th>Document généré</th>';

$output.='<th>Attachements </th>';

    if ($can_delete) {
        $output .= '<th>Actions</th>';
    }
    $output .= '</tr></thead><tbody>';

    // Générer les lignes du tableau
    foreach ($items as $index => $item) {
        $template_id = get_post_meta($item->ID, '_used_template_id', true);
        $precedentItemId = null;
        $suivantItemId = null;
    
        // Vérifie si un élément précédent existe
        if (isset($items[$index - 1])) {
            $precedentItemId = $items[$index - 1]->ID;
        }
    
        // Vérifie si un élément suivant existe
        if (isset($items[$index + 1])) {
            $suivantItemId = $items[$index + 1]->ID;
        }
        $template_name = get_the_title($template_id);
        $name = get_the_title($item->ID);
        $date_creation = get_the_date('d-m-Y', $item->ID);
        $pdf_url = get_post_meta($item->ID, '_pdf_url', true);
        $generated_doc_pieces_joints = get_post_meta($item->ID, '_generated_doc_pieces_joints', true);

        $userDocId = get_post_meta($item->ID, '_generated_doc_user_id', true);
        $user_info = get_userdata($userDocId);
        $company_name = get_user_meta($userDocId, 'billing_company', true);
        $user_name = $company_name ?: ($user_info ? $user_info->last_name . ' ' . $user_info->first_name : '');
        $class_edit="regenerate-document";
        $output .= '<tr data-id="' . esc_attr($item->ID) . '" data-precedent="' . esc_attr($precedentItemId) . '" data-suivant="' . esc_attr($suivantItemId) . '">
                        <td class="' . $class_edit . '" data-id="' . esc_attr($item->ID) . '" data-precedent="' . esc_attr($precedentItemId) . '" data-suivant="' . esc_attr($suivantItemId) . '">' . esc_html($date_creation) . '</td>';

        if ($show_user_column) {
            $output .= '<td class="' . $class_edit . '" data-id="' . esc_attr($item->ID) . '"data-precedent="' . esc_attr($precedentItemId) . '" data-suivant="' . esc_attr($suivantItemId) . '">' . esc_html($user_name) . '</td>';
        }

        $output .= '<td class="' . $class_edit . '" data-id="' . esc_attr($item->ID) . '"data-precedent="' . esc_attr($precedentItemId) . '" data-suivant="' . esc_attr($suivantItemId) . '">' . esc_html($template_name) . '</td>
                    <td class="' . $class_edit . '" data-id="' . esc_attr($item->ID) . '"data-precedent="' . esc_attr($precedentItemId) . '" data-suivant="' . esc_attr($suivantItemId) . '">' . esc_html($name) . '</td>
                    ';

        
        if ($pdf_url) {

            $output .= '<td><a href="' . esc_url($pdf_url) . '" target="_blank">
                            <img src="' . esc_url($pdfIconUrl) . '" alt="PDF" style="width: 20px; height: 20px;">
                        </a></td>';
        }
        else{
            $output .= '<td>--</td>';

        }

        if (!empty($generated_doc_pieces_joints) && is_array($generated_doc_pieces_joints)) {
            $output .= '<td>';
            foreach ($generated_doc_pieces_joints as $key => $file) {
            
                $file_extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                $icon_url=get_file_icon($file_extension);
                $output .= '
                                <a href="' . $file . '" target="_blank">
                                    <img src="' . $icon_url . '"  file" style="width: 20px; height: 20px; margin-right: 5px;">
                                    
                                </a>
                            ';
            } 
            $output .= '</td>';
        } else {
            $output .= '<td>--</td>';
        }

        $output .= '</td><td>';

        if ($can_delete) {
            $output .= '<a href="#" class="delete-document" data-id="' . esc_attr($item->ID) . '"data-notif-container="generate_document_notification">
                            <img src="' . esc_url($trashIconUrl) . '" alt="Supprimer" style="width: 24px; height: 24px;">
                        </a>';
        } else {
            $output .= '--';
        }

        $output .= '</td></tr>';
    }

    $output .= '</tbody></table></div></div>';

    return $output;
}

function get_file_icon($file_extension)
{
    switch ($file_extension) {
        case 'pdf':
            $icon_url = plugin_dir_url(__FILE__) . '../assets/icones/pdf-icon.svg';
            break;
        case 'doc':
        case 'docx':
            $icon_url = plugin_dir_url(__FILE__) . '../assets/icones/word-icon.svg';
            break;
        case 'xls':
        case 'xlsx':
            $icon_url = plugin_dir_url(__FILE__) . '../assets/icones/excel-icon.svg';
            break;
        case 'jpg':
        case 'jpeg':
        case 'png':
            $icon_url = plugin_dir_url(__FILE__) . '../assets/icones/image-icon.svg';
            break;
        case 'zip':
        case 'rar':
            $icon_url = plugin_dir_url(__FILE__) . '../assets/icones/zip-icon.svg';
            break;
        default:
            $icon_url = plugin_dir_url(__FILE__) . '../assets/icones/image-icon.svg';
            break;
    }
    return $icon_url;

}
/**
 * Récupère les détails d'un document et retourne une réponse JSON.
 *
 * Cette fonction est utilisée pour obtenir les informations d'un document, y compris 
 * son contenu, ses pièces jointes, les métadonnées associées, et les variables utilisées.
 * Elle est principalement utilisée dans le cadre d'une requête AJAX.
 *
 * Étapes principales :
 * - Vérifie si l'ID du document est fourni et valide.
 * - Récupère le contenu du document, ainsi que ses pièces jointes, métadonnées et variables.
 * - Traite les variables du document en les comparant aux métadonnées utilisateur.
 * - Prépare une réponse JSON avec les informations nécessaires.
 * - Renvoie une réponse JSON de succès ou d'erreur selon le cas.
 *
 * Données retournées dans la réponse JSON (en cas de succès) :
 * - `title` : Titre du document.
 * - `attachments` : Liste des pièces jointes associées au document.
 * - `content` : Contenu du document avec les sauts de page remplacés par `[Saut_page]`.
 * - `acceptAttachement` : Indique si les pièces jointes sont autorisées pour ce document.
 * - `variables_document` : Variables générées pour le document, décodées en tableau.
 * - `template_verision` : Version du modèle utilisé pour générer le document.
 * - `document_version` : Version du modèle spécifiquement utilisée pour ce document.
 * - `variables_template` : Variables disponibles dans le contenu du modèle.
 * - `pre_filled` : Variables pré-remplies basées sur les métadonnées utilisateur.
 * - `racine` : Métadonnée `_racine` du modèle.
 * - `compteur` : Nombre total de documents générés à partir de ce modèle.
 *
 * Données en cas d'erreur :
 * - `wp_send_json_error` : Renvoie un message d'erreur si l'ID ou le document est invalide.
 *
 * @return void
 */
function get_document_details() {
    $document_id = isset($_POST['document_id']) ? intval($_POST['document_id']) : 0;

    $current_user = wp_get_current_user();
    $user_roles = $current_user->roles;
    $can_edit=false;
    $can_delete=false;
 
    if (!$document_id) {
        wp_send_json_error('ID de document invalide.');
    }

    $document = get_post($document_id);
    if (!$document) {
        wp_send_json_error('Document introuvable.');
    }
    //<div style="page-break-before: always;"></div>
    $contentQuill = str_replace('<div style="page-break-before: always;"></div>', '[Saut_page]', $document->post_content);
                    
    $attachments = get_post_meta($document_id, '_generated_doc_pieces_joints', true);
    $template_id=get_post_meta($document_id, '_used_template_id', true);
    $acceptAttachement=get_post_meta($template_id, '_template_autorise_documents_joints', true);
    $template_version=get_post_meta($template_id, '_template_version', true);
    $document_version=get_post_meta($document_id, '_used_template_version', true);
    
    $user_id= get_post_meta($document_id, '_generated_doc_user_id', true);
    $nom_societe =get_user_meta($user_id, 'billing_company', true);
    $first_name =get_user_meta($user_id, 'first_name', true);
    $last_name = get_user_meta($user_id, 'last_name', true);
    if($last_name||$first_name)            
    {
           $prenom_nom=$last_name .' '.$first_name;
    }
    else{
        $prenom_nom=$nom_societe;
    }
   /* $variables_document = get_post_meta($document_id, '_generated_doc_vars', true);
    $cleanJson = stripslashes($variables_document);
    
    $variables_document_array = json_decode($cleanJson, true);
*/
$variables_document = get_post_meta($document_id, '_generated_doc_vars', true);

// Nettoyer la chaîne JSON (suppression des échappements si nécessaire)
$cleanJson = stripslashes(($variables_document));

// Décoder la chaîne JSON
$variables_document_array = json_decode($cleanJson, true);
if (is_null($variables_document_array)) {
    // Supprimer les accolades si elles existent
    $cleanJson = trim($cleanJson, '{}');
    
    $pairs = explode('",', $cleanJson);
    
    $variables_document_array = [];
    foreach ($pairs as $pair) {
        // Diviser chaque paire par le séparateur ':'
        $keyValue = explode(':', $pair, 2); 
        if (count($keyValue) === 2) {
            // Nettoyer les clés et les valeurs
            $key = trim($keyValue[0], ' "');
            $value = trim($keyValue[1], ' "');
            //$value = stripslashes($keyValue[1]);
            $variables_document_array[$key] = $value;
        }
    }
}

   // wp_send_json_error([$variables_document,gettype($variables_document),$cleanJson,gettype($cleanJson),$variables_document_array,gettype($variables_document_array)]);

if (!($template_version == $document_version)) {
    $template_content = get_post_field('post_content', $template_id);
    preg_match_all('/\{([^\}]+)\}/', $template_content, $matches);
    $variables_template = array_unique($matches[1]);
    $pre_filled = [];
    foreach ($variables_document_array as $key => $value) {
        if (!in_array($key, $variables_template)) {
            unset($variables_document_array[$key]);
        }
    }
    foreach ($variables_template as $variable) {
        $clean_variable = preg_replace('/[\*\#\@\|]/', '', $variable);
    
        if (strpos($variable, '|') !== false) {
            $parts = explode('|', $variable);
            $clean_variable = ltrim($parts[0], '*'); // Retirer '*' s'il existe dans la première partie
        }
        $meta_value = get_user_meta($user_id, $clean_variable, true);
    
        $meta_value = get_user_meta($user_id, $variable, true);
        
            $pre_filled[$variable] = $variables_document_array[$variable]?$variables_document_array[$variable]:($meta_value?$meta_value:'');
       
    }
    foreach ($variables_template as $variable) {
        if (!array_key_exists($variable, $variables_document_array)) {
            $variables_document_array[$variable] = $pre_filled[$variable] ?? '';
        }
    }

}
    //$entreprise_affichee = !empty($nom_societe) ? $nom_societe :( $user->display_name?$user->display_name:$prenom_nom);
    $hashedId=  crm_document_generate_user_hash($user_id);   
    $author_id = get_post_field('post_author', $document_id);  
    $author_email = get_the_author_meta('user_email', $author_id);
    //gestion des droits
    $dateCreation = strtotime(get_post_field('post_date', $document_id));
    
        // Calculer la différence en jours entre aujourd'hui et la date de création
    $differenceInDays = (time() - $dateCreation) / (60 * 60 * 24); // Conversion en jours
        
    if(in_array('administrator', $user_roles)|| in_array('responsable_crm', $user_roles)){
        $can_edit=true;
        $can_delete=true;
        
    }
    elseif(in_array('utilisateur_crm', $user_roles)){
        $associer_crm = get_user_meta($user_id, 'associer_crm', true);
        $can_edit=(($current_user->ID==$user_id&&$differenceInDays<7)||
        ($associer_crm && in_array($current_user->ID,  $associer_crm)&&$differenceInDays<7&&$author_id==$current_user->ID));
        $can_delete=(($current_user->ID==$user_id&&$differenceInDays<7)||
        ($associer_crm && in_array($current_user->ID,  $associer_crm)&&$differenceInDays<7&&$author_id==$current_user->ID));
        
    }
    else{
        
        $can_edit=($current_user->ID==$user_id&&$differenceInDays<7);
        $can_delete=($current_user->ID==$user_id&&$differenceInDays<7);

    }
    //fin gestions droits
    
    //wp_send_json_error([$attachments,gettype($attachments)]);
    $response = array(
        'title' => $document->post_title,
        'attachments'=>$attachments,
        'tiers'=>$prenom_nom,
        'creator'=>$author_email,
        'dateCreation' => date('d/m/y à H:i', strtotime(get_post_field('post_date', $document_id))),
        'content' => nl2br($contentQuill),
        'acceptAttachement'=>$acceptAttachement,
        'variables_document'=>$variables_document_array,
        //'variables_document'=>json_decode($cleanJson,true),
        //'variables_template'=>$variables_template,
        'template_version'=>$template_version,
        'document_version'=>$document_version,
        //'pre_filled'=>$pre_filled,
        'FicheTiers'=>home_url('crm-customer/' . $hashedId),
        'racine' => get_post_meta($template_id, '_racine', true),
        'compteur' => count(get_posts([
            'post_type'   => 'crm_docs_gen',
            'meta_key'    => '_used_template_id',
            'meta_value'  => $template_id,
            'numberposts' => -1,
        ])),
        'plugin_base_url'=> plugin_dir_url(__FILE__) . '../assets/icones/',
        'documentContent'=>$document->post_content,
        'canEdit'=>$can_edit,
        'canDelete'=>$can_delete,
    );

    wp_send_json_success($response);
}
add_action('wp_ajax_get_document_details', 'get_document_details');

function crm_document_generate_user_hash($user_id) {
    $secret_key = 'u9bX2!kzT$P3nV7&jLm0@fQxR#c8Y^W6*ZaG5'; 
    return hash_hmac('sha256', $user_id, $secret_key);
}
/**
 * Fonction pour modifier le contenu d'un document généré via une requête AJAX.
 * 
 * 1. Récupère les données envoyées dans la requête, telles que l'ID du document, le titre, le contenu, et les variables associées.
 * 2. Valide et met à jour le titre, le contenu, et les métadonnées du document généré.
 * 3. Gère les pièces jointes supplémentaires ajoutées via la requête.
 * 4. Supprime et régénère le fichier PDF associé si nécessaire.
 * 5. Renvoie une réponse JSON pour indiquer le succès ou l'échec de l'opération.
 */
function edit_generated_post_content() {
    //wp_send_json_error($_POST['content']);
    $document_id = isset($_POST['generated_document_id']) ? intval($_POST['generated_document_id']) : 0;
    $title = isset($_POST['generated_document_title']) ? sanitize_text_field($_POST['generated_document_title']) : '';
    $content = isset($_POST['content']) ? nl2br($_POST['content']) : '';
   
    //$generatePdf = isset($_POST['generatePdf']) ? ($_POST['generatePdf']) : '';
    $rawVariables=$_POST['variables'];
    
    if (!$document_id) {
        wp_send_json_error('ID de document invalide.');
    }
    $user_id=get_post_meta($document_id, '_generated_doc_user_id',true);
    $user_info = get_userdata($user_id);
    $vosfactures_id=get_post_meta($user_id, 'vosfactures_id',true);
    $user_login = $user_info->user_login??$vosfactures_id;


    $year = date('Y');
    //$content = str_replace('[Saut_page]', '<div style="page-break-before: always;"></div>', $content);
    $doc_url=get_post_meta($document_id, '_pdf_url', true);
    $template_id=get_post_meta($document_id, '_used_template_id', true);
    $template_autorise_generation_pdf = get_post_meta($template_id, '_template_autorise_generation_pdf', true);
   
    $template = get_post($template_id);
    $template_verision=get_post_meta($template_id, '_template_version', true);
    
    $templateContent = $template->post_content;
   // $variables = json_decode($rawVariables, true); 
    $cleanJson = stripslashes($rawVariables);

    // Décoder la chaîne JSON en tableau PHP
    $variables = json_decode($cleanJson, true);
    $contenu=$templateContent;
    //wp_send_json_error(($variables));
    foreach ($variables as $variable => $value) {
        if($variable=="document_name"||$variable=="document_name*"){
            $value=$title;
        }
        /**/if (strpos($variable, '@') !== false) {
            // Insérer directement du HTML si '#' est présent
            $regex = "/\{" . preg_quote($variable, '/') . "\}/";
            $newContenu = preg_replace($regex, $value, $contenu); 
        } 
        else {
        
        $regex = "/\{" . preg_quote($variable, '/') . "\}/";
        $newContenu = preg_replace($regex, ' <b>' . esc_html($value) . '</b> ', $contenu);

   }

    $contenu = $newContenu;
    }
    update_post_meta($document_id, '_used_template_version', $template_verision);
   
    update_post_meta($document_id, '_generated_doc_vars', json_encode($variables));
    // Mettre à jour le titre et le contenu du post
    $post_data = array(
        'ID' => $document_id,
        'post_title' => $title,
        'post_content' => $contenu
    );
    wp_update_post($post_data);

    // Gérer les nouvelles pièces jointes
    $attachments = get_post_meta($document_id, '_generated_doc_pieces_joints', true);
    if (!$attachments) {
        $attachments = [];
    }
    //wp_send_json_error(get_post_meta($document_id, '_generated_doc_pieces_joints', true));
   
    if (isset($_FILES['additional_files'])) {
        $uploaded_files = [];
        $file_count = count($_FILES['additional_files']['name']);
        $upload_dir = wp_upload_dir();
        //$custom_dir = $upload_dir['basedir'] . '/documents-crm';

        $custom_dir = $upload_dir['basedir'] . "/documents-crm/$user_login/$year";
        
            if (!file_exists($custom_dir)) {
                mkdir($custom_dir, 0755, true);
            }
    
            for ($i = 0; $i < $file_count; $i++) {
                $original_name = $_FILES['additional_files']['name'][$i];
                $tmp_name = $_FILES['additional_files']['tmp_name'][$i];
                $file_ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
    
                $forbidden_extensions = ['php', 'js', 'exe', 'bat', 'sh'];
                if (in_array($file_ext, $forbidden_extensions)) {
                    continue; 
                }
    
                // Génération du nom sécurisé
                $safe_name = sanitize_file_name($original_name);
                 $new_name = "{$title} - {$safe_name}";
                $new_name = preg_replace('/[^a-zA-Z0-9._-]/', '', $new_name); 
                $target_file = $custom_dir . '/' . $new_name;
    
                if (move_uploaded_file($tmp_name, $target_file)) {
                    $attachments[] = $upload_dir['baseurl'] . "/documents-crm/$user_login/$year/$new_name";
                }
            }
    
         
    
        if (!empty($attachments)) {
            update_post_meta($document_id, '_generated_doc_pieces_joints', $attachments);
        }

    }

     if($template_autorise_generation_pdf&&$template_autorise_generation_pdf=="on"){
        if ($doc_url) {
            $pdf_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $doc_url);
            if (file_exists($pdf_path)) {
                unlink($pdf_path);
            }
        }
        //$pdf_url = generate_pdf($document_id,$content, 'generated_doc_' . $document_id . '.pdf');
        $pdf_url = generate_pdf($document_id,$content, $title . '.pdf');

            update_post_meta($document_id, '_pdf_url', $pdf_url);
           

    }
    wp_send_json_success('Document mis à jour avec succès.');
}
add_action('wp_ajax_edit_generated_post_content', 'edit_generated_post_content');



/**
 * Fonction pour récupérer l'ID d'un post à partir de son titre dans un type de post spécifique.
 * 
 * Cette fonction utilise la base de données WordPress pour rechercher un post dans le type de post "crm_documents" 
 * avec un titre donné, et renvoie l'ID de ce post s'il est publié.
 * 
 * 1. Utilise la variable globale `$wpdb` pour exécuter une requête SQL sécurisée.
 * 2. La requête cherche dans la table `wp_posts` où le `post_title` correspond au titre fourni, le `post_type` est "crm_documents" et le `post_status` est 'publish'.
 * 3. Si un post est trouvé, l'ID du post est renvoyé, sinon `null` est retourné.
 * 
 * @param string $title Le titre du post recherché.
 * @return int|null L'ID du post trouvé ou `null` si aucun post n'a été trouvé.
 */
function get_post_id_from_title($title) {
    global $wpdb;
    $post_type="crm_documents";

    // Requête pour récupérer l'ID du post
    $post_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} 
             WHERE post_title = %s 
             AND post_type = %s 
             AND post_status = 'publish' 
             LIMIT 1",
            $title,
            $post_type
        )
    );

    return $post_id ? (int) $post_id : null;
}


/**
 * Gère la suppression d'un document via une requête AJAX sécurisée.
 *
 * Cette fonction est utilisée pour supprimer un document à partir de son ID. Elle 
 * effectue les étapes suivantes :
 * 
 * - Vérifie la validité du nonce envoyé pour sécuriser la requête AJAX.
 * - Vérifie que l'ID du document est fourni et est un entier valide.
 * - Récupère l'URL du fichier PDF associé au document (métadonnée `_pdf_url`).
 * - Traduit l'URL du fichier en chemin absolu sur le serveur et supprime le fichier physique.
 * - Supprime le post WordPress associé au document de manière définitive.
 * - Renvoie une réponse JSON en cas de succès ou d'erreur.
 *
 * Réponses possibles :
 * - Succès : `{ success: true, data: { message: "Document supprimé avec succès." } }`
 * - Erreur : `{ success: false, data: { message: "Document non trouvé." } }`
 *
 * @return void
 */
function delete_document_handler() {
    check_ajax_referer('delete-document-nonce', 'security');

    if (isset($_POST['document_id']) && is_numeric($_POST['document_id'])) {
        $document_id = intval($_POST['document_id']);
        $pdf_url =get_post_meta($document_id, '_pdf_url', true);
        $attachements =get_post_meta($document_id, '_generated_doc_pieces_joints', true);

        if ($pdf_url) {
            $pdf_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $pdf_url);
            if (file_exists($pdf_path)) {
                unlink($pdf_path);
            }
        }
      
        if(is_array($attachements)&&count($attachements)>0){
            foreach($attachements as $url){
                 $pdf_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $url);
            if (file_exists($pdf_path)) {
                unlink($pdf_path);
            }
            }
        }

        wp_delete_post($document_id, true);
        wp_send_json_success(['message' => 'Document supprimé avec succès.']);
    } else {
        wp_send_json_error(['message' => 'Document non trouvé.']);
    }

    exit;
}
add_action('wp_ajax_delete_document', 'delete_document_handler');



/**
 * Gère la suppression d'une atachament via une requête AJAX sécurisée.
 *
 * Cette fonction est utilisée pour supprimer un document lié à un document ou un rapport à partir de son ID. Elle 
 * effectue les étapes suivantes :
 * 
 * - Vérifie la validité du nonce envoyé pour sécuriser la requête AJAX.
 * - Vérifie que l'ID du document ou rapport est fourni et est un entier valide.
 * - Récupère l'URL du fichier associé au document.
 * - Traduit l'URL du fichier en chemin absolu sur le serveur et supprime le fichier physique.
 * - Mettre à jour la list des attachement de ce document ou rapport.
 * - Renvoie une réponse JSON en cas de succès ou d'erreur.
 *
 * @return void
 */
function delete_attachement() {
   // check_ajax_referer('deleteDocumentNonce', 'security');
    //wp_localize_script('your-script-handle', 'deleteDocumentNonce', wp_create_nonce('delete-document-nonce'));
    if (isset($_POST['document_id']) && is_numeric($_POST['document_id']) && isset($_POST['attachement_url'])) {
        $document_id = intval($_POST['document_id']);
        $attachment_url = sanitize_text_field($_POST['attachement_url']);

        // Récupère les pièces jointes existantes
        $generated_doc_pieces_joints = get_post_meta($document_id, '_generated_doc_pieces_joints', true);

        if (is_array($generated_doc_pieces_joints)) {
            // Supprime l'URL du tableau
            $generated_doc_pieces_joints = array_filter($generated_doc_pieces_joints, function ($url) use ($attachment_url) {
                return $url !== $attachment_url;
            });

            // Supprime le fichier du serveur
            $upload_dir = wp_upload_dir();
            $file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $attachment_url);
            if (file_exists($file_path)) {
                unlink($file_path);
            }

            // Met à jour les pièces jointes
            update_post_meta($document_id, '_generated_doc_pieces_joints', $generated_doc_pieces_joints);

            wp_send_json_success(['message' => 'Document supprimé avec succès.']);
        } else {
            wp_send_json_error(['message' => 'Aucune pièce jointe trouvée pour ce document.']);
        }
    } else {
        wp_send_json_error(['message' => 'Requête invalide.']);
    }

    exit;
}
add_action('wp_ajax_delete_attachement', 'delete_attachement');