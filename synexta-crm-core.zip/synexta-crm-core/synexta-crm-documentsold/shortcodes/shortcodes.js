jQuery(document).ready(function($) {
            //generer documents js
            const labelsArray = {
                'user_status': 'Statut utilisateur',
                'display_name': 'Nom affiché',
                'nickname': 'Surnom',
                'first_name': 'Prénom',
                'last_name': 'Nom',
                'description': 'Description',
                'wc_last_active': 'Dernière activité WooCommerce',
                'tax_no': 'Numéro fiscal',
                'user_mailing': 'Adresse de messagerie utilisateur',
                'shipping_first_name': 'Prénom (livraison)',
                'shipping_last_name': 'Nom (livraison)',
                'shipping_company': 'Entreprise (livraison)',
                'shipping_address_1': 'Adresse 1 (livraison)',
                'shipping_address_2': 'Adresse 2 (livraison)',
                'shipping_city': 'Ville (livraison)',
                'shipping_postcode': 'Code postal (livraison)',
                'shipping_country': 'Pays (livraison)',
                'shipping_state': 'Région/État (livraison)',
                'shipping_phone': 'Téléphone (livraison)',
                'shipping_email': 'E-mail (livraison)',
                'billing_first_name': 'Prénom (facturation)',
                'billing_last_name': 'Nom (facturation)',
                'billing_company': 'Entreprise (facturation)',
                'billing_address_1': 'Adresse 1 (facturation)',
                'billing_address_2': 'Adresse 2 (facturation)',
                'billing_city': 'Ville (facturation)',
                'billing_postcode': 'Code postal (facturation)',
                'billing_country': 'Pays (facturation)',
                'billing_state': 'Région/État (facturation)',
                'billing_phone': 'Téléphone (facturation)',
                'billing_email': 'E-mail (facturation)',
                'reference_template': 'Référence modèle',
                'creation_date': 'Date de création',
                'template_name': 'Nom template',
                'display_author_name': 'Nom de l\'auteur',
                'display_author_bio': 'Biographie de l\'auteur',
            };

            $('#show-gen-document-sidebar-btn').click(function() {
                //$('#templates-list').slideToggle();
                //$(this).hide();
                $('#gen-document-sidebar').addClass('open').show();


                /* if ($(this).data('user-id') != '') {
                     $('#templates-list').show();

                 } else {

                     $('.user_select__container').show();
                 }*/

            });
            $('#user_select').on('change', function() {
                const userId = $(this).val();


                $('#template_select').empty();

                if (userId) {
                    $.get(ajax_object.ajax_url, {
                            action: 'get_templates_by_user_role',
                            user_id: userId
                        },
                        function(response) {
                            if (response.success) {
                                templates = response.data.templates;
                                $('#templates-list').slideDown();
                                if (templates.length > 0) {
                                    templateSelect.append('<option value="">-- Sélectionnez un modèle --</option>');
                                    templates.forEach(function(template) {
                                        templateSelect.append(`<option value="${template.id}">${template.title}</option>`);
                                    });
                                    templateListError.html('').hide();
                                }

                            } else {
                                alert(response.data.message || 'Erreur lors de la récupération des templates.');
                            }

                        });
                }
            });
            const quillEditors = {};

            function decodeHtmlEntities(str) {
                var txt = document.createElement('textarea');
                txt.innerHTML = str;
                return txt.value;
            }
            $('#template-select,#user_select').change(function() {
                        const templateId = $('#template-select').val();
                        if (!templateId || !$('#user_select').val()) {
                            $('#gen-document-sidebar-variables-list, #gen-document-sidebar-associated-templates').hide();
                            return;
                        }

                        const userId = $('#user_select').val();

                        $.get(ajax_object.ajax_url, { action: 'get_template_variables', template_id: templateId, user_id: userId }, function(response) {
                                    if (response.success) {
                                        const container = $('#gen-document-sidebar-variables-container');
                                        container.empty();
                                        const today = new Date();
                                        const formattedDate = `${today.getDate().toString().padStart(2, '0')}-${(today.getMonth() + 1).toString().padStart(2, '0')}`; // JJ-MM
                                        const variables = response.data.variables;
                                        let associatedTemplates = response.data.associated_templates;
                                        let associatedTemplatesData = response.data.associated_templates_data;
                                        let preFilled = response.data.pre_filled;
                                        const templateRacine = response.data.racine;
                                        //const compteur = (response.data.compteur || 1).toString().padStart(4, '0');
                                        const compteur = response.data.compteur || 1;
                                        const templateNom = decodeHtmlEntities(response.data.templateNom);
                                        const societeNom = response.data.societeNom;
                                        const docTitle = ` ${formattedDate} - ${societeNom} - ${templateNom}`;
                                        $('#gen-document-sidebar-document-title').val(docTitle);



                                        variables.forEach(variable => {

                                                    let cleanedVariable = variable.replace(/[*#@]/g, '').replace(/[*#@]/g, '').trim();
                                                    let value = preFilled[variable] || '';

                                                    // Tests sur la version nettoyée de la variable
                                                    if (cleanedVariable === 'reference_template') {
                                                        value = `${templateRacine}-${formattedDate}-${compteur}`;
                                                    } else if (cleanedVariable === 'template_name') {
                                                        value = `${templateNom}`;
                                                    } else if (cleanedVariable === 'creation_date') {
                                                        const day = today.getDate().toString().padStart(2, '0');
                                                        const month = (today.getMonth() + 1).toString().padStart(2, '0');
                                                        const year = today.getFullYear();
                                                        value = `${year}-${month}-${day}`;
                                                    } else if (cleanedVariable === 'document_name') {
                                                        value = docTitle;
                                                    }

                                                    // Application des styles pour les champs cachés
                                                    let hiddenChamps = ['template_name*', 'template_name', 'reference_template*', 'reference_template', 'undefined'];
                                                    let readOnlyChamps = ['creation_date#*', 'creation_date'];


                                                    const hiddenStyle = hiddenChamps.includes(variable) ? 'style="display:none;"' : '';
                                                    const readOnlyAttr = readOnlyChamps.includes(variable) ? 'readonly' : '';
                                                    if (variable.includes('@')) {
                                                        let requiredChamp = variable.includes('*');
                                                        const labelText = (labelsArray[variable.replace('@', '').replace('*', '').trim()] || variable.replace('@', '').replace('*', '').trim());
                                                        const sanitizedVariable = variable.replace(/'/g, '&#39;');
                                                        const sanitizedVariableId = variable.replace(/'/g, '&#39;').replace(/[@*]/g, 'a').replace(/\s+/g, '_');
                                                        const newvalue = generate_document_escapeString(value);
                                                        container.append(`
                                                            <div class="variable__item" style="height:260px;">
                                                                <label class="crm-doc-label"for="${sanitizedVariableId}">${labelText}${requiredChamp ? ' *' : ''} :</label>
                                                                <div style="height:260px; "data-original-value="${newvalue}">
                                                                    <div id="${sanitizedVariableId}" name="${sanitizedVariable}" style="width: -webkit-fill-available; height:200px;" ${requiredChamp ? 'required' : ''}>${value}</div>
                                                                </div>
                                                            </div>
                                                            <div class="error-message" style="color:red;display:none;">Ce champ est requis.</div>
                                                        `);



                                                        const quillInstance = new Quill(`#${sanitizedVariableId}`, { theme: "snow" });
                                                        quillEditors[sanitizedVariableId] = quillInstance;


                                                        quillInstance.on("text-change", function() {
                                                            $(document).trigger("quill-new-text-change", [sanitizedVariableId, quillInstance]);
                                                        });



                                                    } else if (variable.includes('|')) {
                                                        const options = variable.split('|').slice(1);
                                                        const parts = variable.split('|');
                                                        let labelText = parts[0].trim();
                                                        let requiredChamp = labelText.includes('*');
                                                        labelText = labelText.replace(/[^a-zA-Z0-9\s]/g, ''); // Nettoyage
                                                        const sanitizedVariable = variable.replace(/'/g, '&#39;'); // Gestion des apostrophes

                                                        container.append(`
                                            <div class="variable__item"${hiddenStyle}>
                                                <label class="crm-doc-label"for="${sanitizedVariable}">${labelText}${requiredChamp ? ' *' : ''} :</label>
                                                <select class="crm-doc-select"data-original-value="${value}" id="${sanitizedVariable}" name="${sanitizedVariable}" ${requiredChamp ? 'required' : ''}${readOnlyAttr}>
                                                    ${options.map(option => `<option value="${option}">${option}</option>`).join('')}
                                                </select>
                                            </div>
                                            <div class="error-message" style="color:red;display:none;">Ce champ est requis.</div>
                                        `);
                                                    } 
                                                    else if (variable.includes('#')) {
                                                        const cleanedVariable = variable.replace(/[*#@]/g, '').replace(/[*#@]/g, '').trim(); 
                                                        const labelText = labelsArray[cleanedVariable] || cleanedVariable;
                                                        let requiredChamp = labelText.includes('*');
                                                        //labelText = labelText.replace(/[^a-zA-Z0-9\s]/g, '');
                                                        container.append(`
                                                            <div class="variable__item"${hiddenStyle}>
                                                                <label class="crm-doc-label"for="${variable}">${labelText} ${requiredChamp ? ' *' : ''} :</label>
                                                                <input class="crm-doc-input"type="date" data-original-value="${value}" id="${variable}" name="${variable}" value="${value}"  ${requiredChamp ? 'required' : ''}${readOnlyAttr}/>
                                                            </div>
                                                            <div class="error-message" style="color:red;display:none;">Ce champ est requis.</div>
                                                        `);
                                                    } 
                                                    else {
                                                        const requiredChamp = variable.includes('*');
                                                        const cleanedVariable = variable.replace(/\*\s*/g,'');
                                                            const labelText = labelsArray[cleanedVariable] || cleanedVariable;
                                                            const sanitizedVariable = cleanedVariable.replace(/'/g, '&#39;'); // Gestion des apostrophes

                                                            if (requiredChamp) {
                                                                //value = preFilled[cleanedVariable] || ''; 
                                                                container.append(`
                                                                    <div class="variable__item"${hiddenStyle}>
                                                                        <label class="crm-doc-label"for="${variable}">${labelText} * :</label>
                                                                        <input class="crm-doc-input"type="text"data-original-value="${value}" id="${variable}" name="${variable}" value="${value}" required ${readOnlyAttr}/>
                                                                    </div>
                                                                    <div class="error-message" style="color:red;display:none;">Ce champ est requis.</div>
                                                                `);
                                                                                                } else {
                                                                                                    //value = preFilled[variable] || '';
                                                                                                    container.append(`
                                                                    <div class="variable__item"${hiddenStyle}>
                                                                        <label class="crm-doc-label"for="${variable}"data-original-value="${value}">${labelText} :</label>
                                                                        <input class="crm-doc-input"type="text" id="${variable}" name="${variable}" value="${value}" ${readOnlyAttr}/>
                                                                    </div>
                                                                `);
                                                            }
                                                        }
                        });

                        container.show();           
                        if (associatedTemplatesData && associatedTemplatesData.length > 0) {
                                const associatedContainer = $('#gen-document-sidebar-associated-templates');
                                associatedContainer.empty();
                                associatedContainer.append('<p>Le template sélectionné a des templates associés :</p>');
                                // Construction du tableau HTML
                                associatedContainer.append(`
                                    <table class="associated-templates-table">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th>Nom de la template</th>
                                                <th>Nom du document à générer</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${associatedTemplatesData.map(template => `
                                                <tr>
                                                    <td>
                                                        <input type="checkbox" id="template_${template.id}" class="associated-template" value="${template.id}" checked />
                                                    </td>
                                                    <td>
                                                        <label class="crm-doc-label" for="template_${template.id}">${template.name}</label>
                                                    </td>
                                                    <td>
                                                        <input type="text" id="nom_doc_${template.id}" class="nom-doc-input" value="${template.nom_doc}" />
                                                        <div class="error-message" style="color:red;display:none;">Le nom du document est requis.</div>

                                                    </td>
                                                </tr>
                                            `).join('')}
                                        </tbody>
                                    </table>
                                `);

                            associatedContainer.append(`
                                <div class="generate_other_documents_container">
                                    <input type="checkbox" id="generate-associated-documents" />
                                    <label class="crm-doc-label"for='generate-associated-documents'>
                                        Voulez-vous générer les documents associés ?
                                    </label>
                                </div>
                            `);
                        $('#gen-document-sidebar-associated-templates').show();
                        }

                        $('#gen-document-sidebar-document-title-container').show();

                        $('#gen-document-sidebar-variables-list').slideDown();
                        const autoriseDocumentsJoints = response.data.autorise_documents_joints;

                        // Afficher le champ d'upload si l'option est activée
                        if (autoriseDocumentsJoints === 'on') {

                            $('#gen-document-sidebar-options-container').empty();
                            const uploadFieldHtml = `
                                <p class="gen-document-sidebar-options-title">Ajouter des documents joints :</p>
                                <div id="upload-documents-container">
                                    <label for="additional-documents"class="crm-doc-label">Ajouter des fichiers :</label>
                                    <input type="file" id="additional-documents" name="additional_documents[]" multiple accept=".pdf,.xls,.xlsx,.doc,.docx,.txt,.jpg,.png,.jpeg,.zip">
                                </div>
                                <div class="error-message"></div>
                            `;
                            $('#gen-document-sidebar-options-container').append(uploadFieldHtml).slideDown(); 
                        }
                        else{
                            $('#gen-document-sidebar-options-container').empty().slideUp(); 
                        }
    
                    }
                });
            });
    function getAllEditorContents(editorsList) {
        const editorContents = {};
        for (const id in editorsList) {
            if (editorsList.hasOwnProperty(id)) {
                editorContents[id] = editorsList[id].root.innerHTML; 
            }
        }
        return editorContents;
    }
    $(document).on('change', '#generate-associated-documents', function () {
    });
    //gestion btn submit
    $(document).on("input", "#gen-document-sidebar-variables-list input",checkForGenDocumentChanges );
    $(document).on("change", "#gen-document-sidebar-variables-list select",checkForGenDocumentChanges );
    $(document).on("quill-new-text-change", function (event, editorId, quillInstance) {
        checkForGenDocumentChanges();
    });
    
    function checkForGenDocumentChanges() {
        let hasChanges = false;
        $('#gen-document-sidebar-variables-list').find('input:visible, select:visible').each(function() {
            
            const originalValue = $(this).data('original-value');
            const currentValue = $(this).val();

            if (originalValue != currentValue) {
                hasChanges = true;
                return false; 
            }
        });
        let editorHasChanges=false;
        for (const [editorId, quillInstance] of Object.entries(quillEditors)) {
            const currentContent = generate_document_escapeString(quillInstance.root.innerHTML); 
            const originalContent = $(`#${editorId}`).parent().data("original-value"); 
            if (originalContent != ""&&currentContent != originalContent) {
                editorHasChanges= true;  
                console.log('aaa',editorId)
   
                

            }
        }
        
        if (hasChanges||editorHasChanges)
                    
         {
            $("#gen-document-sidebar-submit").prop("disabled", false);
        } else {
            $("#gen-document-sidebar-submit").prop("disabled", true);
        }
    }
    //end gestion btn submit

    $('#gen-document-sidebar-submit').click(function () {
        let isValid = true;
        const variables = {};
        const docTitleInput = $('#gen-document-sidebar-document-title');
        if (!docTitleInput.val().trim()) {
            isValid = false;
            docTitleInput.parent().next('.error-message').show(); 
        } else {
            docTitleInput.parent().next('.error-message').hide(); 
        }
        const editorContents = getAllEditorContents(quillEditors);
        $('#gen-document-sidebar-variables-container').find('input, select').each(function () {
            const input = $(this);
            const isRequired = input.prop('required'); 
            
            if (isRequired && !input.val().trim()) { 
                isValid = false;
                input.parent().next('.error-message').show();
            } 
            else {
                input.parent().next('.error-message').hide();
                const value = $(this).val() || ""; 
                variables[input.attr('name')] = value;
                
                            
            }
        });
        /*for (const editorId in editorContents) {
            if (editorContents.hasOwnProperty(editorId)) {
                const varName=$(`#${editorId}`).attr('name');
                variables[varName] = editorContents[editorId];
            }
        }*/

            for (const editorId in editorContents) {
                if (editorContents.hasOwnProperty(editorId)) {
                    const $editorElement = $(`#${editorId}`);
                    const varName = $editorElement.attr('name');
                    const content = editorContents[editorId];
            
                    const $errorMessageElement = $editorElement.parent().parent().next('.error-message');
            
                    if ($editorElement.attr('required') && (!content || content.trim() === '<p><br></p>')) {
                        isValid = false;
                        $editorElement.addClass('error'); 
                        
                        // Affiche le message d'erreur
                        $errorMessageElement.text('Ce champ est requis.').show();
                    } else {
                        $editorElement.removeClass('error');
                        
                        $errorMessageElement.text('').hide();
                    }
            
                    variables[varName] = content;
                }
            }
                    
       
        const generateAssociated = $('#generate-associated-documents').is(':checked'); // Vérifie si le checkbox est coché
        if (generateAssociated){
            $('.nom-doc-input').each(function () {
                let input = $(this);
                if (!input.val().trim()) { 
                    isValid = false;
                    input.next('.error-message').show();
                } 
                else {
                    input.next('.error-message').hide();
                }
                
                
            })
        }
        const filesInput = $('#additional-documents');
        const filesData = new FormData();
        if (filesInput.length > 0 && filesInput[0].files.length > 0) {
            const files = filesInput[0].files;
            for (let i = 0; i < files.length; i++) {
                const file = files[i];

                // Vérification des extensions interdites
                const forbiddenExtensions = ['php', 'js', 'exe', 'bat', 'sh'];
                const fileExtension = file.name.split('.').pop().toLowerCase();

                if (forbiddenExtensions.includes(fileExtension)) {
                    isValid = false;
                    filesInput.parent().next('.error-message')
                        .text('Le fichier "' + file.name + '" a une extension non autorisée.')
                        .show();
                } else {
                    filesData.append('additional_files[]', file); 
                    filesInput.parent().next('.error-message').hide(); 
                }
            }
        }


        if (!isValid) return;

        const selectedTemplates = [];
        if (generateAssociated) {
            $('.associated-template:checked').each(function () {
                const templateId = $(this).val(); 
                const nomDoc = $(`#nom_doc_${templateId}`).val();

                selectedTemplates.push({
                    id: templateId,
                    nom_doc: nomDoc
                });
            });
        }

        // Appel AJAX pour générer le document
        const doctitle = $('#gen-document-sidebar-document-title').val(); 
        const templateId = $('#template-select').val();
        const userId = $('#user_select').val();
        filesData.append('action', 'save_generated_document');
        filesData.append('template_id', templateId);
        filesData.append('user_id', userId);
        filesData.append('variables', JSON.stringify(variables));
        filesData.append('doctitle', doctitle);
        filesData.append('selectedTemplates', JSON.stringify(selectedTemplates));
        filesData.append('generateAssociated', generateAssociated);

        // Envoi de la requête AJAX avec $.ajax()
        /**/$.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: filesData,
            processData: false,
            contentType: false, 
            success: function (response) {

                if (response.success) {
                  
                    $('#gen-document-msg')
                        .text('Document ajouté avec succes.')
                        .addClass("text-success").removeClass("error-message")
                        .fadeIn()
                        .delay(1500)
                        .fadeOut(function() {
                            
                            const baseUrl = window.location.origin;
                            const redirectionUrl = baseUrl + '/' + response.data.url_redirection;
                            window.location.href = redirectionUrl;
                        });
                } else {
                    $('#gen-document-msg')
                        .text(response.data.message)
                        .removeClass("text-success").addClass("error-message")
                        .fadeIn()
                        .delay(1500)
                        .fadeOut();
                }
            },
            error: function() {
                $('#gen-document-msg')
                    .text("Erreur lors de l\'ajout du document.")
                    .removeClass("text-success").addClass("error-message")
                    .fadeIn()
                    .delay(1500)
                    .fadeOut();
            }
            
          
        });
    });
    let noteEditors={};
//shortcode note
$('#show-note-sidebar-btn').click(function() {
    const userId=$(this).data('user-id');
   const templateId=$(this).data('template-id');
   $.get(ajax_object.ajax_url, 
        { action: 'get_template_variables', 
            template_id: templateId, 
            user_id: userId 
        }, 
        function(response) {
            if (response.success) {
                const container = $('#note-variables-container');
                container.empty();
                const today = new Date();
                const formattedDate = `${today.getDate().toString().padStart(2, '0')}-${(today.getMonth() + 1).toString().padStart(2, '0')}`; // JJ-MM
                const variables = response.data.variables;
                let preFilled = response.data.pre_filled;
                const templateRacine = response.data.racine;
                const compteur = response.data.compteur || 1;
                const templateNom = decodeHtmlEntities(response.data.templateNom);
                const creatorNom = response.data.creatorNom;
                const docTitle = ` Note de ${creatorNom} `;
                $('#note-title').val(docTitle);



                variables.forEach(variable => {

                            let cleanedVariable = variable.replace(/[*#@]/g, '').replace(/[*#@]/g, '').trim();
                            let value = preFilled[variable] || '';

                            // Tests sur la version nettoyée de la variable
                            if (cleanedVariable === 'reference_template') {
                                value = `${templateRacine}-${formattedDate}-${compteur}`;
                            } else if (cleanedVariable === 'template_name') {
                                value = `${templateNom}`;
                            } else if (cleanedVariable === 'creation_date') {
                                const day = today.getDate().toString().padStart(2, '0');
                                const month = (today.getMonth() + 1).toString().padStart(2, '0');
                                const year = today.getFullYear();
                                value = `${year}-${month}-${day}`;
                            } else if (cleanedVariable === 'document_name') {
                                value = docTitle;
                            }

                            // Application des styles pour les champs cachés
                            let hiddenChamps = ['template_name*', 'template_name', 'reference_template*', 'reference_template', 'undefined'];
                            let readOnlyChamps = ['creation_date#*', 'creation_date'];


                            const hiddenStyle = hiddenChamps.includes(variable) ? 'style="display:none;"' : '';
                            const readOnlyAttr = readOnlyChamps.includes(variable) ? 'readonly' : '';
                            if (variable.includes('@')) {
                                let requiredChamp = variable.includes('*');
                                const labelText = (labelsArray[variable.replace('@', '').replace('*', '').trim()] || variable.replace('@', '').replace('*', '').trim());
                                const sanitizedVariable = variable.replace(/'/g, '&#39;');
                                const sanitizedVariableId = variable.replace(/'/g, '&#39;').replace(/[@*]/g, 'a').replace(/\s+/g, '_');
                                container.append(`
                                    <div class="variable__item" style="height:260px;">
                                        <label class="crm-doc-label"for="${sanitizedVariableId}">${labelText}${requiredChamp ? ' *' : ''} :</label>
                                        <div style="height:260px; ">
                                        <div id="${sanitizedVariableId}" name="${sanitizedVariable}" style="width: -webkit-fill-available; height:200px;" ${requiredChamp ? 'required' : ''}>${value}</div>
                                    </div></div>
                                    <div class="error-message" style="color:red;display:none;">Ce champ est requis.</div>
                                `);
                                /* var quillVariable = new Quill(`#${sanitizedVariableId}`, {
                                        theme: "snow"
                                    });*/

                                noteEditors[sanitizedVariableId] = new Quill(`#${sanitizedVariableId}`, {
                                    theme: "snow"
                                        /* modules: {
                                            toolbar: toolbarOptions
                                        }*/
                                });



                            } else if (variable.includes('|')) {
                                const options = variable.split('|').slice(1);
                                const parts = variable.split('|');
                                let labelText = parts[0].trim();
                                let requiredChamp = labelText.includes('*');
                                labelText = labelText.replace(/[^a-zA-Z0-9\s]/g, ''); // Nettoyage
                                const sanitizedVariable = variable.replace(/'/g, '&#39;'); // Gestion des apostrophes

                                container.append(`
                                    <div class="variable__item"${hiddenStyle}>
                                        <label class="crm-doc-label"for="${sanitizedVariable}">${labelText}${requiredChamp ? ' *' : ''} :</label>
                                        <select class="crm-doc-select" id="${sanitizedVariable}" name="${sanitizedVariable}" ${requiredChamp ? 'required' : ''}${readOnlyAttr}>
                                            ${options.map(option => `<option value="${option}">${option}</option>`).join('')}
                                        </select>
                                    </div>
                                    <div class="error-message" style="color:red;display:none;">Ce champ est requis.</div>
                                `);
                            } 
                            else if (variable.includes('#')) {
                                const cleanedVariable = variable.replace(/[*#@]/g, '').replace(/[*#@]/g, '').trim(); 
                                const labelText = labelsArray[cleanedVariable] || cleanedVariable;
                                let requiredChamp = labelText.includes('*');
                                //labelText = labelText.replace(/[^a-zA-Z0-9\s]/g, '');
                                container.append(`
                                    <div class="variable__item"${hiddenStyle}>
                                        <label class="crm-doc-label"for="${variable}">${labelText} ${requiredChamp ? ' *' : ''} :</label>
                                        <input class="crm-doc-input"type="date" id="${variable}" name="${variable}" value="${value}"  ${requiredChamp ? 'required' : ''}${readOnlyAttr}/>
                                    </div>
                                    <div class="error-message" style="color:red;display:none;">Ce champ est requis.</div>
                                `);
                            } 
                            else {
                                const requiredChamp = variable.includes('*');
                                const cleanedVariable = variable.replace(/\*\s*/g,'');
                                    const labelText = labelsArray[cleanedVariable] || cleanedVariable;
                                    const sanitizedVariable = cleanedVariable.replace(/'/g, '&#39;'); // Gestion des apostrophes

                                    if (requiredChamp) {
                                        //value = preFilled[cleanedVariable] || ''; 
                                        container.append(`
                                            <div class="variable__item"${hiddenStyle}>
                                                <label class="crm-doc-label"for="${variable}">${labelText} * :</label>
                                                <input class="crm-doc-input"type="text" id="${variable}" name="${variable}" value="${value}" required ${readOnlyAttr}/>
                                            </div>
                                            <div class="error-message" style="color:red;display:none;">Ce champ est requis.</div>
                                        `);
                                                                        } else {
                                                                            //value = preFilled[variable] || '';
                                                                            container.append(`
                                            <div class="variable__item"${hiddenStyle}>
                                                <label class="crm-doc-label"for="${variable}">${labelText} :</label>
                                                <input class="crm-doc-input"type="text" id="${variable}" name="${variable}" value="${value}" ${readOnlyAttr}/>
                                            </div>
                                        `);
                                    }
                                }
                            });
                //
                const autoriseDocumentsJoints = response.data.autorise_documents_joints;

                        // Afficher le champ d'upload si l'option est activée
                        if (autoriseDocumentsJoints === 'on') {

                            $('#gen-note-sidebar-options-container').empty();
                            const uploadFieldHtml = `
                             <p class="gen-note-sidebar-options-title">Ajouter des documents joints :</p>
                               
                                <div id="upload-documents-container">
                                    <label for="additional-documents"class="crm-doc-label">Ajouter des fichiers :</label>
                                    <input type="file" id="additional-documents" name="additional_documents[]" multiple accept=".pdf,.xls,.xlsx,.doc,.docx,.txt,.jpg,.png,.jpeg,.zip">
                                </div>
                                <div class="error-message"></div>
                            `;
                            $('#gen-note-sidebar-options-container').append(uploadFieldHtml).slideDown(); 
                        }
                        else{
                            $('#gen-note-sidebar-options-container').empty().slideUp(); 
                        }
    
                $("#gen-note-sidebar").addClass("open").show();
            }
        },
    )
   
});
$('#generate-note-btn').click(function () {
    let isValid = true;
    const variables = {};
    const docTitleInput = $('#note-title');
    if (!docTitleInput.val().trim()) {
        isValid = false;
        docTitleInput.parent().next('.error-message').show(); 
    } else {
        docTitleInput.parent().next('.error-message').hide(); 
    }
    const editorContents = getAllEditorContents(noteEditors);
    $('#note-variables-container').find('input, select').each(function () {
        const input = $(this);
        const isRequired = input.prop('required'); 
        
        if (isRequired && !input.val().trim()) { 
            isValid = false;
            input.parent().next('.error-message').show();
        } 
        else {
            input.parent().next('.error-message').hide();
            const value = $(this).val() || ""; 
            variables[input.attr('name')] = value;
            
                        
        }
    });
    /*for (const editorId in editorContents) {
        if (editorContents.hasOwnProperty(editorId)) {
            const varName=$(`#${editorId}`).attr('name');
            variables[varName] = editorContents[editorId];
        }
    }*/
        for (const editorId in editorContents) {
            if (editorContents.hasOwnProperty(editorId)) {
                const $editorElement = $(`#${editorId}`);
                const varName = $editorElement.attr('name');
                const content = editorContents[editorId];
        
                const $errorMessageElement = $editorElement.parent().parent().next('.error-message');
        //console.log($editorElement.attr('required'),content,content.trim());
                if ($editorElement.attr('required') && (!content || content.trim() === '<p><br></p>')) {
                    isValid = false;
                    $editorElement.addClass('error'); 
                    
                    // Affiche le message d'erreur
                    $errorMessageElement.text('Ce champ est requis.').show();
                } else {
                    $editorElement.removeClass('error');
                    
                    $errorMessageElement.text('').hide();
                }
        
                variables[varName] = content;
            }
        }
        
          console.log('fff',isValid)    
   
    const filesData = new FormData();
  


    if (!isValid) return;

    

    // Appel AJAX pour générer le document
    const doctitle = $('#note-title').val(); 
    const templateId =  $('#note_template_id').val();
       
    const userId = $('#note_user_id').val();
    filesData.append('action', 'save_generated_document');
    filesData.append('template_id', templateId);
    filesData.append('user_id', userId);
    filesData.append('variables', JSON.stringify(variables));
    filesData.append('doctitle', doctitle);
    const filesInput = $('#additional-documents');
    if (filesInput.length > 0 && filesInput[0].files.length > 0) {
    const files = filesInput[0].files;
    for (let i = 0; i < files.length; i++) {
        const file = files[i];

        // Vérification des extensions interdites
        const forbiddenExtensions = ['php', 'js', 'exe', 'bat', 'sh'];
        const fileExtension = file.name.split('.').pop().toLowerCase();

        if (forbiddenExtensions.includes(fileExtension)) {
            isValid = false;
            filesInput.parent().next('.error-message')
                .text('Le fichier "' + file.name + '" a une extension non autorisée.')
                .show();
        } else {
            filesData.append('additional_files[]', file); 
            filesInput.parent().next('.error-message').hide(); 
        }
    }
    }


    // Envoi de la requête AJAX avec $.ajax()
    $.ajax({
        url: ajax_object.ajax_url,
        type: 'POST',
        data: filesData,
        processData: false,
        contentType: false, 
        success: function (response) {

            if (response.success) {
                $('#gen-note-msg')
                    .text('Note ajouté avec succes.')
                    .addClass("text-success").removeClass("error-message")
                    .fadeIn()
                    .delay(1500)
                    .fadeOut(function() {
                        location.reload();
                    });
            } else {
                $('#gen-note-msg')
                    .text(response.data.message)
                    .removeClass("text-success").addClass("error-message")
                    .fadeIn()
                    .delay(1500)
                    .fadeOut();
            }
        },
        error: function() {
            $('#gen-note-msg')
                .text("Erreur lors de l\'ajout de la note.")
                .removeClass("text-success").addClass("error-message")
                .fadeIn()
                .delay(1500)
                .fadeOut();
        }
        
    });
});
///


//shortcodes table_document_generes   
    $(document).on("click", ".delete-document", function(e) {
        e.preventDefault();
        const documentId = $(this).data("id");
        const containerNotif = $(this).data("notif-container");

        if (confirm("Êtes-vous sûr de vouloir supprimer ce document ?")) {
            $.ajax({
                url: ajax_object.ajax_url,
                type: "POST",
                data: {
                    action: "delete_document",
                    document_id: documentId,
                    security: ajax_object.security
                },
                success: function(response) {
                    if (response.success) {
                        $(`#${containerNotif}`)
                            .text(response.data.message)
                            .addClass("text-success").removeClass("error-message")
                            .fadeIn()
                            .delay(1500)
                            .fadeOut(function() {
                                location.reload();
                            });
                    } else {
                        $(`#${containerNotif}`)
                            .text(response.data.message)
                            .removeClass("text-success").addClass("error-message")
                            .fadeIn()
                            .delay(1500)
                            .fadeOut();
                    }
                },
                error: function() {
                    $(`#${containerNotif}`)
                        .text("Erreur lors de la suppression du document.")
                        .removeClass("text-success").addClass("error-message")
                        .fadeIn()
                        .delay(1500)
                        .fadeOut();
                }
            });
        }
    });
    const toolbarOptions = [
        ["bold", "italic", "underline", "strike"], // toggled buttons
        ["blockquote", "code-block"],
        ["link", "image", "video", "formula"],

        [{ "header": 1 }, { "header": 2 }], // custom button values
        [{ "list": "ordered" }, { "list": "bullet" }, { "list": "check" }],
        [{ "script": "sub" }, { "script": "super" }], // superscript/subscript
        [{ "indent": "-1" }, { "indent": "+1" }], // outdent/indent
        [{ "direction": "rtl" }], // text direction

        [{ "size": ["small", false, "large", "huge"] }], // custom dropdown
        [{ "header": [1, 2, 3, 4, 5, 6, false] }],

        [{ "color": [] }, { "background": [] }], // dropdown with defaults from theme
        [{ "font": [] }],
        [{ "align": [] }],

        ["clean"] // remove formatting button
    ];

    let editVarsEditors={};
    $(document).on("click", ".regenerate-document", function(e) {
        e.preventDefault();
        const documentId = $(this).data("id");
        //const precedentId = $(this).data("precedent");
        //const suivantId = $(this).data("suivant");
        $('#get_document_data_to_edit_btn').show();
        $('#generate_document_confirm_edit_btn').hide();
        $('#generate_document_edit_submit').hide();
        $("#generate_document_edit_title").attr('readOnly',true);
        $('#crm_document_content').show().empty();
        $("#generate_document_edit_submit").prop("disabled", true);
            
        $("#generate_document_edit_contents_container").hide();
        $("#crm_document_note_version_container").hide();
        const currentTr = $(`.crm-doc-documents tr[data-id="${documentId}"]`);

        const precedentId = currentTr.data("precedent");
        const suivantId = currentTr.data("suivant");   
        $('#get_document_data_to_edit_btn').data("id",documentId)

        if(suivantId){

        $('#sidebar_document_suivant').data("id",suivantId).attr('disabled',false);
        }
        else{
            $('#sidebar_document_suivant').data("id","").attr('disabled',true);
    

        }
        if(precedentId){

            
            $('#sidebar_document_precedent').data("id",precedentId).attr('disabled',false);
        }
        else{
            $('#sidebar_document_precedent').data("id","").attr('disabled',true);
        

        }
                

        $.ajax({
            url: ajax_object.ajax_url,
            type: "POST",
            data: {
                action: "get_document_details",
                document_id: documentId,
            },
            success: function(response) {

                if (response.success) {
                    const data = response.data;
                    const attachments = data.attachments || [];
                    const variables = data.variables_document || {};
                    const templateVersion = data.template_version;
                    const documentVersion = data.document_version;
                    const variablesTemplate = data.variables_template || [];
                    let preFilled = response.data.pre_filled;
                    const templateRacine = response.data.racine;
                    const compteur = response.data.compteur || 1;
                    editVarsEditors={};
                    if(data.canDelete==true){
                        $('#sidebar_delete_document_btn').attr('disabled',false).show();
                    }
                    else{
                        $('#sidebar_delete_document_btn').attr('disabled',true).hide();
                    }


                    $('#sidebar_delete_document_btn').data("id",documentId);
                

                    const today = new Date();
                    const formattedDate = `${today.getDate().toString().padStart(2, '0')}-${(today.getMonth() + 1).toString().padStart(2, '0')}`; // JJ-MM
                                    
                                   
                    $("#generate_document_edit_right_sidebar").addClass("open");
                    $("#document_tier").html('<span>Tiers : </span>' +data.tiers).attr('href',data.FicheTiers);
                    $("#document_creator").html('<span>Par : </span>'+ data.creator);
                    $("#document_creation_date").html('<span>Crée le : </span>'+data.dateCreation);
                    
                    if(data.canEdit==true){
                        $('#get_document_data_to_edit_btn').show();
                    }
                    else{
                        $('#get_document_data_to_edit_btn').hide();
                    }

                     $('#crm_document_content').html(data.documentContent)
                    //$("#generate_document_edit_submit").prop("disabled", true);
                    $("#generate_document_edit_title").val(data.title).data("original-value", (data.title)).attr('readOnly',true);
                    $("#generate_document_edit_id").val(documentId);
                    //////////////////
                    const versionContainer = $("#crm_document_note_version_container");
                    const editContentContainer = $("#generate_document_edit_contents_container");
                  
                    $('#get_document_data_to_edit_btn').on("click", function () {
                        $('#crm_document_content').hide();
                        //versionContainer.hide();
                        //editContentContainer.show();
                        if (templateVersion === documentVersion) {
                            versionContainer.hide();
                            editContentContainer.show();
                            $('#generate_document_confirm_edit_btn').hide();
                            $('#get_document_data_to_edit_btn').hide();
                            $('#generate_document_edit_submit').show();

                            $("#generate_document_edit_title").attr('readOnly',false);

                            $('#add-new-attachement-tr').show();
                        } else {
                            versionContainer.show();
                            editContentContainer.hide();
                            $('#generate_document_confirm_edit_btn').show();
                            $('#get_document_data_to_edit_btn').hide();
                            //$('#generate_document_edit_submit').show();

                            $("#generate_document_edit_title").attr('readOnly',false);

                        }
                    });

                   

                    $("#generate_document_confirm_edit_btn").on("click", function () {
                        versionContainer.hide();
                        editContentContainer.show();
                        $('#generate_document_confirm_edit_btn').hide();
                        $('#generate_document_edit_submit').show();
                       
                        $('#add-new-attachement-tr').show();
                    }); /**/

                    

                // variablesContainer.empty();


                    /////////////////////
                    //$("#generate_document_edit_content").data("original-content", generate_document_escapeString(data.content))
                    //quillEditContent.setContents(quillEditContent.clipboard.convert(data.content));
                    let container = $('#generate_document_edit_contents_vars');
                    let hiddenChamps = ['template_name*', 'template_name', 'reference_template*', 'reference_template', 'undefined'];
                    let readOnlyChamps = ['creation_date#*', 'creation_date'];
                    let existingVariables = Object.keys(variables);
                    container.empty();

                    // Identifier les nouvelles variables qui ne sont pas dans `existingVariables`
                    let newVariables = variablesTemplate.filter(varName => !existingVariables.includes(varName));
                    

                    for (const [variable, value] of Object.entries(variables)) {
                        let cleanedVariable = variable.replace(/[*#@]/g, '').trim();
                        
                    
                        // Déterminer le style caché et en lecture seule
                        const hiddenStyle = hiddenChamps.includes(variable) ? 'style="display:none;"' : '';
                        const readOnlyAttr = readOnlyChamps.includes(variable) ? 'readonly' : '';
                    
                            if (variable.includes('@')) {
                                let requiredChamp = variable.includes('*');
                                const labelText = (labelsArray[variable.replace('@', '').replace('*', '').trim()] || variable.replace('@', '').replace('*', '').trim());
                                const sanitizedVariable = variable.replace(/'/g, '&#39;');
                                const sanitizedVariableId = variable.replace(/'/g, '&#39;').replace(/[@*]/g, 'a').replace(/\s+/g, '_');
                                const newvalue=generate_document_escapeString(value);
                                
                                container.append(`
                                    <div class="variable__item" ${hiddenStyle}style="height:260px;">
                                        <label class="crm-doc-label" for="${sanitizedVariableId}">${labelText}${requiredChamp ? ' *' : ''} :</label>
                                        <div style="width:100%"data-original-value="${newvalue}"style="height:250px;">
                                            <div id="${sanitizedVariableId}" name="${sanitizedVariable}" style="width: -webkit-fill-available; height:200px;" ${requiredChamp ? 'required' : ''} ${readOnlyAttr}>${value}</div>
                                        </div>
                                    </div>
                                    <div class="error-message" style="color:red;display:none;">Ce champ est requis.</div>
                                `);
                                const quillInstance = new Quill(`#${sanitizedVariableId}`, { theme: "snow" });
                                editVarsEditors[sanitizedVariableId] = quillInstance;

                    
                                /*editVarsEditors[sanitizedVariableId] = new Quill(`#${sanitizedVariableId}`, {
                                    theme: "snow"
                                });*/
                                quillInstance.on("text-change", function () {
                                    $(document).trigger("quill-text-change", [sanitizedVariableId, quillInstance]);
                                });
                    
                            } else if (variable.includes('|')) {
                                const options = variable.split('|').slice(1);
                                const parts = variable.split('|');
                                let labelText = parts[0].trim();
                                let requiredChamp = labelText.includes('*');
                                labelText = labelText.replace(/[^a-zA-Z0-9\s]/g, ''); // Nettoyage
                                const sanitizedVariable = variable.replace(/'/g, '&#39;');
                    
                                container.append(`
                                    <div class="variable__item" ${hiddenStyle}>
                                        <label class="crm-doc-label" for="${sanitizedVariable}">${labelText}${requiredChamp ? ' *' : ''} :</label>
                                        <select class="crm-doc-select" id="${sanitizedVariable}"data-original-value="${value}" name="${sanitizedVariable}" ${requiredChamp ? 'required' : ''}>
                                            ${options.map(option => `<option value="${option}"${value == option ? ' selected' : ''}>${option}</option>`).join('')}
                                        </select>
                                    </div>
                                    <div class="error-message" style="color:red;display:none;">Ce champ est requis.</div>
                                `);
                    
                            } else if (variable.includes('#')) {
                                const labelText = labelsArray[cleanedVariable] || cleanedVariable;
                                let requiredChamp = labelText.includes('*');
                    
                                container.append(`
                                    <div class="variable__item" ${hiddenStyle}>
                                        <label class="crm-doc-label" for="${variable}">${labelText}${requiredChamp ? ' *' : ''} :</label>
                                        <input class="crm-doc-input"type="date" id="${variable}"data-original-value="${value}" name="${variable}" value="${value}" ${requiredChamp ? 'required' : ''} ${readOnlyAttr}/>
                                    </div>
                                    <div class="error-message" style="color:red;display:none;">Ce champ est requis.</div>
                                `);
                    
                            } else {
                                const requiredChamp = variable.includes('*');
                                const labelText = labelsArray[cleanedVariable] || cleanedVariable;
                                const sanitizedVariable = cleanedVariable.replace(/'/g, '&#39;');
                    
                                container.append(`
                                    <div class="variable__item" ${hiddenStyle}>
                                        <label class="crm-doc-label"for="${variable}">${labelText}${requiredChamp ? ' *' : ''} :</label>
                                        <input class="crm-doc-input"type="text" id="${variable}"data-original-value="${value}" name="${variable}" value="${value}" ${requiredChamp ? 'required' : ''} ${readOnlyAttr}/>
                                    </div>
                                    <div class="error-message" style="color:red;display:none;">Ce champ est requis.</div>
                                `);
                            }
                    }

                    
                    const attachmentsArray = Array.isArray(attachments) ? attachments : Object.values(attachments);
                    console.log(attachmentsArray)
                
                    // Construire la table des pièces jointes
                    if (attachmentsArray.length > 0 || (data.acceptAttachement == "on"&&data.canEdit==true)) {
                       
                        $('.sidebar-content-right').show();
                        let attachmentsHtml = "<p>Documents joints</p><table><thead><tr></tr></thead><tbody>";
                        if (attachmentsArray.length > 0) {
                           
                            attachmentsArray.forEach((docUrl) => {
                                
                            
                                const fileName = docUrl.split("/").pop();
                                const fileExtension = fileName.split('.').pop().toLowerCase();
                                const iconUrl = data.plugin_base_url+ '/'+ getFileIcon(fileExtension);
                                const deleteIcon = data.plugin_base_url+ '/trash-icon.svg';
                                attachmentsHtml += `
                                    <tr>
                                        <td><img class="icon-attachment" src="${iconUrl}" alt="File Icon"></td>
                    
                                        <td><a href="${docUrl}" target="_blank">${fileName}</a></td>
                                    <td> `;

                                    if(data.canDelete==true){
                                        attachmentsHtml += `<img  class="delete-attachment" data-document-id="${documentId}" data-url="${docUrl}" src="${deleteIcon}" alt="delete Icon">
                                    `;
                                    }
                                    else{
                                        attachmentsHtml += `--`;
                                    }
                                        attachmentsHtml += `
                                        </td>
                                        </tr>
                                `;
                            });
                        }

                        if (data.acceptAttachement == "on"&&data.canEdit==true) {
                            const iconAdd = data.plugin_base_url + "add-icon.svg";
                            attachmentsHtml += ` <tr id="add-new-attachement-tr">
                                <td colspan="3"style="text-align: end;">
                                <img  class="add-attachment"   id="add-new-document-attachment-btn"src="${iconAdd}" alt="Add Icon" >
                            
                                
                                </td>
                            </tr>`;
                        }
                        attachmentsHtml += "</tbody></table>";
                        $("#generate_document_edit_attachement_container").html(attachmentsHtml);
                
                    }   
                    else{
                        $('.sidebar-content-right').hide();
                    } 
                
                } 
                else {
                    alert("Erreur: " + response.data);
                }
            },
            error: function() {
                alert("Une erreur s\'est produite.");
            }
        });
    });

    $(document).on("quill-text-change", function (event, editorId, quillInstance) {
        checkForChanges1();
    });
    
  

    $(document).on("click", function(e) {
        const isOutsideEditSidebar = !$(e.target).closest(".right-sidebar").length;

        const isDiscardEditSidebarButton1 = $(e.target).is("#generate_document_edit_discard");
        const isDiscardEditEditSidebarButton2= $(e.target).is(".discard-sidebar");

        const isOutsideNoteSidebar = !$(e.target).closest(".crm_gen_note_sidebar").length;
        const isDiscardNoteButton = $(e.target).is(".discard-note-sidebar");

        const isOutsideNewDocSidebar = !$(e.target).closest("#gen-document-sidebar").length;
        const isBtnAddNewDocSidebar = $(e.target).closest("#show-gen-document-sidebar-btn").length;
        const isDiscardNewDocButton = $(e.target).is(".discard-document-sidebar");
        if ((isOutsideEditSidebar || isDiscardEditSidebarButton1 ||isDiscardEditEditSidebarButton2)&& $(".right-sidebar").hasClass("open")) {
            $(".right-sidebar").removeClass("open");
            $(".right-sidebar").removeClass("open");
            $("#generate_document_edit_attachement_container,#generate_document_edit_contents_vars").empty();
            $("#generate_document_edit_title").val("");
            $(".right-sidebar input").val("");
            $("#generate_document_edit_new_attachment_container").hide();
            $("#generate_document_edit_submit").prop("disabled", true);
            $('#get_document_data_to_edit_btn').show();
            $('#generate_document_confirm_edit_btn').hide();
            $('#generate_document_edit_submit').hide();
            $("#generate_document_edit_title").attr('readOnly',true);
            $('#crm_document_content').show().empty();
            $("#generate_document_edit_contents_container").hide();
            $("#crm_document_note_version_container").hide();
            
         
        }

        // Fermer la sidebar des notes si elle est ouverte et clic à l'extérieur
        if ((isDiscardNoteButton||isOutsideNoteSidebar) && $(".crm_gen_note_sidebar").hasClass("open")) {
            $(".crm_gen_note_sidebar").removeClass("open").hide();
            $('#note-variables-container').empty();

            $('#gen-note-sidebar-options-container').empty().slideUp(); 
        }
        if (((!isBtnAddNewDocSidebar&&isOutsideNewDocSidebar)||isDiscardNewDocButton) && $("#gen-document-sidebar").hasClass("open")) {
            console.log('bbbb',isOutsideNewDocSidebar,isDiscardNewDocButton,$("#gen-document-sidebar").hasClass("open"))
            $("#gen-document-sidebar").removeClass("open").hide();

            $('#variables-container').empty().hide();
            $('#template-select,#gen-document-sidebar-document-title').val('');
            $('#gen-document-sidebar-options-container').empty().slideUp();
            $('#gen-document-sidebar-associated-templates').empty().slideUp();
            $('#gen-document-sidebar-variables-list').slideUp();
            $('#gen-document-sidebar-submit').attr('disabled',true);
        }
    
    });

    function generate_document_escapeString(str) {
        if (typeof str !== "string") return str;
        if (str.includes('"')) {
            return str.replace(/"/g, " ");
        }
        else
        return str;

       // return str.replace(/\"/g, "'").replace(/\'/g, "\\'");
    }
    $("#generate_document_edit_title").on("input", checkForChanges1);
    $("#generate_document_edit_new_attachment").on("change", checkForChanges1);

    $(document).on("input", "#generate_document_edit_contents_vars input",checkForChanges1 );
    $(document).on("input", "#generate_document_edit_title",checkForChanges1 );
    $(document).on("change", "#generate_document_edit_contents_vars select",checkForChanges1 );
   
    function checkForChanges1() {
        let hasChanges = false;
        $('#generate_document_edit_contents_vars').find('input:visible, select:visible').each(function() {
            
            const originalValue = $(this).data('original-value');
            const currentValue = $(this).val();

            if (originalValue != currentValue) {
                hasChanges = true;
                return false; 
            }
        });
        let editorHasChanges=false;
        let updatedTitle=$("#generate_document_edit_title").data("original-value")!=$("#generate_document_edit_title").val()
        let hasNewFiles = $("#generate_document_edit_new_attachment").get(0).files && $("#generate_document_edit_new_attachment").get(0).files.length > 0;
        for (const [editorId, quillInstance] of Object.entries(editVarsEditors)) {
            const currentContent = generate_document_escapeString(quillInstance.root.innerHTML); 
            const originalContent = $(`#${editorId}`).parent().data("original-value"); 
            if (originalContent != ""&&currentContent != originalContent) {
                editorHasChanges= true;  
                console.log('aaa',editorId)
   
                

            }
        }
       console.log('xs',editorHasChanges,hasChanges,updatedTitle)
        
        if (hasChanges||updatedTitle||hasNewFiles||editorHasChanges)
                    
         {
            $("#generate_document_edit_submit").prop("disabled", false);
        } else {
            $("#generate_document_edit_submit").prop("disabled", true);
        }
    }
 

    $(document).on("submit", "#generate_document_edit_form", function(e) {
        e.preventDefault();

        const formData = new FormData(this);
        isValid = true;
        //const quillContent = quillEditContent.root.innerHTML;
        //formData.append("content", quillContent);
        let variables= {};
        formData.append("action", "edit_generated_post_content");
        //formData.append("generatePdf", "on");
        const filesInput = $("#generate_document_edit_new_attachment");
        if (filesInput.length > 0 && filesInput[0].files.length > 0) {
            const files = filesInput[0].files;
            for (let i = 0; i < files.length; i++) {
                const file = files[i];

                const forbiddenExtensions = ["php", "js", "exe", "bat", "sh"];
                const fileExtension = file.name.split('.').pop().toLowerCase();

                if (forbiddenExtensions.includes(fileExtension)) {
                    isValid = false;
                    filesInput.parent().next(".error-message")
                        .text("Le fichier " + file.name + " a une extension non autorisée.")
                        .show();
                } else {
                    formData.append("additional_files[]", file);
                    filesInput.parent().next(".error-message").hide();
                }
            }
        }

        const docTitleInput = $('#generate_document_edit_title');
        if (!docTitleInput.val().trim()) {
            isValid = false;
            docTitleInput.parent().next('.error-message').show(); 
        } else {
            docTitleInput.parent().next('.error-message').hide(); 
        }
        const editorContents = getAllEditorContents(editVarsEditors);
        $('#generate_document_edit_contents_vars').find('input, select').each(function () {
            const input = $(this);
            const isRequired = input.prop('required'); 
            
            if (isRequired && !input.val().trim()) { 
                isValid = false;
                input.parent().next('.error-message').show();
            } 
            else {
                input.parent().next('.error-message').hide();
                const value = $(this).val() || ""; 
                variables[input.attr('name')] = value;
                
                            
            }
        });
        /*for (const editorId in editorContents) {
            if (editorContents.hasOwnProperty(editorId)) {
                const varName=$(`#${editorId}`).attr('name');
                variables[varName] = editorContents[editorId];
            }
        }*/
            for (const editorId in editorContents) {
                if (editorContents.hasOwnProperty(editorId)) {
                    const $editorElement = $(`#${editorId}`);
                    const varName = $editorElement.attr('name');
                    const content = editorContents[editorId];
            
                    const $errorMessageElement = $editorElement.parent().parent().next('.error-message');
            
                    if ($editorElement.attr('required') && (!content || content.trim() === '<p><br></p>')) {
                        isValid = false;
                        $editorElement.addClass('error'); 
                        
                        // Affiche le message d'erreur
                        $errorMessageElement.text('Ce champ est requis.').show();
                    } else {
                        $editorElement.removeClass('error');
                        
                        $errorMessageElement.text('').hide();
                    }
            
                    variables[varName] = content;
                }
            }


        if(isValid)
        {

        formData.append('variables', JSON.stringify(variables));
            $.ajax({
                url: ajax_object.ajax_url,
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                       // alert("Document mis à jour avec succès.");
                        // location.reload(); 
                         $("#sidebar_document_msg")
                         .text("Document mis à jour avec succès")
                         .addClass("text-success").removeClass("error-message")
                         .fadeIn()
                         .delay(1500)
                         .fadeOut(function() {
                             location.reload();
                         });
                 } else {
                     $("#sidebar_document_msg")
                         .text(response.data.message)
                         .removeClass("text-success").addClass("error-message")
                         .fadeIn()
                         .delay(1500)
                         .fadeOut(
                             
                         );
                 }
                   
                },
                error: function() {
                    alert("Une erreur s\'est produite lors de la mise à jour.");
                }
            });
            
        }
    });
    $(document).on("submit", "#edit-event", function(e) {
        e.preventDefault();

        const formData = new FormData(this);
        isValid = true;
        //const quillContent = quillEditContent.root.innerHTML;
        //formData.append("content", quillContent);
        let variables= {};
        formData.append("action", "edit_generated_post_content");
        formData.append("generatePdf", "off");
        const filesInput = $("#generate_event_edit_new_attachment");
        if (filesInput.length > 0 && filesInput[0].files.length > 0) {
            const files = filesInput[0].files;
            for (let i = 0; i < files.length; i++) {
                const file = files[i];

                const forbiddenExtensions = ["php", "js", "exe", "bat", "sh"];
                const fileExtension = file.name.split('.').pop().toLowerCase();

                if (forbiddenExtensions.includes(fileExtension)) {
                    isValid = false;
                    filesInput.parent().next(".error-message")
                        .text("Le fichier " + file.name + " a une extension non autorisée.")
                        .show();
                } else {
                    formData.append("additional_files[]", file);
                    filesInput.parent().next(".error-message").hide();
                }
            }
        }

        const docTitleInput = $('#generate_events_document_title');
        if (!docTitleInput.val().trim()) {
            isValid = false;
            docTitleInput.parent().next('.error-message').show(); 
        } else {
            docTitleInput.parent().next('.error-message').hide(); 
        }
        const editorContents = getAllEditorContents(editVarsEditors);
        $('#generate_events_contents_vars').find('input, select').each(function () {
            const input = $(this);
            const isRequired = input.prop('required'); 
            
            if (isRequired && !input.val().trim()) { 
                isValid = false;
                input.parent().next('.error-message').show();
            } 
            else {
                input.parent().next('.error-message').hide();
                const value = $(this).val() || ""; 
                variables[input.attr('name')] = value;
                
                            
            }
        });
        /*for (const editorId in editorContents) {
            if (editorContents.hasOwnProperty(editorId)) {
                const varName=$(`#${editorId}`).attr('name');
                variables[varName] = editorContents[editorId];
            }
        }*/
            for (const editorId in editorContents) {
                if (editorContents.hasOwnProperty(editorId)) {
                    const $editorElement = $(`#${editorId}`);
                    const varName = $editorElement.attr('name');
                    const content = editorContents[editorId];
            
                    const $errorMessageElement = $editorElement.parent().parent().next('.error-message');
            
                    if ($editorElement.attr('required') && (!content || content.trim() === '<p><br></p>')) {
                        isValid = false;
                        $editorElement.addClass('error'); 
                        
                        // Affiche le message d'erreur
                        $errorMessageElement.text('Ce champ est requis.').show();
                    } else {
                        $editorElement.removeClass('error');
                        
                        $errorMessageElement.text('').hide();
                    }
            
                    variables[varName] = content;
                }
            }

        if(isValid)
        {

        formData.append('variables', JSON.stringify(variables));
            $.ajax({
                url: ajax_object.ajax_url,
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                       // alert(".");
                         //location.reload(); 
                         $("#sidebar_event_msg")
                            .text("Contenu mis à jour avec succès")
                            .addClass("text-success").removeClass("error-message")
                            .fadeIn()
                            .delay(1500)
                            .fadeOut(function() {
                                location.reload();
                            });
                    } else {
                        $("#sidebar_event_msg")
                            .text(response.data.message)
                            .removeClass("text-success").addClass("error-message")
                            .fadeIn()
                            .delay(1500)
                            .fadeOut(

                            );
                    }

                  
                },
                error: function() {
                    alert("Une erreur s\'est produite lors de la mise à jour.");
                }
            });
            
        }
    });
    $(document).on("click", ".delete-attachment", function() {
        const button = $(this);
        const documentId = button.data("document-id");
        const docUrl = button.data("url");

        if (!confirm("Êtes-vous sûr de vouloir supprimer ce document ?")) {
            return;
        }
        $.ajax({
            url: ajax_object.ajax_url,
            method: "POST",
            data: {
                action: "delete_attachement",
                // security: deleteDocumentNonce, // Nonce généré pour la sécurité
                document_id: documentId,
                attachement_url: docUrl,
            },
            success: function(response) {
                if (response.success) {
                    //alert(response.data.message);
                   // location.reload();
                   let msgContainer=$('#generate_document_edit_right_sidebar').hasClass('open')?"sidebar_document_msg":'sidebar_event_msg';
                   $(`#${msgContainer}`)
                   .text("Attachement supprimé avec succès")
                   .addClass("text-success").removeClass("error-message")
                   .fadeIn()
                   .delay(1500)
                   .fadeOut(function() {
                       location.reload();
                   });
           } else {
            $(`#${msgContainer}`)
                   .text(response.data.message)
                   .removeClass("text-success").addClass("error-message")
                   .fadeIn()
                   .delay(1500)
                   .fadeOut(
                       
                   );
           }
                
            },
            error: function() {
                alert("Une erreur s\'est produite lors de la suppression du document.");
            },
        });


    });
    //generate_event_confirm_edit



    $(document).on('click', '#add-new-attachment-btn', function () {
        $("#generate_event_edit_new_attachment_container").show();
    });
    $(document).on('click', '#add-new-document-attachment-btn', function () {
        $("#generate_document_edit_new_attachment_container").show();
    });
    function getFileIcon(fileExtension) {
        switch (fileExtension) {
            case 'pdf':
                return 'pdf-icon.svg';
            case 'doc':
            case 'docx':
                return 'word-icon.svg';
            case 'xls':
            case 'xlsx':
                return 'excel-icon.svg';
            case 'jpg':
            case 'jpeg':
            case 'png':
                return 'image-icon.svg';
            case 'zip':
            case 'rar':
                return 'zip-icon.svg';
            default:
                return 'default-icon.svg';
        }
    }
    
    $(document).on("click", ".edit-documentold", function(e) {
        e.preventDefault();
        const documentId = $(this).data("id");

        $.ajax({
            url: ajax_object.ajax_url,
            type: "POST",
            data: {
                action: "get_document_details",
                document_id: documentId,
            },
            success: function(response) {

                if (response.success) {
                    const data = response.data;
                    const attachments = data.attachments || [];
                    $("#generate_events_right_sidebar").addClass("open");

                   // $("#submit_edit_document").prop("disabled", true);
                    $("#generate_events_document_title").val(data.title).data("original-title", escapeString(data.title));
                    $("#generate_events_document_id").val(documentId);
                    $("#generate_events_document_content").data("original-content", escapeString(data.content))
                   // quillEditorContent.setContents(quillEditorContent.clipboard.convert(data.content));

                    // Construire la table des pièces jointes
                    if (attachments.length) {

                        let attachmentsHtml = "<table><thead><tr><th>Nom du fichier</th><th>Action</th></tr></thead><tbody>";
                        attachments.forEach(function(docUrl) {
                            const fileName = docUrl.split("/").pop();
                            attachmentsHtml += `
                                <tr>
                                    <td><a href="${docUrl}" target="_blank">${fileName}</a></td>
                                    <td><button type="button" class="delete-attachment" data-document-id="${documentId}" data-url="${docUrl}">Supprimer</button></td>
                                </tr>
                            `;
                        });
                        attachmentsHtml += "</tbody></table>";
                        $("#documents_container").html(attachmentsHtml);
                    }
                    if (data.acceptAttachement == "on") {
                        $("#new-attachment-container").show();
                    } else {
                        $("#new-attachment-container").hide();
                    }

                } else {
                    alert("Erreur: " + response.data);
                }
            },
            error: function() {
                alert("Une erreur s\'est produite.");
            }
        });
    });


    function escapeString(str) {
        if (typeof str !== "string") return str;
        return str.replace(/\'/g, "\'");
    }

    $("#generate_events_document_title").on("input", checkForChanges);
    $("#new-attachment").on("change", checkForChanges);

   // quillEditorContent.on("text-change", checkForChanges);

    function checkForChanges() {

        const originalTitle = escapeString($("#generate_events_document_title").data("original-title") || "");
        const currentTitle = escapeString($("#generate_events_document_title").val());

        const originalContent = escapeString($("#generate_events_document_content").data("original-content") || "");
        //const currentContent = escapeString(quillEditorContent.root.innerHTML.trim());

        if (
            originalTitle !== currentTitle ||
            //originalContent !== currentContent ||
            $("#new-attachment").val() != ""
        ) {
            $("#submit_edit_document").prop("disabled", false);
        } else {
            $("#submit_edit_document").prop("disabled", true);
        }
    }
    


    // Gestion de la soumission du formulaire
    $(document).on("submit", "#edit-eventold", function(e) {
        e.preventDefault();

        const formData = new FormData(this);
        const quillContent = quillEditorContent.root.innerHTML;
        formData.append("content", quillContent);
        formData.append("action", "edit_generated_post_content");
        formData.append("generatePdf", "off");
        const filesInput = $("#new-attachment");
        if (filesInput.length > 0 && filesInput[0].files.length > 0) {
            const files = filesInput[0].files;
            for (let i = 0; i < files.length; i++) {
                const file = files[i];

                const forbiddenExtensions = ["php", "js", "exe", "bat", "sh"];
                const fileExtension = file.name.split('.').pop().toLowerCase();

                if (forbiddenExtensions.includes(fileExtension)) {
                    isValid = false;
                    filesInput.parent().next(".error-message")
                        .text("Le fichier " + file.name + " a une extension non autorisée.")
                        .show();
                } else {
                    formData.append("additional_files[]", file);
                    filesInput.parent().next(".error-message").hide();
                }
            }
        }




        $.ajax({
            url: ajax_object.ajax_url,
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    //alert("Document mis à jour avec succès.");
                    location.reload();
                } else {
                    alert("Erreur: " + response.data);
                }
            },
            error: function() {
                alert("Une erreur s\'est produite lors de la mise à jour.");
            }
        });
    });

    /*

    $(document).on("click", ".delete-document", function(e) {
        e.preventDefault();
        const documentId = $(this).data("id");

        if (confirm("Êtes-vous sûr de vouloir supprimer ce document ?")) {
            $.ajax({
                url: ajax_object.ajax_url,
                type: "POST",
                data: {
                    action: "delete_document",
                    document_id: documentId,
                    security: ajax_object.security
                },
                success: function(response) {
                    if (response.success) {
                        $("#msg-div-container")
                            .text(response.data.message)
                            .addClass("text-success").removeClass("error-message")
                            .fadeIn()
                            .delay(1500)
                            .fadeOut(function() {
                                location.reload();
                            });
                    } else {
                        $("#msg-div-container")
                            .text(response.data.message)
                            .removeClass("text-success").addClass("error-message")
                            .fadeIn()
                            .delay(1500)
                            .fadeOut();
                    }
                },
                error: function() {
                    $("#msg-div-container")
                        .text("Erreur lors de la suppression du document.")
                        .removeClass("text-success").addClass("error-message")
                        .fadeIn()
                        .delay(1500)
                        .fadeOut();
                }
            });
        }
    });
    $(document).on("click", ".delete-attachment", function() {
        const button = $(this);
        const documentId = button.data("document-id");
        const docUrl = button.data("url");

        if (!confirm("Êtes-vous sûr de vouloir supprimer ce document ?")) {
            return;
        }
        $.ajax({
            url: ajax_object.ajax_url,
            method: "POST",
            data: {
                action: "delete_attachement",
                // security: deleteDocumentNonce, // Nonce généré pour la sécurité
                document_id: documentId,
                attachement_url: docUrl,
            },
            success: function(response) {
                if (response.success) {
                    //alert(response.data.message);
                    location.reload();
                } else {
                    alert("Erreur : " + response.data.message);
                }
            },
            error: function() {
                alert("Une erreur s\'est produite lors de la suppression du document.");
            },
        });


    });*/








});