<?php

// Fonction pour enregistrer le Custom Post Type
function vosfactures_register_facture_cpt() {
    $labels = array(
        'name'               => 'Factures',
        'singular_name'      => 'Facture',
        'menu_name'          => 'Factures',
        'name_admin_bar'     => 'Facture',
        'add_new'            => 'Ajouter Nouvelle',
        'add_new_item'       => 'Ajouter Nouvelle facture',
        'new_item'           => 'Nouvelle facture',
        'edit_item'          => 'Modifier la facture',
        'view_item'          => 'Voir la facture',
        'all_items'          => 'Factures',
        'search_items'       => 'Rechercher factures',
        'parent_item_colon'  => 'Facture Parente :',
        'not_found'          => 'Aucune facture trouvée.',
        'not_found_in_trash' => 'Aucune facture trouvée dans la corbeille.'
    );

    $args = array(
        'labels'             => $labels,
        'public'             => false,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'show_in_menu'       => 'crm-dashboard',
        'capability_type'    => 'post',
        'capabilities'  => [
            'create_posts' => 'do_not_allow', 
        ],
        'map_meta_cap'       => true,
        'hierarchical'       => false,
        'menu_position'      => 25,
        'menu_icon'          => 'dashicons-media-spreadsheet',
        'supports'           => array('title'),//, 'editor'
        'has_archive'        => false,
        'rewrite'            => false,
    );

    register_post_type('facture', $args);
}


add_action('init', 'vosfactures_register_facture_cpt');

// Fonction pour ajouter des métadonnées personnalisées
function vosfactures_add_meta_boxes() {
    add_meta_box(
        'vosfactures_meta_box',
        'Détails de la Facture',
        'vosfactures_meta_box_callback',
        'facture',
        'normal',
        'default'
    );
}
function vosfactures_meta_box_callback($post) {
    wp_nonce_field('vosfactures_save_meta_box_data', 'vosfactures_meta_box_nonce');

    $number = get_post_meta($post->ID, '_vosfacture_number', true);
    $kind = get_post_meta($post->ID, '_vosfacture_kind', true);
    $id = get_post_meta($post->ID, '_vosfacture_id', true);
    $issue_date = get_post_meta($post->ID, '_vosfacture_issue_date', true);
    $price_net = get_post_meta($post->ID, '_vosfacture_price_net', true);
    $price_gross = get_post_meta($post->ID, '_vosfacture_price_gross', true);
    $paid = get_post_meta($post->ID, '_vosfacture_paid', true);
    $view_url = get_post_meta($post->ID, '_vosfacture_view_url', true);
    $vendeurId = get_post_meta($post->ID, '_vosfacture_department_id', true);
    $client_id = get_post_meta($post->ID, '_vosfacture_client_id', true);
    $payment_to = get_post_meta($post->ID, '_vosfacture_payment_to', true);
    $status = get_post_meta($post->ID, '_vosfacture_status', true);
    $commentaire = get_post_meta($post->ID, '_vosfacture_commentaire', true);
    //$vendeurId = get_post_meta($post->ID, '_vosfacture_department_id', true);
    $client_display_name=$client_id;
    $users = get_users([
        'meta_key'   => 'vosfactures_id',
        'meta_value' => $client_id,
        'number'     => 1,
        'fields'     => ['display_name'], 
    ]);

    if (!empty($users)) {
        $client_display_name= $users[0]->display_name;
    }

    
    $fields = [
        'Référence' => $number,
        'Numéro de Facture' => $number,
        'Type' => $kind,
        'ID' => $id,
        'Date d\'émission' => $issue_date,
        'Montant HT' => $price_net,
        'Montant TTC' => $price_gross,
        'Montant Réglé' => $paid,
        'Lien de Visualisation' => $view_url,
        'Date limite de règlement' => $payment_to,
        'Status' => $status
    ];
    foreach ($fields as $label => $value) {
        echo '<div class="vosfactures-field">';
        echo '<label>' . esc_html($label) . ':</label>';
        echo '<input type="text" value="' . esc_attr($value) . '" readonly />';
        echo '</div>';
    }

    // === CHAMPS MODIFIABLES SI STATUS = PAID ===
    if ($status === 'paid') {
        // CHAMP CLIENT - AutoComplete
        echo '<div class="vosfactures-field">';
        echo '<label for="vosfacture_client_autocomplete">Client :</label>';
        echo '<input type="text" name="vosfacture_client_autocomplete" id="vosfacture_client_autocomplete" value="' . esc_attr($client_display_name) . '" placeholder="Rechercher un client..." />';
        echo '</div>';
        echo '<div class="vosfactures-field">';
        echo '<label>ID Client :</label>';
        echo '<input type="text" name="vosfacture_client_id" id="vosfacture_client_id" value="' . esc_attr($client_id) . '" readOnly/>';
        echo '</div>';

        // CHAMP VENDEUR - Dropdown départements 
        echo '<div class="vosfactures-field">';
        echo '<label for="vosfacture_vendeur_id">Vendeur :</label>';
        echo '<select name="vosfacture_vendeur_id" id="vosfacture_vendeur_id">';
        echo '<option value="">-- Sélectionnez --</option>';
        $selected_vendeur = $vendeurId;
        if (get_option('vosfactures_sync_enabled') == 'yes') {
            $departments_vf = get_option('_crm_vosfactures_departments', []);
            $departments_manual = get_option('_crm_departements_manuels', []);

            if (!empty($departments_vf)) {
                echo '<optgroup label="Depuis VosFactures">';
                foreach ($departments_vf as $dept) {
                    $selected = ($dept['id'] == $selected_vendeur) ? 'selected' : '';
                    echo '<option value="' . esc_attr($dept['id']) . '" ' . $selected . '>' . esc_html($dept['nom_usage']) . '</option>';
                }
                echo '</optgroup>';
            }

            if (!empty($departments_manual)) {
                echo '<optgroup label="Ajout manuel">';
                foreach ($departments_manual as $dept) {
                    $selected = ($dept['id'] == $selected_vendeur) ? 'selected' : '';
                    echo '<option value="' . esc_attr($dept['id']) . '" ' . $selected . '>' . esc_html($dept['nom_usage']) . '</option>';
                }
                echo '</optgroup>';
            }
        }

        echo '</select>';
        echo '</select>';
        echo '</div>';
    }
    else {
        // Lecture seule pour Client et Vendeur
        echo '<div class="vosfactures-field">';
        echo '<label for="vosfacture_client_autocomplete">Client :</label>';

        echo '<input type="text" name="vosfacture_client_autocomplete" id="vosfacture_client_autocomplete" value="' . esc_attr($client_display_name) . '" placeholder="Rechercher un client..." /readOnly>';
       echo '</div>';
       echo '<div class="vosfactures-field">';
        echo '<label>ID Client :</label>';
        echo '<input type="text" value="' . esc_attr($client_id) . '" readonly />';
        echo '</div>';

        echo '<div class="vosfactures-field">';
        echo '<label>Vendeur :</label>';
        echo '<input type="text" value="' . esc_attr($vendeurId) . '" readonly />';
        echo '</div>';
    }

    // COMMENTAIRE (toujours éditable)
    echo '<div class="vosfactures-field">';
    echo '<label>Commentaire:</label>';
    echo '<textarea rows="4" cols="50" name="vosfacture_commentaire">' . esc_textarea($commentaire) . '</textarea>';
    echo '</div>';
    echo '<style>
    .vosfactures-field { display: flex; align-items: center; margin-bottom: 10px; }
    .vosfactures-field label { width: 180px; font-weight: bold; }
    .vosfactures-field input, .vosfactures-field select, .vosfactures-field textarea {
        flex: 1; padding: 5px; border: 1px solid #ccc; border-radius: 4px; background-color: #f9f9f9;
    }
    .vosfactures-field textarea { resize: vertical; }
</style>';

    echo "<script>jQuery(document).ready(function($) {
        $('#vosfacture_client_autocomplete').autocomplete({
            source: function(request, response) {
                $.ajax({
                    url: ajaxurl,
                    dataType: 'json',
                    data: {
                        action: 'autocomplete_clients',
                        term: request.term
                    },
                    success: function(data) {
                        response(data);
                    }
                });
            },
            minLength: 2,
            select: function(event, ui) {
                $('#vosfacture_client_autocomplete').val(ui.item.value);
                $('#vosfacture_client_id').val(ui.item.id);
            }
        });
    });</script>";
}


add_action('add_meta_boxes', 'vosfactures_add_meta_boxes');
function autocomplete_clients_callback() {
    $term = sanitize_text_field($_GET['term']);
    $results = [];

    $args = [
        'number' => -1,
        'meta_query' => [
            [
                'key' => 'user_status',
                'value' => ['ACTIF', 'actif', 'active'],
                'compare' => 'IN',
            ],
        ],
        'role__in' => ['tiers', 'customer', 'prospect', 'non_qualifie', 'hors_cible']
    ];

    $user_query = new WP_User_Query($args);
    $users = $user_query->get_results();

    $filtered_users = array_filter($users, function($user) use ($term) {
        if (stripos($user->display_name, $term) !== false || stripos($user->user_nicename, $term) !== false || stripos($user->user_email, $term) !== false) {
            return true;
        }
        $user_meta = get_user_meta($user->ID);
        foreach ($user_meta as $key => $values) {
            foreach ($values as $value) {
                if (stripos($value, $term) !== false) {
                    return true;
                }
            }
        }
        return false;
    });

    $filtered_users = array_slice($filtered_users, 0, 10);

    foreach ($filtered_users as $user) {
        $first_name = get_user_meta($user->ID, 'billing_first_name', true);
        $last_name = get_user_meta($user->ID, 'billing_last_name', true);
        $company_name = get_user_meta($user->ID, 'billing_company', true);

        $display = trim("$first_name $last_name");
        
        
            $results[] = [
                'id' => get_user_meta($user->ID,'vosfactures_id',true),
               'label' => $user->display_name, 
            'value' => $user->display_name 
            ];
        
    }

    wp_send_json($results);
}
add_action('wp_ajax_autocomplete_clients', 'autocomplete_clients_callback');
add_action('wp_ajax_nopriv_autocomplete_clients', 'autocomplete_clients_callback');
// Fonction pour sauvegarder les métadonnées personnalisées


add_action('save_post', 'vosfactures_save_meta_box_data');
function vosfactures_save_meta_box_data($post_id) {
    /* if (!isset($_POST['vosfactures_meta_box_nonce'])) {
        return;
    }

   if (!wp_verify_nonce($_POST['vosfactures_meta_box_nonce'], 'vosfactures_save_meta_box_data')) {
        return;
    }*/

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    $fields = [
        'vosfacture_vendeur_id' => '_vosfacture_department_id',
        'vosfacture_client_id' => '_vosfacture_client_id',
        'vosfacture_commentaire' => '_vosfacture_commentaire',
    ];
    $client_modified = false;
    $dept_modified = false;
    foreach ($fields as $field_key => $meta_key) {
        if (isset($_POST[$field_key])) {
            $new_value = sanitize_text_field($_POST[$field_key]);
            $old_value = get_post_meta($post_id, $meta_key, true);

            if ($new_value !== $old_value) {
                update_post_meta($post_id, $meta_key, $new_value);

                if ($meta_key === '_vosfacture_client_id') {
                    $client_modified = true;
                }
                if ($meta_key === '_vosfacture_department_id') {
                    $dept_modified = true;
                }

        }
    }
}
if ($client_modified) {
    update_post_meta($post_id, '_clientid_updated_manually', '1');
}

if ($dept_modified) {
    update_post_meta($post_id, '_clientdep_updated_manually', '1');
}

    foreach ($fields as $field_key => $meta_key) {
        if (isset($_POST[$field_key])) {
            $new_value = sanitize_text_field($_POST[$field_key]);
            $old_value = get_post_meta($post_id, $meta_key, true);

            if ($new_value !== $old_value) {
                update_post_meta($post_id, $meta_key, $new_value);
            }
        }
    }
}



// Callback pour afficher les champs de métadonnées

// Fonction pour calculer la catgorie en fonction du type
function vosfactures_calculer_categorie($kind) {
    switch ($kind) {
        case 'vat':
        case 'advance':
        case 'final':
        case 'correction':
            return 'facture';
        case 'receipt':
        case 'payment_receipt':
            return 'reçu';
        case 'invoice_other':
            return 'autre';
        case 'estimate':
            return 'devis';
        case 'client_order':
            return 'commande ou livraison';
        case 'maintenance_request':
            return 'demande';
        case 'proforma':
            return 'proforma';
        case 'kp':
            return 'entrée caisse';
        case 'kw':
            return 'sortie caisse';
        default:
            return 'inconnu';
    }
}



// Fonction pour importer les factures depuis l'API VosFactures
function vosfactures_import_invoices($start_date = null, $end_date = null) {
    $api_url = get_option('vosfactures_api_url');
    $api_key = get_option('vosfactures_api_key');
    $page = 1;
    $total_invoices = 0;
   //wp_send_json_error([$start_date, $end_date ]);
 
    do {
        $url = "$api_url/invoices.json?api_token=$api_key&per_page=100&page=$page&period=more&search_date_type=issue_date";
        if ($start_date && $end_date) {
            $url .= "&date_from=$start_date&date_to=$end_date";
        }

        $response = wp_remote_get($url);

        if (is_wp_error($response)) {
            crm_core_update_logs_option(
                'Import factures VosFactures',
                'Erreur lors de la connexion à l\'API VosFactures : ' . $response->get_error_message(),
                get_current_user_id(),
                [
                    'url_requete' => $url,
                    'start_date' => $start_date,
                    'end_date' => $end_date,
                    'page' => $page
                ]
            );
          
            break;
        }

        $body = wp_remote_retrieve_body($response);
        $invoices = json_decode($body, true);

        if (empty($invoices)) {
            crm_core_update_logs_option(
                'Import factures VosFactures',
                'Aucune facture reçue ou réponse invalide de l\'API VosFactures.',
                get_current_user_id(),
                [
                    'url_requete' => $url,
                    'reponse_brute' => $body,
                    'start_date' => $start_date,
                    'end_date' => $end_date,
                    'page' => $page
                ]
            );
            break;
        }

        foreach ($invoices as $invoice) {
            $invoice_number = sanitize_text_field($invoice['number']);
            $existing_post = get_page_by_title($invoice_number, OBJECT, 'facture');

            $kind = sanitize_text_field($invoice['kind']);
            $issue_date = sanitize_text_field($invoice['issue_date']);
            $annee = date('Y', strtotime($issue_date));
            $categorie = vosfactures_calculer_categorie($kind);
            $price_net = floatval($invoice['price_net']);
            $price_gross = floatval($invoice['price_gross']);
            $montant_tva = $price_gross - $price_net;

            $payment_to = isset($invoice['payment_to']) ? sanitize_text_field($invoice['payment_to']) : '';
            $status = isset($invoice['status']) ? sanitize_text_field($invoice['status']) : '';
            $department_id = isset($invoice['department_id']) ? intval($invoice['department_id']) : '';
            $client_id = isset($invoice['client_id']) ? intval($invoice['client_id']) : '';

            $meta_input = [
                '_vosfacture_number'       => $invoice_number,
                '_vosfacture_kind'         => $kind,
                '_vosfacture_id'           => intval($invoice['id']),
                '_vosfacture_issue_date'   => $issue_date,
                '_vosfacture_price_net'    => $price_net,
                '_vosfacture_price_gross'  => $price_gross,
                '_vosfacture_paid'         => floatval($invoice['paid']),
                '_vosfacture_view_url'     => esc_url($invoice['view_url']),
                '_vosfacture_annee'        => $annee,
                '_vosfacture_montant_tva'  => $montant_tva,
                '_vosfacture_categorie'    => $categorie,
                '_vosfacture_payment_to'   => $payment_to,
                '_vosfacture_status'       => $status,
            ];

            if ($existing_post) {
                // Récupérer les métadonnées existantes 
                $existing_client_id = get_post_meta($existing_post->ID, '_vosfacture_client_id', true);
                $existing_department_id = get_post_meta($existing_post->ID, '_vosfacture_department_id', true);
                $manually_clientid_updated = get_post_meta($existing_post->ID, '_clientid_updated_manually', true);
                $manually__departement_updated = get_post_meta($existing_post->ID, '_clientdep_updated_manually', true);

                // Mettre à jour uniquement si le statut est "paid"
                     if($manually_clientid_updated == 1)
                    {
                        $meta_input['_vosfacture_client_id'] = $existing_client_id;
                    }
                    else{

                    $meta_input['_vosfacture_client_id'] = $client_id;

                    }
                    if($manually__departement_updated== 1){

                    $meta_input['_vosfacture_department_id'] = $existing_department_id;
                    }
                    else{
                     
                    $meta_input['_vosfacture_department_id'] = $department_id;   
                    }
               
                 

                $post_data = [
                    'ID'         => $existing_post->ID,
                    'post_title' => $invoice_number,
                    'post_type'  => 'facture',
                    'post_status'=> 'publish',
                    'meta_input' => $meta_input,
                ];

                wp_update_post($post_data);
            } else {
                // Nouvelle facture
                $meta_input['_vosfacture_client_id'] = $client_id;
                $meta_input['_vosfacture_department_id'] = $department_id;

                $post_data = [
                    'post_title'  => $invoice_number,
                    'post_type'   => 'facture',
                    'post_status' => 'publish',
                    'meta_input'  => $meta_input,
                ];

                wp_insert_post($post_data);
            }

            $total_invoices++;
        }

        $page++;
    } while (count($invoices) === 100);

    $today = date('Y-m-d H:i');
    update_option('_vosfacture_last_sync', $today);

    return $total_invoices;
}

// Fonction pour afficher le sous-menu "Importer par date"


function vosfactures_importer_par_date() {
    if (!current_user_can('manage_options')) {
        return;
    }

    ?>
    <div class="wrap">
        <h1>Importer Factures par Date</h1>
        <div id="vosfactures-import-msg" style="display:none;"></div>
        <?php if (get_option('vosfactures_sync_enabled') == 'yes') : ?>
            <form id="vosfactures-import-form" method="post"novalidate>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><label for="start_date">Date de début :</label></th>
                        <td><input type="date" id="start_date" name="start_date"  /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="end_date">Date de fin :</label></th>
                        <td><input type="date" id="end_date" name="end_date"  /></td>
                    </tr>
                </table>
                <button type="submit" class="button button-primary">Importer les factures</button>
            </form>
        <?php else : ?>
            <div class="notice notice-warning"><p><strong>La synchronisation est désactivée.</strong></p></div>
        <?php endif; ?>
    </div>

    <script>
    jQuery(document).ready(function($) {
        const urlParams = new URLSearchParams(window.location.search);
                const tab = urlParams.get('tab');
//
                if (tab && tab=="importation-facture") {

                $('.nav-tab').removeClass('nav-tab-active');
                    $('.nav-tab[href=\"#tab-factures\"]').addClass('nav-tab-active');
                    $('.tab-content').hide();
                    $('#tab-factures').show();
            
                    $('.custom-tab-factures').removeClass('active');
                    $('.custom-tab-factures-content').hide();
                    $('.custom-tab-factures[href=\"#factures-importation\"]').addClass('active');
                    $('#factures-importation').show();
                    const url = new URL(window.location.href);
                    url.searchParams.delete('tab');
                    window.history.replaceState({}, document.title, url.toString());

                }
                
        $('#vosfactures-import-form').on('submit', function(e) {
            e.preventDefault();
            $('#vosfactures-import-msg').html("").slideUp();
         
            let start = $('#start_date').val();
            let end = $('#end_date').val();

            if (!start || !end) {
                $('#vosfactures-import-msg').removeClass('notice-success notice-error').addClass('notice notice-error').html("Veuillez remplir les deux dates.").slideDown();
                return;
            }

            if (start > end) {
                $('#vosfactures-import-msg').removeClass('notice-success notice-error').addClass('notice notice-error').html("La date de fin doit être supérieure à la date de début.").slideDown();
                return;
            }

            // Message d'attente
            let loadingMsg = $('<div class="notice notice-info"><p>Importation en cours...</p></div>');
            $('#vosfactures-import-msg').removeClass('notice-success notice-error').addClass('notice').html(loadingMsg).slideDown();

            // Données AJAX
            let formData = {
                action: 'vosfactures_importer_factures_par_date',
                start_date: start,
                end_date: end,
                _ajax_nonce: '<?php echo wp_create_nonce("vosfactures_import_ajax"); ?>'
            };

            $.post(ajaxurl, formData, function(response) {
                loadingMsg.remove();

                if (response.success) {
                  

                    $('#vosfactures-import-msg').removeClass('notice-success notice-error').addClass('notice notice-success' )
                    .html(response.data).slideDown();
                    setTimeout(() => {
                        const url = new URL(window.location.href);
                                url.searchParams.set('tab', 'importation-facture');
                                window.location.href = url.toString();
                    }, 2000);
                } else {
                   
                    $('#vosfactures-import-msg').removeClass('notice-success notice-error').addClass('notice notice-error')
                    .html(response.data).slideDown();
                }
            });
        });
    });
    </script>
    <?php
}

// AJAX callback
add_action('wp_ajax_vosfactures_importer_factures_par_date', 'vosfactures_importer_factures_par_date_callback');

function vosfactures_importer_factures_par_date_callback() {
   /* if (!current_user_can('manage_options')) {
        wp_send_json_error("Accès refusé.");
    }*/

    check_ajax_referer('vosfactures_import_ajax');

    $start_date = sanitize_text_field($_POST['start_date'] ?? '');
    $end_date   = sanitize_text_field($_POST['end_date'] ?? '');

    if (!$start_date || !$end_date) {
        wp_send_json_error("Les deux dates sont requises.");
    }

    if ($start_date > $end_date) {
        wp_send_json_error("La date de fin doit être supérieure à la date de début.");
    }

    // Appel à la fonction réelle d'importation
    $count = vosfactures_import_invoices($start_date, $end_date);

    if ($count >= 0) {
        wp_send_json_success("$count factures importées entre $start_date et $end_date.");
    } else {
        wp_send_json_error("Erreur pendant l’importation.");
    }
}

// Ajouter les sous-menus "Importer par date" et "Importer toutes les factures" dans le menu Factures
/*add_action('admin_menu', function() {
     add_submenu_page(
        'edit.php?post_type=facture',
        'Importer par date',
        'Importer par date',
        'manage_options',
        'importer-par-date',
        'vosfactures_importer_par_date'
    );
   add_submenu_page(
        'edit.php?post_type=facture',
        'Importer toutes les factures',
        'Importer toutes les factures',
        'manage_options',
        'importer-toutes-factures',
        function() {
            if( get_option('vosfactures_sync_enabled') === 'yes')
             {
            
            $imported_count = vosfactures_import_invoices();
            echo '<div class="wrap"><h1>Importer toutes les factures</h1>';
            echo '<div class="notice notice-success is-dismissible"><p>' . $imported_count . ' factures ont été importées.</p></div></div>';
        }
        else{
      ?>
           <div class="notice notice-error">
              <p><strong>La synchronisation est désactivée.</strong></p>
              <p>Si vous voulez activer la synchronisation, rendez-vous dans les <a href="<?php echo admin_url('admin.php?page=vosfactures-settings'); ?>">paramètres de VosFactures</a>.</p>
          </div>
        <?php }
         
        }
    );
});*/

// Fonction pour afficher le sous-menu "Factures en cours"
function vosfactures_factures_en_cours() {
    global $wpdb;
    $api_url = get_option('vosfactures_api_url');

    // Requête SQL pour filtrer les factures et devis avec un statut "issued", vide, ou "partial"
    $query = "
    SELECT p.ID, pm_issue.meta_value AS issue_date, p.post_title, pm_id.meta_value AS invoice_id
    FROM {$wpdb->posts} p
    INNER JOIN {$wpdb->postmeta} pm_categorie ON p.ID = pm_categorie.post_id
    INNER JOIN {$wpdb->postmeta} pm_status ON p.ID = pm_status.post_id
    INNER JOIN {$wpdb->postmeta} pm_issue ON p.ID = pm_issue.post_id
    INNER JOIN {$wpdb->postmeta} pm_id ON p.ID = pm_id.post_id
    WHERE p.post_type = 'facture'
    AND pm_categorie.meta_key = '_vosfacture_categorie'
    AND pm_categorie.meta_value IN ('devis', 'facture')
    AND pm_status.meta_key = '_vosfacture_status'
    AND (pm_status.meta_value = 'issued' OR pm_status.meta_value = 'partial' OR pm_status.meta_value IS NULL OR pm_status.meta_value = '')
    AND pm_issue.meta_key = '_vosfacture_issue_date'
    AND pm_id.meta_key = '_vosfacture_id'
    ORDER BY pm_issue.meta_value DESC
    ";

    $results = $wpdb->get_results($query);

    echo '<h2>Factures en cours</h2>';
    echo '<p>Liste des factures et devis avec un statut "issued", "partial" ou vide.</p>';

  
    if (!empty($results)) {
        $recent_invoice_date = $results[0]->issue_date;
        echo '<p>Date de la facture ou devis le plus récent : ' . esc_html($recent_invoice_date) . '</p>';
       $links = [];
        
        foreach ($results as $invoice) {
            $edit_link = admin_url('post.php?post=' . intval($invoice->ID) . '&action=edit');
            $title = esc_html($invoice->post_title);
            $links[] = '<a href="' . esc_url($edit_link) . '" target="_blank">' . $title . '</a>';
        }

        echo implode(', ', $links);
     }
      else {
        echo '<p>Aucune facture ou devis en cours trouvé.</p>';
    }
}


// Fonction pour afficher le sous-menu "Factures orphelines"
function vosfactures_factures_orphelines() {
    global $wpdb;
    $api_url = get_option('vosfactures_api_url');

    // Requête SQL pour trouver les factures avec client_id vide ou 0
    $query = "
    SELECT p.ID, pm_issue.meta_value AS issue_date, p.post_title, pm_id.meta_value AS invoice_id
    FROM {$wpdb->posts} p
    INNER JOIN {$wpdb->postmeta} pm_client_id ON p.ID = pm_client_id.post_id
    INNER JOIN {$wpdb->postmeta} pm_issue ON p.ID = pm_issue.post_id
    INNER JOIN {$wpdb->postmeta} pm_id ON p.ID = pm_id.post_id
    WHERE p.post_type = 'facture'
    AND pm_client_id.meta_key = '_vosfacture_client_id'
    AND (pm_client_id.meta_value IS NULL OR pm_client_id.meta_value = 0)
    AND pm_issue.meta_key = '_vosfacture_issue_date'
    AND pm_id.meta_key = '_vosfacture_id'
    ORDER BY pm_issue.meta_value DESC
    ";

    $results = $wpdb->get_results($query);

    echo '<h2>Factures orphelines</h2>';
    echo '<p>Liste des factures qui n\'ont pas de client associé (client_id vide ou 0).</p>';

 
    if (!empty($results)) {
        $links = [];
        
        foreach ($results as $invoice) {
            $edit_link = admin_url('post.php?post=' . intval($invoice->ID) . '&action=edit');
            $title = esc_html($invoice->post_title);
            $links[] = '<a href="' . esc_url($edit_link) . '" target="_blank">' . $title . '</a>';
        }

        echo implode(', ', $links);
    } else {
        echo '<p>Aucune facture orpheline trouvée.</p>';
    }
}

// Ajouter les sous-menus "Factures en cours" et "Factures orphelines" dans le menu Factures
add_action('admin_menu', function() {
    add_submenu_page(
        'edit.php?post_type=facture',
        'Factures en cours',
        'Factures en cours',
        'manage_options',
        'factures-en-cours',
        'vosfactures_factures_en_cours'
    );
    add_submenu_page(
        'edit.php?post_type=facture',
        'Factures orphelines',
        'Factures orphelines',
        'manage_options',
        'factures-orphelines',
        'vosfactures_factures_orphelines'
    );
});
function crm_factures_settings_page() {
    ?>
    <div class="crm-custom-wrap ">
        <div class="custom-tab-container">
            <a href="#presentation-factures" class="custom-tab custom-tab-factures active" data-tab="presentation-factures"><h2>Présentation </h2></a>
            <a href="#factures-cours" class="custom-tab custom-tab-factures" data-tab="factures-cours"><h2>Factures en cours</h2></a>
            <a href="#factures-orphelines" class="custom-tab custom-tab-factures" data-tab="factures-orphelines"><h2>Factures orphelines</h2></a>
            <a href="#factures-importation" class="custom-tab custom-tab-factures" data-tab="factures-importation"><h2>Importer Factures</h2></a>
        </div>
        <div class="crm-custom-wrap-right">
        
        <div id="presentation-factures" class="custom-tab-content custom-tab-factures-content" style="display:block;">
            <div style="border-bottom: 1px solid #ddd; margin-bottom: 20px; padding-bottom: 20px;">
                <h2 style="font-size: 1.5em; margin-bottom: 10px;">Type de post "CRM Factures"</h2>
                <p>Le type de post <strong>CRM Factures</strong> permet de gérer les factures clients et offre une intégration avec la plateforme <strong>VosFactures</strong>.</p>

                <p><strong>Fonctionnalités principales :</strong></p> 
                <ul style="list-style-type: disc; margin-left: 20px;"> 
                    <li>Liste des factures importées depuis VosFactures pour chaque client</li>
                    <li>Synchronisation automatique des factures (si activée)</li>
                    <li>Récupération des factures associées à chaque client à partir de VosFactures</li>
                    <li>Affichage des statistiques de chiffre d'affaires par année</li>
                    <li>Compatibilité avec les plugins CRM Core, CRM Events et WooCommerce</li>
                </ul> 

                <div style="border: 1px solid #ddd; background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin-top: 20px;">
                    <h3 style="font-size: 1.2em; margin-bottom: 10px;">Shortcodes disponibles</h3> 

                    <!-- 1er shortcode -->
                    <h4 style="font-size: 1.1em; margin-bottom: 5px;">1. [factures]</h4>
                    <p>Ce shortcode affiche les factures synchronisées depuis VosFactures regroupées par année :</p>
                    <ul style="list-style-type: disc; margin-left: 20px;">
                        <li>Tri par année avec sous-totaux et total général</li>
                        <li>Affichage des factures liées à l’utilisateur authentifié</li>
                        <li>Gestion automatique des droits via ID haché</li>
                    </ul>
                    <!--<h5>Attributs disponibles :</h5>
                    <ul style="list-style-type: disc; margin-left: 20px;">
                        <li><code>all</code>:  Si défini à <code>"true"</code>, le shortcode <strong>affiche une liste de clients</strong> au lieu des factures de l'utilisateur connecté.<br>
                            Si omis ou défini à <code>"false"</code>, les <strong>factures de l’utilisateur identifié</strong> seront affichées.
                            </li>
                    
                    </ul>-->
                    <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"><code>[factures]</code> </pre>

                    <!-- 2ème shortcode -->
                    <h4 style="font-size: 1.1em; margin-bottom: 5px;">2. [chiffre-affaire]</h4>
                    <p>Affiche les statistiques de chiffre d'affaires extraites des factures :</p>
                    <ul style="list-style-type: disc; margin-left: 20px;">
                        <li>CA de l’année en cours et de l’année précédente</li>
                        <li>Meilleure année de chiffre d'affaires</li>
                        <li>Montant en attente de règlement</li>
                        <li>Représentation sous forme de blocs informatifs</li>
                    </ul>
                    <p>Il accepte l’attribut suivant (facultatif) :</p>
                    <ul>
                        <li><strong>type</strong> : Définit le type d'affichage : <code>follow</code> (par défaut) ou <code>stats</code></li>
                    </ul>
                    <pre style="background-color: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">[chiffre-affaire type="stats"]</pre>
                </div>
            </div>
        </div>

        <div id="factures-cours" class="custom-tab-content custom-tab-factures-content" style="display:none;">
            
            <?php
            vosfactures_factures_en_cours();
            ?>
        </div>
        <div id="factures-orphelines" class="custom-tab-content custom-tab-factures-content" style="display:none;">
           
            <?php
            vosfactures_factures_orphelines();
            ?>
        </div>
        <div id="factures-importation" class="custom-tab-content custom-tab-factures-content" style="display:none;">
            
            <?php
            vosfactures_importer_par_date();
            ?>
        </div>
    </div>
</div>
 
    <?php
}