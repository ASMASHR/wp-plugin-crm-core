<?php

/**
 * Shortcode [factures] pour afficher les factures importées depuis VOSFACTURES.
 *
 * Ce fichier enregistre le shortcode [factures] qui affiche les factures d'un utilisateur
 * regroupées par année. Chaque groupe d'année est précédé d'un titre <h4> indiquant
 * l'année. Les factures sont présentées dans des tableaux HTML avec sous-totaux et
 * un total général. Le shortcode gère l'authentification via des IDs hachés et
 * récupère les factures associées à l'ID VOSFACTURES de l'utilisateur.
 */

// Ajout du shortcode [factures]
function vosfactures_shortcode($atts) {
    // Traitement des attributs du shortcode
    $atts = shortcode_atts(array(
        'all' => 'false',
    ), $atts, 'factures');

    // Vérification de la présence du shortcode sur la page
    if (!is_singular()) {
        return ''; // Ignorer si ce n'est pas une page ou un article
    }

    // Ajouter les styles pour la réactivité
    //wp_enqueue_style('vosfactures-responsive', plugin_dir_url(__FILE__) . '../global.css');

    // Récupération du vosfactures_id à l'aide de la fonction mémorisée
    $hashedId = get_hashed_id_from_url();
    $user_id = get_user_id_from_hash($hashedId);

    if (!$user_id) {
        return '<div class="vosfactures-id">ID non disponible</div>';
    }

    $vosfactures_id = get_user_meta($user_id, 'vosfactures_id', true);

    if ($atts['all'] === 'true') {
        return '<h4>Clients</h4>';
    } else {
        if ($vosfactures_id) {
            if( get_option('vosfactures_sync_enabled') === 'yes')
            {
                update_factures_from_vosfactures($vosfactures_id,$user_id);
            } 
    
            $output = '';

            // Section factures par année
            $output .= get_factures_by_year($vosfactures_id);

            // Section "devis"
            $output .= get_vosfactures_by_category($vosfactures_id, 'devis', 'Devis', false);

            // Section "autres"
            $output .= get_vosfactures_by_category($vosfactures_id, 'proforma', 'Autres', false);
            $output .='<script>
            jQuery(document).ready(function($) {
                    $(".vendeur_select").change(function() {
                        var selectedVendeur = $(this).find("option:selected").text();
                        var table = $(this).closest(".form-group").next(".invoicetable");
                        table.find("tr").show(); 
                        if (selectedVendeur !== "-- Sélectionnez --") {
                            table.find("tr:not(:first)").filter(function() {
                                return $(this).find("td").eq(5).text() !== selectedVendeur;
                            }).hide();
                        }
                    });
                });</script>
                
                ';
                        return $output;
                    } else {
                        return '<div class="vosfactures-id"></div>';
                    }
                }
}

// Fonction pour obtenir les factures par catégorie (incluant les devis)
function get_vosfactures_by_category($vosfactures_id, $category, $title, $include_payed_column) {
    $args = array(
        'post_type'      => 'facture',
        'posts_per_page' => -1,
        'meta_query'     => array(
            array(
                'key'     => '_vosfacture_client_id',
                'value'   => $vosfactures_id,
                'compare' => '='
            ),
            array(
                'key'     => '_vosfacture_categorie',
                'value'   => $category,
                'compare' => '='
            ),
        ),
        'orderby'        => 'meta_value',
        'meta_key'       => '_vosfacture_issue_date',
        'order'          => 'DESC',
    );

    $factures = new WP_Query($args);
    $output = '';
    $departments = get_option('_crm_vosfactures_departments', []);
           
    if ($factures->have_posts()) {
        $output .= "<h4>$title</h4>";
        if (!empty($departments))
                {
                    $output .= '    <div class="form-group vendeur_select_container">
                    <label>Vendeur :</label>
                    <select class="vendeur_select">
                        <option value="">-- Sélectionnez --</option>';
                        
                    foreach ($departments as $department) {
                        $output .= '<option value="' . esc_attr($department['id']) . '">' .  esc_html($department['nom_usage']) .'</option>';
                    }
                    $output .= '</select></div>';

                }
        $output .= '<table class="invoicetable">';
        $output .= '<tr><th>num.</th><th class="download"></th><th>émission</th><th>HT</th><th class="tva-column">TVA</th><th>Vendeur</th><th>état</th></tr>';

        while ($factures->have_posts()) {
            $factures->the_post();
            
            $num_facture     = get_post_meta(get_the_ID(), '_vosfacture_number', true);
            $id_facture      = get_post_meta(get_the_ID(), '_vosfacture_id', true);
            $date_emission   = get_post_meta(get_the_ID(), '_vosfacture_issue_date', true);
            $montant_ht      = get_post_meta(get_the_ID(), '_vosfacture_price_net', true);
            $montant_tva     = get_post_meta(get_the_ID(), '_vosfacture_montant_tva', true);
            $view_url        = get_post_meta(get_the_ID(), '_vosfacture_view_url', true);
            $status          = get_post_meta(get_the_ID(), '_vosfacture_status', true);
            $vendeurId       = get_post_meta(get_the_ID(), '_vosfacture_department_id', true);
            $vendeurNom="--";
            //get_option('vosfactures_sync_enabled')=='yes'&&
                 
            if (!empty($departments)&&$vendeurId!="")
            {
                 
                    foreach ($departments as $department) {
                        if ($department['id'] == $vendeurId) {
                            $vendeurNom = $department['nom_usage'];
                            break;
                        }
                    }
        
                 
            }

            $date_emission_formatted = '<span class="full-date">' . date_i18n(get_option('date_format'), strtotime($date_emission)) . '</span>';
            $date_emission_formatted .= '<span class="short-date">' . date('d.m', strtotime($date_emission)) . '</span>';

            $montant_ht_formatted   = wc_price($montant_ht);

            // Determine status display
            if ($status === 'accepted') {
                $status_display = '<span class="etat">accepté</span>';
            } elseif ($status === 'rejected') {
                $status_display = '<span class="etat">refusé</span>';
            } else {
                $status_display = '<span class="etat"><a href="' . esc_url(get_option('vosfactures_api_url') . 'invoices/' . $id_facture) . '" target="_blank">editer</a></span>';
                if ($category === 'devis') {
                    $status_display .= '<span class="etat"><a href="' . esc_url($view_url) . '" target="_blank">signer</a></span>';
                }
            }

            $output .= '<tr>';
            $output .= '<td><a href="' . esc_url(get_option('vosfactures_api_url') . 'invoices/' . $id_facture) . '" target="_blank">' . esc_html($num_facture) . '</a></td>';
            $output .= '<td class="download"><a href="' . esc_url($view_url . '.pdf') . '" target="_blank"><img src="' . esc_url(plugin_dir_url(__FILE__) . 'img/document-pdf.svg') . '" alt="Télécharger PDF"></a></td>';
            $output .= '<td class="date-column">' . $date_emission_formatted . '</td>';
            $output .= '<td>' . $montant_ht_formatted . '</td>';
            $output .= '<td class="tva-column">' . wc_price($montant_tva) . '</td>';
            $output .= '<td>' . $vendeurNom . '</td>';
            $output .= '<td>' . $status_display . '</td>';
            $output .= '</tr>';
        }
        $output .= '</table>';
    }

    wp_reset_postdata();
    return $output;
}



// Fonction pour obtenir les factures par année
function get_factures_by_year($vosfactures_id) {
    $args = array(
        'post_type'      => 'facture',
        'posts_per_page' => -1,
        'meta_query'     => array(
            array(
                'key'     => '_vosfacture_client_id',
                'value'   => $vosfactures_id,
                'compare' => '='
            ),
            array(
                'key'     => '_vosfacture_categorie',
                'value'   => 'facture',
                'compare' => '='
            ),
        ),
        'orderby'        => 'meta_value',
        'meta_key'       => '_vosfacture_issue_date',
        'order'          => 'DESC',
    );

    $factures = new WP_Query($args);
    $departments = get_option('_crm_vosfactures_departments', []);
           
    $output = '';
    $current_year = date('Y');
    $year_subtotals = array();
    $grand_total_ht = 0;
    $grand_total_paid = 0;
    $archive_years = array();

    if ($factures->have_posts()) {
        $current_displayed_year = null;

        while ($factures->have_posts()) {
            $factures->the_post();

            $num_facture     = get_post_meta(get_the_ID(), '_vosfacture_number', true);
            $id_facture      = get_post_meta(get_the_ID(), '_vosfacture_id', true);
            $date_emission   = get_post_meta(get_the_ID(), '_vosfacture_issue_date', true);
            $montant_ht      = get_post_meta(get_the_ID(), '_vosfacture_price_net', true);
            $montant_tva     = get_post_meta(get_the_ID(), '_vosfacture_montant_tva', true);
            $montant_ttc     = get_post_meta(get_the_ID(), '_vosfacture_price_gross', true);
            $montant_regle   = get_post_meta(get_the_ID(), '_vosfacture_paid', true);
            $view_url        = get_post_meta(get_the_ID(), '_vosfacture_view_url', true);
            $annee           = get_post_meta(get_the_ID(), '_vosfacture_annee', true);
            $annee           = get_post_meta(get_the_ID(), '_vosfacture_annee', true);
            $vendeurId       = get_post_meta(get_the_ID(), '_vosfacture_department_id', true);
            $vendeurNom="--";
            //get_option('vosfactures_sync_enabled')=='yes'&&
            //$departments = get_option('_crm_vosfactures_departments', []);
                
            if (!empty($departments)&&$vendeurId!="")
            {
                foreach ($departments as $department) {
                    if ($department['id'] == $vendeurId) {
                        $vendeurNom = $department['nom_usage'];
                        break;
                    }
                }
        
                 
            }


            if ($current_year - $annee > 2) {
                $archive_years[] = array(
                    'num_facture' => $num_facture,
                    'id_facture' => $id_facture,
                    'date_emission' => $date_emission,
                    'montant_ht' => $montant_ht,
                    'montant_tva' => $montant_tva,
                    'montant_ttc' => $montant_ttc,
                    'montant_regle' => $montant_regle,
                    'view_url' => $view_url,
                    'annee' => $annee,
                    'Vendeur'=>$vendeurNom,
                );
                continue;
            }

            if ($current_displayed_year !== $annee) {
                if ($current_displayed_year !== null) {
                    $output .= '<tr class="soustotal"><td colspan="3">Sous total ' . esc_html($current_displayed_year) . '</td>';
                    $output .= '<td>' . wc_price($year_subtotals[$current_displayed_year]['ht']) . '</td>';
                    $output .= '<td colspan="2"></td></tr>';
                    $output .= '</table>';
                }
                $current_displayed_year = $annee;
                $output .= '<h4>fact. ' . esc_html($annee) . '</h4>';
                if (!empty($departments))
                {
                    $output .= '    <div class="form-group vendeur_select_container">
                    <label for="departement_vendeur">Vendeur :</label>
                    <select class="vendeur_select">
                        <option value="">-- Sélectionnez --</option>';
                        
                    foreach ($departments as $department) {
                        $output .= '<option value="' . esc_attr($department['id']) . '">' .  esc_html($department['nom_usage']) .'</option>';
                    }
                    $output .= '</select></div>';

                }
                $output .= '<table class="invoicetable">';
               
                
                $output .= '<tr><th>num.</th><th class="download"></th><th>émission</th><th>HT</th><th class="tva-column">TVA</th><th>Vendeur</th><th>état</th></tr>';

                if (!isset($year_subtotals[$annee])) {
                    $year_subtotals[$annee] = array('ht' => 0, 'paid' => 0);
                }
            }

            $date_emission_formatted = '<span class="full-date">' . date_i18n(get_option('date_format'), strtotime($date_emission)) . '</span>';
            $date_emission_formatted .= '<span class="short-date">' . date('d.m', strtotime($date_emission)) . '</span>';

            $year_subtotals[$annee]['ht'] += $montant_ht;
            $year_subtotals[$annee]['paid'] += $montant_regle;

            $grand_total_ht   += $montant_ht;
            $grand_total_paid += $montant_regle;

            $status = ($montant_regle == $montant_ttc) ? '<span class="etat">clôturée</span>' : '<span class="etat"><a href="' . esc_url($view_url) . '" target="_blank">ouverte</a></span>';
            if ($montant_regle != $montant_ttc) {
                $status .= ' <span class="etat"><a href="' . esc_url(get_option('vosfactures_api_url') . 'banking/payments/new?from_index=no&invoice_id=' . $id_facture) . '" target="_blank">régler</a></span>';
            }
            $row_class = '';
                if ($status === 'rejected') {
                    $row_class = 'dev-rejet';
                } elseif ($montant_regle == $montant_ttc) {
                    $row_class = 'est-regle';
                } else {
                    $row_class = 'non-regle';
                }

            $montant_ht_formatted   = wc_price($montant_ht);

            $output .= '<tr class="' . esc_attr($row_class) . '">';
            $output .= '<td><a href="' . esc_url(get_option('vosfactures_api_url') . 'invoices/' . $id_facture) . '" target="_blank">' . esc_html($num_facture) . '</a></td>';
            $output .= '<td class="download"><a href="' . esc_url($view_url . '.pdf') . '" target="_blank"><img src="' . esc_url(plugin_dir_url(__FILE__) . 'img/document-pdf.svg') . '" alt="Télécharger PDF"></a></td>';
            $output .= '<td class="date-column">' . $date_emission_formatted . '</td>';
            $output .= '<td>' . $montant_ht_formatted . '</td>';
            $output .= '<td class="tva-column">' . wc_price($montant_tva) . '</td>';
            $output .= '<td>' . $vendeurNom . '</td>';
            $output .= '<td>' . $status . '</td>';
          
            $output .= '</tr>';
        }

        if ($current_displayed_year !== null) {
            $output .= '<tr class="soustotal"><td colspan="3">Sous total ' . esc_html($current_displayed_year) . '</td>';
            $output .= '<td>' . wc_price($year_subtotals[$current_displayed_year]['ht']) . '</td>';
            $output .= '<td colspan="2"></td></tr>';
            $output .= '</table>';
        }

        // Ajouter les archives
        if (!empty($archive_years)) {
            $output .= '<h4>Archives</h4>';
            if (!empty($departments))
                {
                    $output .= '    <div class="form-group vendeur_select_container">
                    <label for="departement_vendeur">Vendeur :</label>
                    <select class="vendeur_select">
                        <option value="">-- Sélectionnez --</option>';
                        
                    foreach ($departments as $department) {
                        $output .= '<option value="' . esc_attr($department['id']) . '">' .  esc_html($department['nom_usage']) .'</option>';
                    }
                    $output .= '</select></div>';

                }
            $output .= '<table class="invoicetable">';
            $output .= '<tr><th>num.</th><th class="download"></th><th>émission</th><th>HT</th><th class="tva-column">TVA</th><th>Vendeur</th><th>état</th></tr>';

            $archive_subtotals = array('ht' => 0, 'paid' => 0);
            foreach ($archive_years as $archive) {
                $date_emission_formatted = '<span class="full-date">' . date_i18n(get_option('date_format'), strtotime($archive['date_emission'])) . '</span>';
                $date_emission_formatted .= '<span class="short-date">' . date('d.m', strtotime($archive['date_emission'])) . '</span>';

                $archive_subtotals['ht'] += $archive['montant_ht'];
                $archive_subtotals['paid'] += $archive['montant_regle'];

                $status = ($archive['montant_regle'] == $archive['montant_ttc']) ? '<span class="etat">clôturée</span>' : '<span class="etat"><a href="' . esc_url($archive['view_url']) . '" target="_blank">ouverte</a></span>';
                if ($archive['montant_regle'] != $archive['montant_ttc']) {
                    $status .= ' <span class="etat"><a href="' . esc_url(get_option('vosfactures_api_url') . 'banking/payments/new?from_index=no&invoice_id=' . $archive['id_facture']) . '" target="_blank">rgler</a></span>';
                }
                $row_class = ($archive['montant_regle'] == $archive['montant_ttc']) ? 'est-regle' : 'non-regle';

                $montant_ht_formatted = wc_price($archive['montant_ht']);

                $output .= '<tr class="' . esc_attr($row_class) . '">';
                $output .= '<td><a href="' . esc_url(get_option('vosfactures_api_url') . 'invoices/' . $archive['id_facture']) . '" target="_blank">' . esc_html($archive['num_facture']) . '</a></td>';
                $output .= '<td class="download"><a href="' . esc_url($archive['view_url'] . '.pdf') . '" target="_blank"><img src="' . esc_url(plugin_dir_url(__FILE__) . 'img/document-pdf.svg') . '" alt="Télécharger PDF"></a></td>';
                $output .= '<td class="date-column">' . $date_emission_formatted . '</td>';
                $output .= '<td>' . $montant_ht_formatted . '</td>';
                $output .= '<td class="tva-column">' . wc_price($archive['montant_tva']) . '</td>';
                $output .= '<td>' . $vendeurNom . '</td>';
                $output .= '<td>' . $status . '</td>';
          
                $output .= '</tr>';
            }

            $output .= '<tr class="soustotal"><td colspan="3">Sous total Archives</td>';
            $output .= '<td>' . wc_price($archive_subtotals['ht']) . '</td>';
            $output .= '<td colspan="2"></td></tr>';
            $output .= '</table>';
        }
    }

    wp_reset_postdata();
    return $output;
}

// Enregistrement du shortcode
add_shortcode('factures', 'vosfactures_shortcode');
function update_factures_from_vosfactures($vosfactures_id,$user_id='') {
    
    $api_key = get_option('vosfactures_api_key');
    $api_url = get_option('vosfactures_api_url') . "invoices.json?api_token=$api_key&client_id=$vosfactures_id&page=";
    $page = 1;
    $all_factures = [];
    $check_client_url = $api_url . "clients/$vosfactures_id.json?api_token=$api_key";
    $client_response = wp_remote_get($check_client_url);
    $bodyArr = json_decode(wp_remote_retrieve_body($client_response), true);
    if (isset($bodyArr['code'])&&$bodyArr['code']=="error"&&$bodyArr['message']=="Contact non trouvé") {
       
        if($user_id!=''){
            update_user_meta($user_id, 'vosfactures_id', '');
            update_user_meta($user_id, 'user_status', 'inactive');
        }/**/
        return ;
    }
    do {
        

        $response = wp_remote_get($api_url);

        if (is_wp_error($response)) {
            break;
        }

        $body = wp_remote_retrieve_body($response);
        $invoices = json_decode($body, true);

        if (empty($invoices)) {
            break;
        }

        foreach ($invoices as $invoice) {
            $invoice_number = sanitize_text_field($invoice['number']);
            $existing_post = get_page_by_title($invoice_number, OBJECT, 'facture');

            $kind = sanitize_text_field($invoice['kind']);
            $issue_date = sanitize_text_field($invoice['issue_date']);
            $annee = date('Y', strtotime($issue_date));
            $categorie = vosfactures_calculer_categorie($kind);
            $price_net = floatval($invoice['price_net']);
            $price_gross = floatval($invoice['price_gross']);
            $montant_tva = $price_gross - $price_net;

            $payment_to = isset($invoice['payment_to']) ? sanitize_text_field($invoice['payment_to']) : '';
            $status = isset($invoice['status']) ? sanitize_text_field($invoice['status']) : '';
            $department_id = isset($invoice['department_id']) ? intval($invoice['department_id']) : '';
            $client_id = isset($invoice['client_id']) ? intval($invoice['client_id']) : '';

            $meta_input = [
                '_vosfacture_number'       => $invoice_number,
                '_vosfacture_kind'         => $kind,
                '_vosfacture_id'           => intval($invoice['id']),
                '_vosfacture_issue_date'   => $issue_date,
                '_vosfacture_price_net'    => $price_net,
                '_vosfacture_price_gross'  => $price_gross,
                '_vosfacture_paid'         => floatval($invoice['paid']),
                '_vosfacture_view_url'     => esc_url($invoice['view_url']),
                '_vosfacture_annee'        => $annee,
                '_vosfacture_montant_tva'  => $montant_tva,
                '_vosfacture_categorie'    => $categorie,
                '_vosfacture_payment_to'   => $payment_to,
                '_vosfacture_status'       => $status,
            ];

            if ($existing_post) {
                // Récupérer les métadonnées existantes 
                $existing_client_id = get_post_meta($existing_post->ID, '_vosfacture_client_id', true);
                $existing_department_id = get_post_meta($existing_post->ID, '_vosfacture_department_id', true);
                $manually_clientid_updated = get_post_meta($existing_post->ID, '_clientid_updated_manually', true);
                $manually__departement_updated = get_post_meta($existing_post->ID, '_clientdep_updated_manually', true);

                // Mettre à jour uniquement si le statut est "paid"
                     if($manually_clientid_updated == 1)
                    {
                        $meta_input['_vosfacture_client_id'] = $existing_client_id;
                    }
                    else{

                    $meta_input['_vosfacture_client_id'] = $client_id;

                    }
                    if($manually__departement_updated== 1){

                    $meta_input['_vosfacture_department_id'] = $existing_department_id;
                    }
                    else{
                     
                    $meta_input['_vosfacture_department_id'] = $department_id;   
                    }
               
                 

                $post_data = [
                    'ID'         => $existing_post->ID,
                    'post_title' => $invoice_number,
                    'post_type'  => 'facture',
                    'post_status'=> 'publish',
                    'meta_input' => $meta_input,
                ];

                wp_update_post($post_data);
            } else {
                // Nouvelle facture
                $meta_input['_vosfacture_client_id'] = $client_id;
                $meta_input['_vosfacture_department_id'] = $department_id;

                $post_data = [
                    'post_title'  => $invoice_number,
                    'post_type'   => 'facture',
                    'post_status' => 'publish',
                    'meta_input'  => $meta_input,
                ];

                wp_insert_post($post_data);
            }

            //$total_invoices++;
        }

        $page++;
    } while (count($invoices) === 100);

  /*  do {
        $response = wp_remote_get($api_url . $page);

        if (is_wp_error($response)) {
            return;
        }

        $factures = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!$factures || empty($factures)) {
            break; 
        }

        $all_factures = array_merge($all_factures, $factures);

        $page++; 
    } 
    while (!empty($factures)); 

    $response = wp_remote_get($api_url);
    if (is_wp_error($response)) {
        return;
    }
    $body = wp_remote_retrieve_body($response);
        $factures = json_decode($body, true);

    wp_send_json_error(['factures'=>$factures]);
    
    if (!$factures) {
        return;
    }

    foreach ($all_factures as $facture) {
        $id_facture = $facture['id'];
        $existing_facture = get_posts(array(
            'post_type' => 'facture',
            'meta_query' => array(
                array('key' => '_vosfacture_id', 'value' => $id_facture, 'compare' => '=')
            )
        ));
        $client_id = isset($facture['client_id']) ? intval($facture['client_id']) : '';
        $department_id = isset($facture['department_id']) ? intval($facture['department_id']) : '';
           
        if (!empty($existing_facture)) {
            $post_id = $existing_facture[0]->ID;
            update_post_meta($post_id, '_vosfacture_issue_date', $facture['issue_date']);
            update_post_meta($post_id, '_vosfacture_price_net', $facture['price_net']);
            update_post_meta($post_id, '_vosfacture_price_gross', $facture['price_gross']);
            update_post_meta($post_id, '_vosfacture_paid', $facture['paid']);
            update_post_meta($post_id, '_vosfacture_status', $facture['status']);
            $existing_department_id = get_post_meta($post_id, '_vosfacture_department_id', true);
            $manually_clientid_updated = get_post_meta($post_id, '_clientid_updated_manually', true);
            $manually__departement_updated = get_post_meta($post_id, '_clientdep_updated_manually', true);
            $existing_client_id = get_post_meta($post_id, '_vosfacture_client_id', true);
               
            // Mettre à jour uniquement si le statut est "paid"
                 if($manually_clientid_updated == 1)
                {
                    update_post_meta($post_id, '_vosfacture_client_id', $existing_client_id);

                }
                else{


                    update_post_meta($post_id, '_vosfacture_client_id', $client_id);

                }
                if($manually__departement_updated== 1){

                update_post_meta($post_id, '_vosfacture_department_id', $department_id);

                }
                else{
                  
                update_post_meta($post_id, '_vosfacture_department_id', $department_id);
 
                }
           
           
        } 
        else {
            $post_data = array(
                'post_title'   => "Facture #" . $id_facture,
                'post_content' => "Facture générée depuis VosFactures.",
                'post_status'  => 'publish',
                'post_type'    => 'facture'
            );

            $new_post_id = wp_insert_post($post_data);

            if ($new_post_id) {
                update_post_meta($new_post_id, '_vosfacture_id', $id_facture);
                update_post_meta($new_post_id, '_vosfacture_issue_date', $facture['issue_date']);
                update_post_meta($new_post_id, '_vosfacture_price_net', $facture['price_net']);
                update_post_meta($new_post_id, '_vosfacture_price_gross', $facture['price_gross']);
                update_post_meta($new_post_id, '_vosfacture_paid', $facture['paid']);
                update_post_meta($new_post_id, '_vosfacture_status', $facture['status']);
                update_post_meta($new_post_id, '_vosfacture_department_id', $department_id);
                update_post_meta($new_post_id, '_vosfacture_client_id', $client_id);
            }
            
        }
    }*/
}


