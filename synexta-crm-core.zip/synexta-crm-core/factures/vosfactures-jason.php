<?php

function vosfactdebug_get_hashed_id_from_url() {
    return isset($_GET['hashed_id']) ? sanitize_text_field($_GET['hashed_id']) : false;
}

function vosfactdebug_get_user_id_from_hash($hashedId) {
    return $hashedId ? base64_decode($hashedId) : false;
}

function test_shortcode() {
    if (!is_user_logged_in()) {
        return ''; // Retourne vide si l'utilisateur n'est pas connecté
    }

    $hashedId = get_hashed_id_from_url();
    if (!$hashedId) {
        return ''; // Retourne vide si l'ID haché n'est pas disponible
    }

    $user_id = get_user_id_from_hash($hashedId);
    if (!$user_id) {
        return ''; // Retourne vide si l'ID utilisateur n'est pas disponible
    }

    $vosfactures_id = get_user_meta($user_id, 'vosfactures_id', true);
    if (!$vosfactures_id) {
        return ''; // Retourne vide si l'ID VosFactures n'est pas disponible
    }

    $api_url = get_option('vosfactures_api_url');
    $api_key = get_option('vosfactures_api_key');

    $response = wp_remote_get("$api_url/invoices.json?client_id=$vosfactures_id&api_token=$api_key&per_page=50");

    if (is_wp_error($response)) {
        return '<p>Erreur lors de la récupération des factures.</p>';
    }

    $body = wp_remote_retrieve_body($response);

    // Afficher le JSON brut
    return '<pre>' . esc_html($body) . '</pre>';
}

add_shortcode('test', 'test_shortcode');
