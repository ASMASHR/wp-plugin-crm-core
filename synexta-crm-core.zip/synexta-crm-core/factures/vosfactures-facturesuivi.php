<?php
// Ajout du shortcode [chiffre-affaire]
function chiffre_affaire_shortcode($atts) {
    // Traitement des attributs du shortcode
    $atts = shortcode_atts(array(
        'type' => 'follow',
    ), $atts, 'chiffre-affaire');

    // Vérification de la présence du shortcode sur la page
    if (!is_singular()) {
        return ''; // Ignorer si ce n'est pas une page ou un article
    }

    if (get_option('vosfactures_sync_enabled') == 'yes') {
    // Récupération du vosfactures_id à l'aide de la fonction mémorisée
    $hashedId = get_hashed_id_from_url();
    $user_id = get_user_id_from_hash($hashedId);

    if (!$user_id) {
        return '<div class="vosfactures-id">ID non disponible</div>';
    }
    $vosfactures_id = get_user_meta($user_id, 'vosfactures_id', true);

    if ($vosfactures_id) {
        $args = array(
            'post_type'      => 'facture',
            'posts_per_page' => -1, // Récupérer toutes les factures
            'meta_query'     => array(
                array(
                    'key'     => '_vosfacture_client_id',
                    'value'   => $vosfactures_id,
                    'compare' => '='
                ),
                array(
                    'key'     => '_vosfacture_categorie',
                    'value'   => 'facture',
                    'compare' => '='
                ),
            ),
        );

        $factures = new WP_Query($args);

        if ($factures->have_posts()) {
            $current_year = date('Y');
            $ca_per_year = array();
            $ca_unpaid = 0;

            while ($factures->have_posts()) {
                $factures->the_post();
                $annee = get_post_meta(get_the_ID(), '_vosfacture_annee', true);
                $montant_ttc = get_post_meta(get_the_ID(), '_vosfacture_price_gross', true);
                $montant_regle = get_post_meta(get_the_ID(), '_vosfacture_paid', true);

                if (!isset($ca_per_year[$annee])) {
                    $ca_per_year[$annee] = 0;
                }

                $ca_per_year[$annee] += $montant_ttc;

                if ($montant_regle < $montant_ttc) {
                    $ca_unpaid += ($montant_ttc - $montant_regle);
                }
            }

            wp_reset_postdata();

            // Trier les années par CA décroissant pour trouver le meilleur CA
            arsort($ca_per_year);

            $best_year = key($ca_per_year);
            $ca_current_year = isset($ca_per_year[$current_year]) ? $ca_per_year[$current_year] : 0;
            $ca_previous_year = 0;
            $ca_previous_year_label = $current_year - 1;

            // Trouver la meilleure année disponible pour n-1 si elle est vide
            foreach ($ca_per_year as $year => $ca) {
                if ($year < $current_year && $ca > 0) {
                    $ca_previous_year = $ca;
                    $ca_previous_year_label = $year;
                    break;
                }
            }

            $ca_best_year = $ca_per_year[$best_year];

            $currency_symbol = get_woocommerce_currency_symbol();

            if ($atts['type'] == 'follow') {
                $output = '<div class="stats-factures">';
                $output .= '<p class="ca-current-year">CA ' . esc_html($current_year) . ': <span class="montant">' . format_ca($ca_current_year, $currency_symbol) . ' TTC</span></p>';
                $output .= '<p class="ca-previous-year">CA ' . esc_html($ca_previous_year_label) . ': <span class="montant">' . format_ca($ca_previous_year, $currency_symbol) . ' TTC</span></p>';
                $output .= '<p class="ca-best-year">Meilleure année ' . esc_html($best_year) . ': <span class="montant">' . format_ca($ca_best_year, $currency_symbol) . ' TTC</span></p>';
                $output .= '</div>';
            } elseif ($atts['type'] == 'stats') {
                $output = '<div class="stats-factures">';
                $ca_unpaid_text = 'Encours : <span class="montant">' . format_ca($ca_unpaid, $currency_symbol) . ' TTC</span>';
                if ($ca_unpaid > 0) {
                    $output .= '<p class="ca-unpaid retard">' . $ca_unpaid_text . '</p>';
                } else {
                    $output .= '<p class="ca-unpaid">' . $ca_unpaid_text . '</p>';
                }
                $output .= '<p class="ca-cumulative">CA cumulé ' . esc_html($current_year) . ': <span class="montant">' . format_ca($ca_current_year, $currency_symbol) . ' TTC</span></p>';
                $output .= '</div>';
            }

            return $output;
        } else {
            return '<div class="vosfactures-id"></div>';
        }
    } else {
        return '<div class="vosfactures-id">ID vosfacture non disponible</div>';
    }
}
else{
    return '';
}
}

// Fonction pour formater le CA
function format_ca($ca, $currency_symbol) {
    if ($ca > 9999) {
        return number_format($ca / 1000, 1, ',', '') . ' K' . $currency_symbol;
    } else {
        return number_format($ca, 0, ',', '') . ' ' . $currency_symbol;
    }
}

// Enregistrement du shortcode
add_shortcode('chiffre-affaire', 'chiffre_affaire_shortcode');
