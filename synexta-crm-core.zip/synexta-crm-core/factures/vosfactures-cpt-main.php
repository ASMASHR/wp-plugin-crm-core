<?php
require_once plugin_dir_path(__FILE__) . 'vosfactures-facture-cpt.php';
require_once plugin_dir_path(__FILE__) . 'vosfactures-jason.php'; // shortcode [test] qui renvoie le JASON afin de mieux comprendre le format retourné
require_once plugin_dir_path(__FILE__) . 'vosfactures-factureshortcode.php'; // shortcode affichage factures coté front
require_once plugin_dir_path(__FILE__) . 'vosfactures-facturesuivi.php'; // shortcode affichage stats analyse