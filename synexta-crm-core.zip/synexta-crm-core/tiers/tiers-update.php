<?php
add_action('profile_update', 'sync_user_with_vosfactures_on_update', 10, 2);

function sync_user_with_vosfactures_on_update($user_id, $old_user_data) {
    $user_info = get_userdata($user_id);
    $vosfactures_id = get_user_meta($user_id, 'vosfactures_id', true);

    $form_data = array(
        'user_id' => $user_id,
        'first_name' => $user_info->first_name,
        'last_name' => $user_info->last_name,
        'email' => $user_info->user_email,
        'billing_address_1' => get_user_meta($user_id, 'billing_address_1', true),
        'billing_postcode' => get_user_meta($user_id, 'billing_postcode', true),
        'billing_city' => get_user_meta($user_id, 'billing_city', true),
        'billing_country' => get_user_meta($user_id, 'billing_country', true),
        'billing_phone' => get_user_meta($user_id, 'billing_phone', true),
        'tax_no' => get_user_meta($user_id, 'tax_no', true),
        'user_type' => get_user_meta($user_id, 'user_type', true),
    );

    $api_key = get_option('vosfactures_api_key');
    $api_url = rtrim(get_option('vosfactures_api_url'), '/');

    if (empty($api_key) || empty($api_url)) {
        wp_send_json_error( array('success' => false, 'message' => 'La clé API ou l\'URL VosFactures n\'est pas configurée.'));
    }

     $contact_data = array(
        'client' => array(
            'name' => custom_normalize_and_uppercase(trim($form_data['first_name'] . ' ' . $form_data['last_name'])),
            'first_name' => custom_normalize_and_uppercase($form_data['first_name']),
            'last_name' => custom_normalize_and_uppercase($form_data['last_name']),
            'email' => $form_data['email'],
            'street' => $form_data['billing_address_1']?custom_normalize_and_uppercase(str_replace('<br>', ', ', $form_data['billing_address_1'])):'',
            'post_code' => $form_data['billing_postcode'],
            'city' => custom_normalize_and_uppercase($form_data['billing_city']),
            'country' => custom_normalize_and_uppercase($form_data['billing_country']),
            'phone' => $form_data['billing_phone'],
            'tax_no' => $form_data['tax_no'],
            'company'=>$form_data['user_type']=="entreprise"?true: false,
        )
    );
   

    // Envoyer les données à VosFactures
    $endpoint = $vosfactures_id ? "/clients/{$vosfactures_id}.json" : "/clients.json";
    $method = $vosfactures_id ? 'PUT' : 'POST';
    $action =  $vosfactures_id ? 'updated' : "created";

    $response = wp_remote_request($api_url . $endpoint, array(
        'method'      => $method,
        'headers'     => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
        ),
        'body'        => json_encode($contact_data),
        'data_format' => 'body'
    ));

    if (is_wp_error($response)) {
        //wp_send_json_error(array('success' => false, 'message' => 'Erreur lors de la connexion à VosFacture.'));
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    if($method=="PUT"&&isset($body['error'])&&$body['error']=="Not Found"){
        $endpoint="/clients.json";
        $responseNew = wp_remote_request($api_url . $endpoint, array(
            'method'      => 'POST',
            'headers'     => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ),
            'body'        => json_encode($contact_data),
            'data_format' => 'body'
        ));

    $body = json_decode(wp_remote_retrieve_body($responseNew), true);
    
    $action =   "created";
    }

    if (isset($body['id'])) {
        update_user_meta($form_data['user_id'], 'vosfactures_id', $body['id']);
       } else {
        }


}

