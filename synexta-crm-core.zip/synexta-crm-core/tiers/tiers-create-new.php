<?php
/*
 * Ce fichier gère la création de nouveaux comptes utilisateurs via un shortcode sur le front-end.
 * Les utilisateurs sont d'abord créés sur VosFactures, puis dans WordPress.
 */

// Fonction pour normaliser et convertir en majuscules
function custom_normalize_and_uppercase($text) {
    $unwanted_array = array(
        'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A', 'Å' => 'A', 'Æ' => 'AE',
        'Ç' => 'C',
        'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
        'Ì' => 'I', 'Í' => 'I', '' => 'I', 'Ï' => 'I',
        '' => 'N',
        'Ò' => 'O', '' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O',
        'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U',
        'Ý' => 'Y',
        'ß' => 'SS',
        'à' => 'A', 'á' => 'A', 'â' => 'A', 'ã' => 'A', 'ä' => 'A', 'å' => 'A', '' => 'AE',
        'ç' => 'C',
        'è' => 'E', 'é' => 'E', 'ê' => 'E', 'ë' => 'E',
        'ì' => 'I', 'í' => 'I', 'î' => 'I', 'ï' => 'I',
        'ñ' => 'N',
        'ò' => 'O', 'ó' => 'O', 'ô' => 'O', 'õ' => 'O', 'ö' => 'O', 'ø' => 'O',
        'ù' => 'U', 'ú' => 'U', 'û' => 'U', 'ü' => 'U',
        'ý' => 'Y', 'ÿ' => 'Y'
    );
    $text = strtr($text, $unwanted_array);
    $text = preg_replace("/[&\/:,']/u", " ", $text);
    $text = preg_replace('/\s+/', ' ', $text); // Supprimer les espaces multiples
    return strtoupper(trim($text));
}

// Fonction pour générer un email unique si l'email existe déjà
function generate_unique_email($email) {
    $email_parts = explode('@', $email);
    if (count($email_parts) != 2) {
        return $email; // Format d'email invalide
    }
    $base = $email_parts[0];
    $domain = $email_parts[1];
    $counter = 1;
    
    while(email_exists($email)) {
        $email = $base . '+' . $counter . '@' . $domain;
        $counter++;
        if ($counter > 1000) { // Éviter une boucle infinie
            break;
        }
    }
    
    return $email;
}

// Fonction pour génrer un user_login unique basé sur l'ID VOSFACTURE
function generate_user_login_from_vosfacture_id($vosfacture_id) {
    // Assurer que user_login est unique
    if (username_exists($vosfacture_id)) {
        // Trs improbable si les IDs VosFactures sont uniques
        // Mécanisme de secours
        return $vosfacture_id . '_' . wp_generate_password(4, false);
    }
    return $vosfacture_id;
}

// Fonction pour afficher le formulaire de création d'utilisateur
function custom_display_crm_creation_form1() {
    // Initialisation des variables de formulaire
    $result_message = '';
    global $wpdb;
    $table_name = $wpdb->prefix . 'users'; // Change ce nom si tu utilises une table personnalisée

    // Récupérer les informations du dernier utilisateur créé
    $last_user = $wpdb->get_row("SELECT * FROM $table_name ORDER BY ID DESC LIMIT 1");
    $selected_type="";
    // Supposons que le type soit stocké dans user_meta ou dans une colonne spécifique
    if ($last_user) {
        $user_id = $last_user->ID;
        $selected_type = get_user_meta($user_id, 'user_type', true);
    }

    // Affichage du formulaire
    ob_start();
    ?>
    <form method="post" id="crm-creation-form" novalidate>
        <div class="container-third">
            <div class="form-group thirdsize obligatoire">
                <label class="label" for="user_role">Rôle :</label>
                
                <select name="user_role" id='user_role'>
                    <option value='tiers'>Tiers</option>
                    <option value='customer'>Client</option>
                    <option value='prospect'selected>Prospect</option>
                    <option value='non_qualifie'>Non qualifié</option>
                    <option value='hors_cible'>Hors cible</option>
                </select>
            </div>
            <div class="form-group thirdsize obligatoire">
                <label class="label"for="last_name">Nom * :</label>
                <input type="text" name="last_name"id="last_name" required>
            </div>

            <div class="form-group thirdsize">
                <label class="label"for="first_name">Prénom :</label>
                <input type="text" name="first_name" id="first_name">
            </div>
        </div>
        <div class="<?php echo ($selected_type == 'entreprise') ? 'container-third' : 'container'; ?>  ">
            <div class="form-group thirdsize obligatoire">
                <label class="label" for="user_type">Type * :</label>
                <select name="user_type" id="user_type" class="dynamic-width" required>
                    <option value="" disabled>-- Séléctionnez --</option>
                    <option value="entreprise"<?php echo ($selected_type == 'entreprise') ? 'selected' : ''; ?>>Entreprise</option>
                    <option value="particulier"<?php echo ($selected_type == 'particulier') ? 'selected' : ''; ?>>Particulier</option>
                </select>
            </div>

            <!-- Champs Entreprise et Siren -->
            <div class="form-group thirdsize entreprise-field obligatoire" style="<?php echo ($selected_type == 'particulier') ? 'display: none;' : ''; ?>">
                <label class="label" for="company">Entreprise * :</label>
                <input type="text" name="company" id="company"required>
            </div>

            <div class="form-group thirdsize entreprise-field obligatoire" style="<?php echo ($selected_type == 'particulier') ? 'display: none;' : ''; ?>">
                <label class="label" for="tax_no">Siren * :</label>
                <input type="text" name="tax_no" id="tax_no"required>
            </div>
        </div>

        <!--<div class="container-third">
            <div class="form-group thirdsize">
                <label class="label"for="user_type">Type :</label>
                <select name="user_type"id="user_type">
                    <option value="" selected disabled>-- Séléctionnez --</option>
                    <option value="entreprise">Entreprise</option>
                    <option value="particulier">Particulier</option>
                </select>
            </div>
            <div class="form-group thirdsize">
            <label class="label"for="company">Entreprise :</label>
                <input type="text" name="company"id="company">
            </div>

            <div class="form-group thirdsize">
                <label class="label"for="tax_no">Siren :</label>
                    <input type="text" name="tax_no"id="tax_no">
                </div>
        </div>-->
        

        <div class="form-group">
            <label class="label"for="billing_address_1">Adresse :</label>
            <textarea type="text" name="billing_address_1"id="billing_address_1"rows="2"></textarea>
        </div>

        <div class="container-third">
            <div class="form-group thirdsize">
                <label class="label" for="billing_postcode">Code postal :</label>
                <input type="text" name="billing_postcode"id="billing_postcode">
            </div>
    
            <div class="form-group thirdsize">
                <label class="label"for="billing_city">Ville :</label>
                <input type="text" name="billing_city"id="billing_city">
            </div>
    
            <div class="form-group thirdsize obligatoire">
                <label class="label"for="billing_country" >Pays/région * :</label>
                <?php
                    if (class_exists('WC_Countries')) {
                        $countries_obj = new WC_Countries();
                        $countries = $countries_obj->get_countries();
                    } else {
                        $countries = array('FR' => 'France'); // Valeur par défaut si WooCommerce n'est pas actif
                    }
                    $default_country = 'FR';
                ?>
                <select name="billing_country" id="billing_country" required>
                    <?php foreach ($countries as $code => $name) : ?>
                        <option value="<?php echo esc_attr($code); ?>"<?php echo $code === $default_country ? 'selected' : ''; ?>><?php echo esc_html($name); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="container-half">
            <div class="form-group halfsize">
                <label class="label"for="billing_phone">Téléphone :</label>
                <input type="text" name="billing_phone" id="billing_phone">
            </div>
    
            <div class="form-group halfsize obligatoire">
                <label class="label"for="user_email" >E-mail * :</label>
                <input type="email" name="user_email" id="user_email" required>
            </div>
        </div>

        <div class="container-half">
            <div class="form-group halfsize">
                <label class="label"for="user_url" >Site web :</label>
                <input type="text" name="user_url"id="user_url">
            </div>

            <div class="form-group halfsize">
                <label class="label"for="user_mailing">Publipostage :</label>
                <select name="user_mailing"id="user_mailing">
                    <option value="yes" selected>Oui</option>
                    <option value="no">Non</option>
                </select>
            </div>
        </div>

        <input type="hidden" name="user_status" value="active">

        <button type="submit">Valider la création</button>
    </form>
    <div id="crm-creation-result">
        
    </div>
    <script>
        jQuery(document).ready(function ($) {
            $('#user_type').on('change', function () {
        const selectedType = $(this).val();
        
        if (selectedType === 'entreprise') {
            $('.entreprise-field').slideDown();  
            $('#user_type').parent().parent().removeClass('container-third').addClass('container');  
        } else {
            $('.entreprise-field').slideUp();  
            $('#user_type').parent().parent().addClass('container-third').removeClass('container');   
        }
    });
            function validateForm() {
                let isValid = true;
                $('#crm-creation-form .obligatoire:visible input, #crm-creation-form .obligatoire:visible select').each(function () {
                    const $field = $(this);
                    const value = $field.val().trim();
                    const $errorMsg = $field.next('.error-message');

                    if (!value) {
                        if ($errorMsg.length === 0) {
                            $field.after('<div class="error-message" style="color: white; font-size: 0.9em;">Ce champ est obligatoire.</div>');
                        }
                        isValid = false;
                    } else {
                        $errorMsg.remove();
                    }
                });
                return isValid;
            }

            $(document).on('input change', '#crm-creation-form:visible input, #crm-creation-form:visible select', function () {
                $(this).next('.error-message').remove();
            });

            // Gestion de la soumission du formulaire
            $(document).on("submit", '#crm-creation-form', function (e) {
                e.preventDefault(); 

                if (validateForm()) {
                    const formData = $(this).serialize();

                    $.ajax({
                        url: ajax_object.ajax_url, 
                        type: 'POST',
                        data: {
                            action: 'create_new_user',
                            form_data: formData
                        },
                        beforeSend: function () {
                            $('#crm-creation-result').html('<p style="color: blue;">Traitement en cours...</p>');
                        },
                        success: function (response) {
                            if (response.success) {
                                $('#crm-creation-result').html('<p style="color: green;">Utilisateur créé avec succès.</p>');
                                setTimeout(function () {
                                    window.location.href = response.data.redirect_url;
                                }, 2000);
                            } else {
                                $('#crm-creation-result').html('<p style="color: red;">' + response.data.message + '</p>');
                            }
                        },
                        error: function () {
                            $('#crm-creation-result').html('<p style="color: red;">Une erreur s\'est produite. Veuillez réessayer.</p>');
                        }
                    });
                }
            });
        });
    </script>
    <?php
    return ob_get_clean();

}
add_shortcode('crm_creation', 'custom_display_crm_creation_form1');

// Fonction pour gérer la soumission du formulaire
function create_new_user() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json_error(array('message' => 'Méthode de requête invalide.'));
    }

    // Récuprer et traiter les données du formulaire
    parse_str($_POST['form_data'], $form_data);

    // Valider les champs obligatoires
    $required_fields = array('last_name', 'billing_country', 'user_email');
    foreach ($required_fields as $field) {
        if (empty($form_data[$field])) {
            wp_send_json_error(array('message' => 'Le champ ' . ucfirst(str_replace('_', ' ', $field)) . ' est obligatoire.'));
        }
    }

    if (empty($form_data['user_email'])) {
        wp_send_json_error(array('success' => false, 'message' => 'L\'email est obligatoire.'));
    }

    if (email_exists($form_data['user_email'])) {
        $form_data['user_email'] = generate_unique_email($form_data['user_email']);
    }

    $api_key = get_option('vosfactures_api_key');
    $api_url = rtrim(get_option('vosfactures_api_url'), '/');

    if (empty($api_key) || empty($api_url)) {
        wp_send_json_error(array('success' => false, 'message' => 'La cl API ou l\'URL VosFactures n\'est pas configurée.'));
    }

    // Normaliser et convertir en majuscules
    $form_data['first_name'] = !empty($form_data['first_name']) ? custom_normalize_and_uppercase($form_data['first_name']) : '';
    $form_data['last_name'] = custom_normalize_and_uppercase($form_data['last_name']);
    $form_data['company'] = !empty($form_data['company']) ? custom_normalize_and_uppercase($form_data['company']) : '';
    //$form_data['billing_address_1'] = !empty($form_data['billing_address_1']) ? custom_normalize_and_uppercase($form_data['billing_address_1']) : '';
    $form_data['billing_address_1'] = !empty($form_data['billing_address_1']) 
    ? custom_normalize_and_uppercase(str_replace('<br>', ', ', $form_data['billing_address_1'])) 
    : '';
	$form_data['billing_city'] = !empty($form_data['billing_city']) ? custom_normalize_and_uppercase($form_data['billing_city']) : '';
    $form_data['billing_country'] = !empty($form_data['billing_country']) ? custom_normalize_and_uppercase($form_data['billing_country']) : 'FRANCE';
    $form_data['user_role'] = !empty($form_data['user_role']) ? $form_data['user_role'] : 'prospect';

    // Préparer les données pour VosFactures
    $contact_data = array(
        'client' => array(
            'name' => !empty($form_data['company']) ? $form_data['company'] : trim($form_data['first_name'] . ' ' . $form_data['last_name']),
            'first_name' => $form_data['first_name'],
            'last_name' => $form_data['last_name'],
            'email' => $form_data['user_email'],
            'street' => $form_data['billing_address_1'],
            'post_code' => $form_data['billing_postcode'],
            'city' => $form_data['billing_city'],
            'country' => $form_data['billing_country'],
            'phone' => $form_data['billing_phone'],
            'tax_no' => $form_data['tax_no'],
            'company' => !empty($form_data['company']) ? true : false,
        )
    );

    // Envoyer les données à VosFactures
    $response = wp_remote_post($api_url . '/clients.json', array(
        'method' => 'POST',
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
        ),
        'body' => json_encode($contact_data),
        'timeout' => 30,
    ));

    if (is_wp_error($response)) {
        wp_send_json_error(array('success' => false, 'message' => 'Erreur lors de la synchronisation avec VosFactures.'));
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (!isset($data['id'])) {
        wp_send_json_error(array('success' => false, 'message' => 'Erreur lors de la création du client sur VosFactures.'));
    }

    $vosfacture_id = $data['id'];

    // Générer un user_login unique basé sur l'ID VOSFACTURE
    $user_login = generate_user_login_from_vosfacture_id($vosfacture_id);

    // Créer l'utilisateur dans WordPress avec l'ID VosFactures comme user_login
    $user_id = wp_insert_user(array(
        'user_login' => $user_login,
        'user_email' => $form_data['user_email'],
        'first_name' => $form_data['first_name'],
        'last_name' => $form_data['last_name'],
        'role' => $form_data['user_role'],
    ));

    if (is_wp_error($user_id)) {
        wp_send_json_error(array('success' => false, 'message' => 'Erreur lors de la création de l\'utilisateur WordPress.'));
    }

  
    // Mettre à jour les mtadonnées utilisateur
    update_user_meta($user_id, 'vosfactures_id', $vosfacture_id);
    update_user_meta($user_id, 'billing_first_name', $form_data['first_name']);
    update_user_meta($user_id, 'billing_last_name', $form_data['last_name']);
    update_user_meta($user_id, 'billing_company', !empty($form_data['company']) ? $form_data['company'] : '');
    update_user_meta($user_id, 'tax_no', $form_data['tax_no']);
    update_user_meta($user_id, 'billing_address_1', $form_data['billing_address_1']);
    update_user_meta($user_id, 'billing_city', $form_data['billing_city']);
    update_user_meta($user_id, 'billing_postcode', $form_data['billing_postcode']);
    update_user_meta($user_id, 'billing_country', $form_data['billing_country']);
    update_user_meta($user_id, 'billing_phone', $form_data['billing_phone']);
    update_user_meta($user_id, 'user_url', $form_data['user_url']);
    update_user_meta($user_id, 'user_mailing', $form_data['user_mailing']);
    update_user_meta($user_id, 'user_status', 'active');
    // update_user_meta($user_id, 'user_type', $form_data['user_type']);
    // test modif florian

    if (!empty($form_data['company'])) {
        $user_type = 'entreprise';
    } else {
        $user_type = 'particulier';
    }
    
    update_user_meta($user_id, 'user_type', $user_type);


    // Copier les informations de facturation vers livraison
    update_user_meta($user_id, 'shipping_first_name', $form_data['first_name']);
    update_user_meta($user_id, 'shipping_last_name', $form_data['last_name']);
    update_user_meta($user_id, 'shipping_company', !empty($form_data['company']) ? $form_data['company'] : '');
    update_user_meta($user_id, 'shipping_address_1', $form_data['billing_address_1']);
    update_user_meta($user_id, 'shipping_city', $form_data['billing_city']);
    update_user_meta($user_id, 'shipping_postcode', $form_data['billing_postcode']);
    update_user_meta($user_id, 'shipping_country', $form_data['billing_country']);
    update_user_meta($user_id, 'shipping_phone', $form_data['billing_phone']);
    $hashedId = generate_user_hash($user_id);
    
    wp_send_json_success(array('redirect_url' => site_url('/crm-customer/' . $hashedId)));

}
add_action('wp_ajax_create_new_user', 'create_new_user');

function import_users_enqueue_scripts() {
    wp_enqueue_script(
        'crm-users-creation-shortcode',
        plugin_dir_url(__FILE__) . 'tiers.js',
        array('jquery'),
        null,
        true
    );
    wp_localize_script(
        'crm-users-creation-shortcode',
        'ajax_object',
        array('ajax_url' => admin_url('admin-ajax.php'))
    );
}
add_action('wp_enqueue_scripts', 'import_users_enqueue_scripts');
?>