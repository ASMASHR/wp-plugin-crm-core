<?php

/*
 * Ce fichier PHP étend les fonctionnalités de gestion des utilisateurs dans WordPress.
 *
 * Il introduit des rôles personnalisés et ajoute des métadonnées utilisateur pour grer des informations supplémentaires.
 *
 * Variables et métadonnées utilisateur :
 * 
 * 1. Rôles Utilisateurs :
 *    - `tiers`
 *    - `utilisateur_crm`
 *    - `responsable_crm`
 *    - `prospect`
 *    - `Non qualifié`
 *    - `Hors cible`
 * 
 *    Ces rôles peuvent être utilisés pour définir des autorisations et niveaux d'accès spécifiques.
 *
 * 2. Métadonnées Utilisateur :
 *    - `tax_no` : Stocke le numéro SIREN et le numéro de TVA. Type : chaîne de caractères.
 *    - `vosfactures_id` : Identifiant unique pour l'intégration avec VosFactures. Type : nombre entier, non modifiable.
 *    - `account_creation_date` : Date et heure de création du compte. Type : chaîne au format 'Y-m-d H:i:s', non modifiable.
 *    - `account_last_modified_date` : Date et heure de la dernière modification du compte. Type : chaîne au format 'Y-m-d H:i:s', non modifiable.
 *    - `user_mailing` : Statut de l'utilisateur concernant le publipostage. Valeurs possibles : 'yes' ou 'no'.
 *    - `user_status` : Statut du compte client. Valeurs possibles : 'active' ou 'inactive'.
 *    - `user_type` : Type de l'utilisateur. Valeurs possibles : 'entreprise' ou 'particulier'.
 *
 * Utilisation :
 * - Pour accéder à ces métadonnées, utilisez les fonctions WordPress `get_user_meta($user_id, 'meta_key', true)` et `update_user_meta($user_id, 'meta_key', $value)`.
 * - Les dates sont au format 'Y-m-d H:i:s' et utilisent la timezone du site. Assurez-vous de manipuler ces données en tenant compte de la timezone.
 * - Les rôles peuvent être grés via les fonctions WordPress `add_role()`, `remove_role()`, et `get_role()`.
 *
 * Les actions et filtres WordPress utiliss incluent 'init', 'show_user_profile', 'edit_user_profile', 'personal_options_update', 'profile_update', etc., 
 * pour intégrer ces fonctionnalités dans le cycle de vie utilisateur.
 */


function create_custom_roles() {
    $roles = array(
        'tiers' => 'Tiers',
        'utilisateur_crm' => 'Utilisateur CRM',
        'responsable_crm' => 'Responsable CRM',
        'non_qualifie'=>'Non qualifié',
        'hors_cible'=>'Hors cible',
        'prospect' => 'Prospect'
    );

    $roles_created = get_option('custom_roles_created', false);

   // if (!$roles_created) {
        foreach ($roles as $role => $name) {
            if (!get_role($role)) {
                add_role(
                    $role,
                    __($name),
                    get_role('subscriber')->capabilities
                );
            }
       // }
       // update_option('custom_roles_created', true);
    }
}
add_action('init', 'create_custom_roles');

// Désactiver les notifications par e-mail lors de la création ou la modification d'un utilisateur
function disable_new_user_notifications() {
    remove_action('register_new_user', 'wp_send_new_user_notifications');
    remove_action('edit_user_created_user', 'wp_send_new_user_notifications', 10, 2);
}
add_action('init', 'disable_new_user_notifications');

// Désactiver la case de notification par e-mail dans le formulaire d'ajout d'utilisateur
function disable_user_notification_checkbox() {
    ?>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            var notifyCheckbox = document.getElementById('send_user_notification');
            if (notifyCheckbox) {
                notifyCheckbox.checked = false;
                notifyCheckbox.disabled = true;
            }
        });
    </script>
    <?php
}
add_action('admin_footer-user-new.php', 'disable_user_notification_checkbox');

// Ajouter les rôles personnalisés au dropdown des rôles éditables dans WordPress
function add_custom_roles_to_dropdown($all_roles) {
    $custom_roles = array(
        'tiers' => 'Tiers',
        'utilisateur_crm' => 'Utilisateur CRM',
        'responsable_crm' => 'Responsable CRM',
        'non_qualifie'=>'Non qualifié',
        'hors_cible'=>'Hors cible',
        'prospect' => 'Prospect'
    );
    foreach ($custom_roles as $role => $display_name) {
        $all_roles[$role] = array(
            'name' => __($display_name),
            'capabilities' => array()
        );
    }
    return $all_roles;
}
add_filter('editable_roles', 'add_custom_roles_to_dropdown');

// Ajouter le champ "Identifiant commercial" dans le profil utilisateur
add_action('show_user_profile', 'add_tax_no_field');
add_action('edit_user_profile', 'add_tax_no_field');
function add_tax_no_field($user) {
    ?>
    <table class="form-table">
        <tr>
            <th><label for="tax_no"><?php _e("Identifiant commercial"); ?></label></th>
            <td>
                <input type="text" name="tax_no" id="tax_no" value="<?php echo esc_attr(get_the_author_meta('tax_no', $user->ID)); ?>" class="regular-text" /><br />
                <span class="description"><?php _e("Numero SIREN et numro de TVA"); ?></span>
            </td>
        </tr>
    </table>
    <?php
}

// Ajouter le champ "ID unique VosFactures" dans le profil utilisateur
add_action('show_user_profile', 'add_vosfactures_id_field');
add_action('edit_user_profile', 'add_vosfactures_id_field');
function add_vosfactures_id_field($user) {
    ?>
    <table class="form-table">
        <tr>
            <th><label for="vosfactures_id"><?php _e("ID unique VosFactures"); ?></label></th>
            <td>
                <input type="number" name="vosfactures_id" id="vosfactures_id" value="<?php echo esc_attr(get_the_author_meta('vosfactures_id', $user->ID)); ?>" class="regular-text" disabled /><br />
                <span class="description"><?php _e("Cl de rattachement avec vosfactures attribution par systeme"); ?></span>
            </td>
        </tr>
    </table>
    <?php
}

// Ajouter le champ "Date de Création" dans le profil utilisateur
add_action('show_user_profile', 'add_account_creation_date_field');
add_action('edit_user_profile', 'add_account_creation_date_field');
function add_account_creation_date_field($user) {
    $creation_date = get_user_meta($user->ID, 'account_creation_date', true);
    if (!$creation_date) {
        $creation_date = current_time('Y-m-d H:i:s');
        update_user_meta($user->ID, 'account_creation_date', $creation_date);
    }
    ?>
    <table class="form-table">
        <tr>
            <th><label for="account_creation_date"><?php _e("Date de Création"); ?></label></th>
            <td>
                <input type="text" name="account_creation_date" id="account_creation_date" value="<?php echo esc_attr($creation_date); ?>" class="regular-text" readonly /><br />
                <span class="description"><?php _e("Date et heure de création du compte."); ?></span>
            </td>
        </tr>
    </table>
    <?php
}

// Ajouter le champ "Date de Modification" dans le profil utilisateur
add_action('show_user_profile', 'add_account_last_modified_date_field');
add_action('edit_user_profile', 'add_account_last_modified_date_field');
function add_account_last_modified_date_field($user) {
    $last_modified_date = get_user_meta($user->ID, 'account_last_modified_date', true);
    if (!$last_modified_date) {
        $last_modified_date = current_time('Y-m-d H:i:s');
        update_user_meta($user->ID, 'account_last_modified_date', $last_modified_date);
    }
    ?>
    <table class="form-table">
        <tr>
            <th><label for="account_last_modified_date"><?php _e("Date de Modification"); ?></label></th>
            <td>
                <input type="text" name="account_last_modified_date" id="account_last_modified_date" value="<?php echo esc_attr($last_modified_date); ?>" class="regular-text" readonly /><br />
                <span class="description"><?php _e("Date et heure de la dernière modification du compte."); ?></span>
            </td>
        </tr>
    </table>
    <?php
}

// Ajouter le dropdown "Publipostage" dans le profil utilisateur
add_action('show_user_profile', 'add_user_mailing_field');
add_action('edit_user_profile', 'add_user_mailing_field');
function add_user_mailing_field($user) {
    ?>
    <table class="form-table">
        <tr>
            <th><label for="user_mailing"><?php _e("Publipostage"); ?></label></th>
            <td>
                <select name="user_mailing" id="user_mailing">
                    <option value="yes" <?php selected(get_the_author_meta('user_mailing', $user->ID), 'yes'); ?>><?php _e("Oui"); ?></option>
                    <option value="no" <?php selected(get_the_author_meta('user_mailing', $user->ID), 'no'); ?>><?php _e("Non"); ?></option>
                </select>
            </td>
        </tr>
    </table>
    <?php
}

// Ajouter le dropdown "Actif / Inactif" dans le profil utilisateur
add_action('show_user_profile', 'add_user_status_field');
add_action('edit_user_profile', 'add_user_status_field');
function add_user_status_field($user) {
    ?>
    <table class="form-table">
        <tr>
            <th><label for="user_status"><?php _e("Statut du compte client"); ?></label></th>
            <td>
                <select name="user_status" id="user_status">
                    <option value="active" <?php selected(get_the_author_meta('user_status', $user->ID), 'active'); ?>><?php _e("Actif"); ?></option>
                    <option value="inactive" <?php selected(get_the_author_meta('user_status', $user->ID), 'inactive'); ?>><?php _e("Inactif"); ?></option>
                </select>
            </td>
        </tr>
    </table>
    <?php
}

// Ajouter le dropdown "Particulier ou Entreprise" et gérer la logique associée
add_action('show_user_profile', 'add_user_type_field');
add_action('edit_user_profile', 'add_user_type_field');
function add_user_type_field($user) {
    ?>
    <table class="form-table">
        <tr>
            <th><label for="user_type"><?php _e("Particulier ou Entreprise"); ?></label></th>
            <td>
                <select name="user_type" id="user_type">
                    <option value="entreprise" <?php selected(get_the_author_meta('user_type', $user->ID), 'entreprise', true); ?>><?php _e("Entreprise"); ?></option>
                    <option value="particulier" <?php selected(get_the_author_meta('user_type', $user->ID), 'particulier'); ?>><?php _e("Particulier"); ?></option>
                </select>
            </td>
        </tr>
    </table>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            var userTypeSelect = document.getElementById('user_type');
            var taxNoField = document.getElementById('tax_no').closest('tr');
            var billingCompanyField = document.querySelector('input[name="billing_company"]');

            function toggleFields() {
                if (userTypeSelect.value === 'particulier') {
                    billingCompanyField.value = '';
                    billingCompanyField.parentElement.parentElement.style.display = 'none';
                    taxNoField.style.display = 'none';
                } else {
                    billingCompanyField.parentElement.parentElement.style.display = '';
                    taxNoField.style.display = '';
                }
            }

            userTypeSelect.addEventListener('change', toggleFields);
            toggleFields(); // Initial call to set the correct state
        });
    </script>
    <?php
}

// Sauvegarder les données des champs personnalisés
add_action('personal_options_update', 'save_extra_user_fields');
add_action('edit_user_profile_update', 'save_extra_user_fields');
function save_extra_user_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }
    update_user_meta($user_id, 'tax_no', $_POST['tax_no']);
    update_user_meta($user_id, 'user_mailing', $_POST['user_mailing']);
    update_user_meta($user_id, 'user_status', $_POST['user_status']);
    update_user_meta($user_id, 'user_type', $_POST['user_type']);

    // Gestion des champs en fonction du type d'utilisateur
    if ($_POST['user_type'] === 'particulier') {
        update_user_meta($user_id, 'billing_company', '');
        update_user_meta($user_id, 'tax_no', '');
    }

    // Mettre à jour la date de dernière modification du compte
    update_user_meta($user_id, 'account_last_modified_date', current_time('Y-m-d H:i:s'));
}

// Restreindre les rôles disponibles lors de l'édition d'un compte utilisateur
function restrict_role_selection($user) {
    $possibles_roles = ['tiers', 'customer', 'non_qualifie', 'hors_cible', 'prospect'];

    // Vérifie si l'utilisateur a un des rôles dans $possibles_roles
    $user_roles_intersect = array_intersect($user->roles, $possibles_roles);

    if (!empty($user_roles_intersect)) {    ?>
        <script type="text/javascript">
            document.addEventListener('DOMContentLoaded', function() {
                var roleSelect = document.getElementById('role');

                var client_roles = <?php echo json_encode($possibles_roles); ?>;
                if (roleSelect) {
                    for (var i = 0; i < roleSelect.options.length; i++) {
                        var role = roleSelect.options[i].value;
                        /*if (role !== 'tiers' && role !== 'customer') {
                            roleSelect.options[i].disabled = true;
                        }*/
                        if (client_roles.indexOf(role) === -1) {
                        roleSelect.options[i].disabled = true;
                       }
                    }
                }
            });
        </script>
        <?php
    } elseif (in_array('utilisateur_crm', $user->roles) || in_array('responsable_crm', $user->roles)) {
        ?>
        <script type="text/javascript">
            document.addEventListener('DOMContentLoaded', function() {
                var roleSelect = document.getElementById('role');
                   
                if (roleSelect) {
                    for (var i = 0; i < roleSelect.options.length; i++) {
                        var role = roleSelect.options[i].value;
                        if (role !== 'utilisateur_crm' && role !== 'responsable_crm') {
                            roleSelect.options[i].disabled = true;
                        }
                    }
                }
            });
        </script>
        <?php
    } 
}
add_action('show_user_profile', 'restrict_role_selection');
add_action('edit_user_profile', 'restrict_role_selection');

// Vérifier les modifications de rôle lors de l'enregistrement du profil utilisateur
function validate_role_changeOld($user_id, $current_user) {
    if (isset($_POST['role'])) {
        $new_role = $_POST['role'];
        $user = get_userdata($user_id);

        if (in_array('tiers', $user->roles) || in_array('customer', $user->roles)) {
            if ($new_role !== 'tiers' && $new_role !== 'customer') {
                $_POST['role'] = $user->roles[0];
            }
        } elseif (in_array('utilisateur_crm', $user->roles) || in_array('responsable_crm', $user->roles)) {
            if ($new_role !== 'utilisateur_crm' && $new_role !== 'responsable_crm') {
                $_POST['role'] = $user->roles[0];
            }
        } elseif (in_array('prospect', $user->roles)) {
            if ($new_role !== 'prospect' && $new_role !== 'tiers' && $new_role !== 'customer') {
                $_POST['role'] = $user->roles[0];
            }
        }
    }
}
function validate_role_change($user_id, $current_user) {
    if (isset($_POST['role'])) {
        $new_role = sanitize_text_field($_POST['role']); 
        $user = get_userdata($user_id);
        
        $allowed_roles = ['tiers', 'customer', 'non_qualifie', 'hors_cible'];

        if (array_intersect($allowed_roles, $user->roles)) {
            if (!in_array($new_role, $allowed_roles)) {
                $_POST['role'] = 'tiers';
            }
        }
        elseif (in_array('utilisateur_crm', $user->roles) || in_array('responsable_crm', $user->roles)) {
            if ($new_role !== 'utilisateur_crm' && $new_role !== 'responsable_crm') {
                $_POST['role'] = $user->roles[0];
            }
        }
    }
}
add_action('profile_update', 'validate_role_change', 10, 2);

// Empêcher les comptes "prospect" et "tiers" de se connecter au back-office
function restrict_login_access($user_login, $user) {
    if (in_array('prospect', $user->roles) || in_array('tiers', $user->roles)) {
        wp_die('Vous n\'êtes pas autoris à accéder au back-office.', 'Accès refusé');
    }
}
add_filter('wp_login', 'restrict_login_access', 10, 2);

?>
