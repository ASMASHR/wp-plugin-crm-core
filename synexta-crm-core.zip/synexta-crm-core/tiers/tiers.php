<?php

/*
 * Ce fichier PHP gère l'affichage des contacts depuis l'API VosFactures dans WordPress.
 *
 * Fonctionnalités principales :
 * - Vérifie la configuration de la clé API VosFactures et affiche un message si elle n'est pas configurée.
 * - Cre le shortcode `[tiers]` pour afficher les informations des contacts sous forme de tableau pagin.
 *
 * Variables et données :
 * - `vosfactures_api_key` : Clé API pour authentifier les requtes à l'API VosFactures.
 * - `vosfactures_api_url` : URL de base pour accéder à l'API VosFactures.
 * - `current_page` : Numro de la page courante pour la pagination des résultats.
 * - `per_page` : Nombre de contacts à afficher par page (défaut : 100).
 *
 * Utilisation :
 * - Le shortcode `[tiers]` peut tre inséré dans les publications ou pages pour afficher un tableau des contacts.
 * - Les résultats incluent les informations de chaque contact, y compris les dates de création et de modification.
 * - Les données sont récuprées et affichées en utilisant les fonctions WordPress `wp_remote_get()` et `wp_enqueue_style()`.
 */

// Inclusion des fichiers nécessaires pour le fonctionnement du module
require_once plugin_dir_path(__FILE__) . 'tiers-wordpress-changes.php';
require_once plugin_dir_path(__FILE__) . 'tiers-modification.php';
require_once plugin_dir_path(__FILE__) . 'tiers-create-new.php';
require_once plugin_dir_path(__FILE__) . 'tiers-update.php';
require_once plugin_dir_path(__FILE__) . 'tiers-import-contacts.php';
require_once plugin_dir_path(__FILE__) . 'tiers-import-contact-coorectionmanuelle.php';

add_action('wp_enqueue_scripts', 'enqueue_tiers_js');

function enqueue_tiers_js() {
    wp_enqueue_script('tiers-js', plugin_dir_url(__FILE__) . 'tiers.js', array('jquery'), '1.0', true);
}

function display_tiers_accounts($atts) {
    $api_key = get_option('vosfactures_api_key');
    $api_url = rtrim(get_option('vosfactures_api_url'), '/');

    if (empty($api_key)) {
        return '<p>La clé API VosFactures n\'est pas configure. Veuillez la configurer dans les paramètres du plugin.</p>';
    }

    $current_page = isset($_GET['tiers_page']) ? intval($_GET['tiers_page']) : 1;
    $per_page = 100;

    $api_url .= '/clients.json?api_key=' . urlencode($api_key) . '&page=' . $current_page . '&per_page=' . $per_page;

    $args = array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
        ),
    );

    $response = wp_remote_get(esc_url_raw($api_url), $args);

    if (is_wp_error($response)) {
        return 'Erreur lors de la connexion à l\'API VosFactures : ' . esc_html($response->get_error_message());
    }

    $status_code = wp_remote_retrieve_response_code($response);
    if ($status_code !== 200) {
        return 'Erreur HTTP : ' . esc_html($status_code) . '. Veuillez vrifier l\'API.';
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        return 'Erreur lors du dcodage des données JSON : ' . json_last_error_msg();
    }

    $clients = $data ?? array();
    $total_clients = count($clients);

    wp_enqueue_style('tiers-style', plugin_dir_url(__FILE__) . '../global.css');

    $output = '<p>Affichage des contacts ' . (($current_page - 1) * $per_page + 1) . ' à ' . min($current_page * $per_page, ($current_page - 1) * $per_page + $total_clients) . '</p>';

    $output .= '<table class="crm-table">
                    <thead>
                        <tr>
                            <th>ID Tiers</th>
                            <th>Company</th>
                            <th>Nom</th>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Adresse</th>
                            <th>CP et ville</th>
                            <th>Email</th>
                            <th>ID Commercial</th>
                            <th>Date de Création</th>
                            <th>Date de Modification</th>
                        </tr>
                    </thead>
                    <tbody>';

    foreach ($clients as $client) {
        $client_id = $client['id'] ?? '';
        $company = $client['company'] ? 'Oui' : 'Non';
        $name = $client['company'] ? $client['name'] : $client['title'];
        $last_name = $client['last_name'] ?? '';
        $first_name = $client['first_name'] ?? '';
        $street = $client['street'] ?? '';
        $post_code = $client['post_code'] ?? '';
        $city = $client['city'] ?? '';
        $country = $client['country'] ?? '';
        $email = $client['email'] ? explode(',', $client['email'])[0] : '';
        $tax_no = $client['tax_no'] ?? '';

        // Convertir les dates au format désir
        $creation_date = !empty($client['created_at']) ? (new DateTime($client['created_at']))->format('d-m-Y H:i:s') : '';
        $modification_date = !empty($client['updated_at']) ? (new DateTime($client['updated_at']))->format('d-m-Y H:i:s') : '';

        $output .= '<tr>
                        <td>' . esc_html($client_id) . '</td>
                        <td>' . esc_html($company) . '</td>
                        <td>' . esc_html($name) . '</td>
                        <td>' . esc_html($last_name) . '</td>
                        <td>' . esc_html($first_name) . '</td>
                        <td>' . esc_html($street) . '</td>
                        <td>' . esc_html($post_code . ' ' . $city . ' (' . $country . ')') . '</td>
                        <td>' . esc_html($email) . '</td>
                        <td>' . esc_html($tax_no) . '</td>
                        <td>' . esc_html($creation_date) . '</td>
                        <td>' . esc_html($modification_date) . '</td>
                    </tr>';
    }

    $output .= '</tbody></table>';

    $output .= '<div class="pagination">';
    if ($current_page > 1) {
        $prev_page_url = add_query_arg('tiers_page', $current_page - 1);
        $output .= '<a href="' . esc_url($prev_page_url) . '">&laquo; Prcdent</a>';
    }
    if ($total_clients === $per_page) {
        $next_page_url = add_query_arg('tiers_page', $current_page + 1);
        $output .= '<a href="' . esc_url($next_page_url) . '">Suivant &raquo;</a>';
    }
    $output .= '</div>';

    return $output;
}

add_shortcode('tiers', 'display_tiers_accounts');
