<?php
/*
Plugin Name: Synexta CRM Core Plugin
Description: Gestion centralisée des dépenses, factures, utilisateurs et événements. Ce plugin CRM tout-en-un permet de suivre vos transactions, organiser vos événements, gérer vos contacts et collaborateurs, et conserver un historique complet des activités. Conçu pour optimiser la gestion de votre entreprise directement depuis WordPress.  
Last Updated: 13 mai 2025 
Version: 1.8
Author URI: https://synexta.com/
Plugin URI: https://synexta.com/

*/

// Chargement des fichiers de configuration et modules
$includes = [
    'configuration/synexta-crm-config-page.php',
    'configuration/synexta-crm-core-logs-page.php',
    'configuration/synexta-crm-users-config-page.php',
    'configuration/authorisation.php',
    'configuration/security.php',
    'factures/vosfactures-cpt-main.php',
    'globalshortcodes.php',
    'depenses/depenses-cpt-main.php',
    'events/events-cpt-main.php',
    'accounts/accounts-main.php',
];

foreach ($includes as $file) {
    require_once plugin_dir_path(__FILE__) . $file;
}
if (!class_exists('Puc_v4_Factory')) {
    require plugin_dir_path(__FILE__) . 'includes/plugin-update-checker/plugin-update-checker.php';
}
$updateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://github.com/ASMASHR/wp-plugin-crm-core/main/update-details.json',
    __FILE__,
    'synexta-crm-core'
);
// Enqueue scripts et styles
add_action('wp_enqueue_scripts', 'gestioncrm_enqueue_scripts');
function gestioncrm_enqueue_scripts() {
    wp_enqueue_script('synexta-global-js', plugin_dir_url(__FILE__) . 'global.js', [], '1.0', true);
    wp_enqueue_style('synexta-global-css', plugin_dir_url(__FILE__) . 'global.css', [], '1.0');
}

// Hook d'activation du plugin
register_activation_hook(__FILE__, 'crm_core_activation_hook');
function crm_core_activation_hook() {
    crm_create_tag_table('crm_users_tags');
    crm_create_tag_table('crm_event_tags');
}

// Fonction générique de création de table (évite la duplication)
function crm_create_tag_table($table_suffix) {
    global $wpdb;
    $table_name = $wpdb->prefix . $table_suffix;
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id INT NOT NULL AUTO_INCREMENT,
        tag_name VARCHAR(255) NOT NULL UNIQUE,
        tag_style TEXT NULL,
        status TINYINT(1) NOT NULL DEFAULT 1,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}
